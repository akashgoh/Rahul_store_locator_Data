# todo:rerun days remaining : (freq - ((since_first%freq))
# last_rerun_date = (since_first - (since_first%freq))    todo : if last_build between today and last_rerun_date

# todo : sheet name '&' with  'and'
# todo : get total tickets as full status url of tower not proper

import pickle
import requests as rr
import json
import html2text
from datetime import datetime, timedelta
import os.path
import pygsheets
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from selenium import webdriver
from selenium.webdriver.firefox.options import Options
import pandas as pd
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from time import sleep

pd.set_option('display.max_colwidth', -1)

# If modifying these scopes, delete the file token.pickle.
SCOPES = ['https://www.googleapis.com/auth/spreadsheets.readonly']

# The ID and range of a sample spreadsheet.
SAMPLE_SPREADSHEET_ID = '1duKkSGzudGv15i2hMI325aXgvaEfOGgqJql2GAEeuLY'
SAMPLE_RANGE_NAME = 'Xbyte Scrapes!A1:AL500'
date_format = "%Y-%m-%d"
today_date = str(datetime.now().date())


def send_mail(email_ids, mail_content, cc_ids, bcc_ids, mail_subject):
    import smtplib
    from email.mime.multipart import MIMEMultipart
    from email.mime.text import MIMEText


    from_email_id = "alerts@xbyte.io"
    # from_email_id = "rahul.sardhara.xbyte@gmail.com"
    # from_email_password = "rahul9265"
    from_email_password = "xbyte123"

    try:
        msg = MIMEMultipart()
        msg['From'] = from_email_id
        msg['To'] = ",".join(email_ids)
        msg['CC'] = ",".join(cc_ids)
        msg['bcc'] = ",".join(bcc_ids)
        msg['Subject'] = mail_subject
        msg.attach(MIMEText(mail_content, 'html'))
        s = smtplib.SMTP("mail.xbyte.io", 587)
        # s = smtplib.SMTP('smtp.gmail.com', 587)

        s.ehlo()
        s.starttls()
        email_ids.extend(cc_ids)
        email_ids.extend(bcc_ids)
        s.login(from_email_id, from_email_password)
        text = msg.as_string()
        s.sendmail(from_email_id, email_ids, text)
        print("Mail Sent ...")
        s.quit()
    except Exception as e:
        print(e)


def gen_mail_string(mail_string):
    mail_content = list()
    mail_content.append("<html>")
    mail_content.append("<head>")
    mail_content.append("<style>")
    mail_content.append("table,th,td {border : 2px solid black;border-collapse: collapse;padding: 10px;}")
    mail_content.append("</style>")
    mail_content.append("</head>")
    mail_content.append("<body>")
    mail_content.append(mail_string)
    mail_content.append('</body></html>')
    return ''.join(mail_content)


def get_cookies():
    # set browser for selenium
    browser = webdriver.FirefoxProfile()
    options = Options()
    # options.add_argument('--headless')
    driver = webdriver.Firefox(firefox_profile=browser, options=options)
    try:
        # login and get cookie
        url_2 = "http://skynet.aggdata.com/"
        driver.get(url_2)
        sleep(5)
        email = driver.find_element_by_xpath('//input[@type="email"]')
        sleep(1)
        email.send_keys('hiralt')
        sleep(1)
        email.send_keys(Keys.ENTER)

        # try:
        #     nxt_btn = driver.find_element_by_xpath('//span[contains(text(),"Next")]')
        #     # nxt_btn = driver.find_element_by_xpath('//*[@id="identifierNext"]//span/span|//*[@id="identifierNext"]//div/button/span')
        # except:
        #     nxt_btn = driver.find_element_by_xpath('//span[contains(text(),"Next")]')
        # nxt_btn.click()
        sleep(2)
        res = driver.page_source
        resb = bytes(res, encoding='utf-8')
        password = driver.find_element_by_xpath('//input[@type="password"]')
        sleep(1)
        password.send_keys('trivedih')
        # nxt_btn = driver.find_element_by_xpath('//*[@id="passwordNext"]//span/span')
        sleep(1)
        password.send_keys(Keys.ENTER)
        # nxt_btn.click()
        sleep(6)
        # agg_url = "https://skynet.aggdata.com/node/api/all/job?buildable=false&showRejectedBuilds=false&Owner=match=%2Fhiral.trivedi%40xbyte%2Fi&offset=0&limit=100"
        agg_url = "https://tower.aggdata.com/node/api/all/job?owner=match=hiral.trivedi@xbyte.io&buildable=false&offset=0&limit=50&sort=-timestamp"
        driver.get(agg_url)
        sleep(5)
        all_cookies = driver.get_cookies()

        # generate cookie
        cookies = list()
        for ck in all_cookies:
            if 'screenResolution' == (ck.get('name')):
                continue
            s = f"{ck.get('name')}={ck.get('value')}"
            cookies.append(s)
        cookies = ';'.join(cookies)
        driver.quit()
        return cookies
    except Exception as e:
        print('error while getting cookie', 'e')
        driver.quit()
        return ''


def check_status(text):
    r_status = 'broken'
    if text not in delivered_list:
        r_status = 'new'
    if text in rerun_list:
        r_status = 'rerun'
    return r_status


def check_new_running(text):
    return 'new' if text in new_list else text


def check_rerun(text):
    return 'rerun' if text in rerun_list else text


def check_new(text):
    return 'broken' if text in delivered_list else 'new'


def check_status_status_df(text):
    r_status = 'delivered'
    if text not in delivered_list:
        r_status = 'new'
    if text in rerun_list:
        r_status = 'rerun'
    if text in new_list:
        r_status = 'new_running'
    if text in broken_list:
        r_status = 'broken'
    return r_status


# Connection to Google sheet and Get Data from it and generate data-frame
gc = pygsheets.authorize(service_file='light-return-263707-2b6996c26436.json')
gsh_ag = gc.open('Xbyte Priority')
worksheet_rerun = gsh_ag.worksheet_by_title("Rerun sheet")
worksheet_scrapes = gsh_ag.worksheet_by_title("Xbyte Scrapes")
g_sheet_df = worksheet_scrapes.get_as_df()


g_sheet_df['Frequency'] = g_sheet_df['Frequency'].replace(r'^\s*$', 0, regex=True)
g_sheet_df['Frequency'].fillna(0,inplace=True)
g_sheet_df['Days Since Last Delivery'] = g_sheet_df['Days Since Last Delivery'].replace(r'^\s*$', 0, regex=True)
g_sheet_df['Days Since Last Delivery'].fillna(0,inplace=True)

# Generate state wise list
new_list = g_sheet_df[g_sheet_df['First Build (Delivery) Date'].isna()]['List Name'].to_list()
delivered_list = g_sheet_df[~g_sheet_df['First Build (Delivery) Date'].isna()]['List Name'].to_list()
a = g_sheet_df['Days Since Last Delivery'].astype(str)
b= g_sheet_df['Frequency'].astype(str)
rerun_list = g_sheet_df[(a>b)]['List Name'].to_list()
print(rerun_list)
# Generate rerun related details and populate in  worksheet of google sheet

rerun_df = g_sheet_df[(a>b)]
rerun_df['Days Since Rerun Date'] = rerun_df['Days Since Last Delivery'] - rerun_df['Frequency']
rerun_df['Days Since Rerun Date'] = rerun_df['Days Since Rerun Date'].dropna().astype('int')
extra_for_rerun = ['Requestor', 'Priority', 'Type of Request', 'QA Assigned', 'DUE DATE', 'ETA',
                   'QA Assigned.1', 'Notes', 'Important Announcements',
                   'Count Ahead Briefing', 'Xbyte Notes/Concerns', 'Assigned Date', 'Days Since Assigned',
                   'Start Date', 'X-Byte ETA',
                   'Back & Forth Count', 'First Build (Delivery) Date', 'X-Byte Re Run Date', 'Approval Date',
                   'Waiting from AggData']

re_run_headers = [x for x in list(rerun_df.columns) if x not in extra_for_rerun]
rerun_df.fillna('',inplace=True)
rerun_df = rerun_df[re_run_headers]

worksheet_rerun.clear()
worksheet_rerun.set_dataframe(rerun_df, (1, 1))
cell_list = worksheet_rerun.range('A1:R1')
for cell in cell_list[0]:
    cell.set_text_format('bold',True)

rerun_mail_df = rerun_df.sort_values(by=['Developer Name'],ascending=False)[['List Name','Developer Name','Days Since Rerun Date']]

developer_mail_ids = ['vikram.chauhan.xbyte@gmail.com', 'rahul.sardhara.xbyte@gmail.com',  'vipul.patel.xbyte@gmail.com', 'anil.dalsaniya.xbyte@gmail.com',  'bhagyashree.rojivadiya.xbyte@gmail.com', 'deep.bhojani.xbyte@gmail.com', 'drashti.gohil.xbyte@gmail.com', 'geet.vasant.xbyte@gmail.com', 'jay.a.panchal.xbyte@gmail.com', 'maulik.kotadiya.xbyte@gmail.com', 'jay.panchal.xbyte@gmail.com', 'dhruv.modi.xbyte@gmail.com', 'ghanshyam.vachhani.xbyte@gmail.com', 'psingh.xbyte@gmail.com', 'khyati.xbyte@gmail.com']

# rerun_mail_df_html = rerun_mail_df.to_html(index=False, na_rep='', justify='center', border=1)

mail_string = '<p>Hello All,</p><p>Please find below list of agg store locator rerun site list.Please work on it.</p>'
mail_string += f'<h3>Number of rerun sites: {len(rerun_list)}</h3>'
mail_string += rerun_mail_df.to_html(index=False, na_rep='', justify='center', border=1)

rerun_cnt_df = rerun_mail_df.groupby('Developer Name').size().reset_index()
rerun_cnt_df.columns = ['Developer Name', 'Count']
mail_string += "<h3>Developer wise count</h3>"
mail_string += rerun_cnt_df.to_html(index=False, na_rep='', justify='center', border=1)

mail_content = gen_mail_string(mail_string)
with open('aggtower_rerun_mail.html','w') as f:
    f.write(mail_content)

email_ids = developer_mail_ids
# email_ids = ['agam.doshi.xbyte@gmail.com']
# cc_ids = ['agam.doshi.xbyte@gmail.com']
cc_ids = [ 'foram.patel.xbyte@gmail.com', 'hiral.trivedi.xbyte@gmail.com',
          'vikram.chauhan.xbyte@gmail.com','rahul.sardhara.xbyte@gmail.com']
bcc_ids = list()
mail_subject = f"Agg tower Rerun Report {today_date}"
print(mail_subject)
# :::::::::::::::::::::::: agg tower re run report :::::::::::::::::::::::::::::::::
# send_mail(email_ids, mail_content, cc_ids, bcc_ids, mail_subject)

# get cookie of agg tower
agg_cookies = get_cookies()
# agg_cookies= "JSESSIONID.fd400690=node01qjtq8zgzraot7xi9p1eh34n139528.node0;sails.sid=s%3AFDwTdxv4sfKldu55QKPKen_PewcAazhf.rVXOuSkixxmce8uxiil59Fj3qOWgS9Y0W3H4RsbV6uo"
print(agg_cookies)

hdr = {
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
    "Accept-Encoding": "gzip, deflate, br",
    "Accept-Language": "en-US,en;q=0.9",
    "Connection": "keep-alive",
    "Cookie": agg_cookies,
    "DNT": "1",
    "Host": "skynet.aggdata.com",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "none",
    "Upgrade-Insecure-Requests": "1",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36"}

url = "https://skynet.aggdata.com/node/api/all/job?buildable=false&showRejectedBuilds=false&Owner=match=%2Fhiral.trivedi%40xbyte%2Fi&offset=0&limit=100"
r1 = rr.get(url, headers=hdr)

j_data = json.loads(r1.text)
if j_data['items']:
    final_report = list()
    for item in j_data['items']:
        try:
            s_name = item['name']
            s_buildId = item['buildId']

            # get latest comment data of ticket
            r_url = f"https://skynet.aggdata.com/node/api/job/{s_name}/builds?changes=true&hideRejected=false&parent={s_buildId}&sort=&offset=0&limit=1"
            r2 = rr.get(r_url, headers=hdr)
            com_j_data = json.loads(r2.text)
            for com_item in com_j_data.get('items'):
                try:
                    item["last_comment_date"] = (com_item.get('timestamp', '').split('T')[0])
                    item["last_comment_by"] = com_item.get('userName')
                    item["last_comment_text"] = (com_item.get('comment', ' '))
                    if item["last_comment_text"]:
                        item["last_comment_text"] = (html2text.html2text(com_item.get('comment', ''))).replace('\n',
                                                                                                               '')
                except Exception as e:
                    print(e)
                # remove link from comment
                # cmnt_list = list()
                # for last_cmt_txt in item["last_comment_text"].split():
                #     if not last_cmt_txt.startswith('http'):
                #         cmnt_list.append(last_cmt_txt)
                # item["last_comment_text"] = ' '.join(cmnt_list)
                break

            item['ticket_created_date'] = (item.get('timestamp', '').split('T')[0])
            d1 = datetime.strptime(item['ticket_created_date'], date_format)
            item['total_number_of_days'] = (datetime.now() - d1).days

            # Get back and forth count
            item['back_and_forth_cnt'] = 0
            back_forth_url = f"https://skynet.aggdata.com/node/api/job/{s_name}/builds?changes=true&hideRejected=false&offset=0&limit=300"
            r3 = rr.get(back_forth_url, headers=hdr)
            back_and_forth_cnt = 0
            back_data = json.loads(r3.text)
            r_items = back_data['items']
            for r_item in r_items:
                if r_item['owner'] == 'hiral.trivedi@xbyte.io' and r_item['result'] == 'Imported' \
                        and r_item['status'] == 'Broken' and r_item['csv'] != '':
                    back_and_forth_cnt += 1
            item['back_and_forth_cnt'] = back_and_forth_cnt
            final_report.append(item)
        except Exception as e:
            print(e)

    tower_broken_df = pd.DataFrame(final_report)
    tower_broken_df = tower_broken_df[['name', 'priority', 'status', 'last_comment_by', 'last_comment_date', 'last_comment_text',
             'ticket_created_date', 'total_number_of_days', 'back_and_forth_cnt']]
    tower_broken_df['status'] = tower_broken_df['name'].apply(lambda x : check_status(x))
    tower_broken_df['status'] = tower_broken_df['status'].str.lower()
    broken_list = tower_broken_df[tower_broken_df['status'] == 'broken']['name'].to_list()
    new_list.extend((tower_broken_df[tower_broken_df['status'] == 'new']['name'].to_list()))

    # Get priority information and generate stat
    priority_df = tower_broken_df.groupby('priority').size().reset_index()
    priority_df.columns = ['Priority', 'Count']
    priority_html = priority_df.to_html(index=False, na_rep='', justify='center', border=1)

    # Modify dataframe columns
    # titled_columns = [col_name.replace('_', ' ').title() for col_name in (list(tower_broken_df.columns))]
    # tower_broken_df.columns = [titled_columns]

    tower_new_df = tower_broken_df[tower_broken_df['status'] == 'new']

    tower_rerun_df = tower_broken_df[tower_broken_df['status'] == 'rerun']

    tower_broken_broken_df = tower_broken_df[tower_broken_df['status'] == 'broken']
    tower_broken_broken_df_html = "there is broken"


else:
    # For no received broken sites
    tower_broken_broken_df_html = ""
    priority_html = ""
    broken_list = list()


# Get total status wise data
new_list = set(new_list)

other_list = (set(delivered_list) - set(broken_list) - set(new_list) - set(rerun_list))

status_df = pd.DataFrame(columns=['Name', 'Status'])
for list_name in new_list:
    status_df = status_df.append({'Name': list_name, 'Status': 'new'}, ignore_index=True)
for list_name in rerun_list:
    status_df = status_df.append({'Name': list_name, 'Status': 'rerun'}, ignore_index=True)
for list_name in broken_list:
    status_df = status_df.append({'Name': list_name, 'Status': 'broken'}, ignore_index=True)
for list_name in other_list:
    status_df = status_df.append({'Name': list_name, 'Status': 'other'}, ignore_index=True)

status_df_mail = status_df.groupby('Status').size().reset_index()
status_df_mail.columns = ['Status', 'Count']
status_df_mail_html = status_df_mail.to_html(index=False, na_rep='', justify='center', border=1)
status_df_html = status_df.to_html(index=False, na_rep='', justify='center', border=1)

# populate internal spreadsheet

xbyte_internal_sh = gc.open_by_key('1WuCniaa8TQRffZHwfS2zURyT02aJAX3-laXI4AMGkc0')
xbyte_internal_state_sheet = xbyte_internal_sh.worksheet('id', 567656918)
xbyte_internal_state_sheet.set_dataframe(status_df,(1,1))
cell_list = xbyte_internal_state_sheet.range('A1:C1')
for cell in cell_list[0]:
    cell.set_text_format('bold',True)


num_rerun_sites = len(rerun_list)
if num_rerun_sites:
    rerun_list = '<br> '.join(rerun_list.copy())
    rerun_html = f"<table><tr><th>List Of Rerun Sites</th></tr><tr><td>{rerun_list}</td></tr></table><br>"

mail_string = '<p>Hello Sir,</p><p>Please find below report of agg store locator.</p>'
mail_string += "<h2>Status Wise Stat</h2>"
mail_string += status_df_mail_html
mail_string += "<p><a href='https://docs.google.com/spreadsheets/d/1WuCniaa8TQRffZHwfS2zURyT02aJAX3-laXI4AMGkc0/edit#gid=567656918'>stat_wise_sheet</a></p>"

if not tower_broken_broken_df_html:
    tower_broken_df_html = f"<h3>No Broken Sites on Agg Tower.</h3>"
    mail_string += '<br><h2>Agg Tower Broken List</h2><br>'+tower_broken_df_html
else:
    if not tower_new_df.empty:
        mail_string += '<br><h2>Agg Tower New List</h2><br>'
        mail_string += tower_new_df.to_html(index=False, na_rep='', justify='center', border=1)
    if not tower_rerun_df.empty:
        mail_string += '<br><h2>Agg Tower Rerun List</h2><br>'
        mail_string += tower_rerun_df.to_html(index=False, na_rep='', justify='center', border=1)
    if not tower_broken_broken_df.empty:
        mail_string += '<br><h2>Agg Tower Broken List</h2><br>'
        mail_string += tower_broken_broken_df.to_html(index=False, na_rep='', justify='center', border=1)

# mail_string += status_df_html

if priority_html:
    mail_string += ("<div style='width:100%; float:left'> <h2>Priority Stats</h2>")
    mail_string += (priority_html)
    mail_string += ('</div>')

if num_rerun_sites:
    mail_string += (f'<h2>Rerun Feed</h2><h2>Number of rerun site : {num_rerun_sites}</h2>')
    mail_string += rerun_mail_df.to_html(index=False, na_rep='', justify='center', border=1)


mail_content = gen_mail_string(mail_string)
try:
    with open('aggtower_mail.html','w') as f:
        f.write(mail_content)
except:
    pass
email_ids = ['alpesh.khunt.xbyte@gmail.com']
# email_ids = ['agam.doshi.xbyte@gmail.com']
# cc_ids = ['agam.doshi.xbyte@gmail.com']
cc_ids = ['rahul.sardhara.xbyte@gmail.com', 'foram.patel.xbyte@gmail.com', 'hiral.trivedi.xbyte@gmail.com',
          'vikram.chauhan.xbyte@gmail.com', 'victor.douglas.xbyte@gmail.com']
bcc_ids = list()
mail_subject = f"Agg tower Report {today_date}"
print(mail_subject)
send_mail(email_ids, mail_content, cc_ids, bcc_ids, mail_subject)





