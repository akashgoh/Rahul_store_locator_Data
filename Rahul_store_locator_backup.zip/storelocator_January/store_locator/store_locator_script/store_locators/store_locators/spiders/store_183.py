# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import random
import re


import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime


class Store183Spider(scrapy.Spider):
    name = 'store_183'
    allowed_domains = []


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]


    def start_requests(self):
        self.f1.set_details(self.list_id,self.run_date)
        if self.f1.search_by != 'link':
            search_terms = self.f1.get_search_term(self.f1.search_by)
            print(search_terms)
        # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)
            search_terms = ''
            for search_term in (search_terms):
                source_url = link = 'https://www.flatbreadcompany.com/locations/'
                file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(search_term) + '_' + str(self.run_date) + '.html'
                if os.path.exists(file_path):
                    link = 'file://' + file_path.replace('\\','/')
                yield scrapy.FormRequest(url=str(link), callback=self.data, meta={'source_url': source_url,'search_term': search_term,'file_path':file_path,'proxy_type': self.proxy_type})
        else:
            yield scrapy.Request(url='https://www.flatbreadcompany.com/locations/', callback=self.data, meta={'proxy_type': self.proxy_type})


    def data(self, response):
        divs = response.xpath('//div[@class="location col-sm-6 col-md-4 align_center"]/a/@href').extract()
        for div in divs:
            yield scrapy.Request(url=div, callback=self.parse_data, meta={'proxy_type': self.proxy_type})


    def parse_data(self, response):
        try:store_name = response.xpath('//div[@class="title-wrapper"]/div/text()').extract_first().strip()
        except:store_name = ''

        text = response.xpath('//span[@class="media-body"]/span/text()').getall()

        try:address1 = text[0].strip()
        except:address1 = ''

        try:city = text[1].split(',')[0].strip()
        except:city = ''

        try:zip_code = text[1].split(',')[-1].split(' ')[-1].strip()
        except:zip_code = ''

        try:state = text[1].split(',')[-1].split(' ')[1].strip()
        except:state = ''

        try:phone_number = response.xpath('//p[@class="res-number"]/a/text()').extract_first().strip()
        except:phone_number = ''

        try:email = response.xpath('//a[contains(@href,"@")]/@href').get().replace('mailto:','').strip()
        except:email = ''

        try:
            Hours = []
            hour_list = response.xpath('//ul[@class="res-date-time"]/li')
            for hl in hour_list:
                day = hl.xpath('./span[@class="day"]/text()').get().strip()
                hour = hl.xpath('./span[@class="time"]/text()').get().strip()
                hours = day + '->' + hour
                Hours.append(hours)
        except Exception as e:
            print(e)

        item = StoreLocatorsItem()
        item['search_term'] = 'link'
        item['store_name']= 'Flatbread - '+store_name
        item['address'] = address1
        item['store_hours'] = ''
        item['city'] = city
        item['state'] = state
        item['country'] = 'USA'
        item['country_code'] = 'US'
        item['zip_code'] = zip_code
        item['phone_number'] = phone_number
        item['email_address'] = email
        item['store_hours'] = '|'.join(Hours)
        item['coming_soon'] = 0
        item['source_url'] = response.url
        yield item


    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_183 -a list_id=183'''.split())
