import re

import scrapy,os,logging,hashlib
import requests,json
import pymysql
from store_locators.db_config import *
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime
from scrapy.cmdline import execute

class Store17Spider(scrapy.Spider):
    name = 'store_17'
    allowed_domains = []
    not_export_data = True
    # f1 = Func()

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):

        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            source_url = link = 'http://www.alumacraft.com/Alumacraft-Boat-Dealer-Locator.php?dealer_locator=1'
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
                run_date) + '.html'

            self.f1.set_details(self.list_id,run_date)
            search_terms = self.f1.get_search_term(self.f1.search_by)
            if self.f1.search_by != 'link':
                connection = pymysql.connect(db_host, db_user, db_password, db_name)

                cursor = connection.cursor()
                query=('select * from '+db_name+'.'+db_zip_table+'')
                cursor.execute(query)
                results = cursor.fetchall()
                for row in results:
                    zip = row[0]
                    country=row[8].strip()
                    country_dict = {'US':226,'CA':38,'AR':10,'BO':26,'CL':43,'CO':47,'FR':73,'LT':123,'EL':150,'RU':177,'SE':205}
                    c_val = country_dict.get(country)
                    if c_val:
                        link=f'http://www.alumacraft.com/Alumacraft-Boat-Dealer-Locator.php?number_of_results=3&' \
                            f'client_id=1098&zip={str(zip)}&country={c_val}'
                        yield scrapy.FormRequest(url=link, callback=self.firstlevel,
                                                 meta={'source_url': source_url,
                                                   'file_path': file_path,'country':country})
                    # break
        except Exception as e:
            logging.log(logging.ERROR, e)

    def firstlevel(self, response):
        if 'No Dealer Found' in str(response.body):
            print('No data')
        else:
            divs=response.xpath('//p[@class="gold"]')
            lat=re.findall('name="end" value="(.*?)"',str(response.body))
            for div,lat in zip(divs,lat):

                source_url = response.meta['source_url']
                search_term = response.meta.get('search_term', '')

                item = StoreLocatorsItem()
                item['search_term'] = 'link'
                item['store_name']= div.xpath('.//text()[1]').get(default='')
                try:item['address']=div.xpath('.//br/following-sibling::text()[1]').get(default='')
                except:item['address']=''
                city=div.xpath('.//br/following-sibling::text()[2]').get()
                if ',' in city:
                    try:item['city'] =div.xpath('.//br/following-sibling::text()[2]').get(default='').split(',')[0]
                    except:item['city']=''
                    item['source_url']=response.url
                    try:item['state'] = div.xpath('.//br/following-sibling::text()[2]').get(default='').split(',')[-1].split(' ')[-2]
                    except:item['state']=''
                    try:item['zip_code'] =div.xpath('.//br/following-sibling::text()[2]').get(default='').split(',')[-1].split(' ')[-1]
                    except:item['zip_code']=''
                    try:item['phone_number'] =div.xpath('.//br/following-sibling::text()[3]').get(default='')
                    except:item['phone_number']=''
                else:
                    try:item['city'] =div.xpath('.//br/following-sibling::text()[3]').get(default='').split(',')[0]
                    except:item['city']=''
                    item['source_url']=response.url
                    try:item['state'] = div.xpath('.//br/following-sibling::text()[3]').get(default='').split(',')[-1].split(' ')[-2]
                    except:item['state']=''
                    try:item['zip_code'] =div.xpath('.//br/following-sibling::text()[3]').get(default='').split(',')[-1].split(' ')[-1]
                    except:item['zip_code']=''
                    try:item['phone_number'] =div.xpath('.//br/following-sibling::text()[4]').get(default='')
                    except:item['phone_number']=''
                item['store_type'] = ''
                item['website_address']=div.xpath('.//a//text()').get(default='')
                item['coming_soon'] = 0
                item['store_number'] =''
                item['country_code'] = response.meta['country'].replace('\r','').strip()
                try:country=self.f1.get_country_from_code(self.f1.country_dict,''+item['country_code'])
                except Exception as e:
                    print(e)
                    country=''
                item['country'] = country.title()
                item['latitude']=lat.split(',')[0].strip()
                item['longitude']=lat.split(',')[1].strip()
                item['email_address'] = ''
                item['services'] = ''
                item['number_of_store'] = 200

                yield item

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_17 -a list_id=17'''.split())
