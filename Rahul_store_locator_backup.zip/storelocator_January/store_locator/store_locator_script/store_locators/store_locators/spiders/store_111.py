# -*- coding: utf-8 -*-
import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime
import re
import html2text
run_date = str(datetime.datetime.today()).split()[0]

class YogasixCrawlerSpider(scrapy.Spider):
    name = 'store_111'
    allowed_domains = []
    f1 = Func()

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            source_url = link = 'https://members.yogasix.com/api/brands/yogasix/locations?open_status=external&geoip=203.114.73.121'
            headers = {'Host': 'members.yogasix.com','User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept': 'application/json, text/javascript, */*; q=0.01','Accept-Language': 'en-GB,en;q=0.5','Accept-Encoding': 'gzip, deflate, br','Origin': 'https://www.yogasix.com','Referer': 'https://www.yogasix.com/location-search'}
            self.f1.set_details(self.list_id, run_date)
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(run_date) + '.html'
            if os.path.exists(file_path):
                link = 'file://' + file_path.replace('\\', '/')
            yield scrapy.FormRequest(url=str(source_url), callback=self.get_store_list, meta={'source_url': source_url,'file_path': file_path, 'proxy_type': self.proxy_type})
        except Exception as e:
            print(e)

    def get_store_list(self,response):
        if not response.url.startswith('file://'):
            self.f1.page_save(response.meta['file_path'], response.body)
        source_url = response.meta.get('source_url', '')
        with open('yogasix.txt', 'r') as content_file:
            content = content_file.read()
        # items = content.split('-')

            df = json.loads(content)
            store_loop = df['locations']
            print(len(store_loop))
            for lp in store_loop:
                try:
                    store_number = lp['seq']
                except Exception as e:
                    store_number = ''

                try:
                    store_code = lp['clubready_id']
                except Exception as e:
                    store_code = ''

                try:
                    store_name = 'Yogasix - '+lp['name']
                except Exception as e:
                    store_name = ''

                try:
                    address = lp['address']
                except Exception as e:
                    address = ''

                try:
                    address_line_2 = lp['address2']
                except Exception as e:
                    address_line_2 = ''

                try:
                    city = lp['city']
                except Exception as e:
                    city = ''

                try:
                    state = lp['state']
                except Exception as e:
                    state = ''

                try:
                    zip_code = lp['zip']
                except Exception as e:
                    zip_code = ''

                try:
                    country = country_code = lp['country_code']
                except Exception as e:
                    country = ''
                try:
                    latitude = lp['lat']
                except Exception as e:
                    latitude= ''

                try:
                    longitude = lp['lng']
                except Exception as e:
                    longitude = ''

                try:
                    email_address = lp['email']
                except Exception as e:
                    email_address = ''

                try:
                    coming_soon = lp['coming_soon']
                    if coming_soon == False:
                        coming_soon = 0
                    else:
                        coming_soon = 1
                except Exception as e:
                    coming_soon = 0

                try:
                    phone_number = lp['phone']
                except Exception as e:
                    phone_number = ''

                try:
                    website_address = lp['site_url']
                    print(website_address)
                except Exception as e:
                    website_address = 'https://www.yogasix.com/location-search'

                if website_address != None:
                    res_s = requests.request("GET", website_address)
                    # res_s = requests.request(url=website_address,method='GET')
                    response_s = HtmlResponse(url=res_s.url, body=res_s.content)
                    # file_path = self.f1.html_data_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
                    #     run_date) + '_' + str(lp['site_url']).split('/')[-1].strip() + '.html'
                    # if not response.url.startswith('file://'):
                    #     self.f1.page_save(file_path, response_s.body)
                    hours = response_s.xpath('//span/@data-hours').extract_first(default='').strip()
                    store_hours = json.dumps(hours.replace('\n', '').replace('  ', ''))
                    if store_hours == '""':
                        store_hours = ''
                else:
                    website_address = 'http://www.yogasix.com'
                    store_hours = ''
                if website_address == 'http://www.yogasix.com':
                    website_address = 'https://www.yogasix.com/location-search'

                try:
                    item = StoreLocatorsItem()
                    item['store_number'] = store_number
                    item['store_name'] = store_name
                    item['store_code'] = store_code
                    item['address'] =address
                    item['address_line_2'] =address_line_2
                    item['city'] = city
                    item['state'] = state
                    item['zip_code'] = zip_code
                    item['country'] = country
                    item['country_code'] = country_code
                    item['email_address'] = email_address
                    item['latitude'] = latitude
                    item['longitude'] = longitude
                    item['coming_soon'] = coming_soon
                    item['phone_number'] = phone_number
                    item['store_hours'] = ''
                    item['website_address'] = website_address
                    yield item
                except Exception as e:
                    print('error in data extraction',e,lp)
                    logging.log(logging.ERROR, e)

# execute('''scrapy crawl store_111 -a list_id=111'''.split())#-s HTTPCACHE_ENABLED=True
# put manuall api
