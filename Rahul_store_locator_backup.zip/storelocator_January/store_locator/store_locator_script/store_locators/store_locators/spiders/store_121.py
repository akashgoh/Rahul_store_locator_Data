# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import random
import re


import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime

class Store121Spider(scrapy.Spider):
    name = 'store_121'
    allowed_domains = []


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()


    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            self.f1.set_details(self.list_id,run_date)
            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                print(search_terms)
            # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)
                search_terms = ''
                for search_term in (search_terms):
                    source_url = link = 'https://worldwrapps.com/locations'
                    file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(search_term) + '_' + str(run_date) + '.html'
                    if os.path.exists(file_path):
                        link = 'file://' + file_path.replace('\\','/')
                    yield scrapy.FormRequest(url=str(link), callback=self.get_store_list, meta={'source_url': source_url,'search_term': search_term,'file_path':file_path,'proxy_type': self.proxy_type})
            else:
                source_url = link = 'https://worldwrapps.com/locations'
                file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(run_date) + '.html'
                yield scrapy.FormRequest(url=str(link), callback=self.data,
                                         meta={'source_url': source_url,
                                               'file_path': file_path, 'proxy_type': self.proxy_type})
        except Exception as e:
            logging.log(logging.ERROR, e)


    def data(self, response):
        divs = response.xpath('//div[@class="place grid__6columns"]')
        for div in divs:
            try:store_name = div.xpath('./h3/text()').extract_first().strip()
            except Exception as e:print(e)

            try:
                address = ''.join(div.xpath('./p[@class="address"]/text()').extract())
                address = re.sub('\s+', ' ', re.sub('\r|\n|\t', ',', address))
            except Exception as e:
                print(e)

            check = False
            for j in ['Unit', 'STE', 'Ste', 'SUITE', 'Suite', 'suite', 'Suit', 'SUIT', 'suit', 'UNIT', 'unit', 'ste']:
                for aw in address.split():
                    if j == aw:
                        address1 = address.split(j)[0].strip().strip(',')
                        address_line_2 = j + ' ' + address.split(j)[-1].strip()
                        check = True
                        break
            if check == True:
                address_line_2 = address_line_2
                address = address1
            else:
                address_line_2 = ''
                address = address

            try:
                text = div.xpath('./p[@class="address"]/text()[3]').extract_first()
                city = text.split(',')[0]
                state = text.split(',')[-1].split(' ')[1]
                zip_code = text.split(',')[-1].split(' ')[-1]
            except Exception as e:
                print(e)

            try:phone_number = div.xpath('./p/span/text()').extract_first()
            except Exception as e:print(e)

            try:store_hours = div.xpath('./p[last()]/text()[1]').extract_first().strip()
            except Exception as e:print(e)

            text = response.text

            if store_name == 'CORTE MADERA':
                latitude = 37.927551
                longitude = -122.517974
            else:
                latitude = 37.389203
                longitude = -121.983687


            item = StoreLocatorsItem()
            item['search_term'] = 'link'
            item['store_name'] = store_name
            item['address'] = address
            item['address_line_2'] = address_line_2
            item['city'] = city
            item['state'] = state
            item['zip_code'] = zip_code
            item['phone_number'] = phone_number
            item['latitude'] = latitude
            item['longitude'] = longitude
            item['store_type'] = ''
            item['website_address'] = ''
            item['coming_soon'] = 0
            item['store_number'] = ''
            item['country_code'] = item['country'] = 'US'  # self.f1.country_dict.get(item['country'].lower())
            item['email_address'] = ''
            item['services'] = ''
            item['store_hours'] = store_hours
            item['additional_info'] = ''
            item['source_url'] = response.url
            yield item

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_121 -a list_id=121'''.split())