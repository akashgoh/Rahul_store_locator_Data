#-*- coding: utf-8 -*-
# pip install scrapy-html-storage
import re

import html2text
import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime


class store191Spider(scrapy.Spider):
    name = 'store_191'
    allowed_domains = []
    f1 = Func()

    def __init__(self, name=None, list_id="",proxy_type="",**kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type= list_id, proxy_type
        self.f1 = Func()

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            source_url = link = 'https://www.terminix.com/exterminators'
            self.f1.set_details(self.list_id, run_date)
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
                run_date) + '.html'
            if os.path.exists(file_path):
                link = 'file://' + file_path.replace('\\', '/')

            yield scrapy.FormRequest(url=str(link), callback=self.get_store,meta={'source_url': source_url,'file_path': file_path,'proxy_type': self.proxy_type})
        except Exception as e:
            print(e)

    def get_store(self,response):

        source_url = response.meta['source_url']
        file_path = response.meta['file_path']
        url = response.xpath('//*[@class="c-directory-list-content"]/li/a/@href').extract()
        # del url[0:3]
        for us in url:
            if len(us) < 3:
                u = 'https://www.terminix.com/exterminators/' + us
                yield scrapy.Request(url=str(u), callback=self.get_store2, dont_filter=True,meta={'source_url': source_url,'file_path': file_path,'proxy_type': self.proxy_type})

            else:
                q = 'https://www.terminix.com/exterminators/' + us
                yield scrapy.Request(url=str(q), callback=self.get_store_list, dont_filter=True,meta={'source_url': source_url, 'file_path': file_path, 'proxy_type': self.proxy_type})



    def get_store2(self, response):
        source_url = response.meta['source_url']
        file_path = response.meta['file_path']

        url = response.xpath('//*[@class="location-list-item c-directory-list-content-item"]/a/@href').extract()
        if url:
            for u in url:
                u = 'https://www.terminix.com/exterminators/' + u
                yield scrapy.Request(url=str(u), callback=self.get_store_list,
                                    meta={'source_url': source_url, 'file_path': file_path, 'proxy_type': self.proxy_type})


    def get_store_list(self,response):
        source_url = response.meta['source_url']
        file_path = response.meta['file_path']

        url = response.xpath('//*[@class="nearby-list"]/li/div/a/@href').extract()
        if url:
            yield scrapy.Request(url=str(url), callback=self.get_store_list)

        else:
            if not response.url.startswith('file://'):
                self.f1.page_save(response.meta['file_path'], response.body)
                source_url = response.meta.get('source_url', '')

            try:
                item = StoreLocatorsItem()
                item['store_name'] = ''.join(re.findall(r'<h3 class="NAP-locationName">(.*?)</h3><span',response.text)).replace('&amp;','')
                # print(store_name)
                fulladdress = ' '.join(response.xpath('//*[@itemprop="streetAddress"]//text()').extract())

                # addinfo = ''.join(response.xpath('//*[@class="basic-details__city"]/text()').extract())
                address_line_2 = ''
                # address = ''

                try:
                    check = False
                    address = fulladdress
                    for i in ['Unit', 'Suite', 'Ste']:
                        for aw in address.split():
                            if i == aw:
                                address1 = address.split(i)[0].strip(',')
                                address_line_2 = i + ' ' + address.split(i)[-1].strip()
                                check = True
                                break

                    if check == True:
                        address_line_2 = address_line_2
                        address = address1
                    else:
                        address_line_2 = ''
                        address = address
                except Exception as e:
                    print(e)


                item['address'] = address
                item['address_line_2'] = address_line_2.strip()

                item['city'] = ''.join(response.xpath('//*[@itemprop="addressLocality"]/text()').extract())
                item['state'] = ''.join(response.xpath('//*[@itemprop="addressRegion"]/text()').extract())

                item['zip_code'] = ''.join(response.xpath('//*[@itemprop="postalCode"]/text()').extract())
                item['phone_number'] = response.xpath('//*[@class="Phone Phone--mobile"]/text()').extract_first(default='')
                item['fax_number'] = ''
                item['email_address'] = ''
                item['latitude'] = re.findall(r'itemprop="latitude" content="(.*?)"><',response.text)[0]
                item['longitude'] = re.findall(r'itemprop="longitude" content="(.*?)"></sp',response.text)[0]
                item['store_type'] = ''
                item['website_address'] = source_url
                item['coming_soon'] = 0
                item['store_number'] = ''
                # if item['store_number'] == 8184:
                #     pass
                item['country'] = 'US'
                item['source_url'] = response.url
                item['state'] = ''.join(re.findall(r'temprop="addressRegion">(.*?)</span',response.text))
                item['country_code'] = 'US'
                # print(item['state'])
                # if item['country_code'] == 'US' and len(item['state']) > 2:
                #     item['state'] = self.f1.state_dict.get(item['state'].lower(), '')
                    # print('::,', item['state'])

                # h = html2text.HTML2Text()
                # h.ignore_links = True
                # h.ignore_emphasis = True
                # h.ignore_images = True
                # h.body_width = 0
                # h.ignore_links = True
                # h.ignore_emphasis = True

                attr = []
                for tr in response.xpath('//*[@class="c-location-hours-details"]/tbody/tr'):
                    key = ''.join(tr.xpath('./td/text()').extract()).strip()
                    value = ''.join(tr.xpath('./td[2]//text()').extract()).strip()
                    # print(key, ' : ', value)
                    if value:
                        attr.append(str(key) + ':' + str(value))

                store_hours = '|'.join(attr)
                item['store_hours'] = store_hours

                #//*[@class="NAP-servicesList"]/li/div/a/text()
                item['services'] = '|'.join(response.xpath('//*[@class="NAP-servicesList"]/li/div/a/text()').extract())
                add_info = dict()
                add_info['distance'] = ''
                add_info['thumb'] = ''
                add_info['description'] = ''
                item['additional_info'] = ''
                yield item
            except Exception as e:
                print(e)

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_191 -a list_id=191 -s HTTPCACHE_ENABLED=True'''.split())






# # -*- coding: utf-8 -*-
# # pip install scrapy-html-storage
# import re
#
# import html2text
# import scrapy,os,logging,hashlib
# import requests,json
# from scrapy.http import HtmlResponse
# from scrapy.cmdline import execute
# from store_locators.items import StoreLocatorsItem
# from store_locators.spiders.common_functions import Func
# import datetime
#
#
# class TerminixSpider(scrapy.Spider):
#     name = 'terminix'
#     allowed_domains = []
#     f1 = Func()
#
#     def __init__(self, name=None, list_id="",proxy_type="",**kwargs):
#         super().__init__(name, **kwargs)
#         self.list_id, self.proxy_type= list_id, proxy_type
#
#     def start_requests(self):
#         run_date = str(datetime.datetime.today()).split()[0]
#         try:
#             source_url = link = 'https://www.terminix.com'
#             self.f1.set_details(self.list_id, run_date)
#             file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
#                 run_date) + '.html'
#             if os.path.exists(file_path):
#                 link = 'file://' + file_path.replace('\\', '/')
#
#             yield scrapy.FormRequest(url=str(link), callback=self.get_store,meta={'source_url': source_url,'file_path': file_path,'proxy_type': self.proxy_type})
#         except Exception as e:
#             print(e)
#
#     def get_store(self,response):
#         source_url = response.meta['source_url']
#         file_path = response.meta['file_path']
#         url = response.xpath('//*[@class="col-xs-12"]/div/ul/li/a/@href').extract()
#         for u in url:
#             yield scrapy.Request(url=str(u), callback=self.get_store_list, meta={'source_url': source_url,'file_path': file_path,'proxy_type': self.proxy_type})
#
#
#     # def get_list(self,response):
#     #
#     #     for u in url:
#     #         u = 'https://locations.tgifridays.com' + u
#     #         yield scrapy.Request(url=str(u), callback=self.get_store_list, meta={'source_url': source_url,'file_path': file_path,'proxy_type': self.proxy_type})
#
#
#     def get_store_list(self,response):
#         source_url = response.meta['source_url']
#         file_path = response.meta['file_path']
#
#         url = response.xpath('//*[@class="nearby-list"]/li/div/a/@href').extract()
#         if url:
#             yield scrapy.Request(url=str(url), callback=self.get_store_list)
#
#         else:
#             if not response.url.startswith('file://'):
#                 self.f1.page_save(response.meta['file_path'], response.body)
#                 source_url = response.meta.get('source_url', '')
#
#             try:
#                 item = StoreLocatorsItem()
#                 item['store_name'] = ''.join(re.findall(r'<h3 class="NAP-locationName">(.*?)</h3><span',response.text)).replace('&amp;','')
#                 # print(store_name)
#                 item['address'] = response.xpath('//*[@itemprop="streetAddress"]/text()').extract_first(default='')
#
#                 addinfo = ''.join(response.xpath('//*[@class="basic-details__city"]/text()').extract())
#
#                 item['address_line_2'] = ''
#                 item['city'] = ''.join(response.xpath('//*[@itemprop="addressLocality"]/text()').extract())
#                 item['state'] = ''.join(response.xpath('//*[@itemprop="addressRegion"]/text()').extract())
#
#                 item['zip_code'] = ''.join(response.xpath('//*[@itemprop="postalCode"]/text()').extract())
#                 item['phone_number'] = response.xpath('//*[@class="Phone Phone--mobile"]/text()').extract_first(default='')
#                 item['fax_number'] = ''
#                 item['email_address'] = ''
#                 item['latitude'] = re.findall(r'itemprop="latitude" content="(.*?)"><',response.text)[0]
#                 item['longitude'] = re.findall(r'itemprop="longitude" content="(.*?)"></sp',response.text)[0]
#                 item['store_type'] = ''
#                 item['website_address'] = source_url
#                 item['coming_soon'] = 0
#                 item['store_number'] = ''
#                 # if item['store_number'] == 8184:
#                 #     pass
#                 item['country'] = 'US'
#                 item['source_url'] = response.url
#                 item['state'] = 'US'
#                 item['country_code'] = 'US'
#                 # print(item['state'])
#                 # if item['country_code'] == 'US' and len(item['state']) > 2:
#                 #     item['state'] = self.f1.state_dict.get(item['state'].lower(), '')
#                     # print('::,', item['state'])
#
#                 # h = html2text.HTML2Text()
#                 # h.ignore_links = True
#                 # h.ignore_emphasis = True
#                 # h.ignore_images = True
#                 # h.body_width = 0
#                 # h.ignore_links = True
#                 # h.ignore_emphasis = True
#
#                 attr = []
#                 for tr in response.xpath('//*[@class="c-location-hours-details"]/tbody/tr'):
#                     key = ''.join(tr.xpath('./td/text()').extract()).strip()
#                     value = ''.join(tr.xpath('./td[2]//text()').extract()).strip()
#                     # print(key, ' : ', value)
#                     if value:
#                         attr.append(str(key) + ':' + str(value))
#
#                 store_hours = '|'.join(attr)
#                 item['store_hours'] = store_hours
#
#                 add_info = dict()
#                 add_info['distance'] = ''
#                 add_info['thumb'] = ''
#                 add_info['description'] = ''
#                 item['additional_info'] = ''
#                 yield item
#             except Exception as e:
#                 print(e)
#
#     def response_html_path(self, request):
#         return request.meta['fpath']
#
# # execute('''scrapy crawl terminix -a list_id=191 -s HTTPCACHE_ENABLED=True'''.split())