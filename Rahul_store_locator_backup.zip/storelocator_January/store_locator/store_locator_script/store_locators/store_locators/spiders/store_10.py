import scrapy
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime
import re

class Agjieans(scrapy.Spider):
    name = 'store_10'
    start_urls = ['https://www.agjeans.com/locations.html']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        run_date = str(datetime.datetime.today()).split()[0]
        self.f1.set_details(self.list_id, run_date)

    def parse(self, response):
        try:
            n_a = response.xpath("//*/li[@id='store-info']/a/p/text()").extract()
            phone = response.xpath("//*/li[@id='store-info']/p[1]/text()").extract()
            time = response.xpath("//*/li[ @ id = 'store-info']/p[2]/text()").extract()

            for i in n_a:
                name = i.split('<br>')[0].split('\r')[0].strip()
                city = i.split('<br>')[0].split('\r')[-2].split(',')[0].strip()
                state = i.split('<br>')[0].split('\r')[-2].split(',')[1].strip().split(' ')[0]
                zip = i.split('<br>')[0].split('\r')[-2].split(',')[1].strip().split(' ')[1]
                Add = i.split('<br>')[0].split('\r')[1].strip()
                Add2 = i.split('<br>')[0].split('\r')[2].strip()

                # remove\t
                x = re.sub("\t", "", time[n_a.index(i)])
                # remove\n
                y = re.sub('\n', '', x)
                z = re.sub('\r', ' | ', y)
                print(i)
                print()
                print('-------')

                item = StoreLocatorsItem()
                url = response.url
                item['store_name'] = name
                item['phone_number'] = phone[n_a.index(i)]
                item['address'] = Add
                if i.split('<br>')[0].split('\r')[-2].strip() != i.split('<br>')[0].split('\r')[2].strip():
                    item['address_line_2'] = Add2
                else:
                    pass
                item['city'] = city
                item['zip_code'] = zip
                item['state'] = state
                item['source_url'] = url
                item['store_hours'] = z.strip(' | ')
                item['country'] = item['country_code'] = 'US'
                yield item

        except Exception as e:
            print('ERROR',e)

# from scrapy.cmdline import execute
# execute('scrapy crawl store_10 -a list_id=10 -s HTTPCACHE_ENABLED=True'.split())