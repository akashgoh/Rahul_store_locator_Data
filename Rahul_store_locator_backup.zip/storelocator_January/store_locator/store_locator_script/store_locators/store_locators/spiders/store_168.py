import hashlib
import re

import scrapy
import json
from store_locators.spiders.common_functions import Func
from store_locators.items import StoreLocatorsItem
import datetime
import html2text,os

class Store168Spider(scrapy.Spider):
    name = 'store_168'
    f1 = Func()
    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            source_url = link = 'https://torchystacos.com/locations/'

            self.f1.set_details(self.list_id, run_date)
            # file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(run_date) + '.html'
            # if os.path.exists(file_path):
            #     link = 'file://' + file_path.replace('\\', '/')

            yield scrapy.FormRequest(url=str(link), callback=self.get_store_links, meta={'source_url': source_url, 'proxy_type': self.proxy_type})#'file_path': file_path,

        except Exception as e:
            print(e)


    def get_store_links(self,response):

        # file_path = response.meta['file_path']
        links = response.xpath('//div[@class="phone-address"]//a/@href').extract()
        blocks = response.xpath('//div[@class="tile-4-to-1 locations-item"]')
        for blk in blocks:
            addr = blk.xpath('.//div[@class="phone-address"]//span[@itemprop="streetAddress"]/text()').get()
            city = blk.xpath('.//div[@class="phone-address"]//span[@itemprop="addressLocality"]/text()').get()
            state = blk.xpath('.//div[@class="phone-address"]//span[@itemprop="addressRegion"]/text()').get()
            zip = blk.xpath('.//div[@class="phone-address"]//span[@itemprop="postalCode"]/text()').get()
            phone = blk.xpath('.//div[@class="phone-address telephone"]//a/text()').get()
            link = blk.xpath('.//div[@class="phone-address"]//a/@href').get()
            # link = 'https://torchystacos.com/location/rogers/'
            yield scrapy.Request(link,self.InsideStore,meta={'ADDR':addr, 'CT':city, 'ST':state, 'ZP':zip, 'PH':phone, 'proxy_type': self.proxy_type})#'file_path':file_path,


    def InsideStore(self,response):

        # if not response.url.startswith('file://'):
        #     self.f1.page_save(response.meta['file_path'], response.body)

        try:
            try:
                store_name = 'Torchys - '+response.xpath('//h1[@class="h-black-bg"]/text()').get()
                if 'Coming Soon' in store_name:
                    store_name = store_name.replace('- Coming Soon','').strip()
                    coming_soon = 1
                else:
                    coming_soon = 0
                address = response.meta['ADDR']
                city = response.meta['CT']
                state = response.meta['ST']
                zip_code = response.meta['ZP']
                if response.meta['PH']:
                    phone_number = response.meta['PH']
                else:
                    phone_number = ''
                lat = response.xpath('//div[@id="ttMap"]/@data-lat').extract()
                if lat:
                    latitude = lat[0]
                long = response.xpath('//div[@id="ttMap"]/@data-lon').extract()
                if long:
                    longitude = long[0]
                store_number = int(hashlib.md5(store_name.encode('ascii', 'ignore')).hexdigest(), 16) % (10 ** 16)
            except Exception as e:
                print("Addr",e,response.url)

            try:
                additional_info = response.xpath('//div[@class="perks"]//div[@class="perks-wrapper"]/p/text()').extract()
                additional_info = '|'.join(additional_info)

                if coming_soon==0:
                    Hours = response.xpath('//div[@id="hours-menu"]//p//text()').extract()
                    Hours = '|'.join(Hours)
                else:
                    Hours = ''
            except Exception as e:
                print("Hr|Info",e,response.url)
        except Exception as e:
            print('DataExtraction', e, response.url)

        check = False
        for i in ['Unit', 'STE', 'Ste', 'Suite', 'Ste.']:
            for aw in address.split():
                if i == aw:
                    address1 = address.split(i)[0].strip(',')
                    address_line_2 = i + ' ' + address.split(i)[-1].strip()
                    check = True
                    break
        if check == True:
            address_line_2 = address_line_2
            address = address1
        else:
            address_line_2 = ''
            address = address

        if address.strip().endswith(','):
            address = address.strip()[0:-1]
        item = StoreLocatorsItem()

        # item['services'] = services
        item['address'] = address.strip()
        item['address_line_2'] = address_line_2
        item['city'] = city.strip()
        item['state'] = state.strip()
        item['zip_code'] = zip_code.strip()
        item['country'] = 'United States'
        item['country_code'] = 'US'
        item['store_name'] = store_name.strip()
        item['phone_number'] = phone_number.strip()
        item['latitude'] = latitude.strip()
        item['longitude'] = longitude.strip()
        item['store_type'] = ''
        item['coming_soon'] = coming_soon
        # item['store_number'] = store_number
        item['source_url'] = response.url
        item['additional_info'] = additional_info.strip()
        item['store_hours'] = Hours
        yield item


from scrapy.cmdline import execute
# execute('''scrapy crawl store_168 -a list_id=168 -a proxy_type='''.split())