# -*- coding: utf-8 -*-
import re
import pgeocode
import scrapy, os, logging, hashlib
import requests, json
from parsel import Selector
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from selenium import webdriver
from selenium.webdriver.firefox.options import Options
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime




class Store1Spider(scrapy.Spider):
    name = 'store_1'
    allowed_domains = []
    start_urls = ['http://10fitness.com//']
    # not_export_data = True

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()

    def parse(self, response):
        run_date = str(datetime.datetime.today()).split()[0]
        self.f1.set_details(self.list_id, run_date)
        storelink = response.xpath('//*[@class="nav et_disable_top_tier"]/li[1]//ul//a/@href').extract()
        for link in storelink:
            yield scrapy.FormRequest(url=link, callback=self.get_stor_data)

    def get_stor_data(self, response):
        try:
            address1 = response.xpath('//*[@class="et_pb_module et_pb_text et_pb_text_3  et_pb_text_align_left et_pb_bg_layout_light"]//p//text()|//*[@class="et_pb_module et_pb_text et_pb_text_4  et_pb_text_align_left et_pb_bg_layout_light"]//p/span//text()').extract_first().strip()
            address = address1.split(',')[0]
        except Exception as e:
            print(e)
        #
        try:
            address_detail = address1
            address_line_2 = ''
            for j in ['Unit', 'STE', 'Ste', 'SUITE', '#Suite', 'suite', 'Suit', 'Units', 'units', 'SUIT',
                      'suit', 'UNIT',
                      'unit', 'ste']:
                for aw in address_detail.split(' '):
                    if j == aw:
                        if address_detail.split(' ').index(aw) != 0:
                            address = address_detail.split(j)[0].strip()
                            address_line_2 = j + ' ' + address_detail.split(j)[-1].strip()
                            break
        except Exception as e:
            address_line_2 = ''
            address = ''
            print(e)
        try:

            city = response.xpath('//*[@class="et_pb_module et_pb_text et_pb_text_0  et_pb_text_align_left et_pb_bg_layout_dark"]//p/text()').extract_first().strip()
        except Exception as e:
            print(e)

        try:
            state1 = ''.join(response.xpath('//*[@class="et_pb_module et_pb_text et_pb_text_3  et_pb_text_align_left et_pb_bg_layout_light"]//p//text()|//*[@class="et_pb_module et_pb_text et_pb_text_4  et_pb_text_align_left et_pb_bg_layout_light"]//p/span//text()').extract()).strip()
            state = ''.join(re.findall('[A-Z]{2}', state1))
            zipcode = ''.join(re.findall('(\d{5})', state1))

            # print(state)
        except Exception as e:
            print(e)



        try:
            store_name = response.xpath('//*[@class="et_pb_module et_pb_text et_pb_text_3  et_pb_text_align_left et_pb_bg_layout_light"]//h4//text()|//*[@class="et_pb_module et_pb_text et_pb_text_4  et_pb_text_align_left et_pb_bg_layout_light"]//h4//text()').extract_first()
        except Exception as e:
            print(e)

        try:
            phone_number = ''.join(response.xpath('//div[@class="et_pb_blurb_description"]/p//a/text()|//div[@class="et_pb_blurb_description"]/div//text()').extract()).strip()
        except Exception as e:
            print(e)

        try:
            store_hour = '|'.join(response.xpath('//*[contains(text(),"Hours")]/../../div//p[2]//text()').extract())
        except Exception as e:
            print(e)

        try:
            longitude = response.xpath('//div[@class="et_pb_map"]/@data-center-lng').extract_first()
        except Exception as e:
            print(e)

        try:
            latitude = response.xpath('//div[@class="et_pb_map"]/@data-center-lat').extract_first()
        except Exception as e:
            print(e)

        try:
            additional_info1 = ''.join(response.xpath('//*[contains(text(),"Member Hours:")]/../../p[1]/text()').extract()).strip()
        except Exception as e:
            additional_info1 = ''
            print(e)

        item = StoreLocatorsItem()
        additional_info = {}
        item['phone_number'] = phone_number
        item['store_name'] = store_name
        # if store_name == "10 Fitness – Rodney Parham":
        #     address = "10901 N Rodney Parham Rd, Suite 7"
        item['address'] = address
        if store_name == "10 Fitness – University":
            city = "Little Rock"
        if store_name == "10 Fitness – Rodney Parham":
            city = "Little Rock"
        if store_name == "10 Fitness – Downtown Little Rock":
            city = "Little Rock"
        if store_name == "10 Fitness – West Conway":
            city = "Conway"
        if store_name == "10 Fitness – Maumelle":
            city = "North Little Rock"

        item['city'] = city
        if store_name == "10 Fitness – Rodney Parham":
            state = "AR"
        if city == "Searcy":
            state = "AR"
        if store_name == "10 Fitness – North Little Rock (JFK)":
            state = "AR"
        # if store_name == "10 Fitness – Searcy":
        #     state = "AR"
        item['state'] = state
        if zipcode == "1173172113":
            zipcode = "72113"
        if store_name == "10 Fitness – Rodney Parham":
            zipcode = "72211"
        if store_name == "10 Fitness – Maumelle":
            zipcode = "72113"
        if city == "Searcy":
            zipcode = "72143"
        item['zip_code'] = zipcode
        item['country'] = 'United States'
        item['country_code'] = 'US'

        if address == "204 S Rockwood Dr":
            address_line_2 = "Suite G"
        if store_name == "10 Fitness – West Conway":
            address_line_2 = "Suite 7"
        if address == "10901 N Rodney Parham Rd":
            address_line_2 = "Suite 7"
        if store_name == "10 Fitness – University":
            address_line_2 = "Suite B"
        if store_name == "10 Fitness – North Little Rock (JFK)":
            address_line_2 = "Suite 110"

        item['address_line_2'] = address_line_2
        item['store_hours'] = store_hour
        item['longitude'] = longitude
        item['latitude'] = latitude
        item['source_url'] = response.url
        if additional_info1 != '':
            additional_info = dict()
            additional_info['Member Hours'] = additional_info1
            item['additional_info'] = json.dumps(additional_info, ensure_ascii=False)
        else:
            item['additional_info'] = json.dumps(additional_info, ensure_ascii=False)
        yield item
        # item['city'] = response.xpath('//div[@class="et_pb_module et_pb_text et_pb_text_0 et_pb_bg_layout_light  et_pb_text_align_left"]//div/p/text()|//div[@class="et_pb_module et_pb_text et_pb_text_0 et_pb_bg_layout_dark  et_pb_text_align_left"]//div/p/text()|//div[@class="et_pb_module et_pb_text et_pb_text_0 et_pb_bg_layout_dark  et_pb_text_align_left"]//div/p/span/text()').extract_first()


        # item['zip_code']=''.join(response.xpath('//div[@class="et_pb_module et_pb_text et_pb_text_2 et_pb_bg_layout_light  et_pb_text_align_left"]//div[@class="et_pb_text_inner"]/p//text()|//div[@class="et_pb_module et_pb_text et_pb_text_3 et_pb_bg_layout_light  et_pb_text_align_left"]//div[@class="et_pb_text_inner"]/p/span/i/text()').extract()).split(' ')[-1]
        # if 'Pass' in item['zip_code']:
        #     item['zip_code']=''.join(response.xpath('//div[@class="et_pb_module et_pb_text et_pb_text_3 et_pb_bg_layout_light  et_pb_text_align_left"]/div/p//text()').extract()).split(' ')[-1]
        #


        # item['state']=''.join(response.xpath('//div[@class="et_pb_module et_pb_text et_pb_text_2 et_pb_bg_layout_light  et_pb_text_align_left"]//div[@class="et_pb_text_inner"]/p//text()|//div[@class="et_pb_module et_pb_text et_pb_text_3 et_pb_bg_layout_light  et_pb_text_align_left"]//div[@class="et_pb_text_inner"]/p/span/i/text()').extract()).split(' ')[-2]
        # if '7-Day' in item['state']:
        #     item['state']=''.join(response.xpath('//div[@class="et_pb_module et_pb_text et_pb_text_3 et_pb_bg_layout_light  et_pb_text_align_left"]/div/p//text()').extract()).split(' ')[-2]


        # hours = response.xpath('//div[@class="et_pb_module et_pb_text et_pb_text_3 et_pb_bg_layout_light  et_pb_text_align_left"]/div//text()|//div[@class="et_pb_module et_pb_text et_pb_text_4 et_pb_bg_layout_light  et_pb_text_align_left"]/div//text()').extract()
        # for i in hours:
        #     if 'Hour' not in hours[0]:
        #         del hours[0]
        #
        #     elif 'Follow' in hours[-1]:
        #         del hours[-1]
        #
        # houres = hours[1:]
        #
        # hour = '|'.join(houres).encode('ascii', 'ignore').decode('utf8')



# execute('''scrapy crawl store_1 -a list_id=1'''.split())

