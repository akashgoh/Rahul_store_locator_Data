
# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import re
import scrapy, os, logging, hashlib
import requests, json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime


class Store177Spider(scrapy.Spider):
    name = 'store_177'
    allowed_domains = []


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            self.f1.set_details(self.list_id, run_date)
            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                print(search_terms)
                # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)
                search_terms = ''
                for search_term in (search_terms):
                    source_url = link = 'https://16handles.com/locations/'
                    file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(search_term) + '_' + str(run_date) + '.html'
                    if os.path.exists(file_path):
                        link = 'file://' + file_path.replace('\\', '/')
                    yield scrapy.FormRequest(url=str(link), callback=self.get_store_list,
                                             meta={'source_url': source_url, 'search_term': search_term,
                                                   'file_path': file_path, 'proxy_type': self.proxy_type})
            else:
                source_url = link = 'https://www.myndspa.com/locations'
                file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(run_date) + '.html'
                yield scrapy.FormRequest(url=str(link), callback=self.firstlevel,
                                         meta={'source_url': source_url,
                                               'file_path': file_path, 'proxy_type': self.proxy_type})
        except Exception as e:
            logging.log(logging.ERROR, e)

    def firstlevel(self, response):
        try:
            source_url = response.meta['source_url']
            file_path = response.meta['file_path']
            proxy_type = response.meta['proxy_type']
            store_links = response.xpath('//*[contains(text(),"Learn More")]/@href').extract()
            for link in store_links:
                url = 'https://www.myndspa.com' + link
                yield scrapy.FormRequest(url=url, callback=self.get_store_list,
                                         meta={'source_url': source_url, 'file_path': file_path,
                                               'proxy_type': proxy_type})
        except Exception as e:
            print("firstlevel", e, response.url)

    def get_store_list(self, response):
        try:
            if not response.url.startswith('file://'):
                self.f1.page_save(response.meta['file_path'], response.body)
            search_term = response.meta.get('search_term', '')
            try:
                item = StoreLocatorsItem()

                try:
                    phone_number = re.findall('"telephone": "(.*?)"',response.text)[0]
                except Exception as e:
                    print("phone_number", e, response.url)

                try:
                    address = response.xpath('//dd[1]/text()').extract_first().strip()
                except Exception as e:
                    print("address", e, response.url)

                try:
                    citystatezipciode = response.xpath('//dd[2]/text()').extract_first().strip().split(",")
                    city = citystatezipciode[0].strip()
                except Exception as e:
                    print("city", e, response.url)

                try:
                    store_name = response.xpath(
                        '//h1[@class="multi-line"]/span[1]/text()').extract_first().strip() + " - " + city
                except Exception as e:
                    print("store_name", e, response.url)

                try:
                    state = citystatezipciode[1].strip()
                except Exception as e:
                    print("state", e, response.url)
                try:
                    zip_code = citystatezipciode[2].strip()
                except Exception as e:
                    print("zip_code", e, response.url)
                try:
                    latitude = re.findall('"lat":(.*?),',response.text)[0].strip()

                    longitude = re.findall('"lng":(.*?),',response.text)[0].strip()
                except Exception as e:
                    print("latitude and longitude", e, response.url)

                try:
                    sun = response.xpath('//td[contains(text(),"Sunday")]/following-sibling::td/text()').extract_first()
                    mon = response.xpath('//td[contains(text(),"Monday")]/following-sibling::td/text()').extract_first()
                    tue = response.xpath('//td[contains(text(),"Tuesday")]/following-sibling::td/text()').extract_first()
                    wed = response.xpath('//td[contains(text(),"Wednesday")]/following-sibling::td/text()').extract_first()
                    thu = response.xpath('//td[contains(text(),"Thursday")]/following-sibling::td/text()').extract_first()
                    fri = response.xpath('//td[contains(text(),"Friday")]/following-sibling::td/text()').extract_first()
                    sat = response.xpath('//td[contains(text(),"Saturday")]/following-sibling::td/text()').extract_first()

                    storehours = "Sunday: "+sun+"|"+"Monday: "+mon+"|"+"Tuesday: "+tue+"|"+"Wednesday: "+wed+"|"+"Thursday: "+thu+"|"+"Friday: "+fri+"|"+"Saturday: "+sat


                except Exception as e:
                    print("store_hours", e, response.url)

                try:
                    additional_info = {}
                    Description = re.findall('"description": "(.*?)",',response.text,re.DOTALL)[0]
                    additional_info['Description'] = Description


                except Exception as e:
                    print("description",e,response.url)

                item['search_term'] = search_term
                item['store_name'] = store_name
                item['address'] = address
                item['city'] = city
                item['state'] = state
                item['zip_code'] = zip_code
                item['phone_number'] = phone_number
                item['latitude'] = latitude
                item['longitude'] = longitude
                item['store_type'] = ''
                item['coming_soon'] = 0
                item['source_url'] = response.url
                item['country_code'] = item['country'] = 'US'  # self.f1.country_dict.get(item['country'].lower())
                item['store_hours'] = storehours
                item['additional_info'] = json.dumps(additional_info, ensure_ascii=False)

                if item['country_code'] == 'US' and len(item['state']) > 2:
                    item['state'] = self.f1.state_dict.get(state, '')
                yield item
            except Exception as e:
                print("problem in the red",e,response.url)

        except Exception as e:
            logging.log(logging.ERROR, e)

    def response_html_path(self, request):
        return request.meta['fpath']


# execute('''scrapy crawl store_177 -a list_id=177'''.split())