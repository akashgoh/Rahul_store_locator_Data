# -*- coding: utf-8 -*-
import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime
import re
import html2text
run_date = str(datetime.datetime.today()).split()[0]

class YumyumdonutsCrawlerSpider(scrapy.Spider):
    name = 'store_108'
    allowed_domains = []
    f1 = Func()

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            source_url = link = 'https://yumyumdonuts.com/maps_xml'
            head = {'Host': 'yumyumdonuts.com','User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept': '*/*','Accept-Language': 'en-GB,en;q=0.5','Accept-Encoding': 'gzip, deflate, br','X-Requested-With': 'XMLHttpRequest','Referer': 'https://yumyumdonuts.com/locations'}
            self.f1.set_details(self.list_id, run_date)
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(run_date) + '.html'
            if os.path.exists(file_path):
                link = 'file://' + file_path.replace('\\', '/')
            yield scrapy.FormRequest(url=str(link), callback=self.get_store_list, meta={'source_url': source_url,'file_path': file_path, 'proxy_type': self.proxy_type})
        except Exception as e:
            print(e)

    def get_store_list(self,response):
        if not response.url.startswith('file://'):
            self.f1.page_save(response.meta['file_path'], response.body)
        try:
            loop = response.body.decode('utf-8').split('<marker ')[1:]
            for lp in loop:
                try:
                    try:
                        add = re.findall('Address="(.*?)"',lp)[0].strip().split(',')[:-1]
                    except Exception as e:
                        logging.log(logging.ERROR,e)
                    item = StoreLocatorsItem()
                    item['store_number'] = re.findall('uuid="(.*?)"',lp)[0].strip()
                    item['store_name'] = re.findall('Location="(.*?)"',lp)[0].strip()
                    item['address'] = add[0].strip()
                    item['city'] = add[1].strip()
                    item['state'] = add[2].strip().split(' ')[0].strip()
                    item['zip_code'] = add[2].strip().split(' ')[-1].strip()
                    item['country'] = 'US'
                    item['store_hours'] = re.findall('Desc="(.*?)"',lp)[0].strip()
                    item['country_code'] = 'US'
                    item['latitude'] = re.findall('Ycoord="(.*?)"',lp)[0].strip()
                    item['longitude'] = re.findall('Xcoord="(.*?)"',lp)[0].strip()
                    item['phone_number'] = re.findall('Phone="(.*?)"',lp)[0].strip().replace('(','').replace(')','').replace('-',' ').replace(' ','.').strip()
                    item['website_address'] = 'https://yumyumdonuts.com/locations'
                    yield item
                except Exception as e:
                    logging.log(logging.ERROR, e)
        except Exception as e:
            logging.log(logging.ERROR,e)

# execute('''scrapy crawl store_108 -a list_id=108'''.split())#-s HTTPCACHE_ENABLED=True