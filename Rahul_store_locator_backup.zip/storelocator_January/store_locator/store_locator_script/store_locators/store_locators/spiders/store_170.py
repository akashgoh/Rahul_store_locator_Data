# -*- coding: utf-8 -*-
import scrapy,os,logging,hashlib
import requests,json,re
from string import punctuation
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime

class TmbBankThCrawlerSpider(scrapy.Spider):
    name = 'store_170'
    allowed_domains = []
    f1 = Func()

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            head = {'Host': 'www.tmbbank.com',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0',
                    'Accept': '*/*',
                    'Accept-Language': 'en-GB,en;q=0.5',
                    'Accept-Encoding': 'gzip, deflate, br',
                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'X-Requested-With': 'XMLHttpRequest',
                    'Referer': 'https://www.tmbbank.com/en/contact/location'}
            data = {"province": ""}  # +":"+slat+":"+slng}
            source_url = link = 'https://www.tmbbank.com/en/googlemap/side/branch/0/0'
            self.f1.set_details(self.list_id, run_date)
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(run_date) + '.html'
            if os.path.exists(file_path):
                link = 'file://' + file_path.replace('\\', '/')
            yield scrapy.FormRequest(url=str(link), callback=self.get_store_list,headers=head,formdata=data, meta={'source_url': source_url,'file_path': file_path, 'proxy_type': self.proxy_type})
        except Exception as e:
            print(e)

    def get_store_list(self,response):
        a=response.url
        print(a)

        s=response.text
        print(s)
        if not response.url.startswith('file://'):
            self.f1.page_save(response.meta['file_path'], response.body)
        source_url = response.meta.get('source_url', '')
        add = response.xpath('//*[@class="panel panel-default "]//span[contains(text(),"Address")]/following-sibling::span/text()').extract()
        # print(add)
        try:
            store_loop = response.xpath('//*[@class="panel panel-default "]')
            for lp in store_loop:
                address, address2, address3,temp_add,temp_add4 = '', '', '','',''
                store_number = lp.xpath('.//span[contains(text(),"Branch Code")]/following-sibling::span/text()').extract_first(default='').strip(punctuation).strip()
                name = lp.xpath('.//h4/a/text()').extract_first(default='').strip(punctuation).strip()
                lat_long = lp.xpath('.//h4/a/@onclick').extract_first(default='').strip()
                if lat_long!='':
                    temp = re.findall(r'\'(.*?)\'',lat_long)

                hours = lp.xpath('.//span[contains(text(),"Open")]/following-sibling::span/text()').extract_first(default='').strip()
                print(hours,name)
                phone = lp.xpath('.//span[contains(text(),"Tel")]/following-sibling::span/text()').extract_first(default='').replace(', ','').replace('-','.').strip()
                print(phone)
                fax = lp.xpath('.//span[contains(text(),"Fax")]/following-sibling::span/text()').extract_first(default='').replace('-','.').strip()
                print(fax)
                # address
                try:
                    temp_add = lp.xpath('.//span[contains(text(),"Address")]/following-sibling::span/text()').extract_first(default='').strip()
                    add = temp_add.split(',')
                    zip = re.findall(r'(\d{5})', add[-1].strip())[0].strip()
                    temp_add4 = add[-1].replace(zip,'').strip()
                    if temp_add4!='':
                        state = temp_add4
                    else:
                        if 'Province' in add[-2].strip():
                            state = add[-2].strip()
                        else:
                            if 'District' not in add[-2].strip():
                                state=add[-2].strip()
                    temp_add = temp_add.replace(state,'').replace(zip,'').strip(punctuation).strip()
                    add = temp_add.split(',')[:-1]
                    # address3
                    if 'Sub-dis' not in add[-1]:
                        address3 = add[-1].strip()
                    else:
                        if 'Sub-dis' in add[-1]:
                            address3 = ''
                            address2 = add[-1].strip()
                        else:
                            address3 = add[-1].strip()
                    temp_add = temp_add.replace(address2,'').replace(address3,'').strip(punctuation).strip()
                    add = temp_add.split(',')
                    # address2
                    if address2 == '':
                        if 'Sub-dis' in add[-1]:
                            address2 = add[-1].strip()
                        else:
                            if len(add)!=1:
                                address2 = add[-1].strip()
                    temp_add = temp_add.replace(address2,'').strip(punctuation).strip()
                    address = temp_add
                except Exception as e:
                    logging.log(logging.ERROR,e)
                try:
                    item = StoreLocatorsItem()
                    item['store_number'] = store_number
                    item['store_name'] = name
                    item['address'] = address
                    item['address_line_2'] = address2
                    item['address_line_3'] = address3
                    item['city'] = ''
                    item['state'] = state
                    item['zip_code'] = zip
                    item['country'] = 'TH'
                    item['country_code'] = 'TH'
                    item['latitude'] = temp[0].strip()
                    item['longitude'] = temp[1].strip()
                    item['store_hours'] = hours
                    item['fax_number'] = fax
                    item['phone_number'] = phone
                    item['source_url'] = "https://www.tmbbank.com/en/googlemap/side/branch/0/0"
                    yield item
                except Exception as e:
                    logging.log(logging.ERROR, e)
        except Exception as e:
            logging.log(logging.ERROR,e)

# execute('''scrapy crawl store_170 -a list_id=170'''.split())

'''
                if len(add)==4:
                    address = add[0].strip(punctuation).strip()
                    address2 = add[1].strip(punctuation).strip()
                    address3 = add[2].strip(punctuation).strip()
                    add4 = add[3].strip(punctuation).strip()
                    zip = re.findall(r'(\d
                    
                    
       
                    
                    {5})',add4)[0].strip()
                    state = add4.replace(zip,'').strip()
                    

'''