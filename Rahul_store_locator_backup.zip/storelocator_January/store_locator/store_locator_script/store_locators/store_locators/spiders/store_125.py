# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import random
import re


import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime

class Store125Spider(scrapy.Spider):
    name = 'store_125'
    allowed_domains = []


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()


    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            self.f1.set_details(self.list_id,run_date)
            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                print(search_terms)
                for search_term in (search_terms):
                    source_url = link = 'https://www.winfieldunited.com/find-a-retailer?zipcode='+str(search_term)
                    yield scrapy.FormRequest(url=str(link), callback=self.data, meta={'source_url': source_url,'search_term': search_term,'proxy_type': self.proxy_type})
            else:
                source_url = link = 'https://www.winfieldunited.com/find-a-retailer?zipcode=55126'
                file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(run_date) + '.html'
                yield scrapy.FormRequest(url=str(link), callback=self.data,meta={'source_url': source_url,'file_path': file_path, 'proxy_type': self.proxy_type})
        except Exception as e:
            logging.log(logging.ERROR, e)


    def data(self, response):
        zipcode = response.meta['search_term']
        headers = {
            "Referer":"https://www.winfieldunited.com/find-a-retailer?zipcode="+str(zipcode),
            "Sec-Fetch-Mode":"no-cors",
            "User-Agent":"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36H"
        }
        yield scrapy.FormRequest(url='https://apis.landolakesinc.com/EntityLocatorAPI/v2/Service1/Entities?instance=2&zip='+str(zipcode)+'&city=&state=&radius=100&attribute=5&max=30&callback=jQuery11230321927418462298_1599105988754&{}&_=1599105988756',
                                 headers=headers, callback=self.parse_data)


    def parse_data(self, response):
        text = response.text
        tot_count = re.findall(r'"RESULT_COUNT":(.*?),', text)[0]
        data = re.findall(r'{"ENTITY_LIST":(.*?),"RESULT_COUNT":'+str(tot_count), text)[0]
        json_data = json.loads(data)
        for i in range(0, int(tot_count)):
            try:store_name = json_data[i]['NAME']
            except:store_name = ''

            try:telephone = json_data[i]['PHONE_NUMBER']
            except:telephone = ''

            try:address = json_data[i]['ADDRESS1']
            except:address = ''

            check = False
            for j in ['Unit', 'STE', 'Ste', 'SUITE', 'Suite', 'suite', 'Suit', 'SUIT', 'suit', 'UNIT', 'unit', 'ste']:
                for aw in address.split():
                    if j == aw:
                        address1 = address.split(j)[0].strip().strip(',')
                        address_line_2 = j + ' ' + address.split(j)[-1].strip()
                        check = True
                        break
            if check == True:
                address_line_2 = address_line_2
                address = address1
            else:
                address_line_2 = ''
                address = address

            try:
                location = json_data[i]['GEO_CODE'].split(',')
                lat = location[-1]
                long = location[0]
            except:
                lat = 0.00
                long = 0.00

            try:city = json_data[i]['CITY']
            except:city = ''

            try:state = json_data[i]['STATE_PROVINCE']
            except:state = ''

            try:zip_code = json_data[i]['POSTAL_CODE']
            except:zip_code = ''

            try:
                email_address = json_data[i]['EMAIL_ADDRESS']
                if email_address == None:
                    email_address = ''
            except:
                email_address = ''

            try:
                fax_number = json_data[i]['FAX_NUMBER']
                if fax_number == None:
                    fax_number = ''
            except:
                fax_number = ''

            try:
                store_type = json_data[i]['TYPE']
                if store_type == None:
                    store_type = ''
            except:
                store_type = ''

            try:
                web_url = json_data[i]['WEB_URL']
                if web_url == None:
                    web_url = ''
            except:
                web_url = ''

            item = StoreLocatorsItem()
            item['search_term'] = 'link'
            item['store_name'] = store_name
            item['address'] = address
            item['city'] = city
            item['state'] = state
            item['country'] = 'USA'
            item['address_line_2'] = address_line_2
            item['latitude'] = lat
            item['longitude'] = long
            item['zip_code'] = zip_code
            item['email_address'] = email_address
            item['fax_number'] = fax_number
            item['store_type'] = store_type
            item['coming_soon'] = 0
            item['country_code'] = 'US'  # self.f1.country_dict.get(item['country'].lower())
            item['store_hours'] = store_type
            item['phone_number'] = telephone
            item['website_address'] = web_url
            item['source_url'] = response.url
            if store_name != '':
                yield item


    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_125 -a list_id=125'''.split())