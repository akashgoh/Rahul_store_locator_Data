import re
from scrapy.cmdline import execute
import scrapy
import json
from store_locators.spiders.common_functions import Func
from store_locators.items import StoreLocatorsItem
import datetime
import html2text,os


class Store165Spider(scrapy.Spider):
    name = 'store_165'
    f1 = Func()
    # not_export_data = True

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            source_url = link = 'https://www.tradefairny.com/store-locations.html'

            self.f1.set_details(self.list_id, run_date)
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
                run_date) + '.html'
            if os.path.exists(file_path):
                link = 'file://' + file_path.replace('\\', '/')

            yield scrapy.FormRequest(url=str(link), callback=self.get_store_links,
                                     meta={'source_url': source_url, 'file_path': file_path,
                                           'proxy_type': self.proxy_type})

        except Exception as e:
            print(e)

    def get_store_links(self, response):
        head = "https://www.tradefairny.com/"
        file_path = response.meta['file_path']
        links = response.xpath('//div[@class="txt "]//p[@style="text-align: center;"]/a/@href').extract()
        for link in links:
            if head not in link:
                link = head + link
            yield scrapy.Request(link, self.InsideStore, meta={'file_path': file_path})

    def InsideStore(self, response):
        try:
            # if not response.url.startswith('file://'):
            #     self.f1.page_save(response.meta['file_path'], response.body)

            try:
                address = response.xpath('//span[@itemprop="streetAddress"]/text()').get()
                city = response.xpath('//span[@itemprop="addressLocality"]/text()').get()
                state = response.xpath('//span[@itemprop="addressRegion"]/text()').get()
                zip_code = response.xpath('//span[@itemprop="postalCode"]/text()').get()
                phone_number = response.xpath('//span[@itemprop="telephone"]/text()').get()
                store_name = response.xpath('//span[@itemprop="name"]/text()').get()
                store_number = store_name.split('Store')[-1].strip()
                Fax = re.findall('Fax: (.*?)<', response.text)
                if Fax:
                    Fax = Fax[0]
                try:
                    info = ','.join(
                        response.xpath('//div[@class="txt "]//p//span[@style="font-size:12px;"]//text()').extract())
                    if not info.strip():
                        info = ','.join(
                            response.xpath('//div[@class="txt "]//p//span[@style="color:#000000;"]//text()').extract())
                except:
                    info = ''

            except Exception as e:
                print('Address', e, response.url)

            item = StoreLocatorsItem()

            item['address'] = address.strip()
            item['address_line_2'] = ''
            item['city'] = city.strip()
            item['state'] = state.strip()
            item['zip_code'] = zip_code.strip()
            item['country'] = 'United States'
            item['country_code'] = 'US'
            item['store_name'] = store_name.strip()
            item['phone_number'] = phone_number.strip()
            item['store_type'] = ''
            item['coming_soon'] = 0
            item['store_number'] = store_number
            item['source_url'] = response.url
            item['fax_number'] = Fax.strip()
            item['additional_info'] = ""
            item['store_hours'] = "Open 24 Hours a Day"

            yield item
        except Exception as e:
            print("Problem in yield item", e)


# execute('''scrapy crawl store_165 -a list_id=165 -s HTTPCACHE_ENABLED=False'''.split())



