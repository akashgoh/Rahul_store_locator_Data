import re

import scrapy
import json
from store_locators.spiders.common_functions import Func
from store_locators.items import StoreLocatorsItem
import datetime
import html2text,os

class StoreLocatoreSpider(scrapy.Spider):
    name = 'store_154'
    f1 = Func()

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            source_url = link = 'https://www.u-gro.com/locations/'

            self.f1.set_details(self.list_id, run_date)
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(run_date) + '.html'
            if os.path.exists(file_path):
                link = 'file://' + file_path.replace('\\', '/')

            yield scrapy.FormRequest(url=str(link), callback=self.get_store_links, meta={'source_url': source_url,'file_path': file_path, 'proxy_type': self.proxy_type})

        except Exception as e:
            print(e)


    def get_store_links(self,response):

        head = "https://www.u-gro.com"
        file_path = response.meta['file_path']
        links = response.xpath('//div[@class="locations-container"]//a[contains(text(),"Learn More")]//@href').extract()
        for link in links:
            if head not in link:
                link = head+link
            yield scrapy.Request(link,self.InsideStore,meta={'file_path':file_path})

    def InsideStore(self,response):
        try:
            if not response.url.startswith('file://'):
                self.f1.page_save(response.meta['file_path'], response.body)

            try:
                Addr = []
                tmpAddr = response.xpath('//div[@class="location-info"]//div[@class="address"]/p//text()').extract()
                for tmp in tmpAddr:
                    if tmp.strip():
                        Addr.append(tmp.strip())
                if len(Addr) > 2:
                    address = ''.join(Addr[:-1])
                else:
                    address = Addr[0]
                CSZ = Addr[-1].split(',')
                city = CSZ[0]
                state = re.findall('([A-Z]{2,2})',CSZ[-1])[0]
                zip_code = re.findall('(\d{5})',CSZ[-1])[0]
                phone_number = response.xpath('//div[@class="location-info"]//a[contains(@href,"tel")]/text()').get()
                store_hours = '|'.join(response.xpath('//div[@class="location-info"]//div[@class="hours"]//p//text()').extract())
                store_location = response.xpath('//h1[@class="entry-title"]/text()').get()

                try:
                    tmpLatLng = response.xpath('//a[contains(text(),"View Map")]/@href').get()
                    tmpLatLng = re.findall('@(.*?)z/',tmpLatLng)
                    if tmpLatLng:
                        tmpLatLng = tmpLatLng[0].split(',')
                    latitude = tmpLatLng[0]
                    longitude = tmpLatLng[1]
                except :
                    latitude = ''
                    longitude = ''
            except Exception as e:
                print('Address',e,response.url)

            email_address = response.xpath('//a[@class="email"]/@href').get().replace('mailto:','')
            services = '|'.join(response.xpath('//div[@class="features"]//li//text()').extract())

            additional_info = dict()
            Description = ' '.join(response.xpath('//div[@class="description"]//text()').extract())
            Curriculum = response.xpath('//div[@class="curriculum"]//p/text()').get()
            DailySchedule = dict()

            PreSchool = list()
            PBlock = response.xpath('//div[@class="grade_content"]')[0]
            PBlocks = PBlock.xpath('.//div[@class="the-schedule"]')
            for blk in PBlocks:
                PDict = dict()
                key = blk.xpath('./strong/text()').get()
                val = ''.join(blk.xpath('.//p//text()').extract())
                PDict[key] = val
                PreSchool.append(PDict)
            DailySchedule['PreSchool'] = PreSchool

            Toddler = list()
            TBlock = response.xpath('//div[@class="grade_content"]')[1]
            TBlocks = TBlock.xpath('.//div[@class="the-schedule"]')
            for blk in TBlocks:
                TDict = dict()
                key = blk.xpath('./strong/text()').get()
                val = ''.join(blk.xpath('.//p//text()').extract())
                TDict[key] = val
                Toddler.append(TDict)
            DailySchedule['Toddler'] = Toddler

            additional_info['Description'] = Description
            additional_info['Curriculum'] = Curriculum
            additional_info['DailySchedule'] = DailySchedule

            # view = json.dumps(str(additional_info))

            item = StoreLocatorsItem()
            item['address'] = address.strip()
            item['address_line_2'] = ''
            item['city'] = city.strip()
            item['state'] = state.strip()
            item['zip_code'] = zip_code.strip()
            item['country'] = 'United States'
            item['country_code'] = 'US'
            item['store_name'] = 'U-GRO Learning Centres'
            item['phone_number'] = phone_number.strip()
            item['store_type'] = ''
            item['latitude'] = latitude.strip()
            item['longitude'] = longitude.strip()
            item['coming_soon'] = 0
            item['store_location'] = store_location
            item['source_url'] = response.url
            item['email_address'] = email_address.strip()
            item['additional_info'] = json.dumps(additional_info, ensure_ascii=False)
            item['store_hours'] = store_hours
            item['services'] = services
            yield item
        except Exception as e:
            print("Problem in yield item",e)

# from scrapy.cmdline import execute
# execute('''scrapy crawl store_154 -a list_id=154 -s HTTPCACHE_ENABLED=False'''.split())
