# # -*- coding: utf-8 -*-
# import re
# import scrapy,os,logging,hashlib
# import requests,json
# from scrapy.http import HtmlResponse
# from scrapy.cmdline import execute
# from store_locators.items import StoreLocatorsItem
# from store_locators.spiders.common_functions import Func
# import datetime
#
# class store_101Spider(scrapy.Spider):
#     name = 'store_101'
#     allowed_domains = []
#     f1 = Func()
#
#     def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
#         super().__init__(name, **kwargs)
#         self.list_id, self.proxy_type = list_id, proxy_type
#
#     def start_requests(self):
#         run_date = str(datetime.datetime.today()).split()[0]
#         try:
#             head={'Host': 'www.spar.at','User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept': '*/*','Accept-Language': 'en-GB,en;q=0.5','Accept-Encoding': 'gzip, deflate, br','X-Requested-With': 'XMLHttpRequest','Referer': 'https://www.spar.at/standorte'}
#             self.f1.set_details(self.list_id, run_date)
#             file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(run_date) + '.html'
#             if os.path.exists(file_path):
#                 source_url =link = 'file://' + file_path.replace('\\', '/')
#             urls = ['https://www.ziebart.com/about/site-map-page-2','https://www.ziebart.com/about/site-map-page-3']
#             for url in urls:
#                 yield scrapy.FormRequest(url=url, callback=self.get_store_list,meta={'proxy_type': self.proxy_type,'file_path': file_path}, dont_filter=True)
#         except Exception as e:
#             logging.log(logging.ERROR, e)
#
#     def get_store_list(self, response):
#         run_date = str(datetime.datetime.today()).split()[0]
#         if not response.url.startswith('file://'):
#             self.f1.page_save(response.meta['file_path'], response.body)
#         links = response.xpath('//*[@class="site-map"]//a/@href').extract()
#         for link in links:
#             if 'location' in link:
#                 res1 = requests.get(f'https://www.ziebart.com{link}')
#                 response1 = HtmlResponse(url=res1.url,body=res1.content)
#                 try:
#                     number = re.findall('Store:(.*?)<',response1.body.decode('utf8'))[0].strip()
#                     name = response1.xpath('//span[@itemprop="name"]/text()').extract_first(default='').strip()
#                     address = response1.xpath('//span[@itemprop="streetAddress"]/text()').extract_first(default='').strip()
#                     city = response1.xpath('//span[@itemprop="addressLocality"]/text()').extract_first(default='').strip()
#                     state = response1.xpath('//span[@itemprop="addressLocality"]/following-sibling::span[1]/text()').extract_first(default='').strip()
#                     zipcode = response1.xpath('//span[@itemprop="addressLocality"]/following-sibling::span[2]/text()').extract_first(default='').strip()
#                     lat = response1.xpath('//input[@id="hfLatitude"]/@value').extract_first(default='').strip()
#                     lng = response1.xpath('//input[@id="hfLongitude"]/@value').extract_first(default='').strip()
#                     days,tf = [], []
#                     days = response1.xpath('//h4[contains(text(),"Hours")]/ancestor::div[1]/table//th/text()').extract()
#                     timings = response1.xpath('//h4[contains(text(),"Hours")]/ancestor::div[1]/table//td/text()').extract()
#                     for t in timings:
#                         temp = t.strip()
#                         if temp!='':
#                             tf.append(temp)
#                         else:continue
#                     hours = dict(zip(days,tf))
#                     phone = response1.xpath('//span[@itemprop="telephone"]/a/text()').extract_first(default='').strip()
#                     services = '|'.join(response1.xpath('//h4[contains(text(),"Services")]/ancestor::div[1]//li//text()').extract())
#                     try:
#                         item = StoreLocatorsItem()
#                         item['store_number'] = number
#                         item['store_name'] = name
#                         item['address'] = address
#                         item['address_line_2'] = ''
#                         item['address_line_3'] = ''
#                         item['city'] = city
#                         item['state'] = state
#                         item['zip_code'] = zipcode
#                         item['country'] = 'US'
#                         item['country_code'] = 'US'
#                         item['latitude'] = lat
#                         item['longitude'] = lng
#                         item['store_hours'] = json.dumps(hours)
#                         item['phone_number'] = phone
#                         item['services'] = services
#                         item['website_address'] = response1.url
#                         item['source_url'] = response.url
#                         yield item
#                     except Exception as e:
#                         logging.log(logging.ERROR, e)
#                 except Exception as e:
#                     logging.log(logging.ERROR, e)
#
# # execute('''scrapy crawl store_101 -a list_id=101 -a proxy_type=luminaty'''.split())


# -*- coding: utf-8 -*-
import re

import scrapy
import datetime
import pandas as pd
# import yaml
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime
import requests
from parsel import Selector




class store_101Spider(scrapy.Spider):
    name = 'store_101'
    allowed_domains = []
    start_urls = ['https://www.lovesfurniture.com/allshops']
    not_export_data = False

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        df = pd.read_csv(r'E:\STORE LOCATOR\AGG_UPDATED_STORE_LOCATOR\store_locator\static\us_Zipcode_old.csv')
        for i in list(df['zip_code']):
            if "'" in i:
                a = i.replace("'","")
                link = f'https://www.ziebart.com/find-my-ziebart?zipcode={a}&distance=100'
            else:
                link = f'https://www.ziebart.com/find-my-ziebart?zipcode={i}&distance=100'
        # for i in link:
            yield scrapy.Request(url=link, dont_filter=True, callback=self.parse1)

    def parse1(self, response):
        self.run_date = str(datetime.datetime.today()).split()[0]
        urls = response.xpath('//*[@class="button-2 _2 location w-button"]/@href').getall()
        for link in urls :
            link = 'https://www.ziebart.com'+str(link)
            print(link)
        # link = 'https://www.lovesfurniture.com//locations-battle-creek-store'
            yield scrapy.Request(url=link,dont_filter=True,callback=self.parse)

    def parse(self, response):

        item = StoreLocatorsItem()

        store_name = response.xpath('//*[@class="div-block-59"]//*[@class="store-title"]/text()').get()
        store_address = response.xpath('//*[@class="div-block-59"]//*[@class="store-detail-text"]/text()[1]').get()
        add = response.xpath('//*[@class="div-block-59"]//*[@class="store-detail-text"]/text()[2]').get()
        city = add.split(',')[0]
        add2 = add.split(',')[1].strip()
        state = add2.split(' ')[-2]
        zip = add2.split(' ')[-1]
        phone =response.xpath('//*[@class="div-block-59"]//*[@class="store-phone"]/a/text()').get()
        hour = '|'.join(response.xpath('//*[@class="store-title _2"]/..//div/text()').extract())
        # cms = response.xpath('//div[@class="shop-full-description"]/h6/text()').get()
        # if cms =='Opening Soon!' :
        #     item['coming_soon'] = 1
        # else:
        #     item['coming_soon'] = 0
        # desc =response.xpath('//div[@class="store-about"]/p/text()').extract()
        # if desc == []:
        #     desc = response.xpath('//div[@class="shop-full-description"]/text()').extract()
        # lat = re.findall('latitude=(.*?) data',response.text)[0].strip().replace('"','')
        # long = re.findall('longitude=(.*?)value',response.text)[0].strip().replace('"','')


        source_url =  "".join(response.url)





        item['store_name'] = store_name
        item['address'] = store_address
        item['zip_code'] =  zip
        item['city'] = city
        item['state'] =state
        item['phone_number'] = phone
        item['store_hours'] = hour
        # item['additional_info'] = desc
        item['country'] = "United Status"
        item['country_code'] = "US"
        # item['latitude'] = lat
        # item['longitude'] = long
        item['source_url'] = source_url


        # item['urls'] = lks

        yield item


    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_101 -a list_id=101'''.split())