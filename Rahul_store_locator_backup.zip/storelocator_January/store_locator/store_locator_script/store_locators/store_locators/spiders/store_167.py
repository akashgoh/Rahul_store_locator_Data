# -*- coding: utf-8 -*-
import re
from string import punctuation
import scrapy,os,logging,hashlib,pymysql
import requests,json
from scrapy.http import HtmlResponse
from store_locators.db_config import *
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime
import html2text
h = html2text.HTML2Text()

class ToshibaCopiersCrawlerSpider(scrapy.Spider):
    name = 'store_167'
    allowed_domains = []


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            self.f1.set_details(self.list_id,run_date)
            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                # print(search_terms)
            # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)
            #     search_terms = ['96701']
                for search_term in (search_terms):
                    # print(search_term)
                    head = {'Host': 'store_locatorbusiness.toshiba.com','User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0','Accept': '*/*','Accept-Language': 'en-GB,en;q=0.5','Accept-Encoding': 'gzip, deflate','X-Requested-With': 'XMLHttpRequest','Referer': 'http://business.toshiba.com/dealers/'}
                    temp = search_term.split('_')
                    # ----------- databse connection
                    con = pymysql.connect(db_host, db_user, db_password)
                    cursor = con.cursor()
                    try:
                        try:
                            cursor.execute(f"Select state,city from store_locator_sep.zip_table where lat_lng='{search_term}'")
                            q1 = cursor.fetchall()
                            # print(q1)
                            cursor.execute(f"SELECT * FROM store_locator_sep.us_state_table where state_name='{q1[0][0]}'")
                            q2 = cursor.fetchall()
                            if q2==():
                                continue
                        except Exception as e:
                            logging.log(logging.ERROR,e)

                        source_url = link = f"http://business.toshiba.com/dealers/ServerRequests.jsp?cenLat={temp[0].strip()}&cenLng={temp[1].strip()}&qryRadius=200&pickedPoi=&searched=onlyState&custCountyState=~~{q2[0][0]}" #{q1[0][1][:5]}
                                            # 'http://business.toshiba.com/dealers/ServerRequests.jsp?cenLat=32.756889&cenLng=-86.844516&qryRadius=200&pickedPoi=&searched=onlyState&custCountyState=~~AL'
                        # print(source_url)
                        # source_url = link = "http://business.toshiba.com/dealers/ServerRequests.jsp?cenLat=40.750166&cenLng=-73.996575&qryRadius=500&pickedPoi=&searched=userSearch&custCountyState=~New%20Y~NY"
                        file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(search_term) + '_' + str(run_date) + '.html'
                        if os.path.exists(file_path):
                            link = 'file://' + file_path.replace('\\','/')
                        yield scrapy.FormRequest(url=str(source_url), callback=self.get_store_list,  meta={'source_url': source_url,'search_term': search_term,'file_path':file_path,'proxy_type': self.proxy_type})
                    except Exception as e:
                        logging.log(logging.ERROR,e)

            else:
                source_url = link = ''
                file_path = ''
                yield scrapy.FormRequest(url=str(link), callback=self.get_store_list,
                                         meta={'source_url': source_url,'file_path': file_path,
                                               'proxy_type': self.proxy_type})
        except Exception as e:
            logging.log(logging.ERROR, e)

    # Get data from the response
    def get_store_list(self, response):
        try:
            if not response.url.startswith('file://'):
                self.f1.page_save(response.meta['file_path'],response.body)

            search_term = response.meta.get('search_term', '')
            source_url = response.meta.get('source_url', '')
            if 'dealerDataArray' in response.text:
                store_data = json.loads(response.text)
                js_data = store_data['dealers']['dealerDataArray']
                for df in js_data:
                    try:
                        item = StoreLocatorsItem()
                        item['store_name'] = df['dealerName']
                        item['address'] = df['addrs1']
                        item['address_line_2'] = df['addrs2']
                        if df['addrs2']=='':
                            if 'SUITE' in df['addrs1']:
                                ad = re.split('(SUITE.*)', df['addrs1'].strip())
                                item['address'] = ad[0].strip(punctuation).strip()
                                item['address_line_2'] = ad[1].strip(punctuation).strip()
                            elif '#' in df['addrs1']:
                                ad = re.split('(\#.*)', df['addrs1'].strip())
                                item['address'] = ad[0].strip(punctuation).strip()
                                item['address_line_2'] = ad[1].strip(punctuation).strip()
                            elif 'PO BOX' in df['addrs1']:
                                ad = re.split('(PO BOX.*)', df['addrs1'].strip())
                                item['address'] = ad[0].strip(punctuation).strip()
                                item['address_line_2'] = ad[1].strip(punctuation).strip()
                            elif 'STE' in df['addrs1']:
                                ad = re.split('(STE.*)', df['addrs1'].strip())
                                item['address'] = ad[0].strip(punctuation).strip()
                                item['address_line_2'] = ad[1].strip(punctuation).strip()
                            elif ',' in df['addrs1']:
                                ad = re.split('(,.*)', df['addrs1'].strip())
                                item['address'] = ad[0].strip(punctuation).strip()
                                item['address_line_2'] = ad[1].strip(punctuation).strip() 
                        item['city'] = df['city']
                        item['state'] = df['state']
                        item['zip_code'] = df['zip']
                        item['country'] = 'US'
                        item['country_code'] = 'US'
                        item['email_address'] = df['email']
                        item['fax_number'] = df['fax']
                        item['phone_number'] = df['phone']
                        item['products'] = h.handle(df['prodData'])
                        item['source_url'] = source_url
                        item['website_address'] = df['website']
                        yield item
                    except Exception as e:
                        logging.log(logging.ERROR, e)
        except Exception as e:
            logging.log(logging.ERROR, e)

# execute('''scrapy crawl store_167 -a list_id=167'''.split())#-s HTTPCACHE_ENABLED=True

