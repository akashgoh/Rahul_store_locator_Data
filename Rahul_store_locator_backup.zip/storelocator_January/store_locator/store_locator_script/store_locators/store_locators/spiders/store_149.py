# -*- coding: utf-8 -*-
import scrapy,os,hashlib
import requests,json
import re
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime
from pprint import pprint as pp


class Store149Spider(scrapy.Spider):
    name = 'store_149'
    allowed_domains = []
    start_urls = ['http://www.usautoforce.com/about/locations/']


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()

    def parse(self, response):
        try:
            phone = response.xpath('//h3[@class="heading"]/text()').get(default='').split()[-1]
            fax = response.xpath('//h3[@class="heading"]/text()[2]').get(default='').split()[-1]
            run_date = str(datetime.datetime.today()).split()[0]
            self.f1.set_details(self.list_id, run_date)
            stores = ((response.xpath('//script[contains(text(),"var loc")]').get().split('locations =')[1]).split('},'))
            for store in stores :
                item = StoreLocatorsItem()
                item['store_name'] = " U.S. AutoForce- " + (store.split('title":"')[1].split('"')[0]).strip()
                address = item['address'] = store.split('street":"')[1].split('"')[0]
                address_split_params = ('unit ', 'suit ', 'ste ')
                for address_split_param in address_split_params:
                    if address_split_param in (item['address'].lower()):
                        item['address'] = (item['address'].lower()).split(address_split_param)[0]
                        item['address_line_2'] = f"{address_split_param} {((address.lower()).split(address_split_param)[1])}"
                        break

                item['city'] = store.split('city":"')[1].split('"')[0]
                item['state'] = store.split('state":"')[1].split('"')[0]
                item['zip_code']= store.split('zip":"')[1].split('"')[0]
                item['longitude'] = store.split('lng":"')[1].split('"')[0]
                item['latitude'] = store.split('lat":"')[1].split('"')[0]
                item['phone_number'] = phone
                item['fax_number'] = fax

                item['source_url'] = response.url

                item['country'] = item['country_code'] = 'US'

                yield item
        except Exception as e:
            print(e)

# execute('''scrapy crawl store_149 -a list_id=149 -s HTTPCACHE_ENABLED=True --nolog'''.split())

