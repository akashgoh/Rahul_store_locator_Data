# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import re
import urllib

import scrapy,os,logging,hashlib
import requests,json
from lxml import html
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from scrapy.utils.response import open_in_browser

from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime
from selenium import webdriver                    # Import module
from selenium.webdriver.common.keys import Keys
import time

from selenium.webdriver.firefox.options import Options


class texas_comSpider(scrapy.Spider):
    name = 'store_189'
    allowed_domains = []

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        self.f1.set_details(self.list_id, run_date)
        try:
            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)
                for search_term in (search_terms):
                    lat = search_term.split('_')[0]
                    lng = search_term.split('_')[1]
                    self.headers = {
                        'Accept': 'text/javascript, application/javascript, application/ecmascript, application/x-ecmascript, */*; q=0.01',
                        'Accept-Encoding': 'gzip, deflate, br',
                        'Accept-Language': 'en-US,en;q=0.9',
                        'Cache-Control': 'no-cache',
                        'Connection': 'keep-alive',
                        'Cookie':'_ga=GA1.2.845480238.1591610586; ai_user=wr5xq|2020-06-08T10:03:06.139Z; _gid=GA1.2.1552614289.1592545912; ai_session=9mLaZ|1592545912700|1592548490689; _dc_gtm_UA-9337032-13=1',
                        'Host': 'www.texaco.com',
                        'Pragma': 'no-cache',
                        'Referer': 'https://www.texaco.com/find-gas-station',
                        'Request-Id': '|GAu/5.Rf7oK',
                        'Sec-Fetch-Dest': 'empty',
                        'Sec-Fetch-Mode': 'cors',
                        'Sec-Fetch-Site': 'same-origin',
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Safari/537.36',
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                    # "https://www.texaco.com/api/app/techron2go/ws_getChevronTexacoNearMe_r2.aspx?callback=jQuery223021950028857122472_1600754988786&lat={lat}&lng={lng}"
                    # "https://locations.valero.com/en-us/Home/SearchForLocations"
                    source_url = link = f"https://www.texaco.com/api/app/techron2go/ws_getChevronTexacoNearMe_r2.aspx?callback=jQuery223021950028857122472_1600754988786&lat={lat}&lng={lng}"
                                         # "https://www.texaco.com/api/app/techron2go/ws_getChevronTexacoNearMe_r2.aspx?callback=jQuery223021950028857122472_1600754988786&lat=64.2008413&lng=-149.4936733&oLat=64.2008413&oLng=-149.4936733&brand=ChevronTexaco&radius=35&_=1600754988788"
                                        # "https://www.texaco.com/api/app/techron2go/ws_getChevronTexacoNearMe_r2.aspx?callback=jQuery223021950028857122472_1600754988786&lat=31.9685988&lng=-99.9018131&oLat=31.9685988&oLng=-99.9018131&brand=ChevronTexaco&radius=35&_=1600754988791"
                    print(source_url)
                    # #source link =""
                    file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(search_term) + '_' + str(
                        run_date) + '.html'
                    if os.path.exists(file_path):
                        link = 'file://' + file_path.replace('\\', '/')
                    yield scrapy.Request(url=str(link), callback=self.parse, headers=self.headers,
                                         meta={'source_url': source_url, 'search_term': search_term,
                                               'file_path': file_path, 'proxy_type': self.proxy_type})
        except Exception as e:
            logging.log(logging.ERROR, e)


    def parse(self, response):
        # open_in_browser(response)
        t=response.text
        file_path =response.meta['file_path']
        count=re.findall(' "count" : "(.*?)"',t)[0]
        c=int(count)
        if c!=0:
                try:
                        item = StoreLocatorsItem()

                        store_name =re.findall('"name" : "(.*?)"',t,re.DOTALL)
                        for i in store_name:
                            store_name=i
                            item['store_name'] = store_name
                            print('storename',store_name)

                        storenumber = re.findall('"id" : "(.*?)"',t,re.DOTALL)
                        for i in storenumber:
                            storenumber=i
                            item['store_number'] = storenumber
                            print(storenumber)

                        address = re.findall('"address" : "(.*?)"',t,re.DOTALL)
                        for i in address:
                            address=i
                            item['address'] = address
                            print(address)

                        city =re.findall('"city" : "(.*?)"',t,re.DOTALL)
                        for i in city:
                            city=i
                            item['city'] = city
                            print(city)

                        state =re.findall('state" : "(.*?)"',t,re.DOTALL)
                        for i in state:
                            state=i
                            item['state'] = state
                            print(state)


                        zipcode =re.findall('zip" : "(.*?)"',t,re.DOTALL)
                        for i in zipcode:
                            zipcode=i
                            item['zip_code'] = zipcode
                            print(zipcode)


                        lat =re.findall('"lat" : "(.*?)"',t,re.DOTALL)
                        for i in lat:
                            lat=i
                            item['latitude'] = lat
                            print(lat)

                        lng =re.findall('"lng" : "(.*?)"',t,re.DOTALL)
                        for i in lng:
                            lng=i
                            item['longitude'] = lng
                            print(lng)


                        phone_number =re.findall('"phone" : "(.*?)"',t,re.DOTALL)
                        for i in phone_number:
                            phone_number=i
                            item['phone_number'] = phone_number
                            print(phone_number)



                        service=re.findall('hours" : "(.*?)"',t,re.DOTALL)
                        if ', ' in service:
                            service=service.replace(',','|')
                            for i in service:
                                service = i
                                item['services'] = service
                                print(storenumber)

                        for i in service:
                            service=i
                            item['services'] = service
                            print(service)


                            additional_info = {}

                            item['search_term'] = ''

                            item['fax_number'] =''
                            item['store_type'] = ''
                            item['website_address'] = ''
                            item['coming_soon'] = 0
                            item['country_code'] = item['country'] = 'US' #self.f1.country_dict.get(item['country'].lower())
                            item['email_address'] = ''
                            item['source_url']=response.url
                            item['store_hours'] = ''
                            item['additional_info'] = json.dumps(additional_info,ensure_ascii=False)
                            yield item
                            # browser.close()


                except Exception as e:
                    logging.log(logging.ERROR, e)
        else:
            pass


    def response_html_path(self, request):
        return request.meta['fpath']


# execute('''scrapy crawl store_189 -a list_id=189'''.split())