# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import random
import re


import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime

class Store116Spider(scrapy.Spider):
    name = 'store_116'
    allowed_domains = []


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()


    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            self.f1.set_details(self.list_id,run_date)
            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                print(search_terms)
            # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)
                search_terms = ''
                for search_term in (search_terms):
                    source_url = link = 'https://yafokitchen.com/'
                    file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(search_term) + '_' + str(run_date) + '.html'
                    if os.path.exists(file_path):
                        link = 'file://' + file_path.replace('\\','/')
                    yield scrapy.FormRequest(url=str(link), callback=self.get_store_list, meta={'source_url': source_url,'search_term': search_term,'file_path':file_path,'proxy_type': self.proxy_type})
            else:
                source_url = link = 'https://yafokitchen.com/'
                file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(run_date) + '.html'
                yield scrapy.FormRequest(url=str(link), callback=self.data,
                                         meta={'source_url': source_url,
                                               'file_path': file_path, 'proxy_type': self.proxy_type})
        except Exception as e:
            logging.log(logging.ERROR, e)


    def data(self, response):
        divs = response.xpath('//h2[@class="section-title text-center"]/..//div[@class="fbox"]')
        for div in divs:

            try:store_name = div.xpath('.//h3[@class="name"]/text()').extract_first()
            except Exception as e:print('store_name', e, response.url)

            address1 = div.xpath('.//address/text()').extract()

            address = address1[0].strip()

            city = address1[-1].split(',')[0].strip()

            data = address1[-1].split(',')[-1].split(' ')

            state = data[1].strip()

            zip_code = data[-1].strip()

            try:phone_number = div.xpath('./div[@class="phonenum"]/a/text()').extract_first(default='')
            except:phone_number = ''


            item = StoreLocatorsItem()
            item['search_term'] = 'link'
            item['store_name'] = store_name
            item['address'] = address
            item['city'] = city
            item['phone_number'] = phone_number
            item['coming_soon'] = 0
            item['state'] = state
            item['zip_code'] = zip_code
            item['country'] = 'USA'
            item['country_code'] = 'US'
            item['source_url'] = response.url
            yield item

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_116 -a list_id=116'''.split())