# -*- coding: utf-8 -*-
import scrapy,os,logging,hashlib
import requests,json,re
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime
import html2text
h = html2text.HTML2Text()

class YamahamotorsportsCrawlerSpider(scrapy.Spider):
    name = 'store_114'
    allowed_domains = []


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        types = ['ATVs','Motorcycles','Power Products - Sales','Power Products - Service','Power Products - Sales & Service','Race Kart Engines','Scooters','Side-by-Sides','Snowmobiles']
        try:
            self.f1.set_details(self.list_id,run_date)
            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                # print(search_terms)
            # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)
            #     search_terms = ['96701']
                for search_term in (search_terms):
                    # search_term='40223'
                    for type in types:
                        source_url = link = "https://www.yamahamotorsports.com/motorsports/locations/dealersearch"
                        head = {'Host': 'www.yamahamotorsports.com','User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept': '*/*','Accept-Language': 'en-GB,en;q=0.5','Accept-Encoding': 'gzip, deflate, br','Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8','X-Requested-With': 'XMLHttpRequest','Referer': 'https://www.yamahamotorsports.com/motorsports/locations/dealers'}
                        data = {'lat':'','lng':'','formatted_address':'','locationField':search_term,'locationProductLine':type}
                        file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(search_term) + '_' + str(run_date) + '.html'
                        if os.path.exists(file_path):
                            link = 'file://' + file_path.replace('\\','/')
                        yield scrapy.FormRequest(url=str(link), callback=self.get_store_list, headers=head, formdata=data,meta={'source_url': source_url,'search_term': search_term,'file_path':file_path,'proxy_type': self.proxy_type})
            else:
                source_url = link = ''
                file_path = ''
                yield scrapy.FormRequest(url=str(link), callback=self.get_store_list,
                                         meta={'source_url': source_url,'file_path': file_path,
                                               'proxy_type': self.proxy_type})
        except Exception as e:
            logging.log(logging.ERROR, e)

    # Get data from the response
    def get_store_list(self, response):
        try:
            if not response.url.startswith('file://'):
                self.f1.page_save(response.meta['file_path'],response.body)

            search_term = response.meta.get('search_term', '')
            source_url = response.meta.get('source_url', '')

            table_loop = response.xpath('//*[@class="locatorResultsListDealerTable locatorResultsListDealer-On"]')
            for lp in table_loop:
                add = lp.xpath('.//div[contains(@id,"dealerAddress_")]/text()').extract()
                add1 = add[-1].strip().split(',')
                id = lp.xpath('.//a[@class="dealerPhoneClick"]/@data-dealer').extract_first(default='').strip()
                name = lp.xpath('.//a[@class="locatorResultsHeaderLink"]/text()').extract_first(default='').strip()
                lat_lng = re.findall('AddPin\((.*?),\s+\''+name+'\'',response.body.decode('utf8'))[0].split(',')
                st_days = lp.xpath('.//td[contains(@class,"locatorResultsHoursDay")]/text()').extract()
                st_hours = lp.xpath('.//td[contains(@class,"locatorResultsHoursHour")]/text()').extract()
                store_hours = '|'.join([i +' '+ j for i, j in zip(st_days, st_hours)])
                phone = lp.xpath('.//a[@class="dealerPhoneClick"]/text()').extract_first(default='').strip().replace('-','.')
                ps = lp.xpath('.//span[@class="locatorCategory"]/img/@title').extract()
                if ps!=[]:
                    ps = '|'.join(ps)
                else:ps=''
                certi = lp.xpath('.//span[@class="locatorCertification"]//img/@title').extract()
                if certi!=[]:
                    certi = json.dumps({'Certifications':'|'.join(certi)})
                else:certi=''
                try:
                    item = StoreLocatorsItem()
                    item['store_number'] = id
                    item['store_name'] = name
                    item['address'] = add[0].strip()
                    item['address_line_2'] = ''
                    item['address_line_3'] = ''
                    item['city'] = add1[0].strip()
                    item['state'] = add1[-1].strip().split(' ')[0].strip()
                    item['zip_code'] = add1[-1].strip().split(' ')[-1].strip()
                    item['country'] = 'US'
                    item['country_code'] = 'US'
                    item['latitude'] = lat_lng[0].strip()
                    item['longitude'] = lat_lng[-1].strip()
                    item['store_hours'] = store_hours
                    item['phone_number'] = phone
                    item['products'] = ps
                    item['services'] = ps
                    item['website_address'] = response.url
                    item['additional_info'] = certi
                    yield item
                except Exception as e:
                    logging.log(logging.ERROR, e)
        except Exception as e:
            logging.log(logging.ERROR, e)

# execute('''scrapy crawl store_114 -a list_id=114'''.split())#-s HTTPCACHE_ENABLED=True