import re

import scrapy
import json
import requests as rr
# from scrapy.http import JSONRequest

from store_locators.spiders.common_functions import Func
from store_locators.items import StoreLocatorsItem
import datetime
import os

class StoreLocatoreSpider(scrapy.Spider):
    name = 'tysabri'
    f1 = Func()

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            source_url = link = 'https://www.tysabri.com/en_us/home/facts/treatment-locator.html'

            self.f1.set_details(self.list_id, run_date)
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(run_date) + '.html'
            if os.path.exists(file_path):
                link = 'file://' + file_path.replace('\\', '/')

            yield scrapy.FormRequest(url=str(link), callback=self.get_store_links, meta={'source_url': source_url,'file_path': file_path, 'proxy_type': self.proxy_type})

        except Exception as e:
            print(e)


    def get_store_links(self,response):

        states = response.xpath('//select[@name="state"]//option/text()').extract()
        for state in states:
            if 'State' in state:
                continue
            dataDr = {'domain':'www.tysabri.com',
                    'serviceType':'neuro',
                    'portal':'tysb',
                    'serviceTags':'biogen-systems:biogen-services/infusioncenter-service,biogen-systems:biogen-services/prescriber-service',
                    'state':state,
                    'treatmentLocator':'biogen-systems:biogen-services/prescriber-service'}

            data = {'domain':'www.tysabri.com',
                    'serviceType':'neuro',
                    'portal':'tysb',
                    'serviceTags':'biogen-systems:biogen-services/infusioncenter-service,biogen-systems:biogen-services/prescriber-service',
                    'state':state,
                    'treatmentLocator':'biogen-systems:biogen-services/infusioncenter-service'}

            headers = {'Accept':'*/*',
                    'Accept-Encoding':'gzip, deflate, br',
                    'Accept-Language':'en-US,en;q=0.9',
                    'Connection':'keep-alive',
                    'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8',
                    'CSRF-Token':'undefined',
                    'Host':'www.tysabri.com',
                    'Origin':'https://www.tysabri.com',
                    'Referer':'https://www.tysabri.com/en_us/home/facts/treatment-locator.html',
                    'Sec-Fetch-Mode':'cors',
                    'Sec-Fetch-Site':'same-origin',
                    'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36',
                    'X-Requested-With':'XMLHttpRequest'}

            link = "https://www.tysabri.com/bin/dxp/generic.json"
            try:
                # a = rr.post(link,headers=headers,data=data)
                yield scrapy.FormRequest(url=link,headers=headers,formdata=data,callback=self.InsideStore,meta={'ST':'Infusion centers'})
                yield scrapy.FormRequest(url=link, headers=headers,formdata=dataDr, callback=self.InsideStore,meta={'ST':'Doctors'})
            except Exception as e:
                print(e)


    def InsideStore(self,response):

        # if not response.url.startswith('file://'):
        #     self.f1.page_save(response.meta['file_path'], response.body)

        data = json.loads(response.text)
        try:
            data = data['prescriberLocators']
        except :
            data = data['InfusionCenters']

        for d in data:
            try:
                store_type = response.meta['ST']
                if 'Doctor' in store_type:
                    try:
                        store_name = d['firstName']+' '+d['lastName']
                    except :
                        store_name = ''

                    try:
                        address = d['address1']
                    except:
                        address = ''

                    try:
                        city = d['city']
                    except:
                        city = ''

                    try:
                        state = d['state']
                    except:
                        state = ''

                    try:
                        zip_code = d['postalCode']
                    except:
                        zip_code = ''

                    try:
                        phone_number = d['phoneNumber']
                    except:
                        phone_number = ''

                    try:
                        latitude = d['latitude']
                        longitude = d['longitude']
                    except:
                        latitude = ''
                        longitude = ''

                else:
                    try:
                        store_name = d['accountName']
                    except:
                        store_name = ''

                    try:
                        address = d['accountAddress']
                    except:
                        address = ''

                    try:
                        city = d['accountCity']
                    except:
                        city = ''

                    try:
                        state = d['accountState']
                    except:
                        state = ''

                    try:
                        zip_code = d['postalCode']
                    except:
                        zip_code = ''

                    try:
                        phone_number = d['accountPhone']
                    except:
                        phone_number = ''

                    try:
                        latitude = d['latitude']
                        if latitude == '':
                            latitude = 0
                        longitude = d['longitude']
                        if longitude == '':
                            longitude = 0
                    except:
                        latitude = 0
                        longitude = 0

                check = False
                for i in ['Unit', 'STE', 'Ste', 'Suite']:
                    for aw in address.split():
                        if i == aw:
                            address1 = address.split(i)[0].strip(',')
                            address_line_2 = i + ' ' + address.split(i)[-1].strip()
                            check = True
                            break
                if check == True:
                    address_line_2 = address_line_2
                    address = address1
                else:
                    address_line_2 = ''
                    address = address

                item = StoreLocatorsItem()
                item['store_type'] = store_type
                item['address'] = address.strip()
                item['address_line_2'] = address_line_2
                item['city'] = city.strip()
                item['state'] = state.strip()
                item['zip_code'] = zip_code.strip()
                item['country'] = 'United States'
                item['country_code'] = 'US'
                item['store_name'] = store_name
                item['phone_number'] = phone_number.strip()
                if latitude != '':
                    item['latitude'] = latitude
                if longitude != '':
                    item['longitude'] = longitude
                item['coming_soon'] = 0
                item['source_url'] = "https://www.tysabri.com/en_us/home/facts/treatment-locator.html"

                yield item
            except Exception as e:
                print("Problem in yield item",e)

# from scrapy.cmdline import execute
# execute('''scrapy crawl tysabri -a list_id=155 -s HTTPCACHE_ENABLED=False'''.split())
