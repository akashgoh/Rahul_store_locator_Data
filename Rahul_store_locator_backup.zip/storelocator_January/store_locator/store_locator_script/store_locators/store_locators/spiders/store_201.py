# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import re

import html2text
import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime


class SuperwashSpider(scrapy.Spider):
    name = 'superwash'
    allowed_domains = []

    def __init__(self, name=None, list_id="",proxy_type="",**kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type= list_id, proxy_type
        self.f1 = Func()

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            source_url = link = 'https://www.superwash.com/649-2/'
            self.f1.set_details(self.list_id, run_date)
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
                run_date) + '.html'
            if os.path.exists(file_path):
                link = 'file://' + file_path.replace('\\', '/')

            yield scrapy.FormRequest(url=str(link), callback=self.get_store_list,meta={'source_url': source_url,'file_path': file_path,'proxy_type': self.proxy_type})
        except Exception as e:
            print(e)


    def get_store_list(self,response):
        if not response.url.startswith('file://'):
            self.f1.page_save(response.meta['file_path'], response.body)
        source_url = response.meta.get('source_url', '')

        try:
            div = response.text.split('<td class="column-1"></td><td class="column-2"></td>')
            a = div[0]
            qs = []
            q = qs.append(a.split('<tbody class="row-hover">')[1].strip())
            del div[0]
            del div[170]
            div = div + qs
            # div = div[15:]
            for f in div:
                if f:
                    divs = re.sub(r'\s+',' ',str(f))

                    stname = re.findall(r'class="column-1">(.*?)</td>',str(divs))
                    storename = '(Superwash -' + stname[0] + ')'

                    address = re.findall(r'<td class="column-1">(.*?)</td>', str(divs))
                    address = address[1]

                    addinfo = re.findall(r'column-1">(.*?)</td>',str(divs))
                    addinfo = addinfo[-1]

                    item = StoreLocatorsItem()
                    item['store_name'] = storename.strip()
                    item['address'] = address.strip()
                    item['city'] = addinfo.split(',')[0]
                    item['state'] = addinfo.split(',')[1].split()[0]
                    item['zip_code'] = addinfo.split(',')[1].split()[1]
                    item['phone_number'] = ''
                    item['fax_number'] = ''
                    item['email_address'] = ''
                    item['store_type'] = ''
                    item['website_address'] = 'https://www.superwash.com/'
                    item['coming_soon'] = 0
                    item['store_number'] = ''
                    # if item['store_number'] == 8184:
                    #     pass

                    item['country'] = 'US'
                    item['source_url'] = 'https://www.superwash.com/649-2/'

                    item['country_code'] = 'US'
                    # print(item['state'])
                    if item['country_code'] == 'US' and len(item['state']) > 2:
                        item['state'] = self.f1.state_dict.get(item['state'].lower(), '')
                        # print('::,', item['state'])

                    item['store_hours'] = ''
                    add_info = dict()
                    add_info['distance'] = ''
                    add_info['thumb'] = ''
                    add_info['description'] = ''
                    item['additional_info'] = ''
                    yield item
                    # break

        except Exception as e:
            print(e)

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl superwash -a list_id=201 -s HTTPCACHE_ENABLED=True'''.split())