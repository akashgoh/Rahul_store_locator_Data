# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import random
import re

import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from w3lib.html import remove_tags

from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime


class Store140Spider(scrapy.Spider):
    name = 'store_140'
    allowed_domains = []


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()


    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]

        self.f1.set_details(self.list_id,run_date)
        if self.f1.search_by != 'link':
            search_terms = self.f1.get_search_term(self.f1.search_by)
            print(search_terms)
        # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)
            search_terms = ''
            for search_term in (search_terms):
                source_url = link = 'https://www.volvoce.com/africa/en-za/contact-us/dealer-locator/'
                file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(search_term) + '_' + str(run_date) + '.html'
                if os.path.exists(file_path):
                    link = 'file://' + file_path.replace('\\','/')
                yield scrapy.FormRequest(url=str(link), callback=self.data, meta={'source_url': source_url,'search_term': search_term,'file_path':file_path,'proxy_type': self.proxy_type})
        else:
            yield scrapy.Request(url='https://www.volvoce.com/africa/en-za/contact-us/dealer-locator/', callback=self.data)


    def data(self, response):
        text = response.text
        json_text = re.findall(r'<script id="dealerData" type="application/json">(.*?)</script>', text, re.DOTALL)[0].strip()
        data = json.loads(json_text)
        dealers = len(data['dealers'])
        for i in range(0,int(dealers)):

            store_name = data['dealers'][i]['name']

            address = data['dealers'][i]['streetAddress']

            try:address2 = data['dealers'][i]['streetAddress2']
            except:address2 = ''

            city = data['dealers'][i]['city']

            try:
                zip_code = data['dealers'][i]['postalCode']
                if zip_code == '-' or zip_code == '.' or zip_code == '---' or zip_code == '--':
                    zip_code = ''
            except:
                zip_code = ''

            try:
                phone_number = data['dealers'][i]['phoneNumber']
                if phone_number == '*':
                    phone_number = ''
            except:
                phone_number = ''

            try:fax_number = data['dealers'][i]['faxNumber']
            except:fax_number = ''

            try:email_address = data['dealers'][i]['emailAddress']
            except:email_address = ''

            try:website_address = data['dealers'][i]['homepageUrl']
            except:website_address = ''

            try:latitude = data['dealers'][i]['latitude']
            except:latitude = ''

            try:longitude = data['dealers'][i]['longitude']
            except:longitude = ''

            try:country_code = data['dealers'][i]['countryCode']
            except:country_code = ''

            try:country = data['dealers'][i]['countryName']
            except:country = ''

            item = StoreLocatorsItem()
            item['search_term'] = 'link'
            item['store_name']= store_name
            item['address'] = address
            item['address_line_2'] = address2
            item['city'] = city
            item['state'] = ''
            item['country'] = country
            item['country_code'] = country_code
            item['zip_code'] = zip_code
            item['phone_number'] = phone_number
            item['fax_number'] = fax_number
            item['email_address'] = email_address
            item['latitude'] = latitude
            item['longitude'] = longitude
            item['website_address'] = website_address
            item['coming_soon'] = 0
            item['source_url'] = response.url
            yield item


    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_140 -a list_id=140'''.split())
