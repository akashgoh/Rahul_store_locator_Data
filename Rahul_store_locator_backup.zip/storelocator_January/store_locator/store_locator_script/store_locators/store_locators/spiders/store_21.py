# -*- coding: utf-8 -*-
import scrapy,os,hashlib
import requests,json
import re
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime
from pprint import pprint as pp


class Store21Spider(scrapy.Spider):
    name = 'store_21'
    allowed_domains = []
    start_urls = ['https://www.afw.com/stores']
    domain = 'https://www.afw.com'


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()


    def parse(self, response):
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.f1.set_details(self.list_id, self.run_date)
        for url in response.xpath('//div[@class="sl-state-links-container"]/a/@href').getall():
            url = self.domain+url
            yield scrapy.FormRequest(url,callback=self.get_city_list)

    def get_city_list(self,response):
        links = response.xpath('//div[@class="sl-city-container row"]//a/@href').getall()
        for link in links:
            link = self.domain+link
            yield scrapy.FormRequest(url=link,callback=self.get_store_data)

    def get_store_data(self,response):
        xp1 = lambda x: response.xpath(x).get(default='')
        xp = lambda x: response.xpath(x).getall()
        item = StoreLocatorsItem()
        if response.url == 'https://www.afw.com/stores/co/lakewood':
            print(response)
            pass
        item['address'] = xp1('//div[@class="sl-store-address-1"]/text()')
        item['addressLine2'] = xp1('//div[@class="sl-store-address-2"]/text()')
        add2 = xp1('//div[@class="sl-store-city"]/text()')
        item['city'] = add2.split(',')[0]
        item['store_name'] =  xp1('//div[@class="sl-store-name"]/text()')+'-' +item['city']
        item['state'] = add2.split(',')[1].strip().split()[0]
        item['zip_code'] = add2.split(',')[1].strip().split()[1]
        item['latitude'] = response.text.split('latitude:')[1].split(',')[0]
        item['longitude'] = response.text.split('longitude:')[1].split('}')[0]
        item['source_url'] = response.url
        item['country'],item['country_code'] = 'USA','US'
        item['phone_number'] = response.xpath('//div[@class="sl-store-phone"]/text()').get(default='')
        lis = response.xpath('//ul[@class="sl-hours"]/li')
        hours = list()
        for li in lis:
            hours.append(re.sub('\n','',(' '.join(li.xpath('.//text()').getall()))).strip())
        item['store_hours'] = '|'.join(hours)

        add_info = dict()
        rdiv = response.xpath('//div[@class="sl-avg-review-stars"]')

        add_info['total_review'] = re.sub('\D','',rdiv.xpath('.//span[last()]/text()').get())

        add_info['avg_review_star'] = int(float(rdiv.xpath('count(.//span[@class="fas fa-star"])').get(default='0')))
        add_info['avg_review_star'] += 0.5 if rdiv.xpath('.//span[@class="fas fa-star-half-alt"]') else 0

        item['additional_info'] = json.dumps(add_info, ensure_ascii=False)

        yield item

# execute('''scrapy crawl store_21 -a list_id=21'''.split())


