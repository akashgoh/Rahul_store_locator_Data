# -*- coding: utf-8 -*-
import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime
import re
import html2text
h = html2text.HTML2Text()
run_date = str(datetime.datetime.today()).split()[0]

class YvesdelormeCrawlerSpider(scrapy.Spider):
    name = 'store_107'
    allowed_domains = []
    f1 = Func()
    not_export_data = False

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            source_url = link = 'https://france.yvesdelorme.com//plugincompany_storelocator/storelocation/storesjson/'
            head = {'Host': 'usa.yvesdelorme.com','User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept': 'application/json, text/javascript, */*; q=0.01','Accept-Language': 'en-GB,en;q=0.5','Accept-Encoding': 'gzip, deflate, br','X-Requested-With': 'XMLHttpRequest','Referer': 'https://usa.yvesdelorme.com/storelocator/store-finder.html'}
            self.f1.set_details(self.list_id, run_date)
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(run_date) + '.html'
            if os.path.exists(file_path):
                link = 'file://' + file_path.replace('\\', '/')
            yield scrapy.FormRequest(url=str(link), callback=self.get_store_list, headers=head, meta={'source_url': source_url,'file_path': file_path, 'proxy_type': self.proxy_type})
        except Exception as e:
            print(e)

    def get_store_list(self,response):
        if not response.url.startswith('file://'):
            self.f1.page_save(response.meta['file_path'], response.body)
        data = json.loads(response.text)
        for d in data:
            try:
                item = StoreLocatorsItem()
                item['store_number'] = d['entity_id'].strip()
                item['store_name'] = d['locname'].strip()
                item['address'] = d['address'].strip()
                item['address_line_2'] = d['address2'].strip()
                item['city'] = d['city'].strip()
                item['state'] = d['state'].strip()
                item['zip_code'] = d['postal'].strip()
                item['country'] = d['country'].strip()
                item['country_code'] = d['country'].strip()
                item['latitude'] = d['lat'].strip()
                item['longitude'] = d['lng'].strip()
                item['store_hours'] = h.handle(d['schedule']).replace('|','').replace('-','').replace('  ','').replace('\n','|').replace('||','').strip()
                item['email_address'] = d['email'].strip()
                item['phone_number'] = d['phone'].strip().replace('(','').replace(')','').replace('-',' ').replace(' ','.').strip()
                item['website_address'] = d['pageurl'].strip()
                item['source_url'] = 'https://france.yvesdelorme.com//plugincompany_storelocator/storelocation/storesjson/'
                yield item
            except Exception as e:
                logging.log(logging.ERROR, e)


# execute('''scrapy crawl store_107 -a list_id=107'''.split())#-s HTTPCACHE_ENABLED=True