# File for common functions
import pymysql
import pandas as pd
import pyap
import platform
import os
import time
import re

from store_locators.db_config import *
from store_locators.py2db import *
from geopy.geocoders import Nominatim


class Func:
    current_directory = os.path.dirname(os.path.abspath(__file__))
    current_directory = str(current_directory).split('store_locator_script')[0]
    if str(platform.system()).lower() == 'windows':
        html_link_directory = current_directory + 'html\\html_link_1\\'
        html_data_directory = current_directory + 'html\\html_data_1\\'
        output_directory = current_directory + 'output\\'+'January\\'+'Bank\\'
        static_directory = current_directory + 'static\\'
    else:
        html_link_directory = current_directory + 'html/html_link/'
        html_data_directory = current_directory + 'html/html_data/'
        output_directory = current_directory + 'output/'
        static_directory = current_directory + 'static/'

    if not os.path.exists(html_link_directory):
        os.makedirs(html_link_directory)
    if not os.path.exists(html_data_directory):
        os.makedirs(html_data_directory)
    if not os.path.exists(output_directory):
        os.makedirs(output_directory)
    # database connection
    try:
        con = pymysql.connect(db_host, db_user, db_password)
        cursor = con.cursor()
        cursor.execute('CREATE DATABASE IF NOT EXISTS ' + db_name+' CHARACTER SET UTF8MB4 COLLATE utf8mb4_general_ci')
        cursor.execute('SET GLOBAL local_infile = "ON";')
    except Exception as e:
        print(str(e))
    con = pymysql.connect(db_host, db_user, db_password, db_name,local_infile = 1)
    cursor = con.cursor()

    dcon = pymysql.connect(db_host, db_user, db_password, db_name, local_infile=1,
                           cursorclass = pymysql.cursors.DictCursor)
    dict_cursor = dcon.cursor()

    last_updated_date = list_id = list_name = country_codes = cc_id =''
    source_url = domain = developer_name = search_by = run_date = developer_email_id = ''
    db_list = list()

    # log file edition
    try:
        file_creation = os.path.getctime('log.txt')
        if file_creation < time.time() - 60 * 60 * 24 * int(7):
            open('log.txt','w')
    except FileNotFoundError as e:
        open('log.txt', 'w')

    def set_details(self,list_id,run_date):
        """Populate master table and Get details from the master table"""
        try:
            # zip_csv_local_file = f"{self.static_directory}master.csv"
            zip_csv_file = master_file
            df = pd.read_csv(zip_csv_file)
            self.cc_id = df['cc_id'][0]

            df1 = df.loc[df['list_id'] == int(list_id)]
            if (len(df1.index)) == 0:
                print(f'Your list id :{list_id} is not on sheet.')
                return
            "list_id	file_name	website_url	country_codes	search_by	developer_name	developer_email_id"
            master = df1.iloc[0, :].to_dict()
            up_sql = f"INSERT INTO {db_master_table} (list_id, file_name, website_url, country_codes, search_by, developer_name, developer_email_id)" \
                f" VALUES('{master.get('list_id','')}' , '{master.get('file_name','')}' , '{master.get('website_url','')}' , '{master.get('country_codes','')}' , '{master.get('search_by','')}' , '{master.get('developer_name','')}' , '{master.get('developer_email_id','')}') " \
                f"ON DUPLICATE KEY UPDATE file_name = '{master.get('file_name','')}' ,website_url = '{master.get('website_url','')}' ,country_codes = '{master.get('country_codes','')}' ,search_by = '{master.get('search_by','')}' ,developer_name = '{master.get('developer_name','')}' ,developer_email_id ='{master.get('developer_email_id','')}';"
            up_sql = up_sql.replace("'nan'",'0')

            self.cursor.execute(up_sql)
            self.con.commit()

            sql_get_master_details = ('select * from ' + db_master_table + " where list_id = '" + str(list_id) + "'")
            self.dict_cursor.execute(sql_get_master_details)
            results_source_url = self.dict_cursor.fetchone()
            if results_source_url:
                self.agg_data_count = master.get('agg_data_count','')
                # self.last_updated_date = results_source_url['last_updated_date']
                self.list_id = results_source_url['list_id']
                self.file_name = results_source_url['file_name']
                self.website_url = results_source_url['website_url']
                self.country_codes = results_source_url['country_codes'].split(',')
                self.search_by = results_source_url['search_by']
                self.developer_name = re.sub('\r|\t|\n','',results_source_url['developer_name'])
                self.developer_email_id = results_source_url['developer_email_id']
                self.run_date = run_date
                self.py2db()
            else:
                print(f'please populate master table with your list id : {list_id}')
        except Exception as e:
            print(str(e))

    def get_search_term(self,search_by):
        """ Getting the search term from log table"""
        # Populate zip table with csv file
        search_terms_list = list()
        c_code = list()
        for country_code in self.country_codes:
        # c_code.append(st_id)
        # for country_code in c_code:
            country_code = country_code.upper()
            try:
                get_count_zip = 'select count(*) from ' + db_zip_table + ' where country_code like "'+country_code + '%"'
                self.cursor.execute(get_count_zip)
                zip_count = self.cursor.fetchall()[0][0]
                if int(zip_count) == 0:
                    zip_csv_file = f"{self.static_directory}{country_code}_Zipcode.csv.csv".replace('\\', '/')
                    load_sql = "LOAD DATA LOCAL INFILE '"+zip_csv_file+"' INTO TABLE " + db_name + "." + db_zip_table + " FIELDS TERMINATED BY ',' ENCLOSED BY '\"'  IGNORE 1 LINES;"
                    self.cursor.execute(load_sql)
                    self.con.commit()
            except Exception as e:
                print(str(e))
            # zip table to log table
            try:
                get_count = "select count(*) from " + db_log_table + " where run_date = '" + str(self.run_date) \
                            + "' and list_id = '" + str(self.list_id) + "' and country_code = '" + country_code + "' "
                self.cursor.execute(get_count)
                log_count = self.cursor.fetchall()[0][0]

                if log_count == 0:
                    sql_get_details = f"select distinct({search_by}) from {db_zip_table} where country_code like '{country_code}%' "
                    # search_by = ','.join((search_by.split(',')))

                    # sql_get_details = ("select " + str(search_by) + ") from " + db_zip_table +
                    #                    " where country_code like '" + str(country_code) + "%'")
                    df_search = pd.read_sql(sql_get_details, self.con)
                    search_list = list(df_search[search_by])

                    df_search['search_term'] = search_list
                    df_search['list_id'] = self.list_id
                    df_search['country_code'] = country_code
                    df_search['number_of_store'] = '-1'
                    df_search['error_desc'] = ''
                    df_search['run_date'] = self.run_date
                    df_search['developer_name'] = self.developer_name
                    df_search.drop(columns=search_by, inplace=True)

                    df_search['country_code'] = df_search['country_code'].apply(lambda x: str.strip(str(x)))
                    df_search['search_term'] = df_search['search_term'].apply(lambda x: str.strip(str(x)))

                    df_search.to_csv('log_table.csv', header=True, encoding='utf-8', index=False)
                    load_sql = "LOAD DATA LOCAL INFILE 'log_table.csv' INTO TABLE " + db_name + "." + \
                               db_log_table + " FIELDS TERMINATED BY ',' ENCLOSED BY '\"'  IGNORE 1 LINES;"
                    self.cursor.execute(load_sql)
                    self.con.commit()
                    os.remove('log_table.csv')

                # sql_get_search_term = ("select distinct(search_term) from " + db_log_table +
                #                        " where run_date = '" + str(self.run_date) + "' and list_id = '"
                #                        + str(self.list_id) + "' and country_code = '" + str(country_code) +
                #                        "' and number_of_store < 0 " )
                sql_get_search_term = f"select distinct(search_term) from {db_log_table} where run_date = '{self.run_date}' and list_id = {self.list_id} and country_code = '{country_code}' and number_of_store < 0"


                # if int(st_id) == 1 :
                #     extra_sql = "ORDER BY search_term DESC LIMIT 50"
                # else:
                #     extra_sql = "LIMIT 50"
                # sql_get_search_term += extra_sql

                df_sql_get_search_term = pd.read_sql(sql_get_search_term, self.con)
                search_terms_list.extend(list(df_sql_get_search_term['search_term']))
            except Exception as e:
                print("Can't populate db_log_table  populary:" + str(e))
        return search_terms_list

    def update_log_table(self,search_term):
        """Update log table where search term have zero entries"""
        try:
            update_log = f"UPDATE {db_log_table}  set  number_of_store = {0},developer_name = '{self.developer_name}'" \
                f" where list_id = '{self.list_id}' and run_date = '{self.run_date}' and search_term = '{search_term}'"
            self.cursor.execute(update_log)
            self.con.commit()
        except Exception as e:
            print(str(e))

    def page_save(self,file_path,response):
        """Save page offline"""
        with open(file_path,'wb') as f:
            f.write(response)

    def py2db(self):
        """get values from py file to database (county code and state code)"""
        get_count_country_code = 'select count(*) from ' + db_country_table
        self.cursor.execute(get_count_country_code)
        zip_count = self.cursor.fetchall()[0][0]
        if int(zip_count) == 0:
            for d in contry_code_dict.items():
                try:
                    in_sql = f"insert into {db_country_table} (country_code,country_name) values('{d[1]}','{d[0]}')"
                    self.cursor.execute(in_sql)
                except Exception as e:
                    print(e)
            self.con.commit()

        get_count_zip = 'select count(*) from ' + db_us_state_table
        self.cursor.execute(get_count_zip)
        zip_count = self.cursor.fetchall()[0][0]
        if int(zip_count) == 0:
            for d in us_states_dict.items():
                in_sql = f"insert into {db_us_state_table} (state_code,state_name) values('{d[1]}','{d[0]}')"
                self.cursor.execute(in_sql)
            self.con.commit()

        sql_get_us_state = ('select * from ' + db_us_state_table)
        self.dict_cursor.execute(sql_get_us_state)
        results_source_url = self.dict_cursor.fetchall()
        state_dict = {}
        for state in results_source_url:
            state_dict[state['state_name']] = state['state_code']
        self.state_dict = state_dict

        sql_get_coutry_code = ('select * from ' + db_country_table)
        self.dict_cursor.execute(sql_get_coutry_code)
        results_source_url = self.dict_cursor.fetchall()
        country_dict = {}
        for country in results_source_url:
            country_dict[country['country_name']] = country['country_code']
        self.country_dict = country_dict

    def reverse_geo_code(self,lat,lng):
        geolocator = Nominatim(user_agent="specify_your_app_name_here")
        location = geolocator.reverse(f"{lat},{lng}")
        return location

    def get_data_from_zip(self,country_code,zip_code):
        """From zip code and country code it will provide all fields from zip_table.
        It will return a dictionary object"""
        sql = f"SELECT * FROM {db_zip_table} WHERE country_code like '{(country_code.upper())}%' and zip_code = '{zip_code}'"
        self.dict_cursor.execute(sql)
        return self.dict_cursor.fetchone()

    def get_data_from_zip_wo_cc(self,zip_code):
        """From zip code and country code it will provide all fields from zip_table.
        It will return a dictionary object"""
        sql = f"SELECT * FROM {db_zip_table} WHERE zip_code = '{zip_code}'"
        self.dict_cursor.execute(sql)
        return self.dict_cursor.fetchall()

    def get_country_from_code(self,mydict,search_key):
        """From Country code get country NAme"""
        return (list(mydict.keys())[list(mydict.values()).index(search_key)])

    def get_us_zip_code(self,state):
        """It will fetch records matching state name"""
        country_code = 'US'
        sql = f"SELECT zip_code FROM {db_zip_table} WHERE country_code like '{country_code}%' and state = '{state}'"
        self.cursor.execute(sql)
        zip_codes = [s[0] for s in self.cursor.fetchall()]
        return zip_codes

    def parse_address(self,raw_address,country='US'):
        """this will take address string as a input , will give dictionary as ouput if it can parse the address"""
        addresses = pyap.parse(raw_address, country=country)
        if addresses:
            add_dict = addresses[0].as_dict()
            address_dict = dict()
            address_dict['city'] = add_dict.get('city','')
            address_dict['state'] = add_dict.get('region1','')
            address_dict['zip_code'] = add_dict.get('postal_code','')
            address_dict['address_ln_1'] = add_dict.get('full_street','')
            address_dict['country_code'] = add_dict.get('country_id')
            return address_dict
        else:
            return None


    def get_us_state(self,city):
        pass



