# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import re
import pgeocode
import scrapy, os, logging, hashlib
import requests, json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime


class Store186Spider(scrapy.Spider):
    name = 'store_186'
    allowed_domains = []


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            self.f1.set_details(self.list_id, run_date)
            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                print(search_terms)
                # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)
                search_terms = ''
                for search_term in (search_terms):
                    source_url = link = 'https://16handles.com/locations/'
                    file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(search_term) + '_' + str(run_date) + '.html'
                    if os.path.exists(file_path):
                        link = 'file://' + file_path.replace('\\', '/')
                    yield scrapy.FormRequest(url=str(link), callback=self.get_store_list,
                                             meta={'source_url': source_url, 'search_term': search_term,
                                                   'file_path': file_path, 'proxy_type': self.proxy_type})
            else:
                source_url = link = 'https://www.thebeerstore.ca/stores/'
                file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(run_date) + '.html'
                yield scrapy.FormRequest(url=str(link), callback=self.firstlevel,
                                         meta={'source_url': source_url,
                                               'file_path': file_path, 'proxy_type': self.proxy_type})
        except Exception as e:
            logging.log(logging.ERROR, e)

    def firstlevel(self, response):
        try:
            source_url = response.meta['source_url']
            file_path = response.meta['file_path']
            proxy_type = response.meta['proxy_type']
            divs = response.xpath('//*[@class="col-lg-12 col-md-12 col-sm-12 new_store_box_container"]/div')
            for div in divs:
                address = div.xpath('.//*[@class="about_store_detail"]/ul/li[1]/a/text()').extract_first().strip()
                zip = div.xpath('.//*[@class="about_store_detail"]/ul/li[2]/a/text()').extract_first().strip().split(',')[-1].strip()
                city = div.xpath('.//*[@class="about_store_detail"]/ul/li[2]/a/text()').extract_first().strip().split(',')[0].strip()
                store_link = div.xpath('.//*[contains(text(),"STORE DETAILS")]/@href').extract_first().strip()
                yield scrapy.FormRequest(url=store_link, callback=self.get_store_list,
                                         meta={'source_url': source_url, 'file_path': file_path,
                                               'proxy_type': proxy_type, 'address': address, 'zip': zip, 'city': city})
        except Exception as e:
            print("firstlevel", e, response.url)

    # Get data from the response
    def get_store_list(self, response):
        try:
            if not response.url.startswith('file://'):
                self.f1.page_save(response.meta['file_path'], response.body)
            search_term = response.meta.get('search_term', '')
            try:
                item = StoreLocatorsItem()
                try:
                    store_name = response.xpath('//*[@class="top_sectionDiv"]/h2/text()').extract_first().strip()
                except Exception as e:
                    print("store_name", e, response.url)

                try:
                    phone_number = response.xpath('//*[@class="tel-hl-tbs"]/text()').extract_first().strip()
                except Exception as e:
                    print("phone_number", e, response.url)

                try:
                    address_detail = address = response.meta['address'].strip(',')
                    address_line_2 = ''
                    for i in ['unit', 'suite', 'suit', 'ste']:
                        for aw in address_detail.split(' '):
                            if i.title() == aw:
                                address = address_detail.split(i.title())[0].strip()
                                address_line_2 = i.title() + ' ' + address_detail.split(i.title())[-1].strip()
                                break
                except Exception as e:
                    print("address", e, response.url)

                try:
                    city = response.meta['city']
                except Exception as e:
                    print("city", e, response.url)

                try:
                    zip_code = response.meta['zip']
                except Exception as e:
                    print("zip_code", e, response.url)

                try:
                    nomi = pgeocode.Nominatim('ca')
                    state = nomi.query_postal_code(str(zip_code[0:3]+' '+zip_code[4:-1])).state_code
                    if not state:
                        state = ''
                except Exception as e:
                    state = ''
                    print("state", e, response.url)

                try:
                    latlong = re.findall(r'center=(.*?)&',response.xpath('//*[@id="beerStoreMap"]/a/img/@src').extract_first())[0].split(',')
                    latitude = latlong[0]
                    longitude = latlong[-1]
                except Exception as e:
                    print("latitude and longitude", e, response.url)

                try:
                    store_hours = []
                    hour_data = response.xpath('//*[@class="rite_col"]/table//tr')
                    del hour_data[0]
                    for tr in hour_data:
                        key = tr.xpath('.//td//text()').extract_first(default='').strip().replace('\n','').replace('\t','')
                        value = tr.xpath('.//td[2]//text()').extract_first(default='').strip().replace('\n','').replace('\t','')
                        store_hours.append(f'{key}:{value}')
                    store_hours = '|'.join(store_hours)
                except Exception as e:
                    print("store_hours", e, response.url)
                try:
                    store_number = re.findall(r'(\d+)',response.xpath('//*[@class="top_sectionDiv"]/p/text()').extract_first())[0]
                except Exception as e:
                    print("store_number", e, response.url)

                item['search_term'] = search_term
                item['store_name'] = store_name
                item['address'] = address
                item['address_line_2'] = address_line_2
                item['city'] = city
                item['state'] = state
                item['zip_code'] = zip_code
                item['phone_number'] = phone_number
                item['latitude'] = latitude
                item['longitude'] = longitude
                item['store_type'] = ''
                item['coming_soon'] = 0
                item['store_number'] = store_number
                item['source_url'] = response.url
                item['country_code'] = item['country'] = 'CA'  # self.f1.country_dict.get(item['country'].lower())
                item['store_hours'] = store_hours.strip('|')
                if item['country_code'] == 'US' and len(item['state']) > 2:
                    item['state'] = self.f1.state_dict.get(state, '')
                yield item
            except Exception as e:
                print(e)

        except Exception as e:
            logging.log(logging.ERROR, e)

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_186 -a list_id=186 -a proxy_type=storm_proxy'''.split())