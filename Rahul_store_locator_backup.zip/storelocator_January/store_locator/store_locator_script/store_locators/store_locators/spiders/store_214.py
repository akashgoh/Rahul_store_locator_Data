# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import re
import urllib

import pymysql as MySQLdb
import html2text
import scrapy,os,logging,hashlib
import requests,json
from geopy import Nominatim
from lxml import html
from scrapy.http import HtmlResponse, JSONRequest
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func, contry_code_dict
import datetime
                                  # Waiting function

class store_214Spiders(scrapy.Spider):
    name = 'store_214'
    allowed_domains = []

    not_export_data = True

    def __init__(self, name=None, list_id="", proxy_type="",a='',b='', **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.f1.set_details(self.list_id, self.run_date)
        self.a = a
        self.b = b

    def start_requests(self):

        try:

            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                connection = MySQLdb.connect("192.168.1.113", "root", "xbyte", "store_locator_june", charset='utf8')
                cursor = connection.cursor()
                cursor.execute("set names utf8;")
                sql = ("Select lat_lng from zip_table")
                cursor.execute(sql)
                results = cursor.fetchall()
                search_terms = results[int(self.a):int(self.b)]
                print(len(search_terms))
                print(len(search_terms))
                # search_terms = search_terms[int(self.a):int(self.b)]
                # print(len(search_terms))
                for search_term in search_terms:
                    lat = search_term[0].split("_")[0]
                    lng = search_term[0].split("_")[1]
                    source_url = "https://www.stihl.fi/api/Dealerlocator/GetDealersDDH"
                    # source_url = link = 'https://www.stihl.fi/controls/AjaxBridge.aspx/DealerUtils_GetDealersY15'
                    payload = {"lat":lat,"lng":lng,"attributes":"","address":"","modeluid":'',"SOPFlag":'',"eap":False,"dealersPagingStart":0}
                    file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(search_term) + '_' + str(self.run_date) + '.html'
                    if os.path.exists(file_path):
                        link = 'file://' + file_path.replace('\\','/')
                    yield JSONRequest(url=source_url, callback=self.parse,data=payload, meta={'source_url': source_url,'lat':lat,'lng':lng,'search_term': search_term,'file_path':file_path,'proxy_type': self.proxy_type})
            else:
                file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
                    self.run_date) + '.html'
                source_url = link = 'https://www.amtrak.com/sitemap.xml'
                yield scrapy.FormRequest(url=str(link), callback=self.parse,
                                         meta={'file_path': file_path, 'proxy_type': self.proxy_type},dont_filter=True)
        except Exception as e:
            logging.log(logging.ERROR, e)


    def parse(self, response):
        try:
            lat = response.meta['lat']
            lng = response.meta['lng']
            file_path = response.meta['file_path']

            try:
                data = urllib.parse.unquote(response.text)
                d = json.loads(data)
            except Exception as e:
                print("problem in json load  in parse")

            if d[0]['DealersPagingStart'] == 0:
                totaldata = d[0]['DealersTotal']

                pages = int(totaldata/20)
                others = totaldata%20
                if others>0:
                    pages = pages+1
                else:
                    pages = pages

            for i in range(0,int(pages)):
                # lat = search_term.split("_")[0]
                # lng = search_term.split("_")[1]
                source_url = "https://www.stihl.fi/api/Dealerlocator/GetDealersDDH"
                payload = {"lat": lat, "lng": lng, "attributes": "", "address": "", "modeluid": '', "SOPFlag": '',
                           "eap": False, "dealersPagingStart": i}

                yield JSONRequest(url=source_url, callback=self.get_store_list, data=payload,dont_filter=True,
                                  meta={'search_term': '', 'file_path': file_path,
                                        'proxy_type': self.proxy_type})
        except Exception as e:
            print("parse",e,response.url)

    def get_store_list(self, response):
        try:
            if not response.url.startswith('file://'):
                self.f1.page_save(response.meta['file_path'],response.body)

            try:
                data = urllib.parse.unquote(response.text)
                d = json.loads(data)

                le = len(d)
                for i in range(0,le):

                    try:
                        response_properties = HtmlResponse(body=d[i]['properties'].encode("utf-8"),url='')
                        # source_url = "https://www.stihl.fi/"+response_properties.xpath('//div[@class="address_data"]/h4/a/@href').extract_first().replace(' ','%20').strip()
                    except Exception as e:
                        print("source_url", e)

                    try:
                        store_name = response_properties.xpath('//h3//text()').extract_first().strip()
                    except Exception as e:
                        print("store_name",e)

                    try:
                        latitude = d[i]['lat']
                    except Exception as e:
                        print("latitude", e)


                    try:
                        longitude = d[i]['lng']
                    except Exception as e:
                        print("longitude", e)

                    try:
                        phone_number = response_properties.xpath('//a[@class="phone"]/text()').extract_first().strip()
                    except Exception as e:
                        print("phone_number",e)

                    try:
                        addresstmp = response_properties.xpath('//address/p/text()').extract()
                        if len(addresstmp)>=1:
                            address = addresstmp[0]
                            cityzipcode = addresstmp[1]
                            zipcode = re.findall('(\d{5})', cityzipcode)[0]
                            city = cityzipcode.replace(zipcode,'').strip()

                        else:
                            address= ''
                            city = ''
                            zipcode = ''
                    except Exception as e:
                        print("address", e)

                    try:
                        email_address = response_properties.xpath('//a[@class="email"]/@href').extract_first()
                        if email_address==None:
                            email_address = ''
                        else:
                            email_address = email_address.replace('mailto:','').replace('?subject=','').strip()
                    except Exception as e:
                        print("email_address",e)


                    try:
                        additional_info = {}
                        # Valikoima = '|'.join(response_properties.xpath('//div[@class="small_icons"]/img/@title').extract())
                        # additional_info['Valikoima'] = Valikoima
                    except Exception as e:
                        print("additional_info",e,response.url)



                    item = StoreLocatorsItem()
                    item['search_term'] = 'lat_lng'
                    item['store_name']= store_name
                    item['address'] = address
                    item['city'] = city
                    item['state'] =''
                    item['zip_code'] = zipcode
                    item['phone_number'] =phone_number
                    item['latitude'] = latitude
                    item['longitude'] = longitude
                    item['store_type'] = ''
                    item['website_address'] = ''
                    item['coming_soon'] = 0
                    item['store_number'] = ''
                    item['country_code'] = item['country'] = 'FI' #self.f1.country_dict.get(item['country'].lower())
                    item['email_address'] = email_address
                    item['services'] = ''
                    item['source_url']= response.url
                    item['fax_number'] = ''
                    item['store_hours'] = ''
                    item['additional_info'] = json.dumps(additional_info)


                    yield item
            except Exception as e:
                print("getstorelist",e)

        except Exception as e:
            logging.log(logging.ERROR, e)

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_214 -a list_id=214 -a a=1 -a b=3500'''.split())
