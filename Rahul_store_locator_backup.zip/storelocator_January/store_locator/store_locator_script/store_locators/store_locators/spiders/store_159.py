# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import re
import urllib
import time
from selenium import webdriver

import scrapy,os,logging,hashlib
import requests,json
from lxml import html
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime
from selenium import webdriver                    # Import module
from selenium.webdriver.common.keys import Keys
import time
import pymysql as MySQLdb
from selenium.webdriver.firefox.options import Options


class store_159Spider(scrapy.Spider):
    name = 'store_159'
    allowed_domains = []
    FIREFOX_GOCKO_DRIVER_PATH = "D:\\geckodriver"

    def __init__(self, name=None, list_id="", proxy_type="",a="",b="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.a = a
        self.b = b


    def start_requests(self):
        self.f1.set_details(self.list_id, self.run_date)

        try:
            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                print(search_terms)
                search_terms = ''
                for search_term in (search_terms):
                    source_url = link = 'https://stretchlab.com/locations/'
                    file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(search_term) + '_' + str(self.run_date) + '.html'
                    if os.path.exists(file_path):
                        link = 'file://' + file_path.replace('\\','/')
                    # yield scrapy.FormRequest(url=str(link), callback=self.get_store_list, meta={'source_url': source_url,'search_term': search_term,'file_path':file_path,'proxy_type': self.proxy_type})
            else:
                url = "https://swissfarms.com/about-us/store-locator/"
                yield scrapy.FormRequest(url=str(url), callback=self.get_store_list)

        except Exception as e:
            print("start_request",e)

    def get_store_list(self,response):
        try:

            path = "E:\\store_tsutsya_pages\\"
            pages = os.listdir(path)
            # partlist = pages[int(self.a):int(self.b)]
            print(len(pages))
            for i in range(0, len(pages)):
                pathurltmp = pages[i]
                htmlpath = path + pages[i]



                with open(htmlpath, 'rb') as f:
                    pagesrc = f.read().decode('utf8')


                    response1 = HtmlResponse(body=pagesrc.encode("utf-8"), url='')
                    id = re.findall('cator/detail/map.html\?storeId=(.*?)"', response1.text)
                # if len(id)>=1:

                    try:
                        storelink = "https://store-tsutaya.tsite.jp/storelocator/detail/" + str(id[0])
                    except Exception as e:
                        print("storelink", e, storelink)

                    try:
                        address = ' '.join(
                            response1.xpath('//dt[contains(text(),"住所")]/following-sibling::dd[1]/text()').extract())
                    except Exception as e:
                        print("address", e, storelink)

                    try:
                        zipcode = re.findall('〒(.*?)\s', address)[0]
                    except Exception as e:
                        print("zipcode", e, storelink)

                    try:
                        store_name = response1.xpath('//div[@class="title clearfix"]//span/text()').extract_first()
                    except Exception as e:
                        print("store_name", e, storelink)

                    try:
                        address = address.replace(zipcode, '').strip()
                    except Exception as e:
                        print("address", e, storelink)

                    try:
                        store_hours = ''.join(
                            response1.xpath('//dt[contains(text(),"営業時間")]/following-sibling::dd[1]/text()').extract())
                        # store_hours = re.findall('(朝.*?～深夜.*?)</dd>', response1.text)[0]
                    except Exception as e:
                        print("store_hours", e, storelink)

                    try:
                        services = "|".join(response1.xpath('//ul[@class="acceptService"]/li/a/text()').extract())
                    except Exception as e:
                        print("services", e, storelink)

                    try:
                        phone_number = response1.xpath(
                            '//*[contains(text(),"電話番号")]//following-sibling::dd[1]//text()').extract_first()
                    except Exception as e:
                        print("phone_number", e, storelink)

                    try:
                        fax_number = response1.xpath(
                            '//*[contains(text(),"FAX番号")]//following-sibling::dd[1]//text()').extract_first()
                    except Exception as e:
                        print("fax_number", e, storelink)

                    try:
                        additional_info = {}
                        parking = response1.xpath(
                            '//*[contains(text(),"駐車場")]//following-sibling::dd[1]//text()').extract_first()
                        if parking == None:
                            additional_info = {}
                        else:
                            additional_info['駐車場'] = parking
                    except Exception as e:
                        print("additional_info", e, storelink)

                    item = StoreLocatorsItem()
                    item['search_term'] = ''
                    item['store_name'] = store_name
                    item['address'] = address
                    item['city'] = ''
                    item['state'] = ''
                    item['zip_code'] = zipcode
                    item['phone_number'] = phone_number
                    item['fax_number'] = fax_number
                    item['latitude'] = ''
                    item['longitude'] = ''
                    item['store_type'] = ''
                    item['website_address'] = ''
                    item['coming_soon'] = 0
                    item['store_number'] = ''
                    item['country_code'] = item['country'] = 'JP'  # self.f1.country_dict.get(item['country'].lower())
                    item['email_address'] = ''
                    item['services'] = services
                    item['source_url'] = storelink
                    item['store_hours'] = store_hours
                    item['additional_info'] = json.dumps(additional_info, ensure_ascii=False)
                    yield item


        except Exception as e:
            print("parse",e)


# execute('''scrapy crawl store_159 -a list_id=159'''.split())

# options = Options()
# options.add_argument("--headless")
# browser = webdriver.Firefox(executable_path=self.FIREFOX_GOCKO_DRIVER_PATH, firefox_options=options)
# browser.get('storelink')  # 1
# time.sleep(20)

# def parse(self, response):
#     try:
#         file_path =response.meta['file_path']
#         links = response.xpath('//div[@class="usualList01_a"]//a/@href').extract()
#         for link in links:
#             link = "https://as.chizumaru.com"+link
#             yield scrapy.FormRequest(url=link,callback=self.get_store_list,meta={'dont_redirect': True,
#                                              'file_path': file_path})
#     except Exception as e:
#         print("parse",e,response.url)

# def get_store_list(self, response):
#     try:
#         if not response.url.startswith('file://'):
#             self.f1.page_save(response.meta['file_path'], response.body)


# divs = response.xpath('//table[@summary="店舗情報"]')
# for div in divs:
#     storelink = div.xpath('.//tr[1]/td[1]/a/@href').extract_first()
#     storename = div.xpath('.//tr[1]/td[1]/a/text()').extract_first()
#     adresshourstext = " ".join(div.xpath('.//tr[2]//text()').extract())
#     adresshourstext = re.sub('\s+', ' ', re.sub('\r|\n|\t', ' ', adresshourstext))
#     address = re.findall('住所 ：(.*?)営業時間', adresshourstext)[0]
#     storehours = re.findall('営業時間 ： (.*?～.*?00)', adresshourstext)[0]
#     options =''
#     options = Options()
#     options.add_argument("--headless")
#     browser = webdriver.Firefox(executable_path=self.FIREFOX_GOCKO_DRIVER_PATH, firefox_options=options)
#     browser.get(storelink)  # 1
#     time.sleep(20)
#     pagesrc = browser.page_source
#     response1 = HtmlResponse(body=pagesrc.encode("utf-8"), url='')
#         path = "D:\\stutsya\\second\\"
#         pages = os.listdir(path)
#         print(len(pages))
#         for k in range(0, 1):
#             htmlpath = path + pages[k]
#             with open(htmlpath, 'rb') as f:
#                 pagesrc = f.read().decode('utf8')
#                 response1 = HtmlResponse(url="", body=pagesrc, encoding='utf-8')
#
#                 try:
#                     id = re.findall('cator/detail/map.html\?storeId=(.*?)"',response1.text)[0]
#                     storelink = "https://store-tsutaya.tsite.jp/storelocator/detail/"+str(id)
#                 except Exception as e:
#                     print("storelink",e,storelink)
#
#                 try:
#
#                     address = ' '.join(response1.xpath('//dt[contains(text(),"住所")]/following-sibling::dd[1]/text()').extract())
#                 except Exception as e:
#                     print("address",e,storelink)
#
#                 try:
#                     zipcode = re.findall('〒(.*?)\s',address)[0]
#                 except Exception as e:
#                     print("zipcode",e,storelink)
#
#                 try:
#                     store_name = response1.xpath('//div[@class="title clearfix"]//span/text()').extract_first()
#                 except Exception as e:
#                     print("store_name", e,storelink)
#
#                 try:
#                     address = address.replace(zipcode,'').strip()
#                 except Exception as e:
#                     print("address", e, storelink)
#
#                 try:
#                     store_hours = ''.join(response1.xpath('//dt[contains(text(),"営業時間")]/following-sibling::dd[1]/text()').extract())
#                     # store_hours = re.findall('(朝.*?～深夜.*?)</dd>', response1.text)[0]
#                 except Exception as e:
#                     print("store_hours",e,storelink)
#
#                 try:
#                     services = "|".join(response1.xpath('//ul[@class="acceptService"]/li/a/text()').extract())
#                 except Exception as e:
#                     print("services",e,storelink)
#
#                 try:
#                     phone_number = response1.xpath('//*[contains(text(),"電話番号")]//following-sibling::dd[1]//text()').extract_first()
#                 except Exception as e:
#                     print("phone_number",e,storelink)
#
#                 try:
#                     fax_number =  response1.xpath('//*[contains(text(),"FAX番号")]//following-sibling::dd[1]//text()').extract_first()
#                 except Exception as e:
#                     print("fax_number", e,storelink)
#
#                 try:
#                     additional_info = {}
#                     parking = response1.xpath('//*[contains(text(),"駐車場")]//following-sibling::dd[1]//text()').extract_first()
#                     if parking == None:
#                         additional_info = {}
#                     else:
#                         additional_info['駐車場'] = parking
#                 except Exception as e:
#                     print("additional_info",e,storelink)
#
#                 item = StoreLocatorsItem()
#                 item['search_term'] = ''
#                 item['store_name']= store_name
#                 item['address'] = address
#                 item['city'] = ''
#                 item['state'] =''
#                 item['zip_code'] = zipcode
#                 item['phone_number'] =phone_number
#                 item['fax_number'] =fax_number
#                 item['latitude'] = ''
#                 item['longitude'] = ''
#                 item['store_type'] = ''
#                 item['website_address'] = ''
#                 item['coming_soon'] = 0
#                 item['store_number'] = ''
#                 item['country_code'] = item['country'] = 'JP' #self.f1.country_dict.get(item['country'].lower())
#                 item['email_address'] = ''
#                 item['services'] = services
#                 item['source_url']=storelink
#                 item['store_hours'] = store_hours
#                 item['additional_info'] = json.dumps(additional_info,ensure_ascii=False)
#                 yield item
#     except Exception as e:
#         print("problem in stores",e,storelink)
#
# def response_html_path(self, request):
#     return request.meta['fpath']
