# -*- coding: utf-8 -*-
import scrapy,os,hashlib
import requests,json
import re
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime
from pprint import pprint as pp


class Store22Spider(scrapy.Spider):
    name = 'store_22'
    allowed_domains = []
    start_urls = ['https://americanhaircuts.com']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()


    def parse(self, response):
        run_date = str(datetime.datetime.today()).split()[0]
        self.f1.set_details(self.list_id, run_date)
        links = response.xpath('//nav[@id="mainNavigation"]//div[@class="collection"]/a/@href').getall()[:5]
        for link in links:
            url = self.start_urls[0]+link
            yield scrapy.FormRequest(url=url, callback=self.get_store_data)

    def get_store_data(self,response):
        try:
            store = json.loads(response.xpath('//div[@class="sqs-block map-block sqs-block-map"]/@data-block-json').get())['location']
            item = StoreLocatorsItem()
            item['store_name'] = response.xpath('//h1//text()').get(default='')
            if not item['store_name']:
                item['store_name'] = response.xpath('//h2//text()').get(default='')
            if 'coming soon' in item['store_name'].lower():
                item['coming_soon'] = 1
            item['longitude'] = store.get('mapLng', '')
            item['latitude'] = store.get('mapLat', '')
            item['source_url'] = response.url
            street_addres = item['address'] = store.get('addressLine1')

            address_split_params = ('unit ', 'suit ', 'ste ', 'suite ', 'units ', 'ste. ')
            for address_split_param in address_split_params:
                if address_split_param in (street_addres.lower()):
                    item['address'] = (item['address'].lower()).split(address_split_param)[0]
                    item['address_line_2'] = f"{address_split_param} {((street_addres.lower()).split(address_split_param)[1])}"
                    break
            item['city'] = store.get('addressLine2','').split(',')[0]
            item['state'] = store.get('addressLine2','').split(' ')[1]
            item['zip_code'] = store.get('addressLine2','').split(' ')[-1]
            item['store_hours'] = ('|'.join(response.xpath('//p[contains(text(),"Monday-")]/text()').getall())).replace('\xa0','')
            services = response.xpath('//h3/strong')
            services_list = list()
            for s in services:
                services_list.append(' '.join(s.xpath('.//text()').getall()))
            item['services'] = '|'.join(services_list)
            item['country'] = item['country_code'] = 'US'
            phn_xp = f"//p[contains(text(),'{(item['address'])}')]/text()[position()=last()]"
            phone = (response.xpath(phn_xp).get(default='')).replace('-', '')
            item['phone_number'] = phone if phone.isdigit() else ''
            yield item
        except Exception as e:
            print(e)

# execute('''scrapy crawl store_22 -a list_id=22'''.split())
