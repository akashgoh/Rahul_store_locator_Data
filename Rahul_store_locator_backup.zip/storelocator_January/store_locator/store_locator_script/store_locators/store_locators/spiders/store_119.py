# # -*- coding: utf-8 -*-
# # pip install scrapy-html-storage
# import random
# import re
#
#
# import scrapy,os,logging,hashlib
# import requests,json
# from scrapy.http import HtmlResponse
# from scrapy.cmdline import execute
#
# from store_locators.items import StoreLocatorsItem
# from store_locators.spiders.common_functions import Func
# import datetime
#
#
# from selenium import webdriver
# from selenium.webdriver.chrome.options import Options
# chrome_options = Options()
# # chrome_options.add_argument("--headless")
# chrome_driver ="D:\\nishant\\chromedriver.exe"
#
# class Store119Spider(scrapy.Spider):
#     name = 'store_119'
#     allowed_domains = []
#
#
#     def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
#         super().__init__(name, **kwargs)
#         self.list_id, self.proxy_type = list_id, proxy_type
#         self.f1 = Func()
#
#
#     def start_requests(self):
#         run_date = str(datetime.datetime.today()).split()[0]
#         try:
#             self.f1.set_details(self.list_id,run_date)
#             if self.f1.search_by != 'link':
#                 search_terms = self.f1.get_search_term(self.f1.search_by)
#                 print(search_terms)
#             # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)
#                 search_terms = ''
#                 for search_term in (search_terms):
#                     source_url = link = 'https://www.worten.pt/lojas-worten'
#                     file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(search_term) + '_' + str(run_date) + '.html'
#                     if os.path.exists(file_path):
#                         link = 'file://' + file_path.replace('\\','/')
#                     yield scrapy.FormRequest(url=str(link), callback=self.firstlevel, meta={'source_url': source_url,'search_term': search_term,'file_path':file_path,'proxy_type': self.proxy_type})
#             else:
#                 source_url = link = 'https://www.worten.pt/lojas-worten'
#                 driver = webdriver.Chrome(chrome_options=chrome_options, executable_path=chrome_driver)
#                 driver.get(link)
#                 driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
#                 response = HtmlResponse(url=driver.current_url, body=driver.page_source.encode('utf8'))
#                 driver.quit()
#                 # headers = {
#                 #     'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
#                 #     'accept-encoding': 'gzip, deflate, br',
#                 #     'accept-language': 'en-US,en;q=0.9',
#                 #     'cache-control': 'no-cache',
#                 #     'cookie': '__cfduid=d3e77fe40b3b4e64f0e8d5f4ed73aec6a1607944782; mg_login=true; mg_get_address=true; mg_get_user=true; sales_features=air_conditioning; shipping_gateway=true; shipping_gateway_v1=true; cart_wishlist=true; product_share_v2=true; is_sced_feature_active=true; is_long_tail_items_active=true; _ALGOLIA=anonymous-dbbca4c5-2c3f-4b67-b1cf-2238eae7854b; CookieConsent={stamp:%27ySFaKwZTP1Y3uDljXL19GJEmNlucDn7ULaZcdKq1iVr8Gf4A57xlug==%27%2Cnecessary:true%2Cpreferences:true%2Cstatistics:true%2Cmarketing:true%2Cver:1%2Cutc:1607944857673%2Cregion:%27in%27}; _fbp=fb.1.1607944859148.820407287; kk_leadtag=true; wpn_https={"last_shown":"Mon, 14 Dec 2020 11:20:59 GMT","shown_count":1}; _clck=16l2tnm; _vz=viz_5fd74a9d96964; _gcl_au=1.1.761870498.1608700896; t2s-p=5e6a270c-dc6b-40bc-a900-6ed45e97dbcb; cf_chl_prog=a37; cf_clearance=83f27bac0cb988a3efc1bb7448a04eb991e790b3-1609129042-0-250; sts=119dfec3eee390fb644a264572fdd7f671ed1fe34cc596b26a6ed1295ff6f819; _gid=GA1.2.343182396.1609129048; facetsv2=true; wpn_https={"status":"denied","last_shown":"Mon, 28 Dec 2020 04:31:23 GMT","shown_count":1}; _uetsid=98d1728048c311ebbe65153dad1941bd; _uetvid=70d571403dfe11eb855299be95b835ca; _ga_WM5ETPQSYP=GS1.1.1609129046.4.1.1609129946.0; _ga=GA1.1.1601328215.1607944853',
#                 #     'pragma': 'no-cache',
#                 #     'upgrade-insecure-requests': '1',
#                 #     'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'
#                 # }
#
#                 # response = requests.request("GET", url, headers=headers, data=payload)
#
#                 # print(response.text)
#
#                 file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(run_date) + '.html'
#                 yield scrapy.FormRequest(url=str(link), callback=self.firstlevel,
#                                          meta={'source_url': source_url, 'file_path': file_path, 'proxy_type': self.proxy_type})
#         except Exception as e:
#             logging.log(logging.ERROR, e)
#
#
#     def firstlevel(self,response):
#         links = response.xpath('//section[@class="w-section__wrapper"]/section//a[@class="w-button-secondary w-store__btn"]/@href').extract()
#         for link in links:
#             yield scrapy.Request(url='https://www.worten.pt'+link, callback=self.data)
#             # yield scrapy.Request(url='https://www.worten.pt/lojas/worten-braga-1037', callback=self.data)
#
#
#     def data(self, response):
#         try:store_name = response.xpath('//h3[@class="w-store__name"]//text()').extract_first().strip()
#         except Exception as e:print('store_name', e, response.url)
#
#         try:
#             address = response.xpath('//span[@class="w-store__streetAddress"]//text()').extract_first().strip()
#             address = re.sub('\s+', ' ', re.sub('\r|\n|\t', ' ', address))
#         except Exception as e:
#             print('address', e, response.url)
#
#         data = response.xpath('//span[@class="w-store__postalcode"]//text()').extract_first().split('\xa0')
#         if len(data) == 3:
#             city = data[1].strip()
#             zip_code = data[0].strip()
#         else:
#             city = data[-1].strip()
#             zip_code = data[0].strip()
#
#         try:phone_number = response.xpath('//a[@class="w-store__phone"]//text()').extract_first()
#         except Exception as e:print('phone_number', e, response.url)
#
#         try:store_hours = response.xpath('//div[@class="w-store-details__schedule"]/p//text()').extract_first()
#         except Exception as e:print('store_hours', e, response.url)
#
#         geo_location = response.xpath('//span[@class="w-store__geolocation"]//text()').extract_first().split(' - ')
#         lat = geo_location[0].strip()
#         long = geo_location[-1].strip()
#
#         item = StoreLocatorsItem()
#         item['search_term'] = 'link'
#         item['store_name'] = store_name
#         item['address'] = address
#         item['city'] = city
#         item['state'] = ''
#         item['zip_code'] = zip_code
#         item['phone_number'] = phone_number
#         item['latitude'] = lat
#         item['longitude'] = long
#         item['store_type'] = ''
#         item['website_address'] = response.url
#         item['coming_soon'] = 0
#         item['store_number'] = ''
#         item['country_code'] = item['country'] = 'PT'  # self.f1.country_dict.get(item['country'].lower())
#         item['email_address'] = ''
#         item['services'] = ''
#         item['store_hours'] = store_hours
#         item['additional_info'] = ''
#
#         # if item['country_code'] == 'US' and len(item['state']) > 2:
#         #     item['state'] = self.f1.state_dict.get(state, '')
#         yield item
#
#     def response_html_path(self, request):
#         return request.meta['fpath']
#
# execute('''scrapy crawl store_119 -a list_id=119'''.split())


##------------- updated code -----------------------------------------------##


# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import random
import re


import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from scrapy.utils.response import open_in_browser

from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime


from selenium import webdriver
from selenium.webdriver.chrome.options import Options
chrome_options = Options()
# chrome_options.add_argument("--headless")
chrome_driver ="D:\\nishant\\chromedriver.exe"

class Store119Spider(scrapy.Spider):
    name = 'store_119'
    allowed_domains = []


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        run_date = str(datetime.datetime.today()).split()[0]
        self.f1.set_details(self.list_id, run_date)


    def start_requests(self):
        yield scrapy.Request(url='file:///D:/nishant/ghanshaym/worten.html', callback=self.firstlevel)

    def firstlevel(self, response):
        links = response.xpath('//section[@class="w-section__wrapper"]/section//a[@class="w-button-secondary w-store__btn"]/@href').extract()
        for link in links:
            link = 'https://www.worten.pt' + link
            print(link)

            headers = {
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                # 'accept-encoding': 'gzip, deflate, br',
                'accept-language': 'en-US,en;q=0.9',
                'cache-control': 'no-cache',
                'cookie': '__cfduid=d3e77fe40b3b4e64f0e8d5f4ed73aec6a1607944782; mg_get_user=true; mg_get_address=true; mg_login=true; sales_features=air_conditioning; shipping_gateway=true; shipping_gateway_v1=true; product_share_v2=true; is_sced_feature_active=true; is_long_tail_items_active=true; cart_wishlist=true; _ALGOLIA=anonymous-dbbca4c5-2c3f-4b67-b1cf-2238eae7854b; CookieConsent={stamp:%27ySFaKwZTP1Y3uDljXL19GJEmNlucDn7ULaZcdKq1iVr8Gf4A57xlug==%27%2Cnecessary:true%2Cpreferences:true%2Cstatistics:true%2Cmarketing:true%2Cver:1%2Cutc:1607944857673%2Cregion:%27in%27}; _fbp=fb.1.1607944859148.820407287; kk_leadtag=true; wpn_https={"last_shown":"Mon, 14 Dec 2020 11:20:59 GMT","shown_count":1}; _clck=16l2tnm; _vz=viz_5fd74a9d96964; _gcl_au=1.1.761870498.1608700896; t2s-p=5e6a270c-dc6b-40bc-a900-6ed45e97dbcb; sts=119dfec3eee390fb644a264572fdd7f671ed1fe34cc596b26a6ed1295ff6f819; _gid=GA1.2.343182396.1609129048; facetsv2=true; wpn_https={"status":"denied","last_shown":"Mon, 28 Dec 2020 04:31:23 GMT","shown_count":1}; cf_chl_prog=a19; cf_clearance=2f069a8cc51b6bcd053401a50b5f8b8192a9c97d-1609132506-0-250; show_store_stock=true; _ga_WM5ETPQSYP=GS1.1.1609129046.4.1.1609132944.0; _ga=GA1.2.1601328215.1607944853; _uetsid=98d1728048c311ebbe65153dad1941bd; _uetvid=70d571403dfe11eb855299be95b835ca; _gat_UA-10378744-1=1',
                'pragma': 'no-cache',
                'upgrade-insecure-requests': '1',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'
            }

            yield scrapy.Request(url=link, callback=self.data,headers=headers)

    def data(self, response):
        # open_in_browser(response)
        try:store_name = response.xpath('//h3[@class="w-store__name"]//text()').extract_first().strip()
        except Exception as e:print('store_name', e, response.url)

        try:
            address = response.xpath('//span[@class="w-store__streetAddress"]//text()').extract_first().strip()
            address = re.sub('\s+', ' ', re.sub('\r|\n|\t', ' ', address))
        except Exception as e:
            print('address', e, response.url)

        data = response.xpath('//span[@class="w-store__postalcode"]//text()').extract_first().split('\xa0')
        if len(data) == 3:
            city = data[1].strip()
            zip_code = data[0].strip()
        else:
            city = data[-1].strip()
            zip_code = data[0].strip()

        try:phone_number = response.xpath('//a[@class="w-store__phone"]//text()').extract_first()
        except Exception as e:print('phone_number', e, response.url)

        try:store_hours = response.xpath('//div[@class="w-store-details__schedule"]/p//text()').extract_first()
        except Exception as e:print('store_hours', e, response.url)

        geo_location = response.xpath('//span[@class="w-store__geolocation"]//text()').extract_first().split(' - ')
        lat = geo_location[0].strip()
        long = geo_location[-1].strip()

        item = StoreLocatorsItem()
        item['search_term'] = 'link'
        item['store_name'] = store_name
        item['address'] = address
        item['city'] = city
        item['state'] = ''
        item['zip_code'] = zip_code
        item['phone_number'] = phone_number
        item['latitude'] = lat
        item['longitude'] = long
        item['store_type'] = ''
        item['website_address'] = response.url
        item['coming_soon'] = 0
        item['store_number'] = ''
        item['country_code'] = item['country'] = 'PT'  # self.f1.country_dict.get(item['country'].lower())
        item['email_address'] = ''
        item['services'] = ''
        item['store_hours'] = store_hours
        item['additional_info'] = ''

        # if item['country_code'] == 'US' and len(item['state']) > 2:
        #     item['state'] = self.f1.state_dict.get(state, '')
        yield item

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_119 -a list_id=119'''.split())
