import hashlib
import re

import scrapy
import json
from store_locators.spiders.common_functions import Func
from store_locators.items import StoreLocatorsItem
import datetime
import html2text,os

class Store169Spider(scrapy.Spider):
    name = 'store_169'
    f1 = Func()

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            source_url = link = 'https://www.togos.com/locations/getLocationJson?'

            self.f1.set_details(self.list_id, run_date)
            # file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(run_date) + '.html'
            # if os.path.exists(file_path):
            #     link = 'file://' + file_path.replace('\\', '/')
            file_path = ''
            yield scrapy.FormRequest(url=str(link), callback=self.InsideStore, meta={'source_url': source_url,'file_path': file_path, 'proxy_type': self.proxy_type})

        except Exception as e:
            print(e)

    def InsideStore(self,response):

        # if not response.url.startswith('file://'):
        #     self.f1.page_save(response.meta['file_path'], response.body)
        try:
            data = json.loads(response.text)
        except Exception as e:
            print("problem in loading json",e)

        for d in data['markers']:
            try:
                store_name = d['fields']['franchisee_name']
                address_detail = address = d['address']
                address_line_2 = ''
                for i in ['Unit', 'STE', 'Ste','SUITE','Suite','suite','Suit','SUIT','suit','UNIT','unit','ste','Ste.']:
                    for aw in address_detail.split(' '):
                        if i == aw:
                            if address_detail.split(' ').index(aw) != 0:
                                address = address_detail.split(i)[0].strip()
                                address_line_2 = i + ' ' + address_detail.split(i)[-1].strip()
                                break
                city = d['city']
                state = d['state']
                if state == 'California':
                    state = 'CA'
                zip_code = d['zipcode']
                store_number = d['id']
                latitude = d['lat']
                longitude = d['lng']
                email_address = d['fields']['contact_email_address']
                phone_number = d['phone']
                additional_info = 'FUNDRAISERS :'+d['fields']['fundraiser_description']
                link = 'https://www.togos.com/locations/'+d['city_slug']+'/'+d['address_slug']
            except Exception as e:
                print('Address|StoreName|LatLng|..',e)
            try:
                Hours = []
                tmpHours = d['hours'].split(';')
                for hr in tmpHours:
                    if hr.strip():
                        hr = hr.replace(',','-')
                        if hr[0] == '1':
                            hr = 'Mon'+hr[1:]
                        if hr[0] == '2':
                            hr = 'Tue'+hr[1:]
                        if hr[0] == '3':
                            hr = 'Wed'+hr[1:]
                        if hr[0] == '4':
                            hr = 'Thu'+hr[1:]
                        if hr[0] == '5':
                            hr = 'Fri'+hr[1:]
                        if hr[0] == '6':
                            hr = 'Sat'+hr[1:]
                        if hr[0] == '7':
                            hr = 'Sun'+hr[1:]
                        time = re.findall('(\d{4})',hr)
                        openH = time[0][0:2]
                        openM = time[0][2:]
                        closeH = time[1][0:2]
                        closeM = time[1][2:]
                        # if int(openH) > 12:
                        #     openH = int(openH) % 12
                        # if int(closeH) > 12:
                        #     closeH = int(closeH) % 12
                        t = str(openH)+':'+openM+'-'+str(closeH)+':'+closeM
                        hr = hr[:3]+'_'+t
                        Hours.append(hr)
                Hours = '|'.join(Hours)

                # check = False
                # for i in ['. Ste','Suite', ', Ste', 'Ste ','Ste.','Ste']:
                #     for aw in address.split():
                #         if i == aw:
                #             address1 = address.split(i)[0].strip(',')
                #             address_line_2 = i + ' ' + address.split(i)[-1].strip()
                #             check = True
                #             break
                # if check == True:
                #     address_line_2 = address_line_2
                #     address = address1
                # else:
                #     address_line_2 = ''
                #     address = address
            except Exception as e:
                print('Hours',e,)

            try:
                item = StoreLocatorsItem()

                item['address'] = address.strip()
                item['address_line_2'] = address_line_2#address_line_2.strip()
                item['address_line_3'] = ''
                item['city'] = city.strip()
                item['state'] = state.strip()
                item['zip_code'] = zip_code.strip()
                item['country'] = 'United States'
                item['country_code'] = 'US'
                item['store_name'] = store_name.strip()
                item['phone_number'] = phone_number.strip()
                item['latitude'] = latitude
                item['longitude'] = longitude
                item['store_type'] = ''
                item['coming_soon'] = 0
                item['store_number'] = store_number
                item['source_url'] = link
                item['additional_info'] = additional_info.strip()
                item['store_hours'] = Hours
                item['email_address'] = email_address
                yield item
            except Exception as e:
                print('yield item',e)
#
# from scrapy.cmdline import execute
# execute('''scrapy crawl store_169 -a list_id=169 -s HTTPCACHE_ENABLED=False'''.split())
#
#
