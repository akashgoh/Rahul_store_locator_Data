# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import random
import re

import html2text
import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime

class Store130Spider(scrapy.Spider):
    name = 'store_130'
    allowed_domains = []


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()


    def start_requests(self):
        self.run_date = str(datetime.datetime.today()).split()[0]
        try:
            self.f1.set_details(self.list_id,self.run_date)
            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                print(search_terms)
            # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)
                search_terms = ''
                for search_term in (search_terms):
                    source_url = link = 'https://www.wayfair.com/wayfair-locations'
                    file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(search_term) + '_' + str(self.run_date) + '.html'
                    if os.path.exists(file_path):
                        link = 'file://' + file_path.replace('\\','/')
                    yield scrapy.FormRequest(url=str(link), callback=self.data,
                                             meta={'source_url': source_url,'search_term': search_term,'file_path':file_path,'proxy_type': self.proxy_type})
            else:
                headers = {
                    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
                    "accept-encoding": "gzip, deflate, br",
                    "accept-language": "en-US,en;q=0.9",
                    "cache-control": "max-age=0",
                    "referer": "https://www.google.com/",
                    "sec-fetch-mode": "navigate",
                    "sec-fetch-site": "cross-site",
                    "sec-fetch-user": "?1",
                    "upgrade-insecure-requests": "1",
                    "user-agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537.36"
                }
                source_url = link = 'https://www.wayfair.com/wayfair-locations'
                file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(self.run_date) + '.html'
                yield scrapy.FormRequest(url=str(link), callback=self.data, headers=headers,
                                         meta={'source_url': source_url,'file_path': file_path, 'proxy_type': self.proxy_type})
        except Exception as e:
            logging.log(logging.ERROR, e)


    def data(self, response):
        divs = response.xpath('//section[@class="LocationsPage-introductionText"]/p[2]/text()|//section[@class="LocationsPage-introductionText"]/p[3]/text()').extract()
        for div in divs:
            store_name = div.split(' ')
            store_name = store_name[0] + ' ' + store_name[1]+ ' ' +store_name[2]

            if store_name == 'The Wayfair Store':
                address = '1245 Worcester St'
                city = 'Natick'
                state = 'MA'
                zipcode = '01760'
                store_hours = ''

            elif store_name == 'The Wayfair Outlet':
                address = '5101 Renegade Way'
                city = 'Florence'
                state = 'KY'
                zipcode = '41042'
                store_hours = 'Friday:10AM-6PM|Satuday:10AM-6PM|Sunday:10AM-4PM'

            item = StoreLocatorsItem()
            item['search_term'] = 'link'
            item['store_name'] = store_name
            item['address'] = address
            item['city'] = city
            item['state'] = state
            item['zip_code'] = zipcode
            item['coming_soon'] = 0
            item['country'] = 'USA'
            item['country_code'] = 'US' # self.f1.country_dict.get(item['country'].lower())
            item['store_hours'] = store_hours
            item['source_url'] = response.url
            yield item

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_130 -a list_id=130'''.split())