import re

import scrapy
import json
from store_locators.spiders.common_functions import Func
from store_locators.items import StoreLocatorsItem
import datetime
import html2text,os
from scrapy.cmdline import execute

class Store152Spider(scrapy.Spider):
    name = 'store_152'
    f1 = Func()
    not_export_data = True

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            source_url = link = 'https://storemapper-herokuapp-com.global.ssl.fastly.net/api/users/5048/stores.js?callback=SMcallback2'

            self.f1.set_details(self.list_id, run_date)
            # file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(run_date) + '.html'
            # if os.path.exists(file_path):
            #     link = 'file://' + file_path.replace('\\', '/')

            yield scrapy.FormRequest(url=str(link), callback=self.get_Json, meta={'source_url': source_url, 'proxy_type': self.proxy_type})#'file_path': file_path,

        except Exception as e:
            print(e)


    def get_Json(self,response):

        Json = re.findall('SMcallback2\((.*)\)',response.text)[0]
        data = json.loads(Json)

        for store in data['stores']:

            storeName = store['name']
            phone_number = store['phone']
            if '.' in phone_number:
                tmp = phone_number.split('.')
                area = tmp[0].strip()
                pre = tmp[1].strip()
                suf = tmp[0].strip()
                phone_number = '('+area+') '+pre+'-'+suf
            latitude = store['latitude']
            longitude = store['longitude']
            store_type = store['category']
            store_number = store['id']
            store_hours = store['description']
            # file_path = response.meta['file_path']
            link = store['url']
            yield scrapy.Request(link,self.InsideStore,meta={'SN':storeName, 'PH':phone_number, 'LAT':latitude, 'LONG':longitude, 'CAT':store_type, 'ID':store_number, 'DSCR':store_hours})#, 'file_path':file_path

    def InsideStore(self,response):

        try:
            # if not response.url.startswith('file://'):
            #     self.f1.page_save(response.meta['file_path']+response.url, response.body)

            try:
                tmpAddr = response.xpath('//h2[contains(text(),"Location")]/parent::div/p/text()').extract()
                address = tmpAddr[0]
                address_line_2 = tmpAddr[1]
                if ',' in address_line_2:
                    CSZ = address_line_2.split(',')
                    city = CSZ[0]
                    state = re.findall('([A-Z]{2,2})',CSZ[1])[0]
                    zip_code = re.findall('(\d{5})',CSZ[1]) or re.findall('([A-Z]\d[A-Z] \d[A-Z]\d)',CSZ[1])#re.sub('([A-Z]{2,2})','',CSZ[1])
                    if zip_code:
                        zip_code = zip_code[0].strip()
                else:
                    CSZ = re.split('\s|\xa0',address_line_2)
                    if CSZ[0] == '':
                        del CSZ[0]
                    city = CSZ[0]
                    state = CSZ[1]
                    zip_code = ' '.join(CSZ[2:])
            except Exception as e:
                print('Address',e,response.url)

            check = False
            for i in ['Unit', 'STE', 'Ste', 'Suite']:
                for aw in address.split():
                    if i == aw:
                        address1 = address.split(i)[0].strip(',')
                        address_line_2 = i + ' ' + address.split(i)[-1].strip()
                        check = True
                        break
            if check == True:
                address_line_2 = address_line_2
                address = address1
            else:
                address_line_2 = ''
                address = address

            item = StoreLocatorsItem()

            item['address'] = address.strip()
            item['address_line_2'] = address_line_2

            if len(zip_code.strip()) == 5:
                item['country'] = 'United States'
                item['country_code'] = 'US'
            elif re.findall('(\w\d\w \d\w\d)',zip_code):
                item['country'] = 'Canada'
                item['country_code'] = 'CA'
            else:
                item['country'] = 'United Kingdom'
                item['country_code'] = 'UK'
            item['city'] = city.strip()
            item['state'] = state.strip()
            item['zip_code'] = zip_code.strip()
            if item['country_code'] == 'UK':
                item['city'] = ''
                item['state'] = ''
                item['zip_code'] = city.strip()+' '+state.strip()
            item['store_name'] = 'Untuckit - '+response.meta['SN']
            item['phone_number'] = response.meta['PH']
            item['latitude'] = response.meta['LAT']
            item['longitude'] = response.meta['LONG']
            item['store_type'] = response.meta['CAT']
            item['coming_soon'] = 0
            store_hours = response.meta['DSCR']
            if '*Carrie' in store_hours:
                store_hours = store_hours.split('*Carrie')[0].strip()
            item['store_hours'] =store_hours
            item['source_url'] = response.url

            # print(item['state'])
            # if item['country_code'] == 'US' and len(item['state']) > 2:
            #     item['state'] = self.f1.state_dict.get(item['state'].lower(), '')
            #     print('::,', item['state'])

            yield item
        except Exception as e:
            print("Problem in yield item",e)


# execute('''scrapy crawl store_152 -a list_id=152'''.split())


