import re
import scrapy
import datetime
from scrapy.cmdline import execute

from store_locators.spiders.common_functions import Func
from store_locators.items import StoreLocatorsItem


class mytagofridy(scrapy.Spider):
    name = 'store_188'
    f1 = Func()

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()




    def start_requests(self):
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.f1.set_details(self.list_id, self.run_date)

        source_url = link = 'https://www.tgifridays.co.uk/xml-sitemap/'

        yield scrapy.FormRequest(url=str(link), callback=self.get_store_list,meta={'source_url': source_url},dont_filter=True)


    def get_store_list(self,response):

        url = re.findall(r'<loc>https://www.tgifridays.co.uk/locations/(.*?)</loc>', response.text, re.DOTALL)
        # print(url)

        for u in url:
            u = 'https://www.tgifridays.co.uk/locations/' + u
            print(u)
            if 'david' in u:
                u = "https://www.tgifridays.co.uk/locations/cardiff-st-david's"

            yield scrapy.Request(url=str(u), callback=self.get_data)

    def get_data(self,response):

        a = re.sub(r'\s+', ' ', response.text)

        try:
            store_name = response.xpath('//*[@class="display-1"]/text()').extract_first(default='').encode(
                'ascii', 'ignore').decode('unicode_escape')
            print(store_name)
        except Exception as e:
            store_name = ''

        try:
            fulladdress = ''.join(re.findall(r'<address> (.*?)<br>', a)).strip()
            print(fulladdress)
        except Exception as e:
            fulladdress = ''

        try:
            check = False
            address = fulladdress
            for i in ['Unit', 'Suite', 'Ste']:
                for aw in address.split():
                    if i == aw:
                        address1 = address.split(i)[0].strip(',')
                        address_line_2 = i + ' ' + address.split(i)[-1].strip()
                        check = True
                        break

            if check == True:
                address_line_2 = address_line_2
                address = address1
            else:
                address_line_2 = ''
                address = address
        except Exception as e:
            print(e)
        # addinfo = ''.join(response.xpath('//*[@class="basic-details__city"]/text()').extract())


        try:
            city = ''.join(re.findall(r'<br> (.*?)<br>', a)).split('<')[0].strip()
            print(city)
        except Exception as e:
            city = ''

        try:
            zip_code = ''.join(re.findall(r'<br> (.*?) </address>', a)).split('<br>')[1].strip()
            print(zip_code)
        except Exception as e:
            zip_code = ''

        try:
            phone_number = ''.join(re.findall(r'href="tel:(.*?)"', response.text))
            print(phone_number)
        except Exception as e:
            phone_number = ''


        # store_hours = response.xpath('//*[@class="col roomy-above"]/text()').extract()
        try:
            store_hours= re.findall('opening hours are:<br/><br/>(.*?)<br/><br/><a href',response.text)[0]
            if '<br/>' in store_hours:
                store_hours=store_hours.replace('<br/>','|')
            print(store_hours)
        except:
            print('urlhours',response.url)
            try:
                store_hours=re.findall('<h4>Dine-in</h4><br/>(.*?)<br/>',response.text)[0]
                print(store_hours)
            except:
                store_hours=''
        # if 'Sorry' in store_hours:
        #         store_hours = '|'.join(response.xpath("//*[contains(text(),'Normal opening times')]/following-sibling::p[1]//text()").extract())

        item = StoreLocatorsItem()
        item['store_name'] = store_name
        item['address'] = address
        item['address_line_2'] = address_line_2
        item['city'] = city
        item['state'] = ''
        item['zip_code'] = zip_code
        item['phone_number'] = phone_number
        item['store_hours'] = store_hours
        add_info = dict()
        add_info['distance'] = ''
        add_info['thumb'] = ''
        add_info['description'] = ''
        item['additional_info'] = ''
        item['country'] = 'UK'
        item['source_url'] = response.url.encode('ascii', 'ignore').decode('unicode_escape')
        item['country_code'] = 'UK'

        if item['country_code'] == 'UK' and len(item['state']) > 2:
            item['state'] = self.f1.state_dict.get(item['state'].lower(), '')
        item['fax_number'] = ''
        item['email_address'] = ''
        item['latitude'] = ''
        item['longitude'] = ''
        item['store_type'] = ''
        item['website_address'] = 'https://www.tgifridays.co.uk/xml-sitemap/'
        item['coming_soon'] = 0
        item['store_number'] = ''
        print(item)
        yield item


# execute('''scrapy crawl store_188 -a list_id=188 -s HTTPCACHE_ENABLED=False'''.split())