# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import re
import pgeocode
import scrapy, os, logging, hashlib
import requests, json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from selenium import webdriver
from selenium.webdriver.firefox.options import Options
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime


class Store164Spider(scrapy.Spider):
    name = 'store_164'
    allowed_domains = []

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
    def start_requests(self):
        try:
            self.f1.set_details(self.list_id, self.run_date)
            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                print(search_terms)
                # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)
                search_terms = ''
                for search_term in (search_terms):
                    source_url = link = 'https://16handles.com/locations/'
                    file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(search_term) + '_' + str(self.run_date) + '.html'
                    if os.path.exists(file_path):
                        link = 'file://' + file_path.replace('\\', '/')
                    yield scrapy.FormRequest(url=str(link), callback=self.get_store_list,
                                             meta={'source_url': source_url, 'search_term': search_term,
                                                   'file_path': file_path, 'proxy_type': self.proxy_type})
            else:
                source_url = link = 'https://tradesecret.com/contact-us/'
                file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(self.run_date) + '.html'
                yield scrapy.FormRequest(url=str(link), callback=self.get_store_list,
                                         meta={'source_url': source_url,
                                               'file_path': file_path, 'proxy_type': self.proxy_type})
        except Exception as e:
            logging.log(logging.ERROR, e)

    # def firstlevel(self, response):
    #     try:
    #         source_url = response.meta['source_url']
    #         file_path = response.meta['file_path']
    #         proxy_type = response.meta['proxy_type']
    #         links = response.xpath('//*[@class="name"]/../@href').extract()
    #         for link in links:
    #             yield scrapy.FormRequest(url=link, callback=self.get_store_list,
    #                                      meta={'source_url': source_url, 'file_path': file_path,
    #                                            'proxy_type': proxy_type})
    #     except Exception as e:
    #         print("firstlevel", e, response.url)

    # Get data from the response
    def get_store_list(self, response):
        try:
            if not response.url.startswith('file://'):
                self.f1.page_save(response.meta['file_path'], response.body)
            search_term = response.meta.get('search_term', '')
            try:
                item = StoreLocatorsItem()
                store_data = response.xpath('//*[@id="google-map"]/iframe')
                # print(store_data)
                for data in store_data:
                    address_url = data.xpath('.//@src').extract_first()
                    # r = requests.get(address_url)
                    print(address_url)
                    #===========   milan=============

                    # response1 = HtmlResponse(url=address_url, body= r.content)
                    # a = response1.text
                    # # print(a)
                    # a = a.split("function onEmbedLoad() ")[1]
                    # print(a)
                    #
                    # add = a.split('USA',1)[0]
                    # print(add)
                    # add = add.rsplit('"',1)[1]
                    # print(add)

                    #=================            ============#
                    if address_url == 'https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d5755.04006465002!2d-79.311697!3d43.845049!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x533907fc24688db5!2sBeauty+Express+Salons+%26+Stores%2C+Inc!5e0!3m2!1sen!2sca!4v1526589521130':
                        add = response.xpath("//div[@class='store-address']/text()").extract()
                        print(add)
                        address = add[2].replace("\r","").replace("\n","").strip()
                        city = add[4].replace("\r","").replace("\n","").strip().split(",")[0].strip()
                        state = add[4].replace("\r","").replace("\n","").strip().split(",")[1].strip()
                        zip_code = add[5].replace("\r","").replace("\n","").strip().split(",")[0].strip()
                        country = add[5].replace("\r","").replace("\n","").strip().split(",")[1].strip()
                        country_code = 'CA'

                    else:
                        add = address_url.split("!2s")[1]
                        add = add.split("!5e")[0].replace("+"," ").replace("%2C",",")
                        print(add)

                        address = add.split(",")[0]
                        city = add.split(",")[1]
                        state = add.split(",")[2].strip().split(" ")[0]
                        zip_code = add.split(",")[2].strip().split(" ")[1]
                        country = 'USA'
                        country_code = 'US'

                    try:
                        phone_number = response.xpath('//*[@class="store-phone"]/a/text()').extract_first().strip()
                    except Exception as e:
                        print("phone_number", e, response.url)

                    # try:
                    #     add = re.findall(r'Trade Secret"\,\["(.*?)\]\,', r.text)[0].replace('"', '').split(',')
                    #     address = add[0].strip()
                    #     city = add[1].strip()
                    #     state = add[2].strip().split(' ')[0]
                    #     zip_code = add[2].strip().split(' ')[-1]
                    # except Exception as e:
                    #     print("address", e, response.url)

                    try:
                        store_name = 'Trade Secret - ' + city
                    except Exception as e:
                        print("store_name", e, response.url)

                    try:
                        latitude = re.findall(r'!3d(.*?)!', address_url)[0][:8]
                        longitude = re.findall(r'!2d(.*?)!3d', address_url)[0][:8]
                    except Exception as e:
                        print("latitude and longitude", e, response.url)

                    try:
                        store_hour = '|'.join(response.xpath('//*[contains(text(),"Office Hours:")]/following-sibling::div/text()').extract())
                        store_hours = store_hour.strip().replace('\r', '').replace('\n', '').replace('  ', '')
                    except Exception as e:
                        print("store_hours", e, response.url)

                    try:
                        email_address = response.xpath('//*[contains(@href,"mailto")]/text()').extract_first()
                    except Exception as e:
                        print("email_address", e, response.url)

                    item['search_term'] = search_term
                    item['store_name'] = store_name
                    item['address'] = address
                    item['city'] = city
                    item['state'] = state
                    item['zip_code'] = zip_code
                    item['phone_number'] = phone_number
                    item['latitude'] = latitude
                    item['longitude'] = longitude
                    item['store_type'] = ''
                    item['coming_soon'] = 0
                    item['email_address'] = email_address
                    item['source_url'] = response.url
                    item['country'] = country
                    item['country_code'] = country_code # self.f1.country_dict.get(item['country'].lower())
                    item['store_hours'] = store_hours.strip('|')
                    # if item['country_code'] == 'US' and len(item['state']) > 2:
                    #     item['state'] = self.f1.state_dict.get(state, '')
                    yield item
            except Exception as e:
                print(e)

        except Exception as e:
            logging.log(logging.ERROR, e)

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_164 -a list_id=164 -a proxy_type='''.split())