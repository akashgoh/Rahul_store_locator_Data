# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import re
import urllib

import scrapy,os,logging,hashlib
import requests,json
from lxml import html
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime


class store_208_Spider(scrapy.Spider):
    name = 'store_208'
    allowed_domains = []
    not_export_data = False

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):

        try:

            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                print(search_terms)
            # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)
                search_terms = ''
                for search_term in (search_terms):
                    source_url = link = 'https://stretchlab.com/locations/'
                    file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(search_term) + '_' + str(self.run_date) + '.html'
                    if os.path.exists(file_path):
                        link = 'file://' + file_path.replace('\\','/')
                    yield scrapy.FormRequest(url=str(link), callback=self.get_store_list, meta={'source_url': source_url,'search_term': search_term,'file_path':file_path,'proxy_type': self.proxy_type})
            else:

                source_url = link = 'https://www.sukiya.jp/en/locations/'
                file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(self.run_date) + '.html'
                yield scrapy.FormRequest(url=str(link), callback=self.get_store_list,
                                         meta={'source_url': source_url,
                                               'file_path': file_path, 'proxy_type': self.proxy_type})

        except Exception as e:
            logging.log(logging.ERROR, e)



    # Get data from the response
    def get_store_list(self, response):
        try:
            if not response.url.startswith('file://'):
                self.f1.page_save(response.meta['file_path'], response.body)


            try:
                data = urllib.parse.unquote(response.text)
                blocks = data.split('{"name":')
                del blocks[0]
                print(len(blocks))
                for block in blocks:
                    try:
                        namejapan = re.findall('"name_jp":"(.*?)"', block)[0]
                    except Exception as e:
                        print("store_name", e, response.url)

                    try:
                        phone_number = ''
                    except Exception as e:
                        print("phonenumber", e, response.url)

                    try:
                        latitude = re.findall('"lat":"(.*?)"',block)[0]
                        longitude = re.findall('"lng":"(.*?)"',block)[0]
                    except Exception as e:
                        print("latitude and longitude", e, response.url)


                    try:
                        strreetaddressjapan = re.findall('"address_jp":"(.*?)"',block)[0]


                    except Exception as e:
                        print("address", e, response.url)

                    try:
                        url = response.url
                    except Exception as e:
                        print("url")


                    try:
                        hourslist = []
                        storehours1 = re.findall('"vhours":"(.*?)"',block)[0]
                        storehours2 = re.findall('"vclose":"(.*?)"', block)[0]
                        hourslist.append(storehours1)
                        hourslist.append(storehours2)
                        store_hours = "/".join(hourslist)
                    except Exception as e:
                        print("store_hours",e,response.url)



                    try:
                        additional_info = {}
                        Address_english = re.findall('"address":"(.*?)"', block)

                        if len(Address_english)>=1:

                            Address_english = Address_english[0]
                            StoreName_English = re.findall('"(.*?)"', block)[0]
                            additional_info['StoreName_English'] = StoreName_English
                            additional_info['Address_English'] = Address_english
                        else:
                            additional_info = {}

                    except Exception as e:
                        print("additional_info",e,response.url)


                    # try:
                    #
                    #     zipcode  = re.findall('ã€’(.*?)(\s+)',strreetaddressjapan)[0]
                    #
                    # except Exception as E:
                    #     print("zipcode",e,response.url)


                    item = StoreLocatorsItem()
                    item['search_term'] = ''
                    item['store_name']= namejapan
                    item['address'] = strreetaddressjapan
                    item['city'] = ''
                    item['state'] =''
                    item['zip_code'] = ''
                    item['phone_number'] =phone_number
                    item['latitude'] = latitude
                    item['longitude'] = longitude
                    item['store_type'] = ''
                    item['website_address'] = ''
                    item['coming_soon'] = 0
                    item['store_number'] = ''
                    item['country_code'] = item['country'] = 'JP' #self.f1.country_dict.get(item['country'].lower())
                    item['email_address'] = ''
                    item['services'] = ''
                    item['source_url']=url
                    item['store_hours'] = store_hours
                    item['additional_info'] = json.dumps(additional_info)



                    yield item
            except Exception as e:
                print(e)

        except Exception as e:
            logging.log(logging.ERROR, e)

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_208 -a list_id=208'''.split())
