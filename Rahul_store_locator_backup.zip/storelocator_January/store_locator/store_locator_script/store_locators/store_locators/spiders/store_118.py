# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import random
import re
import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime


class Store118Spider(scrapy.Spider):
    name = 'store_118'
    allowed_domains = []

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        run_date = str(datetime.datetime.today()).split()[0]
        self.f1.set_details(self.list_id, run_date)

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            self.f1.set_details(self.list_id,run_date)
            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                print(search_terms)
            # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)
                search_terms = ''
                for search_term in (search_terms):
                    source_url = link = 'https://www.worten.es/tiendas'
                    file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(search_term) + '_' + str(run_date) + '.html'
                    if os.path.exists(file_path):
                        link = 'file://' + file_path.replace('\\','/')
                    yield scrapy.FormRequest(url=str(link), callback=self.get_store_list, meta={'source_url': source_url,'search_term': search_term,'file_path':file_path,'proxy_type': self.proxy_type})
            else:
                headers = {
                    "Upgrade-Insecure-Requests":"1",
                    "User-Agent":"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36",
                    "Sec-Fetch-Mode":"navigate",
                    "Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b"
                }
                source_url = link = 'https://www.worten.es/tiendas'
                file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(run_date) + '.html'
                yield scrapy.FormRequest(url=str(link), callback=self.firstlevel, headers=headers,
                                         meta={'source_url': source_url, 'file_path': file_path, 'proxy_type': self.proxy_type})
        except Exception as e:
            logging.log(logging.ERROR, e)


    def firstlevel(self,response):
        # headers = {
        #     "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
        #     "accept-encoding": "gzip, deflate, br",
        #     "accept-language": "en-US,en;q=0.9",
        #     "cache-control": "max-age=0",
        #     "if-none-match": 'W/"3f05e-NE0gGlniWgsLJi7BstD4HXUgrb0"',
        #     "referer": "https://www.worten.es/tiendas/worten-lloret-de-mar",
        #     "sec-fetch-mode": "navigate",
        #     "sec-fetch-site": "same-origin",
        #     "sec-fetch-user": "?1",
        #     "upgrade-insecure-requests": "1",
        #     "user-agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36"
        # }
        headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'accept-language': 'en-US,en;q=0.9',
            'cache-control': ' max-age=0',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'none',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36',
        }
        links = response.xpath('//a[@class="w-button-secondary w-store__btn"]/@href').extract()
        for link in links:
            yield scrapy.Request(url='https://www.worten.es'+link, callback=self.data,headers=headers, meta={'proxy_type':self.proxy_type})


    def data(self, response):
        print(response.url)
        # response1 = response.read().decode("utf8")
        try:
            store_name = response.xpath('//h3[@class="w-store__name"]/text()').extract_first()
            if store_name == None:
                store_name = response.xpath('//*[@class="w-store-details__content"]//text()').extract_first()
                if store_name == None:
                    store_name = response.xpath('//title/text()').extract_first()
        except Exception as e:print('store_name', e, response.url)

        try:address = ''.join(response.xpath('//span[@class="w-store__streetAddress"]/text()').extract())
        except Exception as e:print('address', e, response.url)

        city = store_name.split()[-1].strip()

        try:
            zip_code = response.xpath('//span[@class="w-store__postalcode"]/text()').extract_first()
            zip_code = re.findall(r'(\d{5})', zip_code)[0]
        except Exception as e:
            print('zip_code', e, response.url)

        # try:phone_number = response.xpath('//div[@class="w-store-details__phone"]/a/text()').extract_first()
        try:
            # phone_number = response.xpath('//div[@class="w-store-details__contact"]//*[contains(text(),"call")]/../..//a[3]/@href').extract_first()
            phone_number = re.findall(r',"telephone":"(.*?)"',response.text,re.DOTALL)[0]
            phone_number = phone_number.strip()
            print(phone_number)
        except Exception as e:print('phone_number', e, response.url)

        try:longitude = response.xpath('//div[@id="store-details-map"]/@data-longitude').extract_first()
        except Exception as e:print('longitude', e, response.url)

        try:latitude = response.xpath('//div[@id="store-details-map"]/@data-latitude').extract_first()
        except Exception as e:print('latitude', e, response.url)

        try:store_hours = response.xpath('//div[@class="w-store-details__schedule"]/p//text()').extract_first()
        except Exception as e:print('store_hours', e, response.url)

        # try:
        #     phone_number = response.xpath('//div[@class="w-store-details__contact"]//a[3]/@href').extract_first()
        # except Exception as e:
        #     print("Phone Number ----->  ",e)

        item = StoreLocatorsItem()
        item['search_term'] = 'link'
        item['store_name']= store_name
        item['address'] = address
        item['city'] = city
        item['state'] =''
        item['zip_code'] = zip_code
        item['phone_number'] = phone_number
        item['latitude'] = latitude
        item['longitude'] = longitude
        item['store_type'] = ''
        item['website_address'] =''
        item['source_url'] = response.url
        item['coming_soon'] = 0
        item['store_number'] = ''
        item['country_code'] = item['country'] = 'ES' #self.f1.country_dict.get(item['country'].lower())
        item['email_address'] = ''
        item['services'] = ''
        item['store_hours'] = store_hours
        item['additional_info'] = ''

        # if item['country_code'] == 'US' and len(item['state']) > 2:
        #     item['state'] = self.f1.state_dict.get(state, '')
        yield item


    # def response_html_path(self, request):
    #     return request.meta['fpath']

if __name__ == '__main__':
    execute('''scrapy crawl store_118 -a list_id=118'''.split())
