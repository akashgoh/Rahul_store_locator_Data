# -*- coding: utf-8 -*-
import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime
import re
import html2text
run_date = str(datetime.datetime.today()).split()[0]

class YoigoCrawlerSpider(scrapy.Spider):
    name = 'store_109'
    allowed_domains = []
    f1 = Func()
    not_export_data = False

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            source_url = link = 'https://www.yoigo.com/tiendas-yoigo/'
            self.f1.set_details(self.list_id, run_date)
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(run_date) + '.html'
            if os.path.exists(file_path):
                link = 'file://' + file_path.replace('\\', '/')
            yield scrapy.FormRequest(url=str(link), callback=self.get_store_list, meta={'source_url': source_url,'file_path': file_path, 'proxy_type': self.proxy_type})
        except Exception as e:
            print(e)

    def get_store_list(self,response):
        if not response.url.startswith('file://'):
            self.f1.page_save(response.meta['file_path'], response.body)
        source_url = response.meta.get('source_url', '')
        # --------- level 1
        level1_links = response.xpath('//*[@id="resultiendas"]//a/@href').extract()
        for links in level1_links:
            res = requests.get(links)
            response_1 = HtmlResponse(url=res.url,body=res.content)
            # page save
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(run_date)+'_'+str(links).split('/')[-2].strip() + '.html'
            if not response.url.startswith('file://'):
                self.f1.page_save(file_path, response_1.body)
            # --------- level 2
            level2_links = response_1.xpath('//*[@id="resultiendas"]//a/@href').extract()
            for links_2 in level2_links:
                res_2 = requests.get(links_2)
                response_2 = HtmlResponse(url=res_2.url,body=res_2.content)
                # page save
                file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(run_date) + '_' + str(links).split('/')[-2].strip()+ '_' + str(links_2).split('/')[-2].strip() + '.html'
                if not response.url.startswith('file://'):
                    self.f1.page_save(file_path, response_2.body)

                store_loop = response_2.xpath('//*[@class="tiendas_busc_caja_resul"]')
                for lp in store_loop:
                    add = ''.join(lp.xpath('.//*[contains(text(),"Dirección")]/following-sibling::div[1]//text()').extract())
                    add_temp = add.split('.')[:-1]
                    if len(add_temp)==2:
                        address = add_temp[0].strip()
                        address_line_2 = add_temp[1].strip()
                    elif len(add_temp)==1:
                        address = add_temp[0].strip()
                        address_line_2 = ''
                    fhours = []
                    hours = lp.xpath('.//*[contains(text(),"Horario")]/following-sibling::div[1]/text()').extract()
                    for h in hours:
                        temp = h.strip()
                        if temp!='':
                            fhours.append(temp)
                    fhours = '|'.join(fhours)
                    phone = lp.xpath('.//*[contains(text(),"Teléfono")]/following-sibling::div[1]/a/text()').extract_first(default='').strip().replace(' / ','|').replace(' ','.').strip()
                    email = lp.xpath('.//*[contains(text(),"Email")]/following-sibling::div[1]/a/text()').extract_first(default='').strip()
                    city = response_2.url.split('/')[-3].strip()
                    state = response_2.url.split('/')[-2].strip()
                    zip = re.findall('(\d{5})',add)
                    if zip !=[]:
                        zip = zip[0]
                    else:zip = ''
                    latlong = lp.xpath('.//*[@class="tnd_busc_result_img"]/iframe/@src').extract_first(default='').strip()
                    try:
                        temp = re.findall(r'll=(.*?)&',latlong)[0].strip().split(',')
                        lat = temp[0].strip()
                        long = temp[1].strip()
                    except:lat=long=''

                    try:
                        item = StoreLocatorsItem()
                        item['store_name'] = 'Yoigo Store - '+city
                        item['address'] = address
                        item['address_line_2'] = address_line_2
                        item['city'] = city
                        item['state'] = state
                        item['zip_code'] = zip
                        item['country'] = 'ES'
                        item['country_code'] = 'ES'
                        item['latitude'] = lat
                        item['longitude'] = long
                        item['store_hours'] = fhours
                        item['email_address'] = email
                        item['phone_number'] = phone
                        item['website_address'] = response_2.url
                        item['source_url'] = 'https://www.yoigo.com/tiendas-yoigo/'
                        yield item
                    except Exception as e:
                        logging.log(logging.ERROR, e)

# execute('''scrapy crawl store_109 -a list_id=109'''.split())#-s HTTPCACHE_ENABLED=True