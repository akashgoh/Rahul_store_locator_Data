# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import re
import time

import pgeocode
import scrapy, os, logging, hashlib
import requests, json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime
from scrapy.http import HtmlResponse
from selenium.webdriver import ActionChains
from selenium.webdriver.chrome.options import Options



class Store173Spider(scrapy.Spider):
    name = 'store_173'
    allowed_domains = []
    not_export_data = True


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
    def start_requests(self):
        try:
            self.f1.set_details(self.list_id, self.run_date)
            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                print(search_terms)
                # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)
                search_terms = ''
                for search_term in (search_terms):
                    source_url = link = 'https://16handles.com/locations/'
                    file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(search_term) + '_' + str(self.run_date) + '.html'
                    if os.path.exists(file_path):
                        link = 'file://' + file_path.replace('\\', '/')
                    yield scrapy.FormRequest(url=str(link), callback=self.get_store_list,
                                             meta={'source_url': source_url, 'search_term': search_term,
                                                   'file_path': file_path, 'proxy_type': self.proxy_type})
            else:
                source_url = link = 'https://www.timex.com/stores-find'
                file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(self.run_date) + '.html'
                yield scrapy.FormRequest(url=str(link), callback=self.firstlevel,
                                         meta={'source_url': source_url,
                                               'file_path': file_path, 'proxy_type': self.proxy_type})
        except Exception as e:
            logging.log(logging.ERROR, e)

    def firstlevel(self, response):
        try:
            source_url = response.meta['source_url']
            file_path = response.meta['file_path']
            proxy_type = response.meta['proxy_type']
            link = response.xpath('//*[@id="dwfrm_storelocator_state"]/@action').extract_first()
            # link = 'https://www.timex.com/stores-find?dwcont=C1588988455'
            states = response.xpath('//*[@name="dwfrm_storelocator_state"]//@value').extract()

            for state in states:
                if state:
                    header = {"accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
                              "accept-encoding": "gzip, deflate, br",
                              "accept-language": "en-US,en;q=0.9",
                              "cache-control": "max-age=0",
                              "content-type": "application/x-www-form-urlencoded",
                              "cookie": "dwanonymous_dd80ea30a41759411559f619a670ca76=abDZpKXtxStkNNDStoC559q3t1; _hc_cart=1085458958; b_s_id=239fd344-7210-4346-b525-631d1565618a; tracker_device=bd125b73-f252-4664-81a8-cbf77e639435; _ga=GA1.3.273038459.1600682570; _ga=GA1.2.273038459.1600682570; _scid=49e5a67f-d7dd-42fd-a6cc-76e480c9932e; _f60_session=F51E1hJDj38pWHB3Q455TeCcpAUvAUkNWIdNpFTEpiw5nDRpFwMhsoukWtD1MGvs; _fbp=fb.1.1600682570385.1131233009; _gcl_au=1.1.2103084039.1600682571; __cq_seg=0~0.00!1~0.00!2~0.00!3~0.00!4~0.00!5~0.00!6~0.00!7~0.00!8~0.00!9~0.00; __cq_uuid=abDZpKXtxStkNNDStoC559q3t1; rskxRunCookie=0; rCookie=22gng3rwqkdwr98w3ikklkfcd2oom; cib_b_desktop=0; ex_cib_b_desktop=Sun, 20 Dec 2020 10:02:54 GMT; ex_views_b_desktop=Sun, 20 Dec 2020 10:02:54 GMT; views_b_desktop=1; ex_vib_b_desktop=Sun, 20 Dec 2020 10:02:56 GMT; vib_b_desktop=1; dwac_01278ad9af749316af9c40b938=qncoPLLDxNPKkn30bdLhBhmDih3fZSyOOwY%3D|dw-only|||USD|false|US%2FEastern|true; cqcid=abDZpKXtxStkNNDStoC559q3t1; sid=qncoPLLDxNPKkn30bdLhBhmDih3fZSyOOwY; __cq_dnt=0; dw_dnt=0; dwsid=bJxPvXmTe1h4rRAvHfma0N9o7ZwUNZMFiTkorgdrhlhRfO3EIQpUlsrG0beFSYh428JCRIOYdPZgwyTxgBmAjA==; dw_cookies_accepted=1; dw=1; _gid=GA1.3.615824179.1601269015; __btr_id=585c869d-5e5d-45d4-bc29-82212adf08a0; _gid=GA1.2.615824179.1601269015; b_pg_v=9%2F28%2F2020%2C%2010%3A26%3A54%20AM; _sctr=1|1601231400000; __cfduid=d69c1ca7b71c31350d2138f4508a2574a1601284860; _hc_exp={*_cr*!1601269015661~*qKhBls4h*!{*_d*![35~11~16]~*EMTczRoVjJxX*![35~11~16~1]}~*52eYmD3Z*!{*_d*![35~11~16]~*WF4swZoJmKnG*![35~11~16~1]}~*cWw1IJpN*!{*DU4nasxB5Dja*![16~11~16~1]~*_d*![16~11~16]}~*ES6Cdzpx*!{*5WLJDjn4AMxd*![16~11~16~1]~*_d*![16~11~16]}~*gmC4azWW*!{*_d*![null~0~null~1]}~*9VGMmtJg*!{*_d*![null~0~null~1]}~*XTq3Ebp5*!{*_d*![null~0~null~1]}~*WV1FDElr*!{*_d*![null~0~null~1]}~*oOk8D8zY*!{*_d*![null~0~null~1]}~*VHSjcBIm*!{*_d*![null~0~null~1]}~*rZYv1FT5*!{*_d*![null~0~null~1]}~*LVnfIp7Y*!{*_d*![null~0~null~1]}~*L7AIQEXO*!{*_d*![null~0~null~1]}~*DAwVTCra*!{*_d*![null~0~null~1]}}; utag_main=v_id:0174b01daddf002272a7bf1f31c803073003206b009dc$_sn:5$_ss:0$_st:1601287124256$dc_visit:5$ses_id:1601284122439%3Bexp-session$_pn:11%3Bexp-session$dc_event:11%3Bexp-session$dc_region:eu-central-1%3Bexp-session; _uetsid=9d251c2ce5cade89209d137398aa1b67; _uetvid=d4b0d6e29d7c2c6bc0f1211db1cb4aa6; stc111387=env:1601284122%7C20201029090842%7C20200928095844%7C11%7C1011499:20210928092844|uid:1600682570763.1012247166.8832603.111387.149019522.:20210928092844|srchist:1011499%3A1601284122%3A20201029090842:20210928092844|tsa:1601284122769.966813945.6444116.015502127524262388:20200928095844; lastRskxRun=1601285325707; vsb_b_desktop=34; ex_vsb_b_desktop=Sun, 27 Dec 2020 09:28:47 GMT; _gali=dwfrm_storelocator_state; _hc_vid={*id*!*276fa3eb-8c10-49eb-952a-5cb14b67f1d2*~*created*!1600682567032~*psq*!24~*ord*!82~*cl*!32~*gbl*!0}; _hc_ses={*id*!*13a66646-75d1-4be2-9d6c-4505e5c229d2*~*created*!1601284119215~*isNew*!false~*psq*!8~*ord*!32~*cl*!12~*ser*!false~*attr*![*(direct)*~*direct*~*(not+set)*~*(not+set)*~*(none)*~*(direct)*]~*ap*!*content*}",
                              "origin": "https://www.timex.com",
                              "referer": "https://www.timex.com/stores-find",
                              "sec-fetch-mode": "navigate",
                              "sec-fetch-site": "same-origin",
                              "sec-fetch-user": "?1",
                              "upgrade-insecure-requests": "1",
                              "user-agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537.36"}
                    print(state)
                    data = {"dwfrm_storelocator_state": state,
                            "dwfrm_storelocator_findbystate": "Search"}
                    yield scrapy.FormRequest(url=link, callback=self.get_store_list, method="POST", formdata=data, headers=header,
                                             meta={'source_url': source_url, 'file_path': file_path,
                                                   'proxy_type': proxy_type})
        except Exception as e:
            print("firstlevel", e, response.url)




    # Get data from the response
    def get_store_list(self, response):
        try:
            if not response.url.startswith('file://'):
                self.f1.page_save(response.meta['file_path'], response.body)
            search_term = response.meta.get('search_term', '')

            try:
                options = Options()
                # options.headless = True
                from selenium import webdriver

                driver = webdriver.Chrome(chrome_options=options, executable_path="chromedriver.exe")
                driver.maximize_window()
                time.sleep(10)

                driver.get(response.url)

                res = driver.page_source
                response = HtmlResponse(url=driver.current_url, body=bytes(res.encode('utf-8')))
                print(response)
                item = StoreLocatorsItem()
                store_data = response.xpath('//*[@id="store-location-results"]/tbody/tr')
                for data in store_data:

                    try:
                        address = data.xpath('normalize-space(.//*[@class="store-address"]/text()[1])').extract_first().strip()
                        city = data.xpath('normalize-space(.//*[@class="store-address"]/text()[2])').extract_first().strip().split(',')[0].strip()
                        state = data.xpath('normalize-space(.//*[@class="store-address"]/text()[2])').extract_first().strip().split(',')[-1].strip().split(' ')[0]
                        zip_code = data.xpath('normalize-space(.//*[@class="store-address"]/text()[2])').extract_first().strip().split(',')[-1].strip().split(' ')[-1]
                    except Exception as e:
                        print("address", e, response.url)
                    try:
                        store_name = data.xpath('normalize-space(.//*[@class="store-name"]/text())').extract_first().replace('(','').strip() + ' - ' + str(city)
                    except Exception as e:
                        print("store_name", e, response.url)
                    # try:
                    #     latitude = re.findall(r'data-lat=\'(.*?)\'', response.text)[0]
                    #     longitude = re.findall(r'data-lng=\'(.*?)\'', response.text)[0]
                    # except Exception as e:
                    #     print("latitude and longitude", e, response.url)

                    try:
                        store_hour = '|'.join(data.xpath('.//*[@class="store-hours"]/p/text()').extract())
                        store_hours = store_hour.strip().replace('\r', '').replace('\n', '').replace('  ', ' ')
                    except Exception as e:
                        print("store_hours", e, response.url)

                    item['search_term'] = search_term
                    item['store_name'] = store_name
                    item['address'] = address
                    item['city'] = city
                    item['state'] = state
                    item['zip_code'] = zip_code
                    # item['latitude'] = latitude
                    # item['longitude'] = longitude
                    item['store_type'] = ''
                    item['coming_soon'] = 0
                    item['source_url'] = response.url
                    item['country_code'] = item['country'] = 'US'  # self.f1.country_dict.get(item['country'].lower())
                    item['store_hours'] = store_hours.strip('|')
                    if item['country_code'] == 'US' and len(item['state']) > 2:
                        item['state'] = self.f1.state_dict.get(state, '')
                    yield item
            except Exception as e:
                print(e)

        except Exception as e:
            logging.log(logging.ERROR, e)

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_173 -a list_id=173 -a proxy_type='''.split())
