# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import re

import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime
from selenium import webdriver                    # Import module
from selenium.webdriver.common.keys import Keys   # For keyboard keys
import time                                       # Waiting function


class tigermowersSpider(scrapy.Spider):
    name = 'store_176'
    allowed_domains = []

    # not_export_data = True
    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        try:

            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                print(search_terms)
            # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)
                search_terms = ''
                for search_term in (search_terms):
                    source_url = link = 'https://stretchlab.com/locations/'
                    file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(search_term) + '_' + str(self.run_date) + '.html'
                    if os.path.exists(file_path):
                        link = 'file://' + file_path.replace('\\','/')
                    yield scrapy.FormRequest(url=str(link), callback=self.get_store_list, meta={'source_url': source_url,'search_term': search_term,'file_path':file_path,'proxy_type': self.proxy_type})
            else:
                # links = ['https://www.tigermowers.com/find-a-dealer?dealerCountry=CA','https://www.tigermowers.com/find-a-dealer?dealerCountry=US']
                links = ['https://www.tigermowers.com/find-a-dealer?dealerCountry=CA',
                         'https://www.tigermowers.com/find-a-dealer?dealerCountry=US'
                         ]
                for link in links:
                    source_url = link
                    file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
                            self.run_date) + '.html'
                    yield scrapy.FormRequest(url=str(link), callback=self.parse,
                                                 meta={'source_url': source_url,
                                                       'file_path': file_path, 'proxy_type': self.proxy_type})

        except Exception as e:
            logging.log(logging.ERROR, e)

    def parse(self, response):
        try:
           file_path =  response.meta['file_path']
           countstmp = response.xpath('//h3[@class="dealer-results-count"]/text()').extract_first()
           countstmp1 = int(re.findall('(\d+)',countstmp)[0])
           check = response.url.split("?")[0]
           check1 = response.url.split("?")[1]
           pages = int(countstmp1/9)
           others= countstmp1%9
           if others>0:
               pages = pages+1
           else:
               pages = pages
           for i in range(1,pages+1):
               newurl = check+"/p"+str(i)+"?"+check1
               yield scrapy.FormRequest(url=newurl,callback=self.get_store_list,meta={
                                                       'file_path': file_path})
        except Exception as e:
            print("parse",e,response.url)


    def get_store_list(self, response):
        try:
            if not response.url.startswith('file://'):
                self.f1.page_save(response.meta['file_path'],response.body)

            try:
                divs = response.xpath('//div[@class="dealer-column"]')
                for div in divs:

                    try:
                        fulladdress = div.xpath('.//div[@class="address dealer-info"]/a/text()').extract()
                        citystatezipcode = fulladdress[1].strip().split(',')
                        city = citystatezipcode[0].strip()
                        statezipcode = citystatezipcode[1].strip()
                        statezipcodetmp = statezipcode.split()
                        le = len(statezipcodetmp)
                        if le == 2:
                            state = statezipcodetmp[0].strip()
                            zip_code = statezipcodetmp[1].strip()

                        else:
                            state = statezipcodetmp[0].strip()
                            zip_code = statezipcodetmp[1].strip()+" "+statezipcodetmp[2].strip()
                    except Exception as e:
                        print("fulladdress",e,response.url)


                    try:
                        check = False
                        address  = fulladdress[0].strip()
                        for i in ['Unit', 'STE', 'Ste' ]:
                            for aw in address.split():
                                if i == aw:

                                    address1 = address.split(i)[0].strip(',')
                                    address_line_2 = i + ' ' + address.split(i)[-1].strip()
                                    check = True
                                    break
                        if check == True:
                            address_line_2 = address_line_2
                            address = address1
                        else:
                            address_line_2 = ''
                            address = address


                    except Exception as e:
                        print("address", e, response.url)


                    # for i in ['unit', 'suite', 'suit', 'ste']:



                    try:
                        city = city
                    except Exception as e:
                        print("city", e, response.url)

                    try:
                        state = state
                    except Exception as e:
                        print("state", e, response.url)

                    try:
                        zip_code = zip_code
                    except Exception as e:
                        print("zip_code", e, response.url)

                    try:
                        store_name = div.xpath('.//h4/text()').extract_first().strip()+" - "+city
                    except Exception as e:
                        print("store_name", e, response.url)

                    try:
                        phone_numbertmp = div.xpath('.//div[@class="phone dealer-info"]/div/a/text()').extract()
                        if len(phone_numbertmp)>1:
                            phone_number = phone_numbertmp[1]
                            tallfreeno = phone_numbertmp[0].replace('(toll-free)','').strip()
                        else:
                            phone_number = phone_numbertmp[0].replace('(toll-free)','').strip()
                            tallfreeno = ''
                    except Exception as e:
                        print("phonenumber", e, response.url)

                    try:
                        website_address = div.xpath('.//div[@class="website dealer-info"]/a/text()').extract_first()
                        if website_address == None:
                            website_address = ''
                        else:
                            website_address = website_address.strip()
                    except Exception as e:
                        print("webaddress",e,response.url)

                    try:
                        additional_info = {}
                        additional_info['Toll Free No'] = tallfreeno
                    except Exception as e:
                        additional_info = '{}'
                        print("additionalinfo",response.url,e)

                    try:
                        email_address = div.xpath('.//div[@class="manager dealer-info"]/a/text()').extract_first().strip()
                        # if email_address == None:
                        #     email_address = ''
                        # else:
                        #     email_address = email_address.strip()

                    except Exception as e:
                        email_address = ""
                        print("email_address",e,response.url)

                    try:
                        if "US" in response.url:
                            country = "US"
                        else:
                            country = "CA"
                    except Exception as e:
                        print("country",e,response.url)

                    item = StoreLocatorsItem()
                    item['search_term'] = 'link'
                    item['store_name']= store_name
                    item['address'] = address
                    item['address_line_2'] = address_line_2
                    item['city'] = city
                    item['state'] =state
                    item['zip_code'] = zip_code
                    item['phone_number'] = phone_number
                    item['latitude'] = ''
                    item['longitude'] = ''
                    item['store_type'] = ''
                    item['website_address'] = website_address
                    item['coming_soon'] = 0
                    item['store_number'] = ''
                    item['country_code'] = item['country'] =  country#self.f1.country_dict.get(item['country'].lower())
                    item['email_address'] = email_address
                    item['services'] = ''
                    item['source_url']=response.url
                    item['store_hours'] = ''
                    item['additional_info'] = json.dumps(additional_info)

                    yield item
            except Exception as e:
                print("tigermowers",e,response.url)

        except Exception as e:
            logging.log(logging.ERROR, e)

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_176 -a list_id=176'''.split())
