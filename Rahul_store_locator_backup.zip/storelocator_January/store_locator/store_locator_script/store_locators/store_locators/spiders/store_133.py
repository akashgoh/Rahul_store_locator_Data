#-*- coding: utf-8 -*-
# pip install scrapy-html-storage
import random
import re


import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime

class Store133Spider(scrapy.Spider):
    name = 'store_133'
    allowed_domains = []


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()


    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            self.f1.set_details(self.list_id,run_date)
            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                print(search_terms)
            # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)
                search_terms = ''
                for search_term in (search_terms):
                    source_url = link = 'https://www.walkaboutbars.co.uk/sitemap'
                    file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(search_term) + '_' + str(run_date) + '.html'
                    if os.path.exists(file_path):
                        link = 'file://' + file_path.replace('\\','/')
                    yield scrapy.FormRequest(url=str(link), callback=self.get_store_list, meta={'source_url': source_url,'search_term': search_term,'file_path':file_path,'proxy_type': self.proxy_type})
            else:
                source_url = link = 'https://www.walkaboutbars.co.uk/sitemap'
                file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(run_date) + '.html'
                yield scrapy.FormRequest(url=str(link), callback=self.firstlevel,
                                         meta={'source_url': source_url,
                                               'file_path': file_path, 'proxy_type': self.proxy_type})
        except Exception as e:
            logging.log(logging.ERROR, e)


    def firstlevel(self,response):
        links = response.xpath('//ul[@class="venue-list"]/li/a/@href').extract()
        for link in links:
            yield scrapy.Request(url='https://www.walkaboutbars.co.uk'+link, callback=self.data)


    def data(self, response):
        try:store_name = response.xpath('//div[@class="large-3 columns welcome-text"]/h1//text()[2]').extract_first().strip()
        except Exception as e:print('store_name', e, response.url)

        try:
            address = response.xpath('//div[@class="address"]/p/text()').extract_first().strip()
            address = re.sub('\s+', ' ', re.sub('\r|\n|\t', ' ', address))
        except Exception as e:
            print('address', e, response.url)

        city = response.url.split('/')[-1].strip()
        if '-' in city:
            city = city.split('-')[0]

        zip_code = address.split(',')[-1].strip()

        try:phone_number = response.xpath('//*[@id="content"]/div[1]/div/div[1]/div/div[3]/ul/li[1]/a/text()').extract_first()
        except Exception as e:print('phone_number', e, response.url)

        try:
            Store_hours = []
            # store_hours = '|'.join(i.strip() for i in response.xpath('//div[@class="opening-times"]//text()').extract() if i != '').strip()
            store_hours = [i.strip() for i in response.xpath('//div[@class="opening-times"]//text()').extract()]
            for i in store_hours:
                if i != '':
                    Store_hours.append(i)
            Store_hours = '|'.join(Store_hours).strip('|').replace(':|','').strip()
        except Exception as e:
            print('store_hours', e, response.url)

        text = response.text

        try:
            lat_lng = re.findall(r'{ lat: (.*), lng: (.*) }', text)
            lat = lat_lng[0][0]
            lng = lat_lng[0][1]
        except Exception as e:
            print('lat_lng', e, response.url)

        try:email = response.xpath('//*[@id="footer"]/div[1]/div[2]/div[1]/ul[1]/li[2]/a/@href').extract_first().split(':')[-1].strip()
        except Exception as e:print('email', e, response.url)

        try:
            services = '|'.join(response.xpath('//ul[@class="menu facilities"]/li/span/text()').extract())
            services = re.sub('\s+', ' ', re.sub('\r|\n|\t', ' ', services))
        except Exception as e:
            print('services', e, response.url)

        item = StoreLocatorsItem()
        item['search_term'] = 'link'
        item['store_name'] = store_name
        item['address'] = address
        item['city'] = city
        item['state'] = ''
        item['zip_code'] = zip_code
        item['phone_number'] = phone_number
        item['latitude'] = lat
        item['longitude'] = lng
        item['store_type'] = ''
        item['website_address'] = response.url
        item['coming_soon'] = 0
        item['store_number'] = ''
        item['country_code'] = item['country'] = 'GB'  # self.f1.country_dict.get(item['country'].lower())
        item['email_address'] = email
        item['services'] = services
        item['store_hours'] = Store_hours
        item['additional_info'] = ''

        # if item['country_code'] == 'US' and len(item['state']) > 2:
        #     item['state'] = self.f1.state_dict.get(state, '')
        yield item

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_133 -a list_id=133'''.split())