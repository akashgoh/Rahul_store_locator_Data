# # -*- coding: utf-8 -*-
# # pip install scrapy-html-storage
# import re
#
# import scrapy,os,logging,hashlib
# import requests,json
# from scrapy.http import HtmlResponse
# from scrapy.cmdline import execute
# from store_locators.items import StoreLocatorsItem
# from store_locators.spiders.common_functions import Func
# import datetime
# import html2text
#
#
# class Store150Spider(scrapy.Spider):
#     name = 'store_150'
#     allowed_domains = []
#     not_export_data  =True
#     start_urls = ['https://www.ucaoa.org/Resources/Find-an-Urgent-Care']
#
#     def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
#         super().__init__(name, **kwargs)
#         self.list_id, self.proxy_type = list_id, proxy_type
#         self.f1 = Func()
#         self.run_date = str(datetime.datetime.today()).split()
#
#     def start_requests(self):
#         run_date = str(datetime.datetime.today()).split()[0]
#         self.f1.set_details(self.list_id, run_date)
#         try:
#             search_terms = self.f1.get_search_term(self.f1.search_by)
#             # for search_term in (search_terms):
#             #     lat = search_term.split('_')[0]
#             #     lng = search_term.split('_')[1]
#             source_url = link = ""
#                 # source_url = link = f"https://www.abbottscustard.com/wp-admin/admin-ajax.php?action=store_search&lat={lat}&lng={lng}&max_results=25&search_radius=50&autoload=1"
#             header = {
#                 "accept":"*/*",
#                 "accept-encoding":"gzip, deflate, br",
#                 "accept-language":"en-US,en;q=0.9",
#                 "x-requested-with":"XMLHttpRequest",
#                 "user-agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36",
#                 "referer":"https://www.abbottscustard.com/locations/",
#                 "cookie":"PHPSESSID=5ef7ff7993f5bd2992f33466086cdeb6"
#             }
#             print(source_url)
#
#             # file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(search_terms) + '_' + str(run_date) + '.html'
#             yield scrapy.Request(url=str(source_url), callback=self.get_store_list,headers=header,
#                                      meta={'source_url': source_url,'proxy_type': self.proxy_type})
#
#         except Exception as e:
#             logging.log(logging.ERROR, e)
#
#
#
