# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import re

import html2text
import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime


class store199Spider(scrapy.Spider):
    name = 'store_199'
    allowed_domains = []
    f1 = Func()

    def __init__(self, name=None, list_id="",proxy_type="",**kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type= list_id, proxy_type

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            source_url = link = 'http://www.supremofoods.com/locations.html'
            self.f1.set_details(self.list_id, run_date)
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
                run_date) + '.html'
            if os.path.exists(file_path):
                link = 'file://' + file_path.replace('\\', '/')

            yield scrapy.FormRequest(url=str(link), callback=self.get_store_list,meta={'source_url': source_url,'file_path': file_path,'proxy_type': self.proxy_type})
        except Exception as e:
            print(e)

    def get_store_list(self,response):
        if not response.url.startswith('file://'):
            self.f1.page_save(response.meta['file_path'], response.body)
        source_url = response.meta.get('source_url', '')

        try:
            item = StoreLocatorsItem()
            # block = response.text.split('alt="Download Ad"')
            # del block[0:4]
            block = re.findall(r'<p class="Circular-Text-Head" id="(.*?)</p>', response.text)
            block = [block for block in block if not "Store Hours:" in block]
            del block[1]
            del block[13]
            del block[-1]
            block = [block for block in block if not 'Office' in block]
            block = block + ['Fax:</span>']


            address = re.findall(r'-2">(.*?),',str(block))
            add_info = ['Elizabeth, NJ 07201', 'Trenton, NJ 08618', 'Trenton, NJ 08611', 'Pennsauken, NJ 08109','Elizabeth, NJ 07202', 'Irvington, NJ 07011', 'Jersey City, NJ 07307', 'Perth Amboy, NJ 08861', 'Plainfield, NJ 07060', 'Philadelphia, PA 19124', 'Philadelphia, PA 19104', 'Allentown, PA 18102']
            fax = re.findall(r"Fax:(.*?)'",str(block))
            phnnumber =re.findall(r"Tel:(.*?)'",str(block))
            name = re.findall(r'r_item colelem" id="(.*?)" data-si',str(response.text))
            del name[0]

            for address,add_info,fax, phnnumber,name in zip(address,add_info,fax,phnnumber,name):
                address = address.replace('</span>','').replace("\\'","").replace("'","").strip()
                add_info = add_info
                fax = fax.replace('</span>','').replace(' </span><span id="u23665-11">','').strip()
                phnnumber = phnnumber.replace('</span>','').replace(' </span><span id="u23665-8">','').strip()
                name = name

                add_info = add_info.strip()
                item['store_hours'] = ''
                item['coming_soon'] = 0
                item['store_name'] = name

                item['address'] = address.strip()
                item['address_line_2'] = ''
                item['city'] = add_info.split(',')[0]
                item['state'] = add_info.split(',')[1].split()[0]
                item['zip_code'] = add_info.split(',')[1].split()[1]

                item['phone_number'] = phnnumber.replace('(Store)','').strip()
                item['fax_number'] = fax.strip()
                item['email_address'] = ''
                item['store_type'] = ''
                item['website_address'] = 'http://www.supremofoods.com/'
                item['store_number'] = ''

                item['country'] = 'US'
                item['source_url'] = source_url
                item['country_code'] = 'US'

                if item['country_code'] == 'US' and len(item['state']) > 2:
                    item['state'] = self.f1.state_dict.get(item['state'].lower(), '')

                add_info = dict()
                add_info['distance'] = ''
                add_info['thumb'] = ''
                add_info['description'] = ''
                item['additional_info'] = ''
                yield item
        except Exception as e:
            print(e)

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_199 -a list_id=199 -s HTTPCACHE_ENABLED=True'''.split())