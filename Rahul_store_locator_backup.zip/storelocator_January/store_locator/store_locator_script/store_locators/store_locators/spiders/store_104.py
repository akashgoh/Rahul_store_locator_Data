# -*- coding: utf-8 -*-
import re

import scrapy,os,logging,hashlib
import requests,json
from string import punctuation
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime

class ZebcoCrawlerSpider(scrapy.Spider):
    name = 'store_104'
    allowed_domains = []
    not_export_data = False

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type

        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        try:
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
                self.run_date) + '.html'
            source_url = url = 'https://www.zebco.com/amlocator/index/ajax/'
            head = {'Host': 'www.zebco.com',
                   'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0',
                   'Accept': '*/*',
                   'Accept-Language': 'en-GB,en;q=0.5',
                   'Accept-Encoding': 'gzip, deflate, br',
                   'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                   'X-Requested-With': 'XMLHttpRequest',
                   'Origin': 'https://www.zebco.com',
                   'Referer': 'https://www.zebco.com/retail-locations/'
                   # Cookie: form_key=MXjEyHgd1qXKFHqq; ZBQSESSID=f7f1bf010b342ae4a07c66e8093c5e01; _gcl_au=1.1.972533256.1573447104; mage-cache-storage-section-invalidation=%7B%7D; mage-cache-sessid=true; mage-banners-cache-storage=%7B%7D; mage-messages=; recently_viewed_product=%7B%7D; recently_viewed_product_previous=%7B%7D; recently_compared_product=%7B%7D; recently_compared_product_previous=%7B%7D; product_data_storage=%7B%7D; section_data_ids=%7B%22cart%22%3A1573447105%7D; _ga=GA1.2.138422231.1573447107; _gid=GA1.2.962103143.1573447107; _fbp=fb.1.1573447106885.521754072
                   }
            data = {"lat": "", "lng": "", "radius": "500", "mapId": "amlocator-map-canvas-wcb","storeListId": "amlocator_store_list5dc8e3875aa0d", "product": "", "category": "", "attributes": ""}

            yield scrapy.FormRequest(url=url,headers=head,formdata=data, callback=self.get_store_list,meta={'source_url': source_url,'file_path': file_path, 'proxy_type': self.proxy_type})
        except Exception as e:
            logging.log(logging.ERROR, e)

    def get_store_list(self, response):
        source_url = response.meta['source_url']

        file_path = response.meta['file_path']
        proxy_type = response.meta['proxy_type']
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            if not response.url.startswith('file://'):
                file_path = self.f1.html_link_directory + str(self.list_id) + '_link_' + str(run_date) + '.html'
                self.f1.page_save(file_path,response.body)

                df = json.loads(response.text)
                store_loop = df['items']
                for lp in store_loop:
                    store_number = lp['id']
                    store_name = lp['name']
                    address = lp['address'].strip(punctuation).strip()
                    address= address[:-1] if address.strip()[-1]==',' else address
                    add2, add3 = '', ''
                    if address.count(',')==2:
                        address = address.split(',')[0].strip()
                        add2 = lp['address'].strip(punctuation)[:-1] if lp['address'].strip(punctuation)[:-1].strip()[-1]==',' else lp['address'].strip(punctuation)[:-1].strip().split(',')[1].strip()
                        add3 = lp['address'].strip(punctuation)[:-1] if lp['address'].strip(punctuation)[:-1].strip()[-1]==',' else lp['address'].strip(punctuation)[:-1].strip().split(',')[2].strip()
                    elif 'SUITE' in address:
                        ad = re.split('(SUITE.*)', address.strip())
                        address = ad[0].strip(punctuation).strip()
                        add2 = ad[1].strip()
                    elif '#' in address:
                        ad = re.split('(\#.*)', address.strip())
                        address = ad[0].strip(punctuation).strip()
                        add2 = ad[1].strip()
                    elif 'UNIT' in address:
                        ad = re.split('(UNIT.*)', address.strip())
                        address = ad[0].strip(punctuation).strip()
                        add2 = ad[1].strip()
                    elif 'Unit' in address:
                        ad = re.split('(Unit.*)', address.strip())
                        address = ad[0].strip(punctuation).strip()
                        add2 = ad[1].strip()
                    elif 'Suite' in address:
                        ad = re.split('(Suite.*)', address.strip())
                        address = ad[0].strip(punctuation).strip()
                        add2 = ad[1].strip()
                    elif ',' in address:
                        ad = re.split('(,.*)', address.strip())
                        address = ad[0].strip(punctuation).strip()
                        add2 = ad[1].strip()
                    city = lp['city']
                    state = lp['state']
                    zip = lp['zip']
                    store_hours = lp['schedule']
                    phone = lp['phone']
                    lat = lp['lat']
                    long = lp['lng']

                    item = StoreLocatorsItem()
                    item['store_number'] = store_number
                    item['store_name'] = store_name
                    item['address'] = address
                    item['address_line_2'] = add2.replace(',','').strip()
                    item['address_line_3'] = add3.replace(',','').strip()
                    item['city'] = city
                    item['state'] = state
                    item['zip_code'] = zip
                    item['country'] = 'US'
                    item['country_code'] = 'US'
                    item['store_hours'] = store_hours
                    item['coming_soon'] = 0
                    item['phone_number'] = phone if lp['phone']!=None else ''
                    item['website_address'] = response.url
                    item['latitude'] = lat
                    item['longitude'] = long
                    item['source_url'] = 'https://www.zebco.com/retail-locations/'
                    yield item
        except Exception as e:
            logging.log(logging.ERROR,e)

# execute('''scrapy crawl store_104 -a list_id=104'''.split())
