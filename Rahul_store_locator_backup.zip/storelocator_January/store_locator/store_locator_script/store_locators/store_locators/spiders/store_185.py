# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import random
import re


import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime


class Store185Spider(scrapy.Spider):
    name = 'store_185'
    allowed_domains = []
    not_export_data=True


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()


    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        self.f1.set_details(self.list_id,run_date)
        if self.f1.search_by != 'link':
            search_terms = self.f1.get_search_term(self.f1.search_by)
            print(search_terms)
        # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)
            search_terms = ''
            for search_term in (search_terms):
                source_url = link = 'https://bflgroup.ae/locate-store/'
                file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(search_term) + '_' + str(run_date) + '.html'
                if os.path.exists(file_path):
                    link = 'file://' + file_path.replace('\\','/')
                yield scrapy.FormRequest(url=str(link), callback=self.data, meta={'source_url': source_url,'search_term': search_term,'file_path':file_path,'proxy_type': self.proxy_type})
        else:
            yield scrapy.Request(url='https://bflgroup.ae/locate-store/', callback=self.data)


    def data(self, response):
        links = response.xpath('//div[@class="stm_works"]//div[@class="title"]/a/@href').extract()
        for link in links:
            yield scrapy.Request(url=link, callback=self.parse_data)
            # yield scrapy.Request(url='https://bflgroup.ae/Locate/grenada-mall-riyadh/', callback=self.parse_data)


    def parse_data(self, response):
        try:
            store_name = 'BFL Group - ' + response.xpath('//div[@class="wpb_wrapper"]/h5/text()').extract_first(default='')
            if store_name == 'BFL Group - ':
                store_name = 'BFL Group ' + response.xpath('//h1[@class="h2"]/text()').extract_first(default='')
        except Exception as e:
            print(e)

        try:address1 = response.xpath('//div[@class="wpb_wrapper"]/p/text()|//div[@class="wpb_text_column"]/p/text()').extract()
        except Exception as e:print(e)

        Address = []
        for add in address1:
            if 'Tel' not in add:
                if 'Email' not in add:
                    if 'E-mail' not in add:
                        if 'Fax' not in add:
                            Address.append(add.strip())
        address = ', '.join(Address).replace(',,',', ')

        # if 'UAE' in address or 'Lebanon' in address or 'Saudi Arabia' in address or 'Oman' in address or 'Kuwaiaddress' in address or 'Maladdressa' in address:
        #     address = address.split(',')[0].replace(',','')
        # else:
        #     address = address.replace(',','')

        t = ''.join(address1)
        try:
            if 'Tel:' in t.strip() or 'Tel. No.' in t.strip() or 'Tel.:':
                phone_number = ''.join(re.findall(r'Tel: (.*)|Tel. No.(.*)|Tel.:(.*)', t)[0])
            else:
                phone_number = ''
        except:phone_number=''
        try:
            if 'Fax:' in t.strip():
                fax_number = re.findall(r'Fax: (.*)', t)[0]
            else:
                fax_number = ''
        except:fax_number=''
        try:
            if 'E-mail ID :' in t or 'Email:' in t.strip() or 'E-mail:' in t.strip():
                email_address = ''.join(re.findall(r'E-mail ID :(.*)|Email:(.*)|E-mail:(.*)', t)[0])
            else:
                email_address = ''
        except:email_address=''

        if 'UAE' in t.strip():
            country = 'United Arab Emirates'
            country_code = 'UA'
        elif 'Lebanon' in t.strip():
            country = 'Lebanon'
            country_code = 'LB'
        elif 'Saudi Arabia' in t.strip():
            country = 'Saudi Arabia'
            country_code = 'SA'
        elif 'Oman' in t.strip():
            country = 'Oman'
            country_code = 'OM'
        elif 'Kuwait' in t.strip():
            country = 'Kuwait'
            country_code = 'KW'
        elif 'Malta' in t.strip():
            country = 'Malta'
            country_code = 'ML'
        else:
            country = ''
            country_code = ''

        if address == 'Showroom # R7B':
            phone_number = '04 288 5864'

        # for t in address1:
        #     if 'Tel:' in t.strip():
        #         phone_number = re.findall(r'Tel: (.*)', t)[0]
        #     else:
        #         phone_number = ''
        #     if 'Fax:' in t.strip():
        #         fax_number = re.findall(r'Fax: (.*)', t)[0]
        #     else:
        #         fax_number = ''
        #     if 'E-mail ID :' in t or 'Email:' in t.strip() or 'E-mail:' in t.strip():
        #         email_address = ''.join(re.findall(r'E-mail ID :(.*)|Email:(.*)|E-mail:(.*)', t)[0])
        #     else:
        #         email_address = ''
        #     if 'UAE' in t.strip() or 'Lebanon' in t.strip() or 'Saudi Arabia' in t.strip() or 'Oman' in t.strip() or 'Kuwait' in t.strip() or 'Malta' in t.strip():
        #         country = t.split(',')[-1]
        #         # city = re.findall(r'(\w+)\, '+str(country), t)[0]
        #     else:
        #         country = ''


        item = StoreLocatorsItem()
        item['search_term'] = 'link'
        item['store_name']= store_name
        item['address'] = address
        item['store_hours'] = ''
        item['city'] = ''
        item['state'] = ''
        item['country'] = country
        item['country_code'] = country_code
        item['zip_code'] = ''
        item['phone_number'] = phone_number
        item['fax_number'] = fax_number
        item['email_address'] = email_address
        item['coming_soon'] = 0
        item['source_url'] = response.url
        yield item


    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_185 -a list_id=185'''.split())

