# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import random
import re
import pymysql as MySQLdb
import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime

class TruGreenSpider(scrapy.Spider):
    name = 'store_160'
    allowed_domains = []
    not_export_data = False
    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type

        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.f1.set_details(self.list_id, self.run_date)
        self.run_date = str(datetime.datetime.today()).split()[0]

    def start_requests(self):

        try:
            source_url = url = 'https://www.trugreen.com/local-lawn-care'

            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
                self.run_date) + '.html'
            yield scrapy.FormRequest(url=url, callback=self.all_link,meta={'source_url': source_url,'file_path': file_path, 'proxy_type': self.proxy_type})

        except Exception as e:
            print(e)

    def all_link(self,response):
        count = 0

        links = response.xpath('//section[@class="d-lg-flex d-none mb-10 mb-md-20 row"]/div[@class="col"]/a/@href').getall()
        for link in links:
            count = count+1
            url = 'https://www.trugreen.com'+ str(link)
            yield scrapy.FormRequest(url=url, callback=self.jlink)

    def jlink(self,response):

        a = response.url

        a2 = a.split('/')[-1]

        url = f'https://www.trugreen.com/cms/content/GetLocalLawnCare/{a2}'
        header = {":authority": "www.trugreen.com",
                    ":method": "GET",
                    ":path": f"/cms/content/GetLocalLawnCare/{a2}",
                    ":scheme": "https",
                    "accept": "application/json, text/plain, */*",
                    "accept-encoding": "gzip, deflate, br",
                    "accept-language": "en-US,en;q=0.9",
                    "referer": response.url,
                    "sec-fetch-dest": "empty",
                    "sec-fetch-mode": "cors",
                    "sec-fetch-site": "same-origin",
                    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.135 Safari/537.36"

        }
        yield scrapy.FormRequest(url=url,headers= header, callback=self.parse)
    def parse(self, response):
        data = response.text

        urls = re.findall(r'"BranchUrl":"(.*?)",',data)


        # for i,j,k in zip(urls,latitude,longitude):
        for i in urls:

            link = i.replace("\\","")
            storelink = 'https://www.trugreen.com' + str(link)


            yield scrapy.FormRequest(url=storelink, callback=self.store)

    def store(self,response):
        # if not response.url.startswith('file://'):
        #     self.f1.page_save(response.meta['file_path'], response.body)
        item = StoreLocatorsItem()
        nxt_link = response.xpath('//*[@id="react-google-map-component"]/section/div[2]/a/@href').get()
        if nxt_link != None:
            link = 'https://www.trugreen.com' + str(nxt_link)
            yield scrapy.FormRequest(url=link, callback=self.instore)

        else:
            Address = response.xpath('//div[@class="field field--name-field-branch-address-line-1 field--type-string field--label-hidden field--item"]/text()').get()
            csz = response.xpath('//*[@id="js-branch"]/div[1]/div/div/div[1]/div[1]/div[1]/span[3]/text()').get().strip()
            city = csz.split(',')[0]
            state = csz.split(',')[1].split(' ')[0]
            zip = csz.split(',')[1].split('  ')[-1]
            store_hours = "| ".join(response.xpath('//div[@class="field field--name-field-hours-of-operation field--type-text-long field--label-hidden field--item"]/div/div//text()').getall())
            phone = response.xpath('//*[@id="js-branch"]/div[1]/div/div/div[1]/div[1]/div[1]/a/text()').get()
            latitude = re.findall(r'"latitude": "(.*?)",',response.text)[0]
            print(latitude)
            longitude = re.findall(r'"longitude": "(.*?)"',response.text)[0]
            store_name = 'TruGreen - ' + city
            try:
                item['store_name'] = store_name
                item['Address'] = Address
                item['city'] = city
                item['state'] = state
                item['zip_code'] = zip
                item['store_hours'] = store_hours
                item['phone_number'] = phone
                item['country'] = item['country_code']= 'US'
                item['source_url'] = response.url
                item['Longitude'] = longitude
                item['Latitude'] = latitude
                yield item
            except Exception as e:
                print(e)

    def instore(self,response):
        item = StoreLocatorsItem()

        Address = response.xpath('//div[@class="field field--name-field-branch-address-line-1 field--type-string field--label-hidden field--item"]/text()').get()
        csz = response.xpath('//*[@id="js-branch"]/div[1]/div/div/div[1]/div[1]/div[1]/span[3]/text()').get().strip()
        city = csz.split(',')[0]
        state = csz.split(',')[1].split(' ')[0]
        zip = csz.split(',')[1].split('  ')[-1]
        store_hours = "| ".join(response.xpath('//div[@class="field field--name-field-hours-of-operation field--type-text-long field--label-hidden field--item"]/div/div//text()').getall())
        phone = response.xpath('//*[@id="js-branch"]/div[1]/div/div/div[1]/div[1]/div[1]/a/text()').get()
        store_name = 'TruGreen - ' + city
        latitude = re.findall(r'"latitude": "(.*?)",', response.text)[0]
        print(latitude)
        longitude = re.findall(r'"longitude": "(.*?)"', response.text)[0]
        try:
            item['store_name'] = store_name
            item['Address'] = Address
            item['city'] = city
            item['state'] = state
            item['zip_code'] = zip
            item['store_hours'] = store_hours
            item['phone_number'] = phone
            item['country'] = item['country_code'] = 'US'
            item['source_url'] = response.url
            item['Longitude'] = longitude
            item['Latitude'] = latitude
            yield item
        except Exception as e:
            print(e)

# execute('''scrapy crawl store_160 -a list_id=160'''.split())









