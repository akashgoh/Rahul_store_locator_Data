# # -*- coding: utf-8 -*-
# # pip install scrapy-html-storage
# import re
#
# import scrapy,os,logging,hashlib
# import requests,json
# from scrapy.http import HtmlResponse
# from scrapy.cmdline import execute
# from store_locators.items import StoreLocatorsItem
# from store_locators.spiders.common_functions import Func
# import datetime
#
#
# class VictoriasSecretSpider(scrapy.Spider):
#     name = 'store_145'
#     allowed_domains = []
#
#     def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
#         super().__init__(name, **kwargs)
#         self.list_id, self.proxy_type = list_id, proxy_type
#         self.f1 = Func()
#         self.run_date = str(datetime.datetime.today()).split()[0]
#         self.f1.set_details(self.list_id, self.run_date)
#
#     def start_requests(self):
#         try:
#             if self.f1.search_by != 'link':
#                 search_terms = self.f1.get_search_term(self.f1.search_by)
#                 print(search_terms)
#                 search_terms = ''
#                 for search_term in (search_terms):
#                     source_url = link = 'https://www.victoriassecret.com/gb/store-locator#storeList/US'
#                     file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(search_term) + '_' + str(self.run_date) + '.html'
#                     if os.path.exists(file_path):
#                         link = 'file://' + file_path.replace('\\','/')
#                     yield scrapy.FormRequest(url=str(link), callback=self.get_store_list, meta={'source_url': source_url,'search_term': search_term,'file_path':file_path})
#             else:
#                 source_url = link = 'https://www.victoriassecret.com/gb/store-locator#storeList/US'
#                 file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(self.run_date) + '.html'
#                 yield scrapy.FormRequest(url=str(link), callback=self.get_storelinks,meta={'source_url': source_url,'file_path': file_path})
#
#         except Exception as e:
#             logging.log(logging.ERROR, e)
#
#     def get_storelinks(self, response):
#
#         urls = ['https://www.victoriassecret.com/gb/store-locator#storeList/US']

#         for url in urls:
#             yield scrapy.FormRequest(url=str(url), callback=self.get_store_list, meta=response.meta, dont_filter=True)
#     # Get data from the response
#     def get_store_list(self, response):
#         try:
#             if not response.url.startswith('file://'):
#                 self.f1.page_save(response.meta['file_path'],response.body)
#
#             search_term = response.meta.get('search_term', '')
#             source_url = response.meta.get('source_url', '')
#
#             iddata = response.text
#             idtable = json.loads(iddata)
#             length1 = len(idtable)
#             for i in range(0, length1):
#                 storeid = idtable[i]['storeId']
#                 flink = 'https://www.victoriassecret.co.uk/store-locator/id?id='+str(storeid)
#                 header = {"Accept":"*/*",
#                             "Cookie":"UID=c32923c8-1c20-456e-825a-5eaa9589756d; vsSigninPrompt=true; lang=en-us; AOS-5634ad978e4e59c8-5555e0e29d99f067043825d1186e38a4=343166dda74d681aaeb2f94321fd62cd3b16800395456d9672b255280726534f; dcc=Thebe; X-Mapping-omgbnpna=AB0D94DE6EACCBF4A06643C5D0456CEA; OPTOUTMULTI=0:0%7C2045:0%7C3004:0%7C3101:0%7C3110:0%7C4001:0%7C4015:0%7C4028:0%7C6026:0%7C7117:0%7C7129:0%7C13032:0%7C20010:0%7C20067:0%7C25016:0; cmTPSet=Y; _fbp=fb.2.1570268817189.1454126726; VSSESSION=nsBrWw0x4lJ8EpYuZhUUrOA7Z1kp0QGJoNljQN326Yo9Y; AOS-03e176e6caccea8f-0e93b5d31d61f17d2dfdb31ef4832639=52f7b8005ea564478388cae6133ffc08698c47c80f28503ed378b5498a4e8d43; dcc2=nsBrWw0x4; utag_main=v_id:016d9b50dd6e00134ae9674631b503071003e06900bd0$_sn:1$_ss:0$_pn:14%3Bexp-session$_st:1570273666150$ses_id:1570268831086%3Bexp-session",
#                             "Host":"www.victoriassecret.co.uk",
#                             "Referer":"https://www.victoriassecret.co.uk/store-locator",
#                             "Sec-Fetch-Mode":"cors",
#                             "Sec-Fetch-Site":"same-origin",
#                             "User-Agent":"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36",
#                             "X-Requested-With":"XMLHttpRequest"}
#                 r = requests.get(url=flink, headers=header)
#                 data = r.text
#                 cmtable = json.loads(data)
#
#                 additional_info = {}
#                 item = StoreLocatorsItem()
#                 try:
#                     store_name = cmtable[0]['mallName']
#                 except Exception as e:
#                     print("store_name",e,response.url)
#
#                 try:
#                     phone_number = cmtable[0]['phone']
#                 except Exception as e:
#                     print("phone_number", e, response.url)
#
#                 try:
#                     email_address = ''
#                 except Exception as e:
#                     print("email_address", e, response.url)
#
#                 try:
#                     address = item['address'] = cmtable[0]['streetAddress']
#
#                     address_split_params = ('unit ', 'suit ', 'ste ', 'suite ', 'units ', 'ste. ')
#                     for address_split_param in address_split_params:
#                         if address_split_param in (address.lower()):
#                             item['address'] = (item['address'].lower()).split(address_split_param)[0]
#                             item[
#                                 'address_line_2'] = f"{address_split_param} {((address.lower()).split(address_split_param)[1])}"
#                             break
#                 except Exception as e:
#                     print("address", e, response.url)
#
#                 try:
#                     city = cmtable[0]['city']
#                 except Exception as e:
#                     print("city", e, response.url)
#
#                 try:
#                     state = cmtable[0]['state']
#                 except Exception as e:
#                     print("state", e, response.url)
#
#                 try:
#                     zip_code = cmtable[0]['postalCode']
#                 except Exception as e:
#                     print("zip_code", e, response.url)
#
#                 try:
#                     latitude = cmtable[0]['latitudeDeg']
#                     longitude = cmtable[0]['longitudeDeg']
#                 except Exception as e:
#                     print("latitude and longitude", e, response.url)
#
#                 try:
#                     prolen = len(cmtable[0]['assortmentInfo'])
#                     prod1 = []
#                     for j in range(0, prolen):
#                         prod2 = cmtable[0]['assortmentInfo'][j]['assortmentType']
#                         prod1.append(prod2)
#                     products = '|'.join(prod1)
#                 except Exception as e:
#                     print("products",e,response.url)
#
#                 try:
#                     store_hours = 'Monday-Friday : ' + cmtable[0]['hoursOpenTimeMon'] + ' - ' + cmtable[0]['hoursCloseTimeMon'] + '|' + \ hours
#                                   'Saturday  : ' + cmtable[0]['hoursOpenTimeSat'] + ' - ' + cmtable[0]['hoursCloseTimeSat'] + '|' + \
#                                   'Sunday  : ' + cmtable[0]['hoursOpenTimeSun'] + ' - ' + cmtable[0]['hoursCloseTimeSun']
#
#                 except Exception as e:
#                     print("store_hours",e,response.url)
#
#                 try:
#                     geeksquad = ''.join(response.xpath('//div[@class="inner-module"]/div[2]/text()').extract()).replace('’',"'")
#                     geeksquad = re.sub('\s+', ' ', re.sub('\r|\n|\t', ' ',str(geeksquad)))
#
#                     additional_info['geek_sqaud'] = (geeksquad)
#
#
#                 except Exception as e:
#                     print("additional_info",e,response.url)
#
#
#                 item['search_term'] = 'link'
#                 item['store_name']= store_name
#                 item['address'] = address
#                 item['city'] = city
#                 item['state'] =state
#                 item['zip_code'] = zip_code
#                 item['phone_number'] =phone_number
#                 item['latitude'] = latitude
#                 item['longitude'] = longitude
#                 item['store_type'] = ''
#                 item['website_address'] = ''
#                 item['coming_soon'] = 0
#                 item['store_number'] = ''
#                 item['country_code'] = item['country'] = cmtable[0]['country']
#                 item['email_address'] = email_address
#                 item['services'] = ''
#                 item['products'] = products
#                 item['store_hours'] = store_hours
#                 item['additional_info'] = ''
#                 item['source_url'] = 'https://www.victoriassecret.co.uk/store-locator#/store/'+str(storeid)
#
#
#                 if item['country_code'] == 'US' and len(item['state']) > 2:
#                     item['state'] = self.f1.state_dict.get(state, '')
#                 yield item
#
#         except Exception as e:
#             logging.log(logging.ERROR, e)
#
#     def response_html_path(self, request):
#         return request.meta['fpath']
#
# # execute('''scrapy crawl store_145 -a list_id=145'''.split())


# import response as response
import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime
import html2text
from pprint import pprint as pp

class store_145Spider(scrapy.Spider):
    name = 'store_145'
    allowed_domains = []
    start_urls = ['https://www.victoriassecret.com/gb/store-locator#storeList/US']
    not_export_data = False

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        self.f1.set_details(self.list_id, run_date)
        try:
            # link = 'https://www.victoriassecret.com/gb/store-locator#storeList/US'

            source_url =url = "https://api.victoriassecret.com/stores/v1/search?countryCode=US&activeCountry=GB"
            payload = {}
            headers = {
                'Accept': '*/*',
                'Host': 'api.victoriassecret.com',
                'Referer': 'https://www.victoriassecret.com/gb/store-locator',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36'
            }
            #
            # response = requests.request("GET", url, headers=headers, data=payload)
            #
            # print(response.text.encode('utf8'))
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
                run_date) + '.html'
            yield scrapy.Request(url=str(url), dont_filter=True, callback=self.parse1,headers=headers,
                                 meta={'source_url': source_url, 'file_path': file_path,
                                       'proxy_type': self.proxy_type})
        except Exception as e:
            logging.log(logging.ERROR, e)



    def parse1(self, response):
        data=response.text
        jsondata=json.loads(data)
        file_path=response.meta['file_path']
        source_url=response.meta['source_url']
        n=len(jsondata)
        for i in range(0,int(n)):
            id=jsondata[i]['storeId']
            url='https://api.victoriassecret.com/stores/v1/store/'+str(id)+'?activeCountry=GB'
            try:
                store_name = jsondata[i]["name"]
            except Exception as e:
                store_name = ''
            try:
                address = jsondata[i]["address"]["streetAddress1"]
            except Exception as e:
                address = ''
            try:
                phonenumber = jsondata[i]["address"]["phone"]
            except Exception as e:
                # print(e)
                phonenumber = ""
            try:
                city = jsondata[i]["address"]["city"]
            except Exception as e:
                city = ""
            try:
                state = jsondata[i]["address"]["region"]
            except Exception as e:
                state = ""
            try:
                zip = jsondata[i]["address"]["postalCode"]
            except Exception as e:
                zip = ""
            try:
                lat = jsondata[i]["latitudeDegrees"]
            except Exception as  e:
                lat = ''
            try:
                long = jsondata[i]["longitudeDegrees"]
            except Exception as e:
                long = ''
            yield scrapy.FormRequest(url=url,dont_filter=True,callback=self.get_store_list,meta={'store_name':store_name,'address':address,'phonenumber':phonenumber,'city':city,'state':state,'zip':zip,'lat':lat,'long':long,'source_url': source_url, 'file_path': file_path,
                                       'proxy_type': self.proxy_type})

    def get_store_list(self, response):
        if not response.url.startswith('file://'):
            self.f1.page_save(response.meta['file_path'], response.body)
            store_name=response.meta['store_name']
            address = response.meta['address']
            city = response.meta['city']
            state = response.meta['state']
            zip = response.meta['zip']
            lat = response.meta['lat']
            long = response.meta['long']
            phonenumber = response.meta['phonenumber']
            item = StoreLocatorsItem()


            data = response.text
            data1 = json.loads(data)
            # print(data1)
            property = len(data1)
            print(property)

            hour = data1['hours']
            if hour != []:

                io =str(data1['hours'][0]['isOpen'])
                print(io)
                if io != "False":
                    h1o = data1['hours'][0]['open']
                    h1c = data1['hours'][0]['close']
                    sunday = h1o+'-'+h1c
                    sun = str(str('Sun')+':'+sunday).replace('PM','').replace('AM','')

                    h2o = data1['hours'][1]['open']
                    h2c = data1['hours'][1]['close']
                    monday = h2o +'-'+ h2c
                    mon = str(str('Mon-Sat')+':'+monday).replace('PM','').replace('AM','')
                else :
                    sun= str('Sun')+':'+"closed"
                    mon = str('Mon-Sat')+':'+"closed"
            else :
                sun= str('Sun')+':'+"closed"
                mon = str('Mon-Sat')+':'+"closed"

                # h3o = data1[i]['hours'][2]['open']
        # item = StoreLocatorsItem()
            item['search_term'] = 'link'
            item['store_name']= store_name

            item['address'] = address
            item['city'] = city
            item['state'] =state
            item['zip_code'] = zip
            item['phone_number'] =phonenumber
            item['latitude'] = lat
            item['longitude'] = long
            item['store_type'] = ''
            item['website_address'] = ''
            item['coming_soon'] = 0
            item['store_number'] = ''
            item['country_code'] = item['country'] ='us'
            item['email_address'] = ''
            item['services'] = ''
            item['products'] = ''
            item['store_hours'] = sun+'|'+mon
            item['additional_info'] = ''
            item['source_url'] = response.url
        #url='https://www.victoriassecret.com/gb/store-locator'
            yield item

# execute('''scrapy crawl store_145 -a list_id=145'''.split())
