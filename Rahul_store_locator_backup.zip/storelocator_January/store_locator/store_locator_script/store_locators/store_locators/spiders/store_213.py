# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import re

import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime


class stretchlabSpider(scrapy.Spider):
    name = 'store_213'
    allowed_domains = []
    not_export_data = True

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.f1.set_details(self.list_id, self.run_date)
    def start_requests(self):

        try:

            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                print(search_terms)
            # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)
                search_terms = ''
                for search_term in (search_terms):
                    source_url = link = 'https://www.stretchlab.com/location-search'
                    file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(search_term) + '_' + str(self.run_date) + '.html'
                    if os.path.exists(file_path):
                        link = 'file://' + file_path.replace('\\','/')
                    yield scrapy.FormRequest(url=str(link), callback=self.get_store_list, meta={'source_url': source_url,'search_term': search_term,'file_path':file_path,'proxy_type': self.proxy_type})
            else:
                source_url = link = 'https://members.stretchlab.com/api/brands/stretchlab/locations?open_status=external&geoip='
                file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
                    self.run_date) + '.html'
                yield scrapy.FormRequest(url=str(link), callback=self.firstlevel,
                                         meta={'source_url': source_url,
                                               'file_path': file_path, 'proxy_type': self.proxy_type})

        except Exception as e:
            logging.log(logging.ERROR, e)


    def firstlevel(self,response):
        try:
            store_data = json.loads(response.text)
            store_datas = store_data['locations']
            print(len(store_datas))
            file_path = response.meta['file_path']
            proxy_type = response.meta['proxy_type']
            print(len(store_data))
            # store_datas = store_datas[97:]
            for store_data in store_datas:
                # break

                phonenumber = store_data['phone']
                email = store_data['email']
                address = store_data['address']
                address_2 = store_data['address2']
                if address_2 == None:
                    address_2 = ''
                else:
                    address_2 = address_2

                city = store_data['city']
                state = store_data['state']
                postal = store_data['zip']

                lat = store_data['lat']
                lng = store_data['lng']

                comingsoon = store_data['coming_soon']



                url = store_data['site_url']
                if url == None:
                    url = "https://www.stretchlab.com/location/go"

                if comingsoon == True:
                    commingsoon = 1
                else:
                    commingsoon= 0

                if url!= None:

                    yield scrapy.FormRequest(url=url,callback=self.get_store_list,meta={'file_path':file_path,'proxy_type':proxy_type,
                                                'phonenumber':phonenumber,'email':email,'commingsoon':commingsoon,
                            'address':address,'address_2':address_2,'city':city,'state':state,'postal':postal,'lat':lat,
                            'lng':lng})


        except Exception as e:
            print("firstlevel",e,url)

    # Get data from the response
    def get_store_list(self, response):
        try:
            if not response.url.startswith('file://'):
                self.f1.page_save(response.meta['file_path'],response.body)

            try:
                search_term = response.meta.get('search_term', '')


                try:
                    address = response.meta['address']
                    address_line_2 = response.meta['address_2']
                except Exception as e:
                    print("fulladdress", e, response.url)

                try:
                    email_address = response.meta['email']
                except Exception as e:
                    print("email_address", e, response.url)


                try:
                    phone_number = response.meta['phonenumber']
                except Exception as e:
                    print("phonenumber", e, response.url)



                try:
                    city = response.meta['city']
                except Exception as e:
                    print("city", e, response.url)

                try:
                    state =response.meta['state']
                except Exception as e:
                    print("state", e, response.url)

                try:
                    zip_code =response.meta['postal']
                except Exception as e:
                    print("zip_code", e, response.url)

                try:
                    latitude = response.meta['lat']
                    longitude = response.meta['lng']
                except Exception as e:
                    print("latitude and longitude", e, response.url)

                try:
                    coming_soon = response.meta['commingsoon']

                except Exception as e:
                    print("commingsoon", e, response.url)


                try:
                    if coming_soon == 1:
                        hours = ''
                    else:
                        hours = response.xpath('//span/@data-hours').extract_first()
                        if hours == None:
                            hours = ''
                        else:
                            hdata = json.loads(hours.replace('&quot;','"'))
                            if "monday" in hdata.keys():
                                if len(hdata['monday']) == 1:
                                    dayvalue = hdata['monday'][0]
                                    le = len(dayvalue)
                                    if le==2:
                                        open = dayvalue[0]
                                        close = dayvalue[1]
                                        monday = "Monday -> " + str(open) + " - " + str(close)
                                    else:
                                        monday = "Monday -> Closed"
                                elif len(hdata['monday']) == 2:
                                    open = hdata['monday'][0][0]
                                    close = hdata['monday'][1][1]
                                    monday = "Monday -> " + str(open) + " - " + str(close)
                                else:
                                    monday = "Monday -> Closed"
                            else:
                                monday = "Monday -> Closed"

                            if "tuesday" in hdata.keys():
                                if len(hdata['tuesday']) == 1:
                                    dayvalue = hdata['tuesday'][0]
                                    le = len(dayvalue)
                                    if le == 2:
                                        open = dayvalue[0]
                                        close = dayvalue[1]
                                        tuesday = "Tuesday -> " + str(open) + " - " + str(close)
                                    else:
                                        tuesday = "Tuesday -> Closed"
                                elif len(hdata['tuesday']) == 2:
                                    open = hdata['tuesday'][0][0]
                                    close = hdata['tuesday'][1][1]
                                    tuesday = "Tuesday -> " + str(open) + " - " + str(close)
                                else:
                                    tuesday = "Tuesday -> Closed"
                            else:
                                tuesday = "Tuesday -> Closed"

                            if "wednesday" in hdata.keys():
                                if len(hdata['wednesday']) == 1:
                                    dayvalue = hdata['wednesday'][0]
                                    le = len(dayvalue)
                                    if le == 2:
                                        open = dayvalue[0]
                                        close = dayvalue[1]
                                        wednesday = "Wednesday -> " + str(open) + " - " + str(close)
                                    else:
                                        wednesday = "Wednesday -> Closed"
                                elif len(hdata['wednesday']) == 2:
                                    open = hdata['wednesday'][0][0]
                                    close = hdata['wednesday'][1][1]
                                    wednesday = "Wednesday -> " + str(open) + " - " + str(close)
                                else:
                                    wednesday = "Wednesday -> Closed"
                            else:
                                wednesday = "Wednesday -> Closed"

                            if "thursday" in hdata.keys():
                                if len(hdata['thursday']) == 1:
                                    dayvalue = hdata['thursday'][0]
                                    le = len(dayvalue)
                                    if le == 2:
                                        open = dayvalue[0]
                                        close = dayvalue[1]
                                        thursday = "Thursday -> " + str(open) + " - " + str(close)
                                    else:
                                        thursday = "Thursday -> Closed"
                                elif len(hdata['thursday']) == 2:
                                    open = hdata['thursday'][0][0]
                                    close = hdata['thursday'][1][1]
                                    thursday = "Thursday -> " + str(open) + " - " + str(close)
                                else:
                                    thursday = "Thursday -> Closed"
                            else:
                                thursday = "Thursday -> Closed"

                            if "friday" in hdata.keys():
                                if len(hdata['friday']) == 1:
                                    dayvalue = hdata['friday'][0]
                                    le = len(dayvalue)
                                    if le == 2:
                                        open = dayvalue[0]
                                        close = dayvalue[1]
                                        friday = "Friday -> " + str(open) + " - " + str(close)
                                    else:
                                        friday = "Friday -> Closed"
                                elif len(hdata['friday']) == 2:
                                    open = hdata['friday'][0][0]
                                    close = hdata['friday'][1][1]
                                    friday = "Friday -> " + str(open) + " - " + str(close)
                                else:
                                    friday = "Friday -> Closed"
                            else:
                                friday = "Friday -> Closed"

                            if "saturday" in hdata.keys():
                                if len(hdata['saturday']) == 1:
                                    dayvalue = hdata['saturday'][0]
                                    le = len(dayvalue)
                                    if le == 2:
                                        open = dayvalue[0]
                                        close = dayvalue[1]
                                        saturday = "Saturday -> " + str(open) + " - " + str(close)
                                    else:
                                        saturday = "Saturday -> Closed"
                                elif len(hdata['saturday']) == 2:
                                    open = hdata['saturday'][0][0]
                                    close = hdata['saturday'][1][1]
                                    saturday = "Saturday -> " + str(open) + " - " + str(close)
                                else:
                                    saturday = "Saturday -> Closed"
                            else:
                                saturday = "Saturday -> Closed"

                            if "sunday" in hdata.keys():
                                if len(hdata['sunday']) == 1:
                                    dayvalue = hdata['sunday'][0]
                                    le = len(dayvalue)
                                    if le == 2:
                                        open = dayvalue[0]
                                        close = dayvalue[1]
                                        sunday = "Sunday -> " + str(open) + " - " + str(close)
                                    else:
                                        sunday = "Sunday -> Closed"
                                elif len(hdata['sunday']) == 2:
                                    open = hdata['sunday'][0][0]
                                    close = hdata['sunday'][1][1]
                                    sunday = "Sunday -> " + str(open) + " - " + str(close)
                                else:
                                    sunday = "Sunday -> Closed"
                            else:
                                sunday = "Sunday -> Closed"

                            hours = monday+"|"+tuesday+"|"+wednesday+"|"+thursday+"|"+friday+"|"+saturday+"|"+sunday
                except Exception as e:
                    print("store_hours",e,response.url)

                additional_info = {}
                try:
                    store_name = "stretchlab - "+response.meta['city']
                except Exception as e:
                    print("store_name", e, response.url)


                item = StoreLocatorsItem()
                item['search_term'] = search_term
                item['store_name']= store_name
                item['address'] = address
                item['address_line_2'] = address_line_2
                item['city'] = city
                item['state'] =state
                item['zip_code'] = zip_code
                item['phone_number'] =phone_number
                item['latitude'] = latitude
                item['longitude'] = longitude
                item['store_type'] = ''
                item['website_address'] = ''
                item['coming_soon'] = coming_soon
                item['store_number'] = ''
                item['country_code'] = item['country'] = 'us' #self.f1.country_dict.get(item['country'].lower())
                item['email_address'] = email_address
                item['services'] = ''
                item['source_url']=response.url

                item['store_hours'] = hours
                item['additional_info'] = json.dumps(additional_info)

                if item['country_code'] == 'US' and len(item['state']) > 2:

                    item['state'] = self.f1.state_dict.get(state, '')



                yield item
            except Exception as e:
                print("strech_clab ",e,response.url)

        except Exception as e:
            logging.log(logging.ERROR, e)

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_213 -a list_id=213'''.split())










# try:
#     stretchlabs = response.xpath('//div[@class="trainer-list__card trainer-card shadow"]')
#     if len(stretchlabs)>=1:
#         stretchlablist = []
#         for stretchlab in stretchlabs:
#             name = stretchlab.xpath('./div[2]/h3/text()').extract_first()
#             work = stretchlab.xpath('./div[2]/h4/text()').extract_first()
#             description = stretchlab.xpath('./div[2]/div/text()').extract_first()
#             if description == None:
#
#                 if name == None:
#                     if work == None:
#                         stretchlabfull = ''
#                     else:
#                         stretchlabfull = name+"-->"+''
#                 else:
#                     if work == None:
#                         stretchlabfull =  name+"-->"+''
#                     else:
#                         stretchlabfull = name + "," + work + "-->" + ''
#             else:
#                 if name == None:
#                     if work == None:
#                         stretchlabfull = description
#                     else:
#                         stretchlabfull = name + "-->" + description
#                 else:
#                     if work == None:
#                         stretchlabfull = name + "-->" + description
#                     else:
#                         stretchlabfull = name + "," + work + "-->" + description
#
#
#             stretchlablist.append(stretchlabfull)
#             additional_info = {}
#             additional_info['StretchLab Team'] = '|'.join(stretchlablist)
#     else:
#
#
#         additional_info = {}
#
#
# except Exception as e:
#     print("additional_info",e,response.url)


store_hourslist = []
# store_hours = response.xpath('//div[@class="hours contained"]/@data-hours').extract_first()
# if store_hours == None:
#     store_hours = ''
# else:
#     if ":" in store_hours:
#         store_hourstmps = store_hours.split(',')
#         for store_hourstmp in store_hourstmps:
#             store_hourstmp = store_hourstmp.split(":")
#             dayname = store_hourstmp[0]
#             statrttime1 = store_hourstmp[1]
#             statrttime2 = store_hourstmp[2]
#             endtime1 = store_hourstmp[3]
#             endtime2 = store_hourstmp[4]
#             endtime = endtime1+":"+endtime2
#             starttime = statrttime1+":"+statrttime2
#             dict = {'Sunday':'1',
#                     'Monday':'2',
#                     'Tuesday':'3',
#                     'Wednesday':'4',
#                     'Thursday':'5',
#                     'Friday':'6',
#                     'Saturday':'7'}
#
#             for key,value in dict.items():
#                 if dayname in value:
#                     dayname = key
#             store_hoursmake = dayname+" = "+starttime + " - "+endtime
#             store_hourslist.append(store_hoursmake)
#         store_hours = "|".join(store_hourslist)
#     else:
#         store_hours = ''