# # -*- coding: utf-8 -*-
# import scrapy,os,hashlib
# import requests,json
# import re
# from scrapy.http import HtmlResponse
# from scrapy.cmdline import execute
# from store_locators.items import StoreLocatorsItem
# from store_locators.spiders.common_functions import Func
# import datetime
# import pandas as pd
#
#
# class Store180Spider(scrapy.Spider):
#     name = 'store_180'
#     allowed_domains = []
#     start_urls = ['http://themelt.com/locations/']
#
#     def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
#         super().__init__(name, **kwargs)
#         self.list_id, self.proxy_type = list_id, proxy_type
#         self.f1 = Func()
#         self.run_date = str(datetime.datetime.today()).split()[0]
#         self.f1.set_details(self.list_id, self.run_date)
#
#     def parse(self, response):
#         test = pd.read_csv('the_melt.csv', encoding="ISO-8859-1")
#         test = test.head(8)
#         print(test)
#
#         item = StoreLocatorsItem()
#         for i, row in test.iterrows():
#             store_name = row['store name']
#             address = row['address']
#             city = row['city']
#             state = row['state']
#             # zipcode = row['zip code']
#             country = row['country']
#             countrycode = row['country code']
#             storehours = row['store hours']
#             phonenumber = row['phone number']
#             additional_info = row['additional info']
#             url = row['source url']
#
#             item['city'] = city
#
#             item['store_name'] = store_name
#             item['address'] = address
#
#             item['state'] = state
#
#             item['phone_number'] = phonenumber
#
#             item['store_hours'] = storehours
#
#             item['source_url'] = url
#
#             # item['zip_code'] = zipcode
#             item['additional_info'] = additional_info
#
#             item['country'] = country
#             item['country_code'] = countrycode
#
#             yield item
#             # print(item)
#
# execute('''scrapy crawl store_180 -a list_id=180'''.split())