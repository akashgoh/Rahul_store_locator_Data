# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from w3lib.http import basic_auth_header

from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime
import itertools
import requests
from requests.auth import HTTPProxyAuth
import re

class store204Spider(scrapy.Spider):
    name = 'store_204'
    allowed_domains = []
    f1 = Func()

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()


    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        self.f1.set_details(self.list_id, run_date)
        try:
            # --------first run this part with uncomment---------#
            url ='https://sunsetgrill.ca/locations/view-all-coming-soon-locations/'

            if 'coming-soon' in url:
                yield scrapy.Request(url=url,callback=self.get_store_list,dont_filter=True)

            else:

            #--------first run this part with uncomment---------#
                Headers = {"cache-control": "max-age=0, must-revalidate, private",
                           "cf-ray": "5171ae4f6ad7dc43-LHR",
                           "content-type": "application/json; charset=UTF-8",
                           "expect-ct": "max-age=604800, report-uri='https://report-uri.cloudflare.com/cdn-cgi/beacon/expect-ct'",
                           "referrer-policy": "strict-origin-when-cross-origin",
                           "server": "cloudflare",
                           "x-cache": "MISS",
                           "x-cache-group": "",
                           "x-cacheable": "NO:Passed",

                           "x-frame-options": "SAMEORIGIN",
                           "x-pass-why": "wp-admin",
                           "user-agent": "Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36",
                           "x-robots-tag": "noindex",
                           "Proxy-Authorization": basic_auth_header("anil.prajapati.xbyte@gmail.com", "xbyte123")
                           }


                source_url = link = 'https://sunsetgrill.ca/wp-admin/admin-ajax.php?action=store_search&lat=0&lng=0&max_results=500&search_radius=10&filter=10&autoload=1'
                # proxies = {"http": "https://account.ipvanish.com/"}
                # from requests.auth import HTTPProxyAuth
                # auth = HTTPProxyAuth("anil.prajapati.xbyte@gmail.com", "xbyte123")
                # r = requests.get(source_url, proxies=proxies, headers=Headers, auth=auth, allow_redirects=True)
                # response = HtmlResponse(url=r.url, body=r.content)
                file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(self.name) + '_' + str(run_date) + '.html'
                yield scrapy.Request(url=source_url, callback=self.get_store_list,headers=Headers,meta={"http": "https://account.ipvanish.com/",'source_url': source_url,'file_path': file_path,'proxy_type': self.proxy_type})

        except Exception as e:
            logging.log(logging.ERROR, e)



    def get_store_list(self, response):
        if 'coming-soon' in response.url:
            try:
                divs = response.xpath('//*[@id="location_search"][2]//*[@class="address-block"]')
                for div in divs:
                    store_name = div.xpath('./h5/text()').get()
                    address = div.xpath('./h6/text()').get()
                    info = div.xpath('.//p[2]').get()

                    item = StoreLocatorsItem()

                    item['store_name'] = store_name
                    item['address'] = address
                    item['coming_soon'] = 1
                    item['additional_info'] = info
                    item['country'] = 'CA'
                    item['source_url'] = response.url
                    yield item

            except Exception as e:
                print('error',e,response.url)

        else:

            try:
                if not response.url.startswith('file://'):
                    self.f1.page_save(response.meta['file_path'],response.body)

                search_term = response.meta.get('search_term', '')
                source_url = response.meta.get('source_url', '')
                store_data = json.loads(response.text)
                print(len(store_data))

                # If you have search_by :zip_code/city/state/lat_lng then you need to add following condition and query to update log table
                # If you have search_by :zip_code/city/state/lat_lng then you need to add following condition and query to update log table
                if len(store_data) == 0:
                    Func.update_log_table(self.f1, search_term)
                else:
                    for store in store_data:
                        st = json.dumps(store)
                        try:
                            additional_info = {}
                            item = StoreLocatorsItem()

                            item['search_term'] = search_term

                            item['state'] = store['state']
                            store_name = store['location_title']
                            if not store_name:
                                store_name = store['store']

                            item['store_name'] = store_name
                            item['address'] = store['address']
                            item['city'] = store['city']

                            item['zip_code'] = store['zip']
                            phone_number = store['phone']

                            if not phone_number:
                                phone_number = ''

                            item['phone_number'] = phone_number
                            item['latitude'] = store['lat']
                            item['longitude'] = store['lng']
                            item['store_type'] = ''
                            item['source_url'] = store['url']
                            if item['source_url'] =='':
                                item['source_url']='https://sunsetgrill.ca/locations/view-all-open-locations/'
                            item['coming_soon'] = 0
                            item['store_number'] = store['id']
                            item['country_code'] = 'CA'
                            item['services'] = ''
                            item['country'] = 'CA'

                            try:
                                store_hours_list = store['hours']
                                if store_hours_list != '':
                                    store_hours_list_temp = []

                                    # list(filter(lambda i: i['Attribute'] != 6, store_hours_list))
                                    a = re.findall(r'><tr><td>(.*?)</td><td><time>', store_hours_list)
                                    b = re.findall(r'</td><td><time>(.*?)</time></td></tr>', store_hours_list)
                                    for a, b in zip(a, b):
                                        a = a
                                        b = b
                                        store_hours_list_temp.append(a + ' : ' + b)

                                    store_hours = '|'.join(store_hours_list_temp)

                                    if 'Store Manager Mobile' in store_hours:
                                        for store_hour in store_hours_list[:8]:
                                            store_hours_list_temp.append(
                                                store_hour['displayName'] + ' : ' + store_hour['displayValue'])

                                        store_hours = '|'.join(store_hours_list_temp).replace('Store Manager Mobile : NA|',
                                                                                              '')

                                    item['store_hours'] = store_hours
                                else:
                                    item['store_hours'] = ''
                            except Exception as e:
                                item['store_hours'] = ''

                            item['email_address'] = store['email']
                            item['additional_info'] = store['extra_info']
                            item['number_of_store'] = len(store_data)
                            yield item
                        except Exception as e:
                            print(e)

            except Exception as e:
                logging.log(logging.ERROR, e)


    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_204 -a list_id=204'''.split())
