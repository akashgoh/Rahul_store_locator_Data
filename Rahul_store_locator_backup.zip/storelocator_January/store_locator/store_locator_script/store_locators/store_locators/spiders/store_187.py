# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import random
import re


import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime


class Store187Spider(scrapy.Spider):
    name = 'store_187'
    allowed_domains = []


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()


    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]

        self.f1.set_details(self.list_id,run_date)
        if self.f1.search_by != 'link':
            search_terms = self.f1.get_search_term(self.f1.search_by)
            print(search_terms)
        # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)
            search_terms = ''
            for search_term in (search_terms):
                source_url = link = 'https://barmethod.com/locations/'
                file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(search_term) + '_' + str(run_date) + '.html'
                if os.path.exists(file_path):
                    link = 'file://' + file_path.replace('\\','/')
                yield scrapy.FormRequest(url=str(link), callback=self.data, meta={'source_url': source_url,'search_term': search_term,'file_path':file_path,'proxy_type': self.proxy_type})
        else:
            yield scrapy.Request(url='https://barmethod.com/locations/', callback=self.data)


    def data(self, response):
        links = response.xpath('//div[@class="x-container max statelist"]/div/ul/li/a/@href').getall()
        for link in links:
            yield scrapy.Request(url=link, callback=self.parse_data)
            # yield scrapy.Request(url='https://barmethod.com/locations/newport-beach/', callback=self.parse_data)


    def parse_data(self, response):
        try:store_name = 'The Bar Method - '+response.xpath('//div[@class="x-column x-sm x-1-1 whitebox"]//h1/text()|//div[@class="headerbar"]//h2/text()').get()
        except Exception as e:print(e)

        try:
            address1 = response.xpath('//div[@class="x-column x-sm x-1-1 whitebox"]/div/address/text()').getall()
            address_ = address1[0]
            if 'Suite' in address_:
                address = address_.split('Suite')[0]
                address_line_2 = 'Suite' + address_.split('Suite')[-1]
            else:
                address = address_
                address_line_2 = ''
            add = address1[1].split(',')
            city = add[0]
            state = add[-1].split(' ')[1]
            zip_code = add[-1].split(' ')[2]
        except Exception as e:
            print(e)

        try:
            condition = re.findall(r'(\d{5})', zip_code)[0]
            if condition != '':
                country = 'United States'
                country_code = 'US'
        except:
            zip_code = str(add[-1].split(' ')[2]) + str(add[-1].split(' ')[3])
            country = 'Canada'
            country_code = 'CA'

        try:
            services = '|'.join(response.xpath('//*[contains(text(),"Services & Amenities")]/../ul//li//text()').getall())
            if 'Coming Soon' in services:
                coming_soon = 1
            else:
                coming_soon = 0
        except:
            services = ''

        try:
            phone_number = response.xpath('//*[@class="phoneNumber"]/text()|//span[@id="phone-number"]/text()').get()
            if phone_number == None:
                phone_number = ''
        except:
            phone_number = ''

        item = StoreLocatorsItem()
        item['search_term'] = 'link'
        item['store_name'] = store_name
        item['address'] = address
        item['address_line_2'] = address_line_2
        item['city'] = city
        item['state'] =state
        item['zip_code'] = zip_code
        item['phone_number'] = phone_number
        item['country'] = country
        item['country_code'] = country_code
        item['services'] = services
        item['coming_soon'] = coming_soon
        item['source_url'] = response.url
        yield item


    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_187 -a list_id=187'''.split())
