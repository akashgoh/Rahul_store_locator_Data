# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse, JSONRequest
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime
import html2text
from pprint import pprint as pp

class Store157Spider(scrapy.Spider):
    name = 'store_157'
    allowed_domains = []
    start_urls = ['https://swissfarms.com/about-us/store-locator/']
    not_export_data = False

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.f1 = Func()
        self.list_id, self.proxy_type = list_id, proxy_type


    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            source_url = link = 'https://www.turktelekom.com.tr/bakim/maps/ProvinceList.js'

            self.f1.set_details(self.list_id, run_date)
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
                run_date) + '.html'
            if os.path.exists(file_path):
                link = 'file://' + file_path.replace('\\', '/')

            yield scrapy.FormRequest(url=str(source_url), callback=self.get_store_list,
                                     meta={'source_url': source_url,
                                           'file_path': file_path,
                                           'proxy_type': self.proxy_type})
        except Exception as e:
            print(e)


    def get_store_list(self, response):
        try:
            if not response.url.startswith('file://'):
                self.f1.page_save(response.meta['file_path'], response.body)

            store_data1 = json.loads(response.text.strip().strip("var prmData =").strip())

            le = len(store_data1)

            for i in range(0, le):


                search_term = response.meta.get('search_term', '')
                try:
                    store_name = store_data1[i]['Title']
                except Exception as e:
                    print("store_name", e, response.url)

                try:
                    address = store_data1[i]['Address'].replace('string;#','')
                except Exception as e:
                    print("address1", e, response.url)

                try:
                    city = store_data1[i]['ProvinceName']
                except Exception as e:
                    print("city", e, response.url)

                try:
                    latitude = store_data1[i]['CoordinateX']
                    longitude = store_data1[i]['CoordinateY']
                except Exception as e:
                    print("latitude and longitude", e, response.url)

                try:
                    phone_number = store_data1[i]['Phone']
                except Exception as e:
                    print("phonenumber", e, response.url)

                try:
                    additional_info = {}
                    additional_info['ProvinceName'] = store_data1[i]['ProvinceName']
                    additional_info['District'] = store_data1[i]['District']
                    additional_info['Category'] = store_data1[i]['Category']

                except Exception as e:
                    print("additionalinfo", response.url, e)

                item = StoreLocatorsItem()
                item['search_term'] = search_term
                item['store_name'] = store_name
                item['address'] = address
                item['address_line_2'] = ''
                item['city'] = city
                item['state'] = ''
                item['zip_code'] = ''
                item['phone_number'] = phone_number
                item['latitude'] = latitude
                item['longitude'] = longitude
                item['store_type'] = ''
                item['website_address'] = ''
                item['coming_soon'] = 0
                item['store_number'] = ''
                item['country_code'] = item['country'] = 'TR'  # self.f1.country_dict.get(item['country'].lower())
                item['email_address'] = ''
                item['services'] = ''
                item['source_url'] = "https://www.turktelekom.com.tr/destek/sayfalar/ofis-ve-bayi-arama.aspx"
                item['store_hours'] = ''
                item['additional_info'] = json.dumps(additional_info, ensure_ascii=False)
                yield item
        except Exception as e:
            print("get_store_list",e,)
    #
# execute('''scrapy crawl store_157 -a list_id=157 -s HTTPCACHE_ENABLED=False'''.split())