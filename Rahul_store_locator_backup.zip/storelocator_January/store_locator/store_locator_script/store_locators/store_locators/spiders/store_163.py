# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import re
# import pgeocode
import scrapy, os, logging, hashlib
import requests, json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from selenium import webdriver
from selenium.webdriver.firefox.options import Options
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime



class Store266Spider(scrapy.Spider):
    name = 'store_163'
    allowed_domains = []
    not_export_data = True

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        self.f1.set_details(self.list_id, run_date)
        try:
            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                print(search_terms)
                for search_term in (search_terms):
                    lat = search_term.split('_')[0]
                    lng = search_term.split('_')[1]
                    run_date = str(datetime.datetime.today()).split()[0]
                    source_url = link = f'https://www.trade-point.co.uk/find-a-store/store-results?lat={lat}&lng={lng}&title=Current+location'
                    headers = {
                        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                        'accept-encoding': 'gzip,deflate,br',
                        'accept-language': 'en-US,en;q=0.9',
                        'cache-control': 'max-age=0',
                        'cookie': 'userPrefLanguage=en_GB; JSESSIONID=JjFeOqgwcBQJHsT1V1pqA1CjYHK0TMzTJHdTyY7J.Str13; checkoutType=OldCheckout; sengine=en2; BIGipServerp-prod11-storefront-trade-point=!6tVLtRLZv/pMc5HJ7nsfDAN9BORaPr2OkZcpeLoxpQPSc8AZN+JvWbx5U2KRblvnBO78XYcTTatjAYc=; rxVisitor=16070763246940BVUBO3B5FAHBQOG5IKQ2TU3LG31MSHI; .=_; _preferenceCookie=id%3A39007244-1%7Call-cookies%3Atrue; _ga=GA1.3.643697114.1607076332; _gcl_au=1.1.266790626.1607076332; RES_TRACKINGID=932711564349836; dtCookie==3=srv=5=sn=ED13024755DD54101B7916F3AE9FC948=perc=100000=ol=0=mul=1=app:d09643a9157f0c88=1; dtLatC=6; utag_main=v_id:01762d36a7b3000a0afb81fa235403073001e06b0086e$_sn:9$_ss:0$_st:1609137505234$_se:2$ses_id:1609135574107%3Bexp-session$_pn:2%3Bexp-session; rxvt=1609137506028|1609135572699; dtPC=5$535705042_118h-vBNCCFUBJRHCFBABCPWLUACKMFAUTUBAK-0e14; dtSa=true%7CS%7C-1%7C-%7C-%7C1609135834464%7C535572693_692%7Chttps%3A%2F%2Fwww.trade-point.co.uk%2Ffind-a-store%2Fstore-results%3Flat%3D51.50732%26lng%3D-0.12764746%26title%3DCurrent%2Blocation%7CFind%20a%20store%20%5Ep%20Tradepoint%7C1609135576546%7C%7C',
                        'if-none-match': 'W/"7dbe2-g3d0+oINfBFgsS3pfVYFgKzWFrs:dtagent10205201116183137Vg73"',
                        'sec-ch-ua': '"Google Chrome";v="87", " Not;A Brand";v="99", "Chromium";v="87"',
                        'sec-ch-ua-mobile': '?0',
                        'sec-fetch-dest': 'document',
                        'sec-fetch-mode': 'navigate',
                        'sec-fetch-site': 'none',
                        'sec-fetch-user': '?1',
                        'upgrade-insecure-requests': '1',
                        'user-agent': ' Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'
                    }

                    file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(run_date) + '.html'

                    yield scrapy.FormRequest(url=str(link), callback=self.firstlevel,headers=headers,
                                             meta={'source_url': source_url,
                                                   'file_path': file_path})
        except Exception as e:
            print(e)


    def firstlevel(self,response):
        source_url = response.meta.get('source_url', '')
        file_path = response.meta['file_path']
        try:
            store_links = response.xpath('//*[@data-test-id="store-panel-store-info"]/@href').extract()
            for link in store_links:
                url = 'https://www.trade-point.co.uk' + link
                yield scrapy.FormRequest(url=url, callback=self.secondlevel, meta={'source_url': source_url, 'file_path': file_path})
        except Exception as e:
            print(e)


    def secondlevel(self,response):
        if not response.url.startswith('file://'):
            self.f1.page_save(response.meta['file_path'], response.body)
        source_url = response.meta['source_url']
        file_path = response.meta['file_path']
        search_term = response.meta.get('search_term', '')
        data3 = re.findall('json">(.*?)</script>',response.text)[0]
        # data3 = re.findall('window.__data=(.*?);',response.text)[0]
        body = json.loads(data3)
        try:
            try:
                store_name = body['name']
            except Exception as e:
                print("store_name", e, response.url)

            try:
                address1 = body['address']['streetAddress']
                address1 = address1.split(',')
                if len(address1) == 5:
                    address = address1[0].strip() + ',' + address1[1].strip()
                    address_line_2 = address1[2].strip() + ',' + address1[3].strip()
                    address_line_3 = address1[4].strip()
                elif len(address1) == 4:
                    address = address1[0].strip() + ',' + address1[1].strip()
                    address_line_2 = address1[2].strip()
                    address_line_3 = address1[3].strip()
                elif len(address1) == 3:
                    address = address1[0].strip()
                    if "Unit" in address:
                        address = address+','+address1[1].strip()
                        address_line_2 = address1[2].strip()
                        address_line_3 = ''
                    else:
                        address = address
                        address_line_2 = address1[1].strip()
                        address_line_3 = address1[2].strip()
                elif len(address1) == 2:
                    address = address1[0].strip()
                    if "Unit" in address:
                        address = address+','+address1[1].strip()
                        address_line_2 = ''
                        address_line_3 = ''
                    else:
                        address = address
                        address_line_2 = address1[1].strip()
                        address_line_3 = ''
                else:
                    address = address1[0].strip()
                    address_line_2 = ''
                    address_line_3 = ''
            except Exception as e:
                print("address", e, response.url)

            try:
                city = body['address']['addressLocality']
            except Exception as e:
                city = ''
                print("city", e, response.url)

            try:
                state = body['address']['addressRegion']
            except Exception as e:
                state = ''
                print("state", e, response.url)

            try:
                zip_code = body['address']['postalCode']
            except Exception as e:
                print("zip_code", e, response.url)

            try:
                phone_number = body['telephone']
            except Exception as e:
                phone_number = ''
                print("phone_number", e, response.url)

            try:
                fax_number = body['faxNumber']
            except Exception as e:
                fax_number = ''
                print("phone_number", e, response.url)

            try:
                latitude = body['geo']['latitude']
            except Exception as e:
                print("latitude", e, response.url)

            try:
                longitude = body['geo']['longitude']
            except Exception as e:
                print("longitude", e, response.url)

            try:
                email_address = re.findall('contactPoint":{"email":"(.*?)",',response.text)[0]
            except Exception as e:
                print("email_address", e, response.url)

            try:
                services = re.findall('facilities":\[(.*?)\],', response.text)
                services = "".join(services).replace('"','').replace(',','|')
            except Exception as e:
                print("email_address", e, response.url)


            try:
                from datetime import datetime
                store_hour1 = body['openingHoursSpecification']
                h = []
                for i in range(0,len(store_hour1)):
                    days = store_hour1[i]['dayOfWeek']
                    opens = store_hour1[i]['opens'].replace('Europe/London','').strip()
                    opens = datetime.strptime(opens,"%H:%M:%S")
                    d = opens.strftime("%I:%M %p")
                    closes = store_hour1[i]['closes'].replace('Europe/London','').strip()
                    closes = datetime.strptime(closes,"%H:%M:%S")
                    c = closes.strftime("%I:%M %p")
                    hours = d+'-'+c
                    store_hours = days+" "+hours
                    h.append(store_hours)
                store_hours = '|'.join(h)

            except Exception as e:
                print("store_hours", e, response.url)


            try:
                country_code = body['address']['addressCountry']
            except Exception as e:
                print("country_code", e, response.url)

            item = StoreLocatorsItem()
            item['search_term'] = search_term
            item['store_name'] = store_name
            item['address'] = address
            item['address_line_2'] = address_line_2
            item['address_line_3'] = address_line_3
            item['city'] = city
            item['state'] = state
            item['zip_code'] = zip_code
            item['phone_number'] = phone_number
            item['fax_number'] = fax_number
            item['latitude'] = latitude
            item['longitude'] = longitude
            item['coming_soon'] = 0
            item['email_address'] = email_address
            item['services'] = services
            if store_name == "TradePoint Jersey":
                store_hours = "Monday 08:00 AM-08:00 PM|Tuesday 08:00 AM-08:00 PM|Wednesday 08:00 AM-08:00 PM|Thursday 08:00 AM-08:00 PM|Friday 08:00 AM-08:00 PM|Saturday 08:00 AM-07:00 PM|Sunday Closed"
            item['store_hours'] = store_hours
            item['source_url'] = response.url
            item['country_code'] = country_code
            item['country'] = 'United Kingdom'
            yield item

        except Exception as e:
            print(e)



# execute('''scrapy crawl store_163 -a list_id=163'''.split())