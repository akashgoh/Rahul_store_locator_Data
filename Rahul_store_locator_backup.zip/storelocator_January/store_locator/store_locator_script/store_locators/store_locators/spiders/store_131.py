# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import random
import re

import html2text
import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime

class Store131Spider(scrapy.Spider):
    name = 'store_131'
    allowed_domains = []


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()


    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            self.f1.set_details(self.list_id,run_date)
            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                print(search_terms)
            # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)
                search_terms = ''
                for search_term in (search_terms):
                    source_url = link = 'https://www.wregional.com/main/find-a-facility-or-clinic'
                    file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(search_term) + '_' + str(run_date) + '.html'
                    if os.path.exists(file_path):
                        link = 'file://' + file_path.replace('\\','/')
                    yield scrapy.FormRequest(url=str(link), callback=self.parse,
                                             meta={'source_url': source_url,'search_term': search_term,'file_path':file_path,'proxy_type': self.proxy_type})
            else:
                source_url = link = 'https://www.wregional.com/main/find-a-facility-or-clinic'
                file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(run_date) + '.html'
                yield scrapy.FormRequest(url=str(link), callback=self.parse,
                                         meta={'source_url': source_url,'file_path': file_path, 'proxy_type': self.proxy_type})
        except Exception as e:
            logging.log(logging.ERROR, e)



    def parse(self, response):
        links = response.xpath('//div[@class="col-1"]//li/a/@href|//div[@class="col-2"]//li/a/@href|//div[@class="col-3"]//li/a/@href').extract()
        for link in links:
            yield scrapy.Request(url='https://www.wregional.com'+link, callback=self.data, dont_filter=True)
            # yield scrapy.Request(url="https://www.wregional.com/main/gynecologic-oncology", callback=self.data, dont_filter=True)

    def data(self, response):
        try:store_name = response.xpath('//div[@class="page-title"]/h1/text()').get(default='').strip()
        except Exception as e:print(e)

        text = response.xpath('//div[@class="col-2"]/p//text()').extract()
        print(len(text))

        try:
            address_text = text[1].strip()
            if ',' in address_text:
                address = address_text.split(',')[0].strip()
                address2 = address_text.split(',')[-1].strip()
            else:
                address = address_text.strip()
                address2 = ''
        except Exception as e:
            print(e)

        try:
            address_text2 = text[2]
            try:city = address_text2.split(',')[0].strip()
            except:city = ''

            try:state = address_text2.split(',')[-1].split()[0].strip()
            except:state = ''

            try:zipcode = address_text2.split(',')[-1].split()[-1].strip()
            except:zipcode = ''
        except Exception as e:
            print(e)

        try:
            telephone = response.xpath('//div[@class="col-2"]//a[contains(@href,"tel")]/text()').get(default='').strip()
            if telephone == '':
                t = [i for i in text if 'phone' in i]
                if t != []:
                    try:telephone = t[0].strip()
                    except:telephone = ''
        except:
            telephone = ''

        try:
            t = [i for i in text if 'Fax' in i]
            if t != []:
                try:fax = t[0].strip()
                except:fax = ''
        except:
            fax = ''

        site_text1 = response.text
        try:
            site_text = site_text1.split('<h3>Hours</h3>')[-1]
            store_hours = re.findall(r'<p>(.*?)</p>', site_text, re.DOTALL)[0].replace('<br>','|').replace('\n','')
        except:
            store_hours = ''

        try:email = response.xpath('//a[contains(@href,"@")]/text()').get(default='').strip()
        except:email = ''

        try:
            services = ''.join(re.findall('<h3>Clinic Services</h3>(.*?)<h3>Hours</h3>|<h3>Services</h3>(.*?)<h3>Hours</h3>', site_text1, re.DOTALL)[0])
            h = html2text.HTML2Text()
            h.ignore_links = True
            h.ignore_emphasis = True
            h.ignore_images = True
            h.body_width = 0
            services = h.handle(services)
        except:
            services = ''


        item = StoreLocatorsItem()
        item['search_term'] = 'link'
        item['store_name'] = store_name
        item['address'] = address
        item['address_line_2'] = address2
        item['city'] = city
        item['state'] = state
        item['zip_code'] = zipcode
        item['phone_number'] = telephone
        item['fax_number'] = fax
        item['email_address'] = email
        item['services'] = services
        item['coming_soon'] = 0
        item['country'] = 'USA'
        item['country_code'] = 'US' # self.f1.country_dict.get(item['country'].lower())
        item['store_hours'] = store_hours
        item['source_url'] = response.url
        yield item

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_131 -a list_id=131'''.split())






















# # -*- coding: utf-8 -*-
# # pip install scrapy-html-storage
# import random
# import re
#
# import html2text
# import scrapy,os,logging,hashlib
# import requests,json
# from scrapy.http import HtmlResponse
# from scrapy.cmdline import execute
# from store_locators.items import StoreLocatorsItem
# from store_locators.spiders.common_functions import Func
# import datetime
#
# class Store131Spider(scrapy.Spider):
#     name = 'store_131'
#     allowed_domains = []
#     handle_httpstatus_list = [301, 302, 400, 403]
#     # not_export_data = True
#
#
#     def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
#         super().__init__(name, **kwargs)
#         self.list_id, self.proxy_type = list_id, proxy_type
#         self.f1 = Func()
#         run_date = str(datetime.datetime.today()).split()[0]
#         self.f1.set_details(self.list_id, run_date)
#
# #     def start_requests(self):
# #         try:
# #             run_date = str(datetime.datetime.today()).split()[0]
# #             self.f1.set_details(self.list_id, run_date)
# #             # if self.f1.search_by != 'link':
# #             #     search_terms = self.f1.get_search_term(self.f1.search_by)
# #             #     print(search_terms)
# #             # search_terms = ''
# #             # for search_term in (search_terms):
# #             source_url = link = 'https://www.wregional.com/main/find-a-facility-or-clinic'
# #             # file_path = self.f1.html_link_directory + str(self.list_id) + '_'  + str(self.run_date) + '.html'
# #                 # if os.path.exists(file_path):
# #                 #     link = 'file://' + file_path.replace('\\', '/')
# #             yield scrapy.FormRequest(url=str(link), callback=self.firstlevel,dont_filter=True,
# #                                          meta={'source_url': source_url,
# #                                                # 'file_path': file_path,
# #                                                'proxy_type': self.proxy_type})
# #         except Exception as e:
# #             print(e)
# #
# #     def firstlevel(self, response):
# #
# #         try:
# #             source_url = response.meta['source_url']
# #             # file_path = response.meta['file_path']
# #             proxy_type = response.meta['proxy_type']
# #             divs = response.xpath('//*[@class="clinics"]//a/@href').extract()
# #             for i in divs:
# #                 if "http" in i:
# #                     url1 = i.replace(".aspx","")
# #                 else:
# #                     url1 = "https://www.wregional.com" + i.replace(".aspx","")
# #
# #                 yield scrapy.FormRequest(url=url1, callback=self.secondlevel,dont_filter=True,
# #                                          meta={'source_url': source_url,
# #                                                # 'file_path': file_path,
# #                                                'proxy_type': proxy_type, 'url1': url1})
# #
# #
# #
# #         except Exception as e:
# #             print("firstlevel", e, response.url)
# #
# #     def secondlevel(self, response):
# #         try:
# #             url1 = response.meta['url1']
# #             source_url = response.meta['source_url']
# #             # file_path = response.meta['file_path']
# #             proxy_type = response.meta['proxy_type']
# #             if "https://www.google.com/maps" in response.text:
# #                 divs = response.xpath('//*[@class="col-1"]//h2//a/@href').extract()
# #                 for i in divs:
# #                     url2 = i
# #                     yield scrapy.FormRequest(url=url2, callback=self.get_store_list,dont_filter=True,
# #                                              meta={'source_url': source_url,
# #                                                # 'file_path': file_path,
# #                                                'proxy_type': proxy_type})
# #             else:
# #                 # url1 = response.url
# #                 yield scrapy.FormRequest(url=response.url, callback=self.get_store_list,dont_filter=True,
# #                                          meta={'source_url': source_url,
# #                                                # 'file_path': file_path,
# #                                                'proxy_type': proxy_type})
# #
# #         except Exception as e:
# #             print("secondlevel", e, response.url)
# #
# #
# #     def get_store_list(self, response):
# #         try:
# #             # if not response.url.startswith('file://'):
# #                 # self.f1.page_save(response.meta['file_path'], response.body)
# #             # source_url = response.meta.get('source_url', '')
# #             try:
# #                 store_name = response.xpath('//*[@class="col-2"]//p/text()[1]').extract_first()
# #             except Exception as e:
# #                 print(e)
# #
# #             try:
# #                 address = response.xpath('//*[@class="col-2"]//p/text()[2]|//*[@class="m-location-panel__section"][2]//p[1]//text()[1]').extract_first()
# #             except Exception as e:
# #                 address = ""
# #                 print(e)
# #
# #             try:
# #                 address_line_2 = address
# #                 for j in ['Unit', 'STE', 'Ste', 'SUITE', 'Suite', 'suite', 'Suit', 'SUIT', 'suit', 'UNIT',
# #                           'unit', 'ste']:
# #                     for aw in address.split(' '):
# #                         if j == aw:
# #                             if address.split(' ').index(aw) != 0:
# #                                 address = address.split(j)[0].strip()
# #                                 address_line_2 = j + ' ' + address.split(j)[-1].strip()
# #                                 break
# #             except Exception as e:
# #                 address_line_2 = ''
# #                 print(e)
# #
# #             try:
# #                 data = response.xpath('//*[@class="col-2"]//p/text()[3]|//*[@class="m-location-panel__section"][2]//p[1]//text()[2]').extract_first()
# #                 city = data.split(",")[0]
# #                 state = data.split(",")[1].split(" ")[1]
# #                 zip_code = data.split(",")[1].split(" ")[2]
# #             except Exception as e:
# #                 city = ""
# #                 state = ""
# #                 zip_code = ""
# #                 print(e)
# #
# #             try:
# #                 phone_number = response.xpath('//*[@class="col-2"]//p//a[1]//text()|//*[@class="m-location-panel__text"]//a[@class="m-location-panel__phone"]//text()').extract_first()
# #             except Exception as e:
# #                 phone_number = ""
# #                 print(e)
# #
# #             try:
# #                 fax_number = response.xpath('//*[@class="col-2"]//p//text()[5]|//*[@class="m-location-panel__text"][2]//a//text()').extract_first()
# #             except Exception as e:
# #                 fax_number = ""
# #                 print(e)
# #
# #             try:
# #                 store_hours = ''.join(response.xpath('//*[@id="inside-page"]/div/div[2]/div[4]/p[1]|//*[@class="m-location-hours__list"]//p//text()').extract()).strip()
# #             except Exception as e:
# #                 print(e)
# #
# #
# #
# #
# #             item = StoreLocatorsItem()
# #             item['store_name'] = store_name
# #             item['address'] = address
# #             item['address_line_2'] = address_line_2
# #             item['city'] = city
# #             item['state'] = state
# #             item['zip_code'] = zip_code
# #             item['phone_number'] = phone_number
# #             item['fax_number'] = fax_number
# #             item['store_hours'] = store_hours
# #             item['source_url'] = response.url
# #             yield item
# #
# #         except Exception as e:
# #             print(e)
# #
# # execute('''scrapy crawl store_131 -a list_id=131'''.split())
#
#
#     #
#     def start_requests(self):
#         run_date = str(datetime.datetime.today()).split()[0]
#         try:
#             self.f1.set_details(self.list_id,run_date)
#             if self.f1.search_by != 'link':
#                 search_terms = self.f1.get_search_term(self.f1.search_by)
#                 print(search_terms)
#             # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)
#                 search_terms = ''
#                 for search_term in (search_terms):
#                     source_url = link = 'https://www.wregional.com/main/find-a-facility-or-clinic'
#                     file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(search_term) + '_' + str(run_date) + '.html'
#                     if os.path.exists(file_path):
#                         link = 'file://' + file_path.replace('\\','/')
#                     yield scrapy.FormRequest(url=str(link), callback=self.parse,
#                                              meta={'source_url': source_url,'search_term': search_term,'file_path':file_path,'proxy_type': self.proxy_type})
#             else:
#                 source_url = link = 'https://www.wregional.com/main/find-a-facility-or-clinic'
#                 file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(run_date) + '.html'
#                 yield scrapy.FormRequest(url=str(link), callback=self.parse,
#                                          meta={'source_url': source_url,'file_path': file_path, 'proxy_type': self.proxy_type})
#         except Exception as e:
#             logging.log(logging.ERROR, e)
#
#
#
#     def parse(self, response):
#         links = response.xpath('//div[@class="col-1"]//li/a/@href|//div[@class="col-2"]//li/a/@href|//div[@class="col-3"]//li/a/@href').extract()
#         for link in links:
#             yield scrapy.Request(url='https://www.wregional.com'+link, callback=self.data, dont_filter=True)
#             # yield scrapy.Request(url="https://www.wregional.com/main/gynecologic-oncology", callback=self.data, dont_filter=True)
#
#     def data(self, response):
#         try:store_name = response.xpath('//div[@class="page-title"]/h1/text()').get(default='').strip()
#         except Exception as e:print(e)
#
#         text = response.xpath('//div[@class="col-2"]/p//text()').extract()
#         print(len(text))
#
#         try:
#             address_text = text[1].strip()
#             if ',' in address_text:
#                 address = address_text.split(',')[0].strip()
#                 address2 = address_text.split(',')[-1].strip()
#             else:
#                 address = address_text.strip()
#                 address2 = ''
#         except Exception as e:
#             print(e)
#
#         try:
#             address_text2 = text[2]
#             try:city = address_text2.split(',')[0].strip()
#             except:city = ''
#
#             try:state = address_text2.split(',')[-1].split()[0].strip()
#             except:state = ''
#
#             try:zipcode = address_text2.split(',')[-1].split()[-1].strip()
#             except:zipcode = ''
#         except Exception as e:
#             print(e)
#
#         try:
#             telephone = response.xpath('//div[@class="col-2"]//a[contains(@href,"tel")]/text()').get(default='').strip()
#             if telephone == '':
#                 t = [i for i in text if 'phone' in i]
#                 if t != []:
#                     try:telephone = t[0].strip()
#                     except:telephone = ''
#         except:
#             telephone = ''
#
#         try:
#             t = [i for i in text if 'Fax' in i]
#             if t != []:
#                 try:fax = t[0].strip()
#                 except:fax = ''
#         except:
#             fax = ''
#
#         site_text1 = response.text
#         try:
#             site_text = site_text1.split('<h3>Hours</h3>')[-1]
#             store_hours = re.findall(r'<p>(.*?)</p>', site_text, re.DOTALL)[0].replace('<br>','|').replace('\n','')
#         except:
#             store_hours = ''
#
#         try:email = response.xpath('//a[contains(@href,"@")]/text()').get(default='').strip()
#         except:email = ''
#
#         try:
#             services = ''.join(re.findall('<h3>Clinic Services</h3>(.*?)<h3>Hours</h3>|<h3>Services</h3>(.*?)<h3>Hours</h3>', site_text1, re.DOTALL)[0])
#             h = html2text.HTML2Text()
#             h.ignore_links = True
#             h.ignore_emphasis = True
#             h.ignore_images = True
#             h.body_width = 0
#             services = h.handle(services)
#         except:
#             services = ''
#
#
#         item = StoreLocatorsItem()
#         item['search_term'] = 'link'
#         item['store_name'] = store_name
#         item['address'] = address
#         item['address_line_2'] = address2
#         item['city'] = city
#         item['state'] = state
#         item['zip_code'] = zipcode
#         item['phone_number'] = telephone
#         item['fax_number'] = fax
#         item['email_address'] = email
#         item['services'] = services
#         item['coming_soon'] = 0
#         item['country'] = 'USA'
#         item['country_code'] = 'US' # self.f1.country_dict.get(item['country'].lower())
#         item['store_hours'] = store_hours
#         item['source_url'] = response.url
#         yield item
#
#     def response_html_path(self, request):
#         return request.meta['fpath']
#
# execute('''scrapy crawl store_131 -a list_id=131'''.split())