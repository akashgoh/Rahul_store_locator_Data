

# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from scrapy.utils.response import open_in_browser
from w3lib.http import basic_auth_header
import re
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime


class Store196Spider(scrapy.Spider):
    name = 'store_196'
    allowed_domains = []
    handle_httpstatus_list = [301, 302]


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            self.f1.set_details(self.list_id,run_date)
            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                print(search_terms)
                # search_terms = ['00501','00544','01005','10010']
                for search_term in (search_terms):

                    link = "https://netportal.tamko.com/DLS/SpatialService.svc/FindNearby?country=US&type=Roofing&custzipcode="+str(search_term)+"&radius=100&_=1597730508211"
                    header={
                        "Accept":"application/xml, text/xml, */*; q=0.01",
                        "Accept-Encoding":"gzip, deflate, br",
                        "Accept-Language":"en-US,en;q=0.9",
                        "Connection":"keep-alive",
                        "Host":"netportal.tamko.com",
                        "Origin":"https://www.tamko.com",
                        "Referer":"https://www.tamko.com/professionals/where-to-buy-tamko",
                        "Sec-Fetch-Dest":"empty",
                        "Sec-Fetch-Mode":"cors",
                        "Sec-Fetch-Site":"same-site",
                        "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36"
                            }
                    yield scrapy.Request(url=link, callback=self.get_store_list, headers=header)
        except Exception as e:
            logging.log(logging.ERROR, e)

    # Get data from the response
    def get_store_list(self, response):
        try:
            text = response.text.split('<BaseEntity>')
            del(text[0])
            for t in text:
                try:store_name = re.findall(r'<DealerName>(.*?)</DealerName>', t)[0]
                except:store_name = ''

                try:address = re.findall(r'<DealerStreet>(.*?)</DealerStreet>', t)[0]
                except:address = ''

                try:city = re.findall(r'<DealerCity>(.*?)</DealerCity>', t)[0]
                except:city = ''

                try:state = re.findall(r'<DealerState>(.*?)</DealerState>', t)[0]
                except:state = ''

                try:zipcode = re.findall(r'<DealerZipcode>(.*?)</DealerZipcode>', t)[0]
                except:zipcode = ''

                try:phone = re.findall(r'<DealerPhone>(.*?)</DealerPhone>', t)[0]
                except:phone = ''

                try:latitude = re.findall(r'<Latitude>(.*?)</Latitude>', t)[0]
                except:latitude = ''

                try:longitude = re.findall(r'<Longitude>-(.*?)</Longitude>', t)[0]
                except:longitude = ''

                item = StoreLocatorsItem()
                item['search_term'] = 'zipcode'
                item['store_name'] = store_name
                item['address'] = address
                item['city'] = city
                item['state'] = state
                item['zip_code'] = zipcode
                item['phone_number'] = phone
                item['latitude'] = latitude
                item['longitude'] = longitude
                item['source_url'] = response.url
                item['country_code'] = item['country'] = 'US'  # self.f1.country_dict.get(item['country'].lower())
                yield item
        except Exception as e:
            logging.log(logging.ERROR, e)


# execute('''scrapy crawl store_196 -a list_id=196'''.split())
