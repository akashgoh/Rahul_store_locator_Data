# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import random
import re


import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime


class Store138Spider(scrapy.Spider):
    name = 'store_138'
    allowed_domains = []
    not_export_data = False

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]


    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        self.f1.set_details(self.list_id,run_date)
        yield scrapy.Request(url='https://api.storepoint.co/v1/15e4d951aa1fce/locations?rq', callback=self.data)


    def data(self, response):
        json_data = json.loads(response.text)

        length = len(json_data['results']['locations'])
        for i in range(0, int(length)):
            try:store_name = json_data['results']['locations'][i]['name']
            except Exception as e:print(e)

            try:
                address1 = json_data['results']['locations'][i]['streetaddress'].split(',')
                address = address1[0]
            except Exception as e:
                print(e)

            if len(address1) == 3:
                address2 = ''
                city = address1[1].strip()
            elif len(address1) == 4:
                address2 = address1[1].strip()
                city = address1[2].strip()

            try:zip_code = address1[-1].split(' ')[-1]
            except:zip_code = ''

            try:lat = json_data['results']['locations'][i]['loc_lat']
            except:lat = ''

            try:long = json_data['results']['locations'][i]['loc_long']
            except:long = ''

            try:state = address1[-1].split(' ')[1]
            except:state = ''

            try:store_hours = ' monday: '+json_data['results']['locations'][i]['monday'] + '|' + ' tuesday: '+json_data['results']['locations'][i]['tuesday'] + '|' + ' wednesday: '+json_data['results']['locations'][i]['wednesday'] + '|' + ' thursday: '+json_data['results']['locations'][i]['thursday'] + '|' + ' friday: '+json_data['results']['locations'][i]['friday'] + '|' + ' saturday: '+json_data['results']['locations'][i]['saturday'] + '|' + ' sunday: '+ json_data['results']['locations'][i]['sunday']
            except:store_hours = ''

            try:phone_number = json_data['results']['locations'][i]['phone']
            except:phone_number = ''

            try:website_address = json_data['results']['locations'][i]['website']
            except:website_address = ''

            try:cs = json_data['results']['locations'][i]['tags']
            except:cs = ''

            if 'COMING SOON,' in cs:
                coming_soon = 1
            else:
                coming_soon = 0

            item = StoreLocatorsItem()
            item['search_term'] = 'link'
            item['store_name']= store_name
            item['address'] = address
            item['address_line_2'] = address2
            item['store_hours'] = store_hours
            item['city'] = city
            item['state'] = state
            item['country'] = 'USA'
            item['country_code'] = 'US'
            item['zip_code'] = zip_code
            item['latitude'] = lat
            item['longitude'] = long
            item['phone_number'] = phone_number
            item['website_address'] = website_address
            item['coming_soon'] = coming_soon
            item['source_url'] = 'https://vbarbershop.com/find-a-location/'
            yield item


    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_138 -a list_id=138'''.split())
