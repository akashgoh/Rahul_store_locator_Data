# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import random
import re

import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from w3lib.html import remove_tags

from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime


class Store141Spider(scrapy.Spider):
    name = 'store_141'
    allowed_domains = []


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()


    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]

        self.f1.set_details(self.list_id,run_date)
        if self.f1.search_by != 'link':
            search_terms = self.f1.get_search_term(self.f1.search_by)
            print(search_terms)
        # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)
            search_terms = ''
            for search_term in (search_terms):
                source_url = link = 'https://maps.vodafone.com.au/VHAMap/datafeeds/StoreLocator?ts=1569196800000'
                file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(search_term) + '_' + str(run_date) + '.html'
                if os.path.exists(file_path):
                    link = 'file://' + file_path.replace('\\','/')
                yield scrapy.FormRequest(url=str(link), callback=self.get_store_list, meta={'source_url': source_url,'search_term': search_term,'file_path':file_path,'proxy_type': self.proxy_type})
        else:
            yield scrapy.Request(url='https://maps.vodafone.com.au/VHAMap/datafeeds/StoreLocator?ts=1570665600000', callback=self.data)


    def data(self, response):
        data = json.loads(response.text)
        stores = len(data['stores'])
        for i in range(0,int(stores)):

            try:store_name = data['stores'][i]['tradingName']
            except:store_name = ''

            try:address = data['stores'][i]['street']
            except:address = ''

            try:
                city = data['stores'][i]['suburb'].title()
                if city == '32':
                    city = ''
            except:
                city = ''

            try:state = data['stores'][i]['state']
            except:state = ''

            try:zip_code = data['stores'][i]['postcode']
            except:zip_code = ''

            try:phone_number =  data['stores'][i]['phone']
            except:phone_number = ''

            try:email_address = data['stores'][i]['email']
            except:email_address = ''

            try:latitude = data['stores'][i]['lat']
            except:latitude = ''

            try:longitude = data['stores'][i]['lon']
            except:longitude = ''

            mon_sh = data['stores'][i]['tradingHoursMon']

            tue_sh = data['stores'][i]['tradingHoursTue']

            wed_sh = data['stores'][i]['tradingHoursWed']

            thur_sh = data['stores'][i]['tradingHoursThu']

            fri_sh = data['stores'][i]['tradingHoursFri']

            sat_sh = data['stores'][i]['tradingHoursSat']

            sun_sh = data['stores'][i]['tradingHoursSun']

            store_hours = 'Monday : ' + str(mon_sh) + '|' + 'Tuesday : ' +str(tue_sh) +'|' + 'Wednesday : ' + str(wed_sh) + '|' + 'Thursday : ' + str(thur_sh) + '|' + 'Friday : ' + str(fri_sh) + '|' + 'Saturday : ' + str(sat_sh) + '|' + 'Sunday : ' + str(sun_sh)

            item = StoreLocatorsItem()
            item['search_term'] = 'link'
            item['store_name']= store_name
            item['address'] = address
            item['store_hours'] = store_hours
            item['city'] = city
            item['state'] =state
            item['country'] = 'Australia'
            item['country_code'] = 'AU'
            item['zip_code'] = zip_code
            item['phone_number'] = phone_number
            item['email_address'] = email_address
            item['latitude'] = latitude
            item['longitude'] = longitude
            item['website_address'] = ''
            item['coming_soon'] = 0
            item['source_url'] = response.url
            yield item


    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_141 -a list_id=141'''.split())
