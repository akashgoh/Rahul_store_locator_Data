# -*- coding: utf-8 -*-
import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime
import re
import html2text
run_date = str(datetime.datetime.today()).split()[0]


class YallamediCrawlerSpider(scrapy.Spider):
    name = 'store_115'
    allowed_domains = []
    f1 = Func()
    not_export_data = True

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            source_url = link = 'https://www.yallamedi.com'
            self.f1.set_details(self.list_id, run_date)
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(run_date) + '.html'
            if os.path.exists(file_path):
                link = 'file://' + file_path.replace('\\', '/')
            yield scrapy.FormRequest(url=str(link), callback=self.get_store_list, meta={'source_url': source_url,
                                            'file_path': file_path, 'proxy_type': self.proxy_type})

        except Exception as e:
            print(e)

    def get_store_list(self,response):
        if not response.url.startswith('file://'):
            self.f1.page_save(response.meta['file_path'], response.body)
        source_url = response.meta.get('source_url', '')
        links = response.xpath('//div[@data-folder="/locations"]//div[@class="container header-menu-nav-item"]/a/@href').getall()
        print(links)
        for link in links:
            # link = '/walnut-creek'
            res_s = requests.get('https://www.yallamedi.com' + link)
            response_s = HtmlResponse(url=res_s.url,body=res_s.content)

            # page save
            file_path = self.f1.html_data_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(run_date) + '_'+str(link[1:])+'.html'
            if not response_s.url.startswith('file://'):
                self.f1.page_save(file_path,response_s.body)

            item = StoreLocatorsItem()

            try:

                store_number = re.findall('"id":"(.*?)"',response_s.body.decode('utf-8'))[0]

                add = response_s.xpath('//div[@class="sqs-block-content"]/h3[3]/following-sibling::p/text()').get(default='').strip().split(',')
                print("add",add)

                # if add==['']:
                #     add = response_s.xpath('//h1/ancestor::div[1]/p[2]/text()').extract_first(default='').strip().split(',')
                #     print(add)

                hours = response_s.xpath('//blockquote/p//text()').extract()


                phone = add[0].split("|")[0].strip().replace("phone",'').replace('(','').replace(')','').replace(' ','-').replace('-','.').strip()
                if phone =='':
                     phone = response_s.xpath('//div[@class="sqs-block-content"]/h3[3]/following-sibling::p/a/text()').get().replace('(','').replace(')','').replace(' ','-').replace('-','.').strip()
                print("phone",phone)
                title = re.findall('"title":"(.*?)"',response_s.body.decode('utf-8'))[0].replace("(Delivery Only)",'')
                print("ti",title)

                item['store_name'] = 'Yalla Mediterranean - ' + title

                item['address'] = add[0].split("|")[1].strip()
                item['city'] = title.split(',')[0]


                item['state'] = title.split(',')[1]
                item['zip_code'] = re.findall(r'(\d+)',add[1])[0].strip()


                item['country'] = 'US'
                item['country_code'] = 'US'
                store_hour = '|'.join(hours).strip()
                item['store_hours'] = store_hour
                item['phone_number'] = phone
            except Exception as e:
                logging.log(logging.ERROR,e)
            try:
                additional_info = dict()
                info1 = response_s.xpath('//p[contains(text(),"contact us at")]/text()').extract_first(default='').strip()+'catering@yallamedi.com'
                if info1!='':
                    additional_info['Catering'] = info1
                info2 = response_s.xpath('//ul[@data-rte-list="default"]//p/text()').extract()
                if info2!=[]:
                    info2 = '|'.join(info2)
                    additional_info['Location Details'] = info2





                item['website_address'] = response_s.url
                item['additional_info'] = json.dumps(additional_info, ensure_ascii=False)
                item['source_url'] = source_url
                yield item
            except Exception as e:
                logging.log(logging.ERROR,e)

# execute('''scrapy crawl store_115 -a list_id=115'''.split())#-s HTTPCACHE_ENABLED=True
