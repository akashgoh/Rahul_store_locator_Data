# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import random
import re

import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from w3lib.html import remove_tags

from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime


class Store139Spider(scrapy.Spider):
    name = 'store_139'
    allowed_domains = []


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()


    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]

        self.f1.set_details(self.list_id,run_date)
        if self.f1.search_by != 'link':
            search_terms = self.f1.get_search_term(self.f1.search_by)
            print(search_terms)
        # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)
            search_terms = ''
            for search_term in (search_terms):
                source_url = link = 'https://voodoobbq.com/wp-admin/admin-ajax.php?action=store_search&lat=29.95107&lng=-90.07153&max_results=25&search_radius=50&autoload=1'
                file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(search_term) + '_' + str(run_date) + '.html'
                if os.path.exists(file_path):
                    link = 'file://' + file_path.replace('\\','/')
                yield scrapy.FormRequest(url=str(link), callback=self.get_store_list, meta={'source_url': source_url,'search_term': search_term,'file_path':file_path,'proxy_type': self.proxy_type})
        else:
            yield scrapy.Request(url='https://voodoobbq.com/wp-admin/admin-ajax.php?action=store_search&lat=29.95107&lng=-90.07153&max_results=25&search_radius=50&autoload=1', callback=self.data)


    def data(self, response):
        data = json.loads(response.text)
        for i in range(0,8):

            store_name = data[i]['store']

            address = data[i]['address']

            source_url = data[i]['permalink']

            city = data[i]['city']

            state = data[i]['state']
            if state == 'Florida':
                state = 'FL'

            zip_code = data[i]['zip']

            phone_number = data[i]['phone']

            fax_number = data[i]['fax']

            email_address = data[i]['email']

            latitude = data[i]['lat']

            longitude = data[i]['lng']

            store_hours1 = data[i]['hours']
            store_hours =store_hours1.replace('</td><td><time>',':').replace('</time></td></tr><tr><td>','|')
            store_hours = remove_tags(store_hours)

            item = StoreLocatorsItem()
            item['search_term'] = 'link'
            item['store_name']= store_name
            item['address'] = address
            item['store_hours'] = store_hours
            item['city'] = city
            item['state'] =state
            item['country'] = 'USA'
            item['country_code'] = 'US'
            item['zip_code'] = zip_code
            item['phone_number'] = phone_number
            item['fax_number'] = fax_number
            item['email_address'] = email_address
            item['latitude'] = latitude
            item['longitude'] = longitude
            item['website_address'] = ''
            item['coming_soon'] = 0
            item['source_url'] = source_url
            yield item


    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_139 -a list_id=139'''.split())
