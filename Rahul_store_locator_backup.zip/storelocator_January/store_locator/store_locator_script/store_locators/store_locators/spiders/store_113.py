# -*- coding: utf-8 -*-
import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime
import re
import html2text
run_date = str(datetime.datetime.today()).split()[0]

class YeswayCrawlerSpider(scrapy.Spider):
    name = 'store_113'
    allowed_domains = []
    f1 = Func()

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            source_url = link = 'https://yesway.com/locations/'
            self.f1.set_details(self.list_id, run_date)
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(run_date) + '.html'
            if os.path.exists(file_path):
                link = 'file://' + file_path.replace('\\', '/')
            yield scrapy.FormRequest(url=str(link), callback=self.get_store_list, meta={'source_url': source_url,'file_path': file_path, 'proxy_type': self.proxy_type})
        except Exception as e:
            print(e)

    def get_store_list(self,response):
        if not response.url.startswith('file://'):
            self.f1.page_save(response.meta['file_path'], response.body)
        source_url = response.meta.get('source_url', '')
        store_loop = response.xpath('//div[contains(@id,"loadcontent-")]')
        for lp in store_loop:
            try:
                id = lp.xpath('./@id').extract_first(default='').strip().split('-')[-1].strip()
                name = lp.xpath('.//h3/text()').extract_first(default='').strip()
                store_code = re.findall('(\d+)',name)[0]
                add = lp.xpath('.//address/text()').extract()
                services = lp.xpath('.//img/@title').extract()
                latlong = lp.xpath('.//marker/@position').extract_first(default='').replace('[','').replace(']','').strip().split(',')
                store_hours = []
                hours = lp.xpath('.//ul[@class="list-unstyled"]/li')
                for h in hours:
                    store_hours.append(''.join(h.xpath('.//text()').extract()))
                store_hours = '|'.join(store_hours)
            except Exception as e:
                logging.log(logging.ERROR,e)
            try:
                item = StoreLocatorsItem()
                item['store_number'] = id
                item['store_name'] = name
                item['store_code'] = store_code
                item['address'] = add[0].replace('[','').replace(']','').replace('"','').replace('  ',' ').strip()
                item['city'] = add[-1].strip().split(',')[0].strip()
                item['state'] = add[-1].strip().split(',')[-1].strip().split(' ')[0].strip()
                item['zip_code'] = add[-1].strip().split(',')[-1].strip().split(' ')[-1].strip()
                item['country'] = 'US'
                item['country_code'] = 'US'
                item['services'] = '|'.join(services)
                item['latitude'] = latlong[0]
                item['longitude'] = latlong[-1]
                item['store_hours'] = store_hours
                item['website_address'] = source_url
                yield item
            except Exception as e:
                logging.log(logging.ERROR, e)


# execute('''scrapy crawl store_113 -a list_id=113'''.split())#-s HTTPCACHE_ENABLED=True