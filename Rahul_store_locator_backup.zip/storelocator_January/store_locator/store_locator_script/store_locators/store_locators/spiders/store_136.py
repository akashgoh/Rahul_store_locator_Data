# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from w3lib.http import basic_auth_header

from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime
import itertools
import requests
from requests.auth import HTTPProxyAuth
import re

class WabagrillCrawlerSpider(scrapy.Spider):
    name = 'wabagrill'
    allowed_domains = []
    f1 = Func()

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            self.f1.set_details(self.list_id,run_date)
            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                print(search_terms)
            # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)

                # search_terms = ''
                # for search_term in (search_terms):
                #     source_url = link = f"https://www.bestbuy.com/browse-api/2.0/store-locator/{search_term}"
                #     file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(search_term) + '_' + str(run_date) + '.html'
                #     if os.path.exists(file_path):
                #         link = 'file://' + file_path.replace('\\','/')
                #     yield scrapy.FormRequest(url=str(link), callback=self.get_store_list, meta={'source_url': source_url,'search_term': search_term,'file_path':file_path,'proxy_type': self.proxy_type})
            else:
                # Headers = {"cache-control": "max-age=0, must-revalidate, private",
                #            "cf-ray": "5171ae4f6ad7dc43-LHR",
                #            "content-type": "application/json; charset=UTF-8",
                #            "expect-ct": "max-age=604800, report-uri='https://report-uri.cloudflare.com/cdn-cgi/beacon/expect-ct'",
                #            "referrer-policy": "strict-origin-when-cross-origin",
                #            "server": "cloudflare",
                #            "x-cache": "MISS",
                #            "x-cache-group": "",
                #            "x-cacheable": "NO:Passed",
                #
                #            "x-frame-options": "SAMEORIGIN",
                #            "x-pass-why": "wp-admin",
                #            "user-agent": "Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36",
                #            "x-robots-tag": "noindex",
                #            "Proxy-Authorization": basic_auth_header("anil.prajapati.xbyte@gmail.com", "xbyte123")
                #            }


                for i in range(1,11):
                    source_url = link = 'https://momentfeed-prod.apigee.net/api/llp.json?auth_token=KBAXTJEEPNAVUUJW&multi_account=false&page=' + str(i)

                # proxies = {"http": "https://account.ipvanish.com/"}
                # from requests.auth import HTTPProxyAuth
                # auth = HTTPProxyAuth("anil.prajapati.xbyte@gmail.com", "xbyte123")
                # r = requests.get(source_url, proxies=proxies, headers=Headers, auth=auth, allow_redirects=True)
                # response = HtmlResponse(url=r.url, body=r.content)


                    file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(self.name) + '_' + str(run_date) + '.html'
                    yield scrapy.Request(url=source_url,dont_filter=True, callback=self.get_store_list,meta={"http": "https://account.ipvanish.com/",'source_url': source_url,'file_path': file_path,'proxy_type': self.proxy_type})

        except Exception as e:
            logging.log(logging.ERROR, e)

    # Get data from the response
    def get_store_list(self, response):
        try:
            if not response.url.startswith('file://'):
                self.f1.page_save(response.meta['file_path'],response.body)

            search_term = response.meta.get('search_term', '')
            source_url = response.meta.get('source_url', '')
            store_data = json.loads(response.text)
            print(len(store_data))

            # If you have search_by :zip_code/city/state/lat_lng then you need to add following condition and query to update log table
            # If you have search_by :zip_code/city/state/lat_lng then you need to add following condition and query to update log table
            if len(store_data) == 0:
                Func.update_log_table(self.f1, search_term)
            else:
                for store in store_data:
                    st = json.dumps(store)
                    try:
                        additional_info = {}
                        item = StoreLocatorsItem()

                        item['search_term'] = search_term
                        item['state'] = store['store_info']['region']
                        item['store_name'] = store['store_info']['name']
                        item['address'] = store['store_info']['address']
                        item['address_line_2'] = store['store_info']['address_extended']

                        item['city'] = store['store_info']['locality']
                        item['zip_code'] = store['store_info']['postcode']
                        item['phone_number'] = store['store_info']['phone']
                        item['latitude'] = store['store_info']['latitude']
                        item['longitude'] = store['store_info']['longitude']
                        item['store_type'] = ''
                        item['source_url'] = store['store_info']['website']
                        item['coming_soon'] = 0
                        item['store_number'] = ''
                        item['store_code'] = store['store_info']['corporate_id']
                        item['country_code'] = 'US'
                        item['services'] = ''
                        item['country'] = 'US'

                        a = ''
                        day = {"Monday": "1", "Tuesday": "2", "Wednesday": "3", "Thursday": "4",
                                 "Friday": "5", "Saturday": "6", "Sunday": "7"}

                        # tymm = {'9:00 am - 10:00 pm':'0900','10:00 am - 9:00 pm':'1000','11:00 am - 9:00 pm ':'1100','12:00 pm - 8:00 pm':'2100','2230':'10:00 am - 10:30 pm','1000,2100':'10:00 am - 9:00 pm','1100,2100':'11:00 am - 9:00 pm','1200,2000':'12:00 pm - 8:00 pm','1030,2100':'10:30 am - 9:00 pm','1030,2000':'10:30 am - 8:00 pm','1030,2200':'10:30 am - 10:00 pm','1100,2200':'11:00 am - 10:00 pm','0930,2230':'9:30 am - 10:30 pm','0800,1900':'8:00 am - 7:00 pm','0800,1800':'8:00 am - 6:00 pm','1030,2200':'10:30 am - 10:00 pm',',0930,2230':'9:30 am - 10:30 pm','1030,2130'}

                        a = store['store_info']['store_hours'].strip()
                        a = a.split(';')
                        del a[-1]
                        hours = []
                        try:
                            for i in a:
                                data = i.split(",")
                                st0 = dict((v, k) for k, v in day.items()).get(str(data[0]))
                                # day = dict((v, k) for k, v in day.items()).get(str(data))
                                start = str(data[1][:2]) + ":" + str(data[1][-2:])
                                end = str(data[2][:2]) + ":" + str(data[2][-2:])
                                hours.append(str(st0) + '-' + str(start) + ':' + str(end))
                            item['store_hours'] = "|".join(hours)
                            print(a)
                        except Exception as e:
                            print(e)

                        # if len(a) ==5:
                        #     a=a.append('closed')
                        # qn = []
                        # try:
                        #     for q in a:
                        #         st0 = dict((v, k) for k, v in day.items()).get(str(q.split(',')[0]))
                        #         st1 = dict((v, k) for k,v in tymm.items()).get(str(q.split(',')[1]))
                        #         qn.append(st0 + ':' + st1)
                        #
                        #     store_hour = '|'.join(qn)
                        #     if store_hour:
                        #         item['store_hours'] = store_hour
                        #     else:
                        #         item['store_hours'] = ''
                        # except Exception as e:
                        #     item['store_hours'] = ''

                        item['email_address'] = ''
                        item['additional_info'] = ''
                        item['number_of_store'] = len(store_data)
                        yield item
                    except Exception as e:
                        print(e)

        except Exception as e:
            logging.log(logging.ERROR, e)

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl wabagrill -a list_id=136'''.split())
# execute('''scrapy crawl sunsetgrill -a list_id=49 -a proxy_type=storm_proxy -s CONCURRENT_REQUESTS=16 -s DOWNLOAD_DELAY=3'''.split())