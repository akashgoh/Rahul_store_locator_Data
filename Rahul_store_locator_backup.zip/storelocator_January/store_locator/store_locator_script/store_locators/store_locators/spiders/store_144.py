# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import re

import html2text
import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime


class VictorymotorcyclesSpider(scrapy.Spider):
    name = 'store_144'
    allowed_domains = []

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        try:
            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                print(search_terms)
                search_terms = ''
                for search_term in (search_terms):
                    source_url = link = 'https://www.victorymotorcycles.com/'
                    yield scrapy.FormRequest(url=str(link), callback=self.get_store_list, meta={'source_url': source_url,'search_term': search_term})
            else:
                source_url = link = 'https://www.victorymotorcycles.com/'
                yield scrapy.FormRequest(url=str(link), callback=self.get_links,meta={'source_url': source_url})

        except Exception as e:
            logging.log(logging.ERROR, e)

    def get_links(self, response):
        links = ['https://www.victorymotorcycles.com/en-us/api/dealerlocator/dealers?Latitude=40.7464969&Longitude=-74.00944709999999&recordcount=1000&geofencecountry=us&productlinecode=vic&distancetype=mi&distancetolook=20000&virtualTerritorySearch=false',
                 'https://www.victorymotorcycles.com/en-ca/api/dealerlocator/dealers?Latitude=49.26526390000001&Longitude=-123.1676483&recordcount=1000&geofencecountry=ca&productlinecode=vic&distancetype=km&distancetolook=20000&virtualTerritorySearch=false']
        for link in links:
            yield scrapy.FormRequest(url=str(link), callback=self.get_store_list, meta=response.meta)

    # Get data from the response
    def get_store_list(self, response):
        try:
            data = response.text

            try:
                UniqueKey = str(int(hashlib.md5(bytes(response.url, "utf8")).hexdigest(), 16) % (10 ** 10))
                file_path = self.f1.html_data_directory + str(self.list_id) + '\\' + str(self.run_date) + '\\'
                if not os.path.exists(file_path):
                    os.makedirs(file_path)
                f = open(file_path + str(UniqueKey) + '.html', 'wb')
                f.write(response.text.encode('utf-8'))
                f.close()
            except Exception as e:
                print(e)

            cmtable = json.loads(data)
            length = len(cmtable)

            for i in range(0, length):
                try:
                    additional_info = {}
                    item = StoreLocatorsItem()
                    try:
                        store_name = cmtable[i]['BusinessName']
                    except Exception as e:
                        print("store_name",e,response.url)

                    try:
                        phone_number = cmtable[i]['Phone']
                        if phone_number == None:
                            phone_number = ''
                    except Exception as e:
                        print("phone_number", e, response.url)

                    try:
                        email_address = ''
                    except Exception as e:
                        print("email_address", e, response.url)

                    try:
                        address = cmtable[i]['Address1']
                    except Exception as e:
                        print("address", e, response.url)

                    try:
                        address_line_2 = ''
                        check = False

                        for j in ['Unit', 'STE', 'Ste', 'SUITE', 'Suite', 'suite', 'Suit', 'SUIT', 'suit', 'UNIT',
                                  'unit', 'ste']:
                            for aw in address.split():
                                if j == aw:
                                    address1 = address.split(j)[0].strip().strip(',')
                                    address_line_2 = j + ' ' + address.split(j)[-1].strip()
                                    check = True
                                    break

                        if check == True:
                            address_line_2 = address_line_2
                            address = address1
                        else:
                            address_line_2 = ''
                            address = address
                    except Exception as e:
                        print("address_line_2", e, response.url)

                    try:
                        city = cmtable[i]['City']
                    except Exception as e:
                        print("city", e, response.url)

                    try:
                        state = cmtable[i]['Region']
                    except Exception as e:
                        print("state", e, response.url)

                    try:
                        zip_code = cmtable[i]['PostalCode']
                    except Exception as e:
                        print("zip_code", e, response.url)

                    try:
                        latitude = cmtable[i]['Latitude']
                        longitude = cmtable[i]['Longitude']
                    except Exception as e:
                        print("latitude and longitude", e, response.url)

                    try:
                        services = ''
                    except Exception as e:
                        print("services",e,response.url)

                    try:
                        store_hour = []
                        shrs = cmtable[i]['StoreHours']
                        hrs = len(cmtable[i]['StoreHours'])

                        for h in range(0,hrs):
                            a = shrs[h]['DayOfWeek'] + ':' + shrs[h]['OpenTime'] + ' - ' + shrs[h]['CloseTime']
                            if a == 'SUNDAY: - ':
                                a = 'SUNDAY: Closed'
                            if a == 'MONDAY: - ':
                                a = 'MONDAY: Closed'
                            store_hour.append(a)

                        store_hours = '|'.join(store_hour)

                    except Exception as e:
                        print("store_hours",e,response.url)

                    try:
                        geeksquad = ''.join(response.xpath('//div[@class="inner-module"]/div[2]/text()').extract()).replace('’',"'")
                        geeksquad = re.sub('\s+', ' ', re.sub('\r|\n|\t', ' ',str(geeksquad)))
                        additional_info['geek_sqaud'] = (geeksquad)
                    except Exception as e:
                        print("additional_info",e,response.url)


                    item['search_term'] = 'link'
                    item['store_name']= store_name
                    item['address'] = address
                    item['address_line_2'] = address_line_2
                    item['city'] = city
                    item['state'] =state
                    item['zip_code'] = zip_code
                    item['phone_number'] =phone_number
                    item['latitude'] = latitude
                    item['longitude'] = longitude
                    item['store_type'] = ''
                    item['website_address'] = cmtable[i]['WebSite']
                    item['coming_soon'] = 0
                    item['store_number'] = ''
                    item['country_code'] = item['country'] = cmtable[i]['Country']
                    item['email_address'] = email_address
                    item['services'] = services
                    item['store_hours'] = store_hours
                    item['additional_info'] = ''
                    item['source_url'] = 'https://www.victorymotorcycles.com/en-us/dealer-locator/#q='+str(zip_code)


                    # if item['country_code'] == 'US' and len(item['state']) > 2:
                    #     item['state'] = self.f1.state_dict.get(state, '')
                    yield item
                except Exception as e:
                    print(e)

        except Exception as e:
            logging.log(logging.ERROR, e)

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_144 -a list_id=144'''.split())
