# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import random
import re


import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime

class Store127Spider(scrapy.Spider):
    name = 'store_127'
    allowed_domains = []


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()


    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            self.f1.set_details(self.list_id,run_date)
            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                print(search_terms)
            # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)
                search_terms = ''
                for search_term in (search_terms):
                    source_url = link = 'https://willys.com/locations/'
                    file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(search_term) + '_' + str(run_date) + '.html'
                    if os.path.exists(file_path):
                        link = 'file://' + file_path.replace('\\','/')
                    yield scrapy.FormRequest(url=str(link), callback=self.get_store_list, meta={'source_url': source_url,'search_term': search_term,'file_path':file_path,'proxy_type': self.proxy_type})
            else:
                source_url = link = 'https://willys.com/locations/'
                file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(run_date) + '.html'
                yield scrapy.FormRequest(url=str(link), callback=self.firstlevel,
                                         meta={'source_url': source_url,
                                               'file_path': file_path, 'proxy_type': self.proxy_type})
        except Exception as e:
            logging.log(logging.ERROR, e)


    def firstlevel(self,response):
        links = response.xpath('//div[@class="location-title"]/a/@href').extract()
        for link in links:
            yield scrapy.Request(url=link, callback=self.data)
            # yield scrapy.Request(url='https://willys.com/stores/norcross/', callback=self.data)


    def data(self, response):
        try:store_name = response.xpath('//div[@class="post-title"]//h4/text()').extract_first().strip()
        except Exception as e:print('store_name', e, response.url)

        text = response.text
        json_data = re.findall(r'"locations":(.*?)};', text)[0]
        data = json.loads(json_data)

        try:
            address = data[0]['address']
            city = data[0]['city']
            state = 'GA'
            zip_code = data[0]['zip']
            country = data[0]['country']
            lat = data[0]['lat']
            lng = data[0]['lng']
        except Exception as e:
            print('address', e, response.url)

        try:phone_number = re.findall('Phone: <span>(.*?)</span>', text)[0]
        except Exception as e:print('phone_number', e, response.url)

        try:
            store_hours = re.findall(r'Hours:</div>(.*?)</div>', text)[0]
            store_hours = re.sub('\s+', ' ', re.sub('\r|\n|\t', ' ', store_hours)).replace('<br>','|')
            store_hours = str(store_hours).encode('ascii','ignore')
        except Exception as e:
            print('store_hours', e, response.url)

        try:
            services = []
            service = response.xpath('//div[@class="location-amenities"]//text()').extract()
            for ser in service:
                services.append(ser.strip())
        except Exception as e:
            print('services', e, response.url)

        item = StoreLocatorsItem()
        item['search_term'] = 'link'
        item['store_name'] = store_name
        item['address'] = address
        item['city'] = city
        item['state'] = state
        item['country'] = country
        item['zip_code'] = zip_code
        item['phone_number'] = phone_number
        item['latitude'] = lat
        item['longitude'] = lng
        item['website_address'] = response.url
        item['coming_soon'] = 0
        item['country_code'] = item['country'] = 'US'  # self.f1.country_dict.get(item['country'].lower())
        item['services'] = '|'.join(services)
        item['store_hours'] = store_hours
        item['additional_info'] = ''

        # if item['country_code'] == 'US' and len(item['state']) > 2:
        #     item['state'] = self.f1.state_dict.get(state, '')
        yield item

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_127 -a list_id=127'''.split())