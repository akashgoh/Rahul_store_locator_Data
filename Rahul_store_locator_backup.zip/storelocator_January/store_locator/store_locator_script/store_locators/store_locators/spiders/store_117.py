# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import random
import re

import html2text
import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime

class Store117Spider(scrapy.Spider):
    name = 'store_117'
    allowed_domains = []


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()


    def start_requests(self):
        self.run_date = str(datetime.datetime.today()).split()[0]
        try:
            self.f1.set_details(self.list_id,self.run_date)
            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                print(search_terms)
            # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)
                search_terms = ''
                for search_term in (search_terms):
                    source_url = link = 'https://wydot.maps.arcgis.com/sharing/proxy?https://docs.google.com/spreadsheets/d/e/2PACX-1vQjUHMaEvNlIzS34w83eRrySQ-p5GKD9acc0AFcNhMTkq7keuJ0TY1DMIa2-PEbUvPsUTKlwA9VWpe5/pub?gid=1581986616&single=true&output=csv'
                    file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(search_term) + '_' + str(self.run_date) + '.html'
                    if os.path.exists(file_path):
                        link = 'file://' + file_path.replace('\\','/')
                    yield scrapy.FormRequest(url=str(link), callback=self.data,
                                             meta={'source_url': source_url,'search_term': search_term,'file_path':file_path,'proxy_type': self.proxy_type})
            else:
                headers = {
                    "Referer":"https://wydot.maps.arcgis.com/apps/Shortlist/index.html?appid=f7834c5fa12c4090b07172d159dbfafd",
                    "Sec-Fetch-Mode":"cors",
                    "User-Agent":"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537.36",
                    "X-Requested-With":"XMLHttpRequest"
                }
                source_url = link = 'https://wydot.maps.arcgis.com/sharing/proxy?https://docs.google.com/spreadsheets/d/e/2PACX-1vQjUHMaEvNlIzS34w83eRrySQ-p5GKD9acc0AFcNhMTkq7keuJ0TY1DMIa2-PEbUvPsUTKlwA9VWpe5/pub?gid=1581986616&single=true&output=csv'
                file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(self.run_date) + '.html'
                yield scrapy.FormRequest(url=str(link), callback=self.data, headers=headers,
                                         meta={'source_url': source_url,'file_path': file_path, 'proxy_type': self.proxy_type})
        except Exception as e:
            logging.log(logging.ERROR, e)


    def data(self, response):
        text = response.text
        divs = text.split('Location,')
        del(divs[0])

        for div in divs:
            store_name = div.split(',')[0].strip()

            latitude = div.split(',')[-2].strip()

            longitude = div.split(',')[-1].strip()

            try:
                store_hours = re.findall(r'Hours of Operation</span><br/>(.*?)","<span style', div)[0]
                store_hours = re.sub('<.*?>', ' ', store_hours)
            except Exception as e:
                print(e)

            try:
                address1 = re.findall(r'Address</span><br/>(.*?)\d{5}', div)[0].split('<br/>')
                address = address1[0].strip()
                city = address1[-1].split(',')[0].strip()
                state = address1[-1].split(',')[-1].strip()
            except Exception as e:
                print(e)

            try:zipcode = re.findall(r'Address</span><br/>.*?(\d{5})', div)[0]
            except Exception as e:print(e)

            try:phone_number = re.findall(r'\d{5}<br/>(.*?)<br/>', div)[0]
            except Exception as e:print(e)

            try:
                additional_info = re.findall(r'Additional Exam Station Information</span><br/>(.*?)Hours', div)[0].replace('</li><li>','|').replace(',"','').replace('",','').replace(',','').replace('"','')
                additional_info = re.sub('<.*?>', ' ', additional_info)
            except:
                additional_info = ''

            item = StoreLocatorsItem()
            item['search_term'] = 'link'
            item['store_name'] = store_name
            item['address'] = address
            item['city'] = city
            item['state'] = state
            item['zip_code'] = zipcode
            item['coming_soon'] = 0
            item['country'] = 'USA'
            item['country_code'] = 'US' # self.f1.country_dict.get(item['country'].lower())
            item['store_hours'] = store_hours
            item['latitude'] = latitude
            item['longitude'] = longitude
            item['phone_number'] = phone_number
            item['additional_info'] = additional_info
            item['source_url'] = response.url
            yield item

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_117 -a list_id=117'''.split())