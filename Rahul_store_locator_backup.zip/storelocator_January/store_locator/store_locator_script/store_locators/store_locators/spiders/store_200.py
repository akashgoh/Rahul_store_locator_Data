# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import re

import html2text
import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime


class SuperdrugCrawlerSpider(scrapy.Spider):
    name = 'superdrug'
    allowed_domains = []
    f1 = Func()

    def __init__(self, name=None, list_id="",proxy_type="",**kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type= list_id, proxy_type

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            source_url = link = 'https://www.superdrug.com/stores/a-to-z'
            self.f1.set_details(self.list_id, run_date)
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
                run_date) + '.html'
            if os.path.exists(file_path):
                link = 'file://' + file_path.replace('\\', '/')

            yield scrapy.FormRequest(url=str(link), callback=self.get_list,meta={'source_url': source_url,'file_path': file_path,'proxy_type': self.proxy_type})
        except Exception as e:
            print(e)


    def get_list(self,response):
        source_url = response.meta['source_url']
        file_path = response.meta['file_path']
        url = response.xpath('//*[@class="az-stores__store-item"]/div/h2/a/@href').extract()
        for u in url:
            u = u.replace('/store/','/store/page/').replace(' ','%20')
            ua = 'https://www.superdrug.com' + u + '?undefined'
            yield scrapy.Request(url=str(ua), callback=self.get_store_list, meta={'source_url': source_url,'file_path': file_path,'proxy_type': self.proxy_type})


    # Get data from the response
    def get_store_list(self, response):
        try:
            if not response.url.startswith('file://'):
                self.f1.page_save(response.meta['file_path'],response.body)

            search_term = response.meta.get('search_term', '')
            source_url = response.meta.get('source_url', '')
            store_data = json.loads(response.text)
            # print(len(store_data))

            # If you have search_by :zip_code/city/state/lat_lng then you need to add following condition and query to update log table

            if len(store_data) == 0:
                Func.update_log_table(self.f1,search_term)
            else:
                store_data = json.loads(response.text)
                additional_info = {}
                item = StoreLocatorsItem()

                item['search_term'] = search_term

                item['state'] = store_data['address']['country']['isocode']
                item['store_name'] = 'Superdrug - '+ store_data['name']
                fulladdress = store_data['address']['line1'] + ',' + store_data['address']['streetNumber']

                try:
                    check = False
                    address = fulladdress
                    for i in ['Unit', 'Suite', 'Ste']:
                        for aw in address.split():
                            if i == aw:
                                address1 = address.split(i)[0].strip(',')
                                address_line_2 = i + ' ' + address.split(i)[-1].strip()
                                check = True
                                break

                    if check == True:
                        address_line_2 = address_line_2
                        address = address1
                    else:
                        address_line_2 = ''
                        address = address
                except Exception as e:
                    print(e)


                item['address'] = address
                item['address_line_2'] = address_line_2.strip()
                # print(store_data['address']['line1'])
                # print(store_data['address']['streetNumber'])
                item['city'] = store_data['address']['town']
                item['source_url'] = response.url
                item['zip_code'] = store_data['address']['postalCode']
                item['phone_number'] = store_data['address']['phone']

                item['latitude'] = store_data['geoPoint']['latitude']
                item['longitude'] = store_data['geoPoint']['longitude']
                item['store_type'] = ''
                item['coming_soon'] = 0
                item['store_number'] = store_data['sdStoreId']
                item['country_code'] = 'UK' #self.f1.country_dict.get(item['country'].lower())
                item['services'] = ''
                item['country'] = 'UK'

                # if item['country_code'] == 'IN' and len(item['state']) > 2:
                #     item['state'] = self.f1.state_dict.get(store.get(item['state'].lower(), '')) #getting  us state code

                try:
                    store_hours_list = store_data['openingHours']['weekDayOpeningList']
                    if store_hours_list != '':
                        store_hours_list_temp = []

                        for store_hour in store_hours_list:
                            store_hour = json.loads(json.dumps(store_hour))

                            store_hours_list_temp.append(store_hour['weekDay'] + ' ' + store_hour['openingTime']['formattedHour'] + ' - ' + store_hour['closingTime']['formattedHour'])

                        store_hours = '|'.join(store_hours_list_temp).strip()
                        item['store_hours'] = store_hours
                    else:
                        item['store_hours'] = ''
                except Exception as e:
                    item['store_hours'] = ''

                item['email_address'] = store_data['address']['email']
                item['additional_info'] = json.dumps(store_data['features']).replace('{','').replace('}','')
                item['number_of_store'] = '805'
                yield item


        except Exception as e:
            logging.log(logging.ERROR, e)

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl superdrug -a list_id=200 -s HTTPCACHE_ENABLED=True'''.split())
# execute('''scrapy crawl superdrug -a list_id=200 -a proxy_type=storm_proxy -s CONCURRENT_REQUESTS=16 -s DOWNLOAD_DELAY=3'''.split())

