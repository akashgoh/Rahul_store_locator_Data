# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import re

import html2text
import pgeocode as pgeocode
import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime


class VisionsSpider(scrapy.Spider):
    name = 'store_142'
    allowed_domains = []

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        try:
            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                print(search_terms)
                for search_term in (search_terms):
                    source_url = link = 'https://www.visions.ca/storelocator/default.aspx'
                    file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(search_term) + '_' + str(self.run_date) + '.html'
                    if os.path.exists(file_path):
                        link = 'file://' + file_path.replace('\\','/')
                    yield scrapy.FormRequest(url=str(link), callback=self.get_store_list, meta={'source_url': source_url,'search_term': search_term,'file_path':file_path})
            else:
                source_url = link = 'https://www.visions.ca/storelocator/default.aspx'
                file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(self.run_date) + '.html'
                yield scrapy.FormRequest(url=str(link), callback=self.get_store_list, meta={'source_url': source_url,'file_path': file_path})

        except Exception as e:
            logging.log(logging.ERROR, e)

    # Get data from the response
    def get_store_list(self, response):
        surl = response.url
        try:
            if not response.url.startswith('file://'):
                self.f1.page_save(response.meta['file_path'],response.body)

            search_term = response.meta.get('search_term', '')
            source_url = response.meta.get('source_url', '')

            attributes = response.xpath('//*[@class="storelocator-container"]')

            for attr in attributes:
                try:
                    additional_info = {}
                    item = StoreLocatorsItem()
                    try:
                        store_name = attr.xpath('.//div[1]/span/text()').get()
                    except Exception as e:
                        print("store_name",e,response.url)

                    try:
                        email_address = attr.xpath('.//div[1]/a/text()').get().strip()
                    except Exception as e:
                        print("email_address", e, response.url)

                    try:
                        addr = attr.xpath('.//*[@class="storelocator-city"]/following-sibling::text()').getall()
                        fulladdress = []
                        for adr in addr:
                            adr = adr.replace('\r','').replace('\n','').replace('\t','').strip()
                            if adr != '':
                             fulladdress.append(adr)

                    except Exception as e:
                        print("Full address", e, response.url)

                    try:
                        if len(fulladdress) == 5:
                            address = fulladdress[0] + ', ' + fulladdress[1]
                            ctstatezip = fulladdress[2]
                            city = ctstatezip.split(',')[0]
                            state = ctstatezip.split(',')[1].strip().split()[0].replace('.','')
                            if state == 'Alberta':
                                state = 'AB'
                            zip_code = ctstatezip.split(',')[1].strip().split()[1] + ' ' + ctstatezip.split(',')[1].strip().split()[2]
                            phone_number = fulladdress[3].replace('Phone:','').strip()
                            if 'Unit' in address:
                                address_line_2 = address.split(',')[0]
                                address = address.split(',')[1]
                            else:
                                address_line_2 = ''
                        else:
                            address = fulladdress[0]
                            ctstatezip = fulladdress[1]
                            if 'Edmonton Alberta. T5Y 2W7' in ctstatezip:
                                ctstatezip = ctstatezip.replace('Edmonton','Edmonton,')
                            city = ctstatezip.split(',')[0]
                            state = ctstatezip.split(',')[1].strip().split()[0].replace('.', '')
                            if state == 'Alberta':
                                state = 'AB'
                            zip_code = ctstatezip.split(',')[1].strip().split()[1] + ' ' + ctstatezip.split(',')[1].strip().split()[2]
                            phone_number = fulladdress[2].replace('Phone:', '').strip()
                            if 'Unit' in address:
                                address_line_2 = address.split(',')[0]
                                address = address.split(',')[1]
                            else:
                                address_line_2 = ''
                    except Exception as e:
                        print("address", e, response.url)

                    try:
                        nomi = pgeocode.Nominatim('ca')
                        latitude = nomi.query_postal_code(zip_code).latitude
                        longitude = nomi.query_postal_code(zip_code).longitude

                    except Exception as e:
                        print("latitude and longitude", e, response.url)

                    try:
                        products = ''
                    except Exception as e:
                        print("products",e,response.url)

                    try:
                        store_hours = '|'.join(attr.xpath('.//div[2]/div[2]/text()').getall()).strip('|')
                    except Exception as e:
                        print("store_hours",e,response.url)

                    try:
                        geeksquad = ''.join(response.xpath('//div[@class="inner-module"]/div[2]/text()').extract()).replace('’',"'")
                        geeksquad = re.sub('\s+', ' ', re.sub('\r|\n|\t', ' ',str(geeksquad)))
                        additional_info['geek_sqaud'] = (geeksquad)
                    except Exception as e:
                        print("additional_info",e,response.url)


                    item['search_term'] = 'link'
                    item['store_name']= store_name
                    item['address'] = address
                    item['address_line_2'] = address_line_2
                    item['city'] = city
                    item['state'] =state
                    item['zip_code'] = zip_code
                    item['phone_number'] =phone_number
                    item['latitude'] = latitude
                    item['longitude'] = longitude
                    item['store_type'] = ''
                    item['website_address'] = ''
                    item['coming_soon'] = 0
                    item['store_number'] = ''
                    item['country_code'] = item['country'] = 'CA'
                    item['email_address'] = email_address
                    item['services'] = ''
                    item['products'] = products
                    item['store_hours'] = store_hours
                    item['additional_info'] = ''
                    item['source_url'] = surl


                    # if item['country_code'] == 'US' and len(item['state']) > 2:
                    #     item['state'] = self.f1.state_dict.get(state, '')
                    yield item
                except Exception as e:
                    print(e)

        except Exception as e:
            logging.log(logging.ERROR, e)

    def response_html_path(self, request):
        return request.meta['fpath']

#execute('''scrapy crawl store_142 -a list_id=142'''.split())
