import re

import scrapy
import datetime


from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import scrapy,os,logging,hashlib

con = 0

class Store123Spider(scrapy.Spider):
    name = 'store_123'

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]

#     def parse(self, response):
#         self.f1.set_details(self.list_id, self.run_date)
#         links = ['https://wolfgangpuck.com/dining/griffith-cafe/',
#                  'https://wolfgangpuck.com/dining/chinois-santa-monica/',
#                  'https://wolfgangpuck.com/dining/culture-kitchen-seattle/',
#                  'https://wolfgangpuck.com/dining/cut-bahrain/',
#                  'https://wolfgangpuck.com/dining/cut-beverly-hills/',
#                  'https://wolfgangpuck.com/dining/cut-dc/',
#                  'https://wolfgangpuck.com/dining/cut-doha/',
#                  'https://wolfgangpuck.com/dining/cut-las-vegas/',
#                  'https://wolfgangpuck.com/dining/cut-london/',
#                  'https://wolfgangpuck.com/dining/cut-new-york/',
#                  'https://wolfgangpuck.com/dining/cut-singapore/',
#                  'https://wolfgangpuck.com/dining/japan-locations/',
#                  'https://wolfgangpuck.com/dining/lupo-by-wolfgang-puck-las-vegas/',
#                  'https://wolfgangpuck.com/dining/reasian-cuisine-bahrain-bay/',
#                  'https://wolfgangpuck.com/dining/spago-2/',
#                  'https://wolfgangpuck.com/dining/spago-istanbul/',
#                  'https://wolfgangpuck.com/dining/spago-lv/',
#                  'https://wolfgangpuck.com/dining/spago-maui/',
#                  'https://wolfgangpuck.com/dining/spago-singapore/',
#                  'https://wolfgangpuck.com/dining/the-kitchen-by-wolfgang-puck-grand-rapids/',
#                  'https://wolfgangpuck.com/dining/wolfgang-puck-at-hotel-bel-air/',
#                  'https://wolfgangpuck.com/dining/wolfgang-puck-bar-and-grill-las-vegas/',
#                  'https://wolfgangpuck.com/dining/wolfgang-puck-bar-and-grill-los-angeles/',
#                  'https://wolfgangpuck.com/dining/orlando-bar-grill/',
#                  'https://wolfgangpuck.com/dining/wolfgang-puck-express-orlando/',
#                  'https://wolfgangpuck.com/dining/wolfgang-puck-kitchen-bar-shanghai/',
#                  'https://wolfgangpuck.com/dining/wolfgang-puck-kitchen-costa-mesa/',
#                  'https://wolfgangpuck.com/dining/wolfgang-puck-players-locker/',
#                  'https://wolfgangpuck.com/bars-lounges/blue-moon-lounge/',
#                  'https://wolfgangpuck.com/bars-lounges/cutlounge/',
#                  'https://wolfgangpuck.com/bars-lounges/nest-at-wp24/',
#                  'https://wolfgangpuck.com/bars-lounges/riva/',
#                  'https://wolfgangpuck.com/bars-lounges/the-bar-lounge-at-hotel-bel-air/']
#         for link in links:
#
#             yield scrapy.Request(url=link, callback=self.extract_data, dont_filter=True)
#
#     def extract_data(self,response):
#         url = response.url
#         try:
#             sname = 'Wolfgang puck -'+url.split('/')[-2]
#         except Exception as e:
#             sname = ''
#             print(e)
#
#         try:
#             add = ''.join(response.xpath('//*[@class="col-md-9 col-sm-6"]/p[1]/text()[2]').extract())
#             if add == '':
#                 add = response.xpath('normalize-space(//*[@class="schema-address"]/text())').extract_first()
#                 if '.' in add:
#                     add = add.split('.')[0]
#                 if ',' in add:
#                     add = add.split(',')[0]
#             if add == '':
#                 add = response.xpath('normalize-space(//*[@class="blockout-ctr"]/p/text()[1])').extract_first()
#                 if '.' in add:
#                     add = add.split('.')[0]
#                 if ',' in add:
#                     add = add.split(',')[0]
#         except Exception as e:
#             add = ''
#             print(e)
#
#         try:
#             addinfo = ''.join(response.xpath('//*[@class="col-md-9 col-sm-6"]/p[1]/text()[3]').extract())
#             if addinfo == '':
#                 addinfo = response.xpath('normalize-space(//*[@class="schema-address"]/text())').extract_first()
#             if addinfo == '':
#                 addinfo = response.xpath('normalize-space(//*[@class="blockout-ctr"]/p/text()[1])').extract_first()
#             city = addinfo.split(',')[-2].strip()
#             if '2709 Main Street Santa Monica' in city:
#                 city = 'Santa Monica'
#             state = addinfo.split(' ')[-2].strip()
#             zipcode = addinfo.split(' ')[-1].strip()
#         except Exception as e:
#             city = ''
#             state = ''
#             zipcode = ''
#             print(e)
#
#         try:
#             LatLong = response.xpath('//*[@class="map"]/@href').extract_first(default='')
#
#             if LatLong != '':
#                 latitude = LatLong.split('@')[-1].split(',')[0]
#                 longitude = LatLong.split('@')[-1].split(',')[1]
#             else:
#                 latitude = ''
#                 longitude = ''
#         except:
#             latitude = ''
#             longitude = ''
#
#         try:
#             phone = response.xpath('//*[@class="blockout-ctr"]/p/span[2]/a/text()|//*[@class="blockout-ctr"]/p/a/text()').extract_first(default='')
#         except Exception as e:
#             phone = ''
#             print(e)
#
#
#         try:
#             hours = response.xpath('//*[@class="location-hours"]/div/text()').extract()
#         except Exception as e:
#             hours = ''
#             print(e)
#
#         try:
#             additional_info = response.xpath('//div[@class="chef-copy"]/p/text()').extract()
#         except Exception as e:
#             additional_info = ''
#             print(e)
#
#         try:
#             item = StoreLocatorsItem()
#             item['search_term'] = 'link'
#             item['store_name'] = sname
#             item['address'] = add
#             item['address_line_2'] = ''
#             item['state'] = state
#             item['city'] = city
#             item['zip_code'] = zipcode
#             item['latitude'] = latitude
#             item['longitude'] = longitude
#             if 'BORGATA' in phone:
#                 item['phone_number'] = ''
#             else:
#                 item['phone_number'] = phone
#             item['coming_soon'] = 0
#             item['source_url'] = response.url
#             item['store_hours'] = '|'.join(hours)
#             item['additional_info'] = '|'.join(additional_info)
#             yield item
#
#         except Exception as e:
#             print(e)
#
# from scrapy.cmdline import execute
# execute('scrapy crawl store_123 -a list_id=123'.split())

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            self.f1.set_details(self.list_id, run_date)
            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                print(search_terms)
                # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)
                search_terms = ''
                for search_term in (search_terms):
                    source_url = link = 'https://wolfgangpuck.com/'
                    file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(search_term) + '_' + str(run_date) + '.html'
                    if os.path.exists(file_path):
                        link = 'file://' + file_path.replace('\\', '/')
                    yield scrapy.FormRequest(url=str(link), callback=self.parse, meta={'source_url': source_url, 'search_term': search_term,'file_path': file_path, 'proxy_type': self.proxy_type})
            else:
                source_url = link = 'https://wolfgangpuck.com/'
                file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(run_date) + '.html'
                yield scrapy.FormRequest(url=str(link), callback=self.pages)
        except Exception as e:
            logging.log(logging.ERROR, e)


    def pages(self, response):
        Restaurants = response.xpath('//*[@id="sub_dining"]/div/div/a/@href').extract()
        bars = response.xpath('//*[@id="sub_bars"]/div/div/a/@href').extract()
        air = response.xpath('//*[@title="Airports"]/@href').extract()
        for i in Restaurants:
            if 'https' in i:
                yield scrapy.FormRequest(url=i, callback=self.Data, dont_filter=True)
            else:
                yield scrapy.FormRequest(url='https://wolfgangpuck.com/'+i, callback=self.Data, dont_filter=True)
        for i in bars:
            if 'https' in i:
                yield scrapy.FormRequest(url=i, callback=self.Data, dont_filter=True)
            else:
                yield scrapy.FormRequest(url='https://wolfgangpuck.com/' + i, callback=self.Data, dont_filter=True)


    def Data(self, response):
        global con
        con+=1
        print(con)

        item = StoreLocatorsItem()
        url = response.url

        name = 'Wolfgang puck - '+ url.split('/')[-2] #str(response.xpath('normalize-space(//*[@class="location-logo-title"]/text())').extract_first())

        item['store_location'] = str(response.xpath('normalize-space(//*[@class="location-logo-title"]/text())').extract_first()).split(',')[0]

        # T_add = response.xpath('normalize-space(//*[@class="schema-address"]/text())').extract_first()
        # if T_add == '':
        #     T_add = response.xpath('normalize-space(//*[@class="blockout-ctr"]/p/text()[1])').extract_first()
        # if T_add == '':
        #     T_add = ''.join(response.xpath('//*[@class="col-md-9 col-sm-6"]/p[1]/text()[2]').extract())
        # else:
        #     pass
        # print(T_add.split(','))

        # try:
        #     city = name.split(',')[-1].strip()
        # except Exception as e:
        #     city = ''
        #     print(e)

        try:
            add = ''.join(response.xpath('//*[@class="col-md-9 col-sm-6"]/p[1]/text()[2]').extract()).strip()
            if add == '':
                add = response.xpath('normalize-space(//*[@class="schema-address"]/text())').extract_first().strip()
                if '.' in add:
                    add = add.split('.')[0]
                if ',' in add:
                    add = add.split(',')[0]
            if add == '':
                add = response.xpath('normalize-space(//*[@class="blockout-ctr"]/p/text()[1])').extract_first().strip()
                if '.' in add:
                    add = add.split('.')[0]
                if ',' in add:
                    add = add.split(',')[0]
        except Exception as e:
            add = ''
            print(e)

        if 'No' in add:
            add = 'No. 795, Disneytown, Lane 255'
        if '800 W' in add:
            add = '800 W. Olympic Blvd'

        try:
            addinfo = ''.join(response.xpath('//*[@class="col-md-9 col-sm-6"]/p[1]/text()[3]').extract()).strip()
            if addinfo == '':
                addinfo = response.xpath('normalize-space(//*[@class="schema-address"]/text())').extract_first().strip()
            if addinfo == '':
                addinfo = response.xpath('normalize-space(//*[@class="blockout-ctr"]/p/text()[1])').extract_first().strip()
            ci = addinfo.split(',')[-2].strip()
            cit = GeoText(ci)
            city = ''.join(cit.cities)
            if 'Mim Kemal Oke Cad No 35 Nisantasi Sisli' in ci:
                city = 'Nisantasi Sisli'
            if 'Mayfair Westminster' in ci:
                city = 'Westminster'

            if 'Wolfgang puck - cut-singapore' in name:
                city = 'singapore'

            if '701 Stone Canyon Road Los Angeles' in add:
                city = 'Los Angeles'

            if 'West Bay Lagoon Doha' in add:
                city = 'Doha'

            if '3900 Wailea Alanui Maui' in add:
                city = 'Alanui Maui'

            if 'PO Box 1669 Manama' in add:
                city = 'Manama'

            if '701 Stone Canyon Road Los Angeles' in add:
                city = 'Los Angeles'

            if 'PO Box 1669 Manama' in add:
                city = 'Manama'

            if 'Tower 2 Level 57 at Marina Bay Sands' in add:
                city = 'Marina Bay Sands'

            if '10955 Oval Park Drive Las Vegas' in add:
                city = 'Las Vegas'

            if '176 North Canon Drive Beverly Hills' in add:
                city = 'Beverly Hills'

            state = addinfo.split(' ')[-2].strip()
            zipcode = re.findall(r'(\d{5})', addinfo.split(',')[-1])[0]#addinfo.split(' ')[-1].strip()
        except Exception as e:
            city = ''
            state = ''
            zipcode = ''
            print(e)

        # check = False
        # for j in ['Unit', 'STE', 'Ste', 'SUITE', 'Suite', 'suite', 'Suit', 'SUIT', 'suit', 'UNIT', 'unit', 'ste']:
        #     for aw in T_add.split():
        #         if j == aw:
        #             address1 = T_add.split(j)[0].strip().strip(',')
        #             address_line_2 = j + ' ' + T_add.split(j)[-1].strip()
        #             check = True
        #             break
        # if check == True:
        #     address_line_2 = address_line_2
        #     address = address1.strip(',')
        # else:
        #     address_line_2 = ''
        #     address = T_add.strip(',')

        try:phone = response.xpath('//*[@class="blockout-ctr"]/p/span[2]/a/text()|//*[@class="blockout-ctr"]/p/a/text()').extract_first(default='')
        except:phone = ''

        try:
            LatLong = response.xpath('//*[@class="map"]/@href').extract_first(default='')

            if LatLong != '':
                latitude = LatLong.split('@')[-1].split(',')[0]
                longitude = LatLong.split('@')[-1].split(',')[1]
            else:
                latitude = ''
                longitude = ''
        except:
            latitude = ''
            longitude = ''

        # try:
        #     if ',' in T_add:
        #         state = re.findall(r', ([A-Z]{2})', T_add)[0]
        #     else:
        #         state = ''
        # except:
        #     state = ''

        # try:zipcode = re.findall(r'(\d{5})', T_add.split(',')[-1])[0]
        # except:zipcode = ''

        # if state != '' and zipcode != '':

        # address = address.replace(zipcode,'').replace(state,'')


        try:hours = response.xpath('//*[@class="location-hours"]/div/text()').extract()
        except:hours = ''

        try:additional_info = response.xpath('//div[@class="chef-copy"]/p/text()').extract()
        except:additional_info = ''

        # if name == 'Wolfgang puck -':
        #     address = '2800 E Observatory Rd.'
        #     city = 'Los Angeles'
        #     state = 'CA'
        #     zipcode = '90027'
        #     phone = '323-661-2231'
        #
        # if '9500 Wilshire Blvd. Beverly Hills' in address:
        #     city = 'Beverly Hills'
        # if '1050 31st St NW, Washington' in address:
        #     city = 'Washington'
        # if '3333 Bristol Street Costa Mesa'  in address:
        #     city = 'Costa Mesa'
        # if '3799 Las Vegas Blvd. Las Vegas' in address:
        #     city = 'Las Vegas'
        # if '701 Stone Canyon Road Los Angeles' in address :
        #     city = 'Las Vegas'
        # if '2709 Main Street Santa Monica' in address:
        #     city = 'Santa Monica'
        if 'Wolfgang puck - culture-kitchen-seattle' in name:
            phone = '2062623030'

        if 'Wolfgang puck - griffith-cafe' in name:
            phone = '3236612231'

        try:
            item = StoreLocatorsItem()
            item['search_term'] = 'link'
            item['store_name'] = name
            item['address'] = add
            item['address_line_2'] = ''
            item['state'] = state
            item['city'] = city
            item['zip_code'] = zipcode
            item['latitude'] = latitude
            item['longitude'] = longitude
            if 'BORGATA' in phone:
                item['phone_number'] = ''
            else:
                item['phone_number'] = phone
            item['coming_soon'] = 0
            item['source_url'] = response.url
            item['store_hours'] = '|'.join(hours)
            item['additional_info'] = '|'.join(additional_info)
            yield item

        except Exception as e:
            print(e)

# from scrapy.cmdline import execute
# execute('scrapy crawl store_123 -a list_id=123'.split())


