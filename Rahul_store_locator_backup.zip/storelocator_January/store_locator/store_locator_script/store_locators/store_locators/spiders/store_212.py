import re
import urllib
from datetime import datetime
import scrapy,os,logging,hashlib
import requests,json
from lxml import html
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime
from geopy.geocoders import Nominatim


class runwithstrideSpider(scrapy.Spider):
    name = 'store_212'
    allowed_domains = []
    not_export_data = True

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.f1.set_details(self.list_id, self.run_date)


    def start_requests(self):
        source_url = link = "https://members.runwithstride.com/api/brands/stride/locations?open_status=external&geoip=45.56.160.98"
        file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
            self.run_date) + '.html'
        yield scrapy.FormRequest(url=str(link), callback=self.parse,
                                 meta={'source_url': source_url,
                                       'file_path': file_path, 'proxy_type': self.proxy_type})

    def parse(self, response):
        source_url = response.meta.get('source_url', '')
        body = json.loads(response.text)
        body1 = body['locations']
        for i in range(0, len(body1)):
            url1 = "https://www.runwithstride.com/location/" + body1[i]['site_slug']
            storename = body1[i]['name']
            address = body1[i]['address']
            address_line_2 = body1[i]['address2']
            zip_code = body1[i]['zip']
            state = body1[i]['state']
            city = body1[i]['city']
            latitude = body1[i]['lat']
            longitude = body1[i]['lng']
            country_code = body1[i]['country_code']
            email = body1[i]['email']
            phone = body1[i]['phone']
            yield scrapy.FormRequest(url="https://www.runwithstride.com/location/tustin", callback=self.get_store_list,
                                     meta={'source_url': source_url, 'proxy_type': self.proxy_type,'storename':storename,
                                           'address': address, 'zip_code': zip_code,
                                           'state': state, 'address_line_2': address_line_2, 'latitude': latitude,
                                           'longitude': longitude, 'country_code':country_code,'city':city,
                                           'email':email,'phone':phone})

    def get_store_list(self, response):
        source_url = response.meta.get('source_url', '')
        try:
            try:
                storename = response.meta['storename']
            except Exception as e:
                print("storename", e, response.url)

            try:
                address = response.meta['address']
            except Exception as e:
                print("address", e, response.url)

            try:
                address_line_2 = response.meta['address_line_2']
            except Exception as e:
                print("address_line_2", e, response.url)

            try:
                city =  response.meta['city']
            except Exception as e:
                print("city", e, response.url)

            try:
                zip_code = response.meta['zip_code']
            except Exception as e:
                print("zip_code", e, response.url)

            try:
                state = response.meta['state']
            except Exception as e:
                print("state", e, response.url)

            try:
                latitude = response.meta['latitude']
            except Exception as e:
                print("latitude", e, response.url)

            try:
                longitude = response.meta['longitude']
            except Exception as e:
                print("longitude", e, response.url)

            try:
                country_code = response.meta['country_code']
            except Exception as e:
                print("country_code", e, response.url)

            try:
                email = response.meta['email']
            except Exception as e:
                print("email", e, response.url)

            try:
                phone = response.meta['phone']
            except Exception as e:
                print("phone", e, response.url)

            try:
                store_hours = response.xpath('//*[@class="location-info-map__item"][5]/span[2]/text()').extract_first()
                if store_hours == None:
                    key = re.findall('data-hours="(.*?)" data-temp-',str(response.text).replace("&quot;",'"'),re.DOTALL)[0]
                    key = re.sub('\n|\t|\s\s+', '', key)
                    key = key.replace("{","").replace("}","")
                    key = key.replace('","',"-").replace("[","").replace("]","").replace('"',"").replace(",","|")

                    print(key)
            except Exception as e:
                print("store_hours", e, response.url)



            item = StoreLocatorsItem()
            item['search_term'] = ''
            item['store_type'] = ''
            item['store_name'] = storename
            item['address'] = address
            item['address_line_2'] = address_line_2
            item['city'] = city
            item['zip_code'] = zip_code
            item['state'] = state
            item['latitude'] = latitude
            item['longitude'] = longitude
            item['email_address'] = email
            item['phone_number'] = phone
            item['country'] = 'United States'
            item['country_code'] = country_code
            item[' store_hours'] =  store_hours
            item['source_url'] = response.url
            yield item


        except Exception as e:
            print(e)

# execute('''scrapy crawl store_212 -a list_id=212'''.split())