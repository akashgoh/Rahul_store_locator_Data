# todo: add sub offices , with existing JS extraction , remaining is the mapping of the store hours , main office : profile hours , sub ofiice seprate hours
# -*- coding: utf-8 -*-
import scrapy
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import usaddress
import json
from pprint import pprint as pp

from datetime import datetime
from scrapy.cmdline import execute
import re


class Store20Spider(scrapy.Spider):
    name = 'store_20'
    allowed_domains = []
    start_urls = ['http://amfam.com/']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id = list_id
        self.f1 = Func()

    def start_requests(self):
        run_date = str(datetime.today()).split()[0]
        self.f1.set_details(self.list_id, run_date)
        sitemap_url = 'https://agent.amfam.com/sitemap.xml'
        yield scrapy.FormRequest(url=sitemap_url, callback=self.get_agent_links)

    def get_agent_links(self, response):
        # test_url = "https://agent.amfam.com/teresa-zucchini-mcclish/mo/springfield/3050-e-battlefield-st/"
        # 'https://ssg.amfam.com/producer/v1/locateagents?searchBy=Location&zip5=65804&useGoogleAPI=true&getExternalId=true'
        # yield scrapy.FormRequest(url=test_url, callback=self.get_agent_info)

        not_include_list = ['/about-me/', '/about-the-team/', '/contact-us/', '/events/', '/insurance/',
                            '/stories-and-articles/', '/google']

        sitemap_links = re.findall(r'<loc>(.*?)</loc>', response.body.decode('utf8'))
        for sitemap_link in sitemap_links:
            print(sitemap_link)
            if not any(ni in sitemap_link for ni in not_include_list):
                yield scrapy.FormRequest(url=sitemap_link, callback=self.get_agent_info)

    def get_agent_details(self,response):
        try:
            item = StoreLocatorsItem()
            js_cont = response.xpath('//script[7]/text()').get()


            def get_store_hour():
                jsc = js_cont.split('window.JSContext =')[1].strip().strip(';')
                if 'office_hours_structured' in jsc:
                    lscl = json.loads(jsc)
                    profile = lscl.get('profile','')
                    if profile:
                        office_hours_structured = profile.get('office_hours_structured','')
                        if office_hours_structured:
                            ohour = office_hours_structured.get('days','')
                            if ohour:
                                store_hours = list()
                                for o in ohour.items():
                                    day = o[0]
                                    open_hr = o[1][0]['open']
                                    open_hr = datetime.strptime(open_hr, "%H:%M")
                                    open_hr = open_hr.strftime("%I:%M %p")
                                    close_hr = o[1][0]['close']
                                    close_hr = datetime.strptime(close_hr, "%H:%M")
                                    close_hr = close_hr.strftime("%I:%M %p")
                                    store_hours.append(f"{day} : {open_hr}-{close_hr}")
                                store_hours = '|'.join(store_hours)
                                return store_hours
                else:
                    return ''

            def get_data_from_js(sp_value):
                if sp_value in js_cont:
                    return js_cont.split(sp_value)[1].split('"')[0]

            item['store_name'] = get_data_from_js('"agency_name": "')
            add_info = dict()
            add_info['desc'] = get_data_from_js('"agent_description": "')
            address = item['address'] = get_data_from_js('"street": "')
            address_split_params = ('unit ', 'suit ', 'ste ', 'suite ', 'units ', 'ste. ')
            for address_split_param in address_split_params:
                if address_split_param in (item['address'].lower()):
                    item['address'] = (item['address'].lower()).split(address_split_param)[0]
                    item['address_line_2'] = f"{address_split_param} {((address.lower()).split(address_split_param)[1])}"
                    break

            item['city'] = get_data_from_js('"city": "')
            item['state'] = get_data_from_js('"state": "')
            item['zip_code'] = get_data_from_js('"zip_code": "')
            if len(item['zip_code']) > 5 and ('-' not  in  item['zip_code']):
                item['zip_code'] = f"{item['zip_code'][:5]}-{item['zip_code'][5:]}"
            try:
                item['latitude'], item['longitude'] =  js_cont.split('"latlng": [')[1].split(']')[0].split(',')
            except Exception as e:
                print('During lat lng ',e)

            item['phone_number'] = get_data_from_js('"phone": "')
            item['fax_number'] = get_data_from_js('"fax": "')
            services = set()
            if len(js_cont.split('"amfam_products": ["')) > 1:
                for prod in js_cont.split('"amfam_products": ["')[1:]:
                    services.add(prod.split('"')[0])
            item['services'] = '|'.join(services)
            try:
                item['store_hours'] = get_data_from_js('"office_hours": "')
                if not item['store_hours']:
                    item['store_hours'] = get_store_hour()
                if item['store_hours']:
                    item['store_hours'] = item['store_hours'].replace('\\n\\', '|')
            except Exception as e:
                print(e)
            item['country'],item['country_code'] = 'USA','US'
            source_url = response.meta.get('source_url','')
            item['source_url'] = source_url if source_url else response.url
            if item['country_code'] == 'US' and len(item['state']) > 2:
             item['state'] = self.f1.state_dict.get((item['state'].lower()), '')
            item['additional_info'] = json.dumps(add_info, ensure_ascii=False)
            yield item
        except Exception as e:
            print('During get_agent_details :',e )

    def get_agent_info(self, response):
        try:
            script_text = response.xpath('//script[7]/text()').get(default='')
            script_content = script_text.split('window.JSContext =')[1].strip().strip(';')
            json_data = json.loads(script_content)
            print(json_data)
            profile_data = json_data.get('profile')
            item = StoreLocatorsItem()
            item['store_name'] = profile_data.get('agency_name', '')
            add_info = dict()
            add_info['desc'] = profile_data.get('agent_description', '')

            address = item['address'] = profile_data.get('address', {}).get('street')
            address_split_params = ('unit ', 'suit ', 'ste ', 'suite ', 'units ', 'ste. ')
            for address_split_param in address_split_params:
                if address_split_param in (item['address'].lower()):
                    item['address'] = (item['address'].lower()).split(address_split_param)[0]
                    item['address_line_2'] = f"{address_split_param} {((address.lower()).split(address_split_param)[1])}"
                    break

            item['city'] = profile_data.get('address', {}).get('city', '')
            item['state'] = profile_data.get('address', {}).get('state', '')
            item['zip_code'] = profile_data.get('address', {}).get('zip_code', '')
            item['phone_number'] = profile_data.get('phones',{}).get('phone','')
            item['fax_number'] = profile_data.get('phones',{}).get('fax','')
            services = set()
            if len(script_text.split('"amfam_products": ["')) > 1:
                for prod in script_text.split('"amfam_products": ["')[1:]:
                    services.add(prod.split('"')[0])
            item['services'] = '|'.join(services)

            hours = profile_data.get('office_hours_structured', {}).get('days', {})
            store_hours = list()
            for hour in hours.items():
                store_hour = f"{hour[0]} : {self.convert_time(hour[1][0].get('open'))} to {self.convert_time(hour[1][0].get('close'))}"
                store_hours.append(store_hour)
            item['store_hours'] = '|'.join(store_hours)

            item['country'], item['country_code'] = 'USA', 'US'
            item['source_url'] = response.url
            if item['country_code'] == 'US' and len(item['state']) > 2:
                item['state'] = self.f1.state_dict.get((item['state'].lower()), '')
            item['additional_info'] = json.dumps(add_info, ensure_ascii=False)
            try:
                item['latitude'], item['longitude'] = profile_data.get('latlng',[0,0])
            except Exception as e:
                item['latitude'], item['longitude'] = [0,0]
                print(e)
            yield item

            for sub_office in profile_data.get('suboffices',[]):
                item['address'] = sub_office.get('street')
                item['address_line_2'] = sub_office.get('suite')
                item['state'] = sub_office.get('state')
                item['city'] = sub_office.get('city')
                item['zip_code'] = sub_office.get('zip_code')
                item['phone_number'] = sub_office.get('phone')
                item['fax_number'] = sub_office.get('fax')
                hours = sub_office.get('office_hours_structured', {}).get('days', {})
                store_hours = list()
                for hour in hours.items():
                    store_hour = f"{hour[0]} : {self.convert_time(hour[1][0].get('open', ''))} to {self.convert_time(hour[1][0].get('close', ''))}"
                    store_hours.append(store_hour)
                item['store_hours'] = '|'.join(store_hours)
                try:
                    item['latitude'], item['longitude'] = profile_data.get('latlon_fields', {}).get('suboffices', {})[0].split(',')
                except Exception as e:
                    item['latitude'], item['longitude'] = 0,0
                yield item
        except Exception as e:
            print(e)

    def convert_time(self, time_str):
        try:
            if time_str:
                d = datetime.strptime(time_str, "%H:%M")
                return d.strftime("%I:%M %p")
            else:
                return time_str
        except Exception as e:
            print(e)
#
# execute('scrapy crawl store_20 -a list_id=20'.split())
