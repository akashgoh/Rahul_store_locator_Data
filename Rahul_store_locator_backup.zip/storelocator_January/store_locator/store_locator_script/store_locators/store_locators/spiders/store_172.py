# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import re
import scrapy, os, logging, hashlib
import requests, json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime


class Store172Spider(scrapy.Spider):
    name = 'store_172'
    allowed_domains = []
    start_urls = ['https://media.timken.com/DistributorLocator/index.aspx']
    not_export_data = False
    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]

    def parse(self, response):
        try:
            self.f1.set_details(self.list_id, self.run_date)
            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                print(len(search_terms))
                # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)
                VIEWSTATE = response.xpath('//*[@name="__VIEWSTATE"]/@value').extract_first()
                VIEWSTATEGENERATOR = response.xpath('//*[@name="__VIEWSTATEGENERATOR"]/@value').extract_first()
                EVENTVALIDATION = response.xpath('//*[@name="__EVENTVALIDATION"]/@value').extract_first()
                country_code = ['244', '39']#244
                for code in country_code:
                    data = {"__EVENTTARGET": "searchBy$0",
                            "__EVENTARGUMENT": '',
                            "__LASTFOCUS:": '',
                            "__VIEWSTATE": VIEWSTATE,
                            "__VIEWSTATEGENERATOR": VIEWSTATEGENERATOR,
                            "__EVENTVALIDATION": EVENTVALIDATION,
                            "hdnLocation": '',
                            "hdnLocationMarks": '',
                            "hdnRadius": '',
                            "hdnDestination": '',
                            "searchBy": "DIST",
                            "regionDropdown": code,
                            "IndustryDropdown": "",
                            "addressBox": "",
                            "cityBox": "",
                            "stateBox": "",
                            "zipBox": "",
                            "radiusDropdown": "25"
                            }
                    header = {
                        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
                        "Accept-Encoding": "gzip, deflate, br",
                        "Accept-Language": "en-US,en;q=0.9",
                        "Cache-Control": "max-age=0",
                        "Connection": "keep-alive",
                        "Content-Type": "application/x-www-form-urlencoded",
                        "Host": "media.timken.com",
                        "cookie": "_gcl_au=1.1.722552407.1571477897; _ga=GA1.2.1197587919.1571477897; _gid=GA1.2.821507405.1571725033",
                        "Origin": "https://media.timken.com",
                        "Referer": "https://media.timken.com/DistributorLocator/index.aspx?Culture=en",
                        "Sec-Fetch-Mode": "navigate",
                        "Sec-Fetch-Site": "same-origin",
                        "Sec-Fetch-User": "?1",
                        "Upgrade-Insecure-Requests": "1",
                        "User-Agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537.36"}
                    source_url = link = 'https://media.timken.com/DistributorLocator/index.aspx?Culture=en'

                    yield scrapy.FormRequest(url=str(link), callback=self.firstlevel, method="POST", formdata=data, headers=header,
                                             meta={'source_url': source_url, 'search_terms': search_terms, 'country_code': code,
                                                   'proxy_type': self.proxy_type})
        except Exception as e:
            logging.log(logging.ERROR, e)

    def firstlevel(self, response):
        try:
            search_terms = response.meta['search_terms']
            source_url = response.meta['source_url']
            proxy_type = response.meta['proxy_type']
            country_code = response.meta['country_code']
            Dropedown = ['INDBSPT', 'AUTOLTAFT', 'COMMVEHAFT']
            VIEWSTATE = response.xpath('//*[@name="__VIEWSTATE"]/@value').extract_first()
            VIEWSTATEGENERATOR = response.xpath('//*[@name="__VIEWSTATEGENERATOR"]/@value').extract_first()
            EVENTVALIDATION = response.xpath('//*[@name="__EVENTVALIDATION"]/@value').extract_first()
            for code in Dropedown:
                data = {"__EVENTTARGET": "IndustryDropdown",
                        "__EVENTARGUMENT": '',
                        "__LASTFOCUS:": '',
                        "__VIEWSTATE": VIEWSTATE,
                        "__VIEWSTATEGENERATOR": VIEWSTATEGENERATOR,
                        "__EVENTVALIDATION": EVENTVALIDATION,
                        "hdnLocation": '',
                        "hdnLocationMarks": '',
                        "hdnRadius": '',
                        "hdnDestination": '',
                        "searchBy": "DIST",
                        "regionDropdown": country_code,
                        "IndustryDropdown": code,
                        "addressBox": "",
                        "cityBox": "",
                        "stateBox": "",
                        "zipBox": "",
                        "radiusDropdown": "25"
                        }
                header = {"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
                          "Accept-Encoding": "gzip, deflate, br",
                          "Accept-Language": "en-US,en;q=0.9",
                          "Cache-Control": "max-age=0",
                          "Connection": "keep-alive",
                          "Content-Type": "application/x-www-form-urlencoded",
                          "Host": "media.timken.com",
                          "cookie": "_gcl_au=1.1.722552407.1571477897; _ga=GA1.2.1197587919.1571477897; _gid=GA1.2.821507405.1571725033",
                          "Origin": "https://media.timken.com",
                          "Referer": "https://media.timken.com/DistributorLocator/index.aspx?Culture=en",
                          "Sec-Fetch-Mode": "navigate",
                          "Sec-Fetch-Site": "same-origin",
                          "Sec-Fetch-User": "?1",
                          "Upgrade-Insecure-Requests": "1",
                          "User-Agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537.36"}
                yield scrapy.FormRequest(url='https://media.timken.com/DistributorLocator/index.aspx?Culture=en', callback=self.get_store_data, method="POST", formdata=data, headers=header,
                                         meta={'source_url': source_url, 'dropdown_code': code, 'search_terms': search_terms,
                                               'proxy_type': proxy_type, 'country_code': country_code})
        except Exception as e:
            print("firstlevel", e, response.url)
    def get_store_data(self, response):
        country_code = response.meta['country_code']
        search_terms = response.meta['search_terms']
        dropdown_code = response.meta['dropdown_code']
        source_url = response.meta['source_url']
        proxy_type = response.meta['proxy_type']
        VIEWSTATE = response.xpath('//*[@name="__VIEWSTATE"]/@value').extract_first()
        VIEWSTATEGENERATOR = response.xpath('//*[@name="__VIEWSTATEGENERATOR"]/@value').extract_first()
        EVENTVALIDATION = response.xpath('//*[@name="__EVENTVALIDATION"]/@value').extract_first()
        for code in search_terms:
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(code) + '_' + str(self.run_date) + '.html'
            if code.strip():
                if len(code) == 4:
                    code = '0' + code
                data = {"__EVENTTARGET": "",
                        "__EVENTARGUMENT": '',
                        "__LASTFOCUS:": '',
                        "__VIEWSTATE": VIEWSTATE,
                        "__VIEWSTATEGENERATOR": VIEWSTATEGENERATOR,
                        "__EVENTVALIDATION": EVENTVALIDATION,
                        "hdnLocation": '',
                        "hdnLocationMarks": '',
                        "hdnRadius": '',
                        "hdnDestination": '',
                        "searchBy": "DIST",
                        "regionDropdown": country_code,
                        "IndustryDropdown": dropdown_code,
                        "addressBox": "",
                        "cityBox": "",
                        "stateBox": "",
                        "zipBox": code,
                        "radiusDropdown": "25",
                        "btnSearch.x": "0",
                        "btnSearch.y": "0"}
                header = {
                    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
                    "Accept-Encoding": "gzip, deflate, br",
                    "Accept-Language": "en-US,en;q=0.9",
                    "Cache-Control": "max-age=0",
                    "Connection": "keep-alive",
                    "Content-Type": "application/x-www-form-urlencoded",
                    "cookie": "_gcl_au=1.1.722552407.1571477897; _ga=GA1.2.1197587919.1571477897; _gid=GA1.2.821507405.1571725033",
                    "Host": "media.timken.com",
                    "Origin": "https://media.timken.com",
                    "Referer": "https://media.timken.com/DistributorLocator/index.aspx?Culture=en",
                    "Sec-Fetch-Mode": "navigate",
                    "Sec-Fetch-Site": "same-origin",
                    "Sec-Fetch-User": "?1",
                    "Upgrade-Insecure-Requests": "1",
                    "User-Agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537.36"}
                yield scrapy.FormRequest(url='https://media.timken.com/DistributorLocator/index.aspx?Culture=en',
                                         callback=self.get_store_list, method="POST", formdata=data, headers=header,
                                         meta={'source_url': source_url, 'dropdown_code': code,
                                               'search_terms': search_terms,
                                               'proxy_type': proxy_type, 'country_code': country_code,
                                               'file_path': file_path})

    # Get data from the response
    def get_store_list(self, response):
        try:
            if not response.url.startswith('file://'):
                self.f1.page_save(response.meta['file_path'], response.body)
            search_term = response.meta.get('search_term', '')
            try:
                item = StoreLocatorsItem()
                store_data = response.xpath('//*[@id="searchResultsDL"]//tr/td')
                for data in store_data:
                    try:
                        store_name = data.xpath('normalize-space(.//b/a/text())').extract_first(default='')
                        phone_number = data.xpath('normalize-space(.//*[contains(text(),"Phone:")]/text())').extract_first(default='')
                        if phone_number:
                            phone_number = phone_number.split(':')[-1].strip()
                        else:
                            phone_number = ''
                        try:
                            fax_number = '|'.join(data.xpath('.//span/text()').extract())#.split(':')[-1].strip()
                            if 'Fax' in fax_number:
                                if 'Website' in fax_number:
                                    fax_number = re.findall(r'Fax:(.*?)\|', fax_number)[0].strip()
                                else:
                                    fax_number = re.findall(r'Fax:(.*?)$', fax_number)[0].strip()
                            else:
                                fax_number = ''
                        except Exception as e:
                            print(e)
                        # if '/' in phone_number:
                        #     phone_number = phone_number.split('/')[0].strip()
                        # if ',' in phone_number:
                        #     phone_number = phone_number.split(',')[0].strip()
                        try:
                            add = '|'.join(data.xpath('./text()').extract()).strip().replace('\r','').replace('\n','').replace('  ','').strip('|').split('|')
                            if len(add) == 2:
                                address_detail = address = add[0].strip()
                                address_line_2 = ''
                                for i in ['Unit', 'STE', 'Ste','SUITE','Suite','suite','Suit','SUIT','suit','UNIT','unit','ste']:
                                    for aw in address_detail.split(' '):
                                        if i == aw:
                                            if address_detail.split(' ').index(aw) != 0:
                                                address = address_detail.split(i)[0].strip()
                                                address_line_2 = i + ' ' + address_detail.split(i)[-1].strip()
                                                break
                                city = add[1].strip().split(',')[0].strip()
                                country = add[-1].strip().split(',')[-1].strip()
                                if country == 'USA':
                                    country = 'US'

                                if country == 'CA':
                                    state = add[1].strip().split(',')[1].strip().split(' ')[0].strip()
                                    zip_code = ' '.join(add[1].strip().split(',')[1].strip().split(' ')[1:]).strip()
                                else:
                                    state = add[1].strip().split(',')[1].strip().split(' ')[0].strip()
                                    zip_code = add[1].strip().split(',')[1].strip().split(' ')[-1].strip()
                            else:
                                address_detail = address = add[0].strip() + ' ' + add[1].strip()
                                address_line_2 = ''
                                for i in ['Unit', 'STE', 'Ste','SUITE','Suite','suite','Suit','SUIT','suit','UNIT','unit','ste']:
                                    for aw in address_detail.split(' '):
                                        if i == aw:
                                            if address_detail.split(' ').index(aw) != 0:
                                                address = address_detail.split(i)[0].strip()
                                                address_line_2 = i + ' ' + address_detail.split(i)[-1].strip()
                                                break
                                city = add[2].strip().split(',')[0].strip()
                                country = add[-1].strip().split(',')[-1].strip()
                                if country == 'USA':
                                    country = 'US'

                                if country == 'CA':
                                    state = add[2].strip().split(',')[1].strip().split(' ')[0].strip()
                                    zip_code = ' '.join(add[2].strip().split(',')[1].strip().split(' ')[1:]).strip()
                                else:
                                    state = add[2].strip().split(',')[1].strip().split(' ')[0].strip()
                                    zip_code = add[2].strip().split(',')[1].strip().split(' ')[-1].strip()
                        except Exception as e:
                            print(e)
                        try:
                            website_address = data.xpath('.//span//a/@href').extract_first(default='')
                        except Exception as e:
                            website_address = ''
                        if store_name:
                            if (country == 'US') or (country == 'CA'):
                                item['search_term'] = search_term
                                item['store_name'] = store_name
                                item['address'] = address.strip()
                                item['address_line_2'] = address_line_2
                                item['city'] = city
                                item['state'] = state
                                item['zip_code'] = zip_code
                                item['phone_number'] = phone_number
                                item['fax_number'] = fax_number
                                item['website_address'] = website_address
                                item['store_type'] = ''
                                item['coming_soon'] = 0
                                item['source_url'] = 'https://www.timken.com/locations/'
                                item['country_code'] = item['country'] = country  # self.f1.country_dict.get(item['country'].lower())
                                if item['country_code'] == 'US' and len(item['state']) > 2:
                                    item['state'] = self.f1.state_dict.get(state, '')
                                yield item
                    except Exception as e:
                        print(e)
            except Exception as e:
                print(e)
        except Exception as e:
            logging.log(logging.ERROR, e)

    def response_html_path(self, request):
        return request.meta['fpath']

if __name__ == '__main__':
    execute('''scrapy crawl store_172 -a list_id=172 -a proxy_type='''.split())