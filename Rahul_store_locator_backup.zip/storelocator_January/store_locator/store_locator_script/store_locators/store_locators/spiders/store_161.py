# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import re

import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime
from selenium import webdriver                    # Import module
from selenium.webdriver.common.keys import Keys   # For keyboard keys
import time                                       # Waiting function

from scrapy.http import HtmlResponse, JSONRequest

class truevaluehardwareSpider(scrapy.Spider):
    name = 'store_161'
    allowed_domains = []
    not_export_data=True

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):

        try:

            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                print(search_terms)
            # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)
                search_terms = ''
                for search_term in (search_terms):
                    source_url = link = 'https://stretchlab.com/locations/'
                    file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(search_term) + '_' + str(self.run_date) + '.html'
                    if os.path.exists(file_path):
                        link = 'file://' + file_path.replace('\\','/')
                    yield scrapy.FormRequest(url=str(link), callback=self.get_store_list, meta={'source_url': source_url,'search_term': search_term,'file_path':file_path,'proxy_type': self.proxy_type})
            else:
                source_url = link = "https://www.mitre10.com.au/locator"
                file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
                        self.run_date) + '.html'
                yield scrapy.FormRequest(url=str(link), callback=self.parse,
                                             meta={'source_url': source_url,
                                                   'file_path': file_path, 'proxy_type': self.proxy_type})

        except Exception as e:
            logging.log(logging.ERROR, e)


    def parse(self, response):
        try:
            file_path = response.meta['file_path']
            pagesrc = response.xpath('//div[@id="store-locator-search-wrapper"]/following-sibling::script/text()').extract_first()
            store_data = json.loads(pagesrc)
            store_data = store_data['*']['Magento_Ui/js/core/app']['components']['store-locator-search']['markers']
            le = len(store_data)
            for i in range(0,le):
                try:
                    storeurl = store_data[i]['url']
                except Exception as e:
                    print("storeurl",e,response.url)

                try:
                    store_name = store_data[i]['name']
                except Exception as e:
                    print("storename", e, response.url)

                try:
                    addressfull = store_data[i]['address'].split(",")
                except Exception as e:
                    print("addressfull", e, response.url)

                try:
                    address = addressfull[0].strip()
                except Exception as e:
                    print("address", e, response.url)

                try:
                    city = addressfull[1].strip()
                except Exception as e:
                    print("city", e, response.url)

                try:
                    postcode = addressfull[2].strip()
                except Exception as e:
                    print("postcode", e, response.url)

                try:
                    latitude = store_data[i]['latitude']
                    longitude = store_data[i]['longitude']
                except Exception as e:
                    print("latlong", e, response.url)

                try:
                    phone_number = store_data[i]['contact_phone']
                except Exception as e:
                    print("phone",e,response.url)

                try:

                    Sunday =store_data[i]['schedule']['openingHours'][0][0]['start_time'] + "-" +store_data[i]['schedule']['openingHours'][0][0]['end_time']
                    Monday = store_data[i]['schedule']['openingHours'][1][0]['start_time'] + "-" +store_data[i]['schedule']['openingHours'][1][0]['end_time']

                    Tuesday = store_data[i]['schedule']['openingHours'][2][0]['start_time'] + "-" +store_data[i]['schedule']['openingHours'][2][0]['end_time']
                    Wednesday = store_data[i]['schedule']['openingHours'][3][0]['start_time'] + "-" +store_data[i]['schedule']['openingHours'][3][0]['end_time']
                    Thursday = store_data[i]['schedule']['openingHours'][4][0]['start_time'] + "-" +store_data[i]['schedule']['openingHours'][4][0]['end_time']
                    Friday = store_data[i]['schedule']['openingHours'][5][0]['start_time'] + "-" +store_data[i]['schedule']['openingHours'][5][0]['end_time']
                    Saturday = store_data[i]['schedule']['openingHours'][6][0]['start_time'] + "-" +store_data[i]['schedule']['openingHours'][6][0]['end_time']

                    pair = "Monday --> "+Monday+"|"+"Tuesday --> "+Tuesday+"|"+"Wednesday --> "+Wednesday+"|"+"Thursday --> "+Thursday+"|"+"Friday --> "+Friday+"|"+"Saturday --> "+Saturday+"|"+"Sunday --> "+Sunday
                    store_hours = pair.replace('12:00 am-12:00 am','Closed')
                except Exception as e:
                    print("storehours",e,response.url)
                additional_info = {}
                item = StoreLocatorsItem()
                item['search_term'] = ''
                item['store_name'] = store_name
                item['address'] = address
                item['address_line_2'] = ''
                item['city'] = city
                item['state'] = ''
                item['zip_code'] = postcode
                item['phone_number'] = phone_number
                item['fax_number'] = ''
                item['latitude'] = latitude
                item['longitude'] = longitude
                item['store_type'] = ''
                item['website_address'] = ''
                item['coming_soon'] = 0
                item['store_number'] = ''
                item['country_code'] = item['country'] = 'AU'  # self.f1.country_dict.get(item['country'].lower())
                item['email_address'] = ''
                item['services'] = ''
                item['source_url'] = storeurl
                item['store_hours'] = store_hours
                item['additional_info'] = json.dumps(additional_info, ensure_ascii=False)

                yield item

                # yield scrapy.FormRequest(url=storeurl, callback=self.get_store_list,meta={'file_path': file_path,'phone':phone,'storename'
                # :storename,'address1':address1,'address2':address2,'lat':lat,'lng':lng,'storehours':storehours,'city':city,'postcode':postcode})

        except Exception as e:
            print("parse",e,storeurl)

    #
    # def get_store_list(self, response):
    #     try:
    #         if not response.url.startswith('file://'):
    #             self.f1.page_save(response.meta['file_path'],response.body)
    #
    #         try:
    #             search_term = response.meta.get('search_term', '')
    #             try:
    #                 store_name = response.meta['storename']
    #             except Exception as e:
    #                 print("store_name",e,response.url)
    #
    #             try:
    #                 address =  response.meta['address1']
    #             except Exception as e:
    #                 print("address1", e, response.url)
    #
    #             try:
    #                 address_line_2 = response.meta['address2']
    #             except Exception as e:
    #                 print("address_line_2", e, response.url)
    #
    #             try:
    #                 city =  response.meta['city']
    #             except Exception as e:
    #                 print("city", e, response.url)
    #
    #             try:
    #                 latitude =   response.meta['lat']
    #                 longitude =  response.meta['lng']
    #             except Exception as e:
    #                 print("latitude and longitude", e, response.url)
    #
    #             try:
    #                 phone_number =  response.meta['phone']
    #             except Exception as e:
    #                 print("phonenumber", e, response.url)
    #
    #             try:
    #                 postcode = response.meta['postcode']
    #             except Exception as e:
    #                 print("postcode",e,response.url)
    #
    #             try:
    #                 store_hours = response.meta['storehours']
    #             except Exception as e:
    #                 print("store_hours",e,response.url)
    #
    #             try:
    #                 additional_info = {}
    #             except Exception as e:
    #                 print("additionalinfo",response.url,e)
    #
    #             try:
    #                 services ='|'.join(response.xpath('//*[contains(text(),"Specialist Services")]/following-sibling::ul//div[@class="service-text"]/label/text()').extract())
    #             except Exception as e:
    #                 print("services",e,response.url)
    #
    #             try:
    #                 fax_number = response.xpath('//*[contains(text(),"Fax:")]/following-sibling::a/text()').extract_first()
    #                 if fax_number == None:
    #                     fax_number = ''
    #                 else:
    #                     fax_number = fax_number.strip()
    #
    #             except Exception as e:
    #                 print("faxnumber",e,response.url)
    #
    #             item = StoreLocatorsItem()
    #             item['search_term'] = search_term
    #             item['store_name']= store_name
    #             item['address'] = address
    #             item['address_line_2'] = address_line_2
    #             item['city'] = city
    #             item['state'] =''
    #             item['zip_code'] = postcode
    #             item['phone_number'] =phone_number
    #             item['fax_number'] = fax_number
    #             item['latitude'] = latitude
    #             item['longitude'] = longitude
    #             item['store_type'] = ''
    #             item['website_address'] = ''
    #             item['coming_soon'] = 0
    #             item['store_number'] = ''
    #             item['country_code'] = item['country'] = 'AU' #self.f1.country_dict.get(item['country'].lower())
    #             item['email_address'] = ''
    #             item['services'] = services
    #             item['source_url']=response.url
    #             item['store_hours'] = store_hours
    #             item['additional_info'] = json.dumps(additional_info,ensure_ascii=False)
    #
    #             yield item
    #         except Exception as e:
    #             print("truevalue",e,response.url)
    #
    #     except Exception as e:
    #         logging.log(logging.ERROR, e)

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_161 -a list_id=161'''.split())
