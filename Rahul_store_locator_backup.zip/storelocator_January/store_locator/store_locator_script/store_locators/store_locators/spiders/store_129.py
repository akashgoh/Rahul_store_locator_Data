# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import random
import re


import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime

class Store129Spider(scrapy.Spider):
    name = 'store_129'
    allowed_domains = []


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()


    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            self.f1.set_details(self.list_id,run_date)
            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                print(search_terms)
            # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)
                search_terms = ''
                for search_term in (search_terms):
                    source_url = link = 'https://www.cw-industrialgroup.com/About/Facilities.aspx'
                    file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(search_term) + '_' + str(run_date) + '.html'
                    if os.path.exists(file_path):
                        link = 'file://' + file_path.replace('\\','/')
                    yield scrapy.FormRequest(url=str(link), callback=self.data,
                                             meta={'source_url': source_url,'search_term': search_term,'file_path':file_path,'proxy_type': self.proxy_type})
            else:
                source_url = link = 'https://www.cw-industrialgroup.com/About/Facilities.aspx'
                file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(run_date) + '.html'
                yield scrapy.FormRequest(url=str(link), callback=self.data,
                                         meta={'source_url': source_url,'file_path': file_path, 'proxy_type': self.proxy_type})

                headers = {
                    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
                    "accept-encoding": "gzip, deflate, br",
                    "accept-language": "en-US,en;q=0.9",
                    "cache-control": "max-age=0",
                    "sec-fetch-mode": "navigate",
                    "sec-fetch-site": "none",
                    "sec-fetch-user": "?1",
                    "upgrade-insecure-requests": "1",
                    "user-agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537.36"
                }

                source_url1 = link1 = 'https://www.cw-industrialgroup.com/Contact/Distributors.aspx'
                file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(run_date) + '.html'
                yield scrapy.FormRequest(url=str(link1), callback=self.data1, headers=headers,
                                         meta={'source_url': source_url1, 'file_path': file_path,'proxy_type': self.proxy_type})
        except Exception as e:
            logging.log(logging.ERROR, e)


    def data(self, response):
        text1 = response.text
        text = text1.split('<h2>NORTH AMERICA</h2>')[-1]
        divs = re.findall(r'<p>(.*?)</p>', text, re.DOTALL)

        for div in divs:
            try:store_name = re.findall(r'<strong>(.*?)</strong>', div)[0].replace('&ndash;','-').replace('&amp;','&').strip()
            except Exception as e:print(e)

            try:
                add = re.findall(r'<br />(.*?)<br />', div, re.DOTALL)[0].replace('&nbsp;','').strip()
                address = str(add.split(',')[0]) + ', ' + str(add.split(',')[1])
            except Exception as e:
                print(e)

            try:phone_number = ''.join(re.findall(r"T: (\+.*)|T: (.*?)<br />", div)[0]).replace('&nbsp;','').strip()
            except Exception as e:print(e)

            try:email_address = re.findall(r'href="mailto:(.*?)"', div)[0].strip()
            except:email_address = ''

            try:
                country = add.split(',')[-1]
                zip = re.findall(r'\d+', country)[0]
                if zip != '':
                    country = country.replace(zip,'').strip()
            except:
                country = country.replace('&rsquo;','').strip()

            try:
                zipcode = ''.join(re.findall(r'(\d{5,6}-?\d?\d?\d?)|(\d{3} \d{3})', add)[0])
                if zipcode == '14100':
                    zipcode = '97224'
            except:
                zipcode = 'BH23 6HH'

            item = StoreLocatorsItem()
            item['search_term'] = 'link'
            item['store_name'] = store_name
            item['address'] = address
            item['city'] = ''
            item['state'] = ''
            item['zip_code'] = zipcode
            item['phone_number'] = phone_number
            item['email_address'] = email_address
            item['services'] = ''
            item['coming_soon'] = 0
            item['country'] = country
            item['country_code'] = '' # self.f1.country_dict.get(item['country'].lower())
            item['store_hours'] = ''
            item['source_url'] = response.url
    #
    #         if email_address != '':
    #             yield item


    def data1(self, response):
        # try:event_target = response.xpath('//*[@id="__EVENTTARGET"]/@value').extract_first(default='')
        # except Exception as e:print(e)

        try:event_argument = response.xpath('//*[@id="__EVENTARGUMENT"]/@value').extract_first(default='')
        except Exception as e:print(e)

        try:last_focus = response.xpath('//*[@id="__LASTFOCUS"]/@value').extract_first(default='')
        except Exception as e:print(e)

        try:view_state_generator = response.xpath('//*[@id="__VIEWSTATEGENERATOR"]/@value').extract_first(default='')
        except Exception as e:print(e)

        try:scroll_position_x = response.xpath('//*[@id="__SCROLLPOSITIONX"]/@value').extract_first(default='')
        except Exception as e:print(e)

        # try:scroll_position_y = response.xpath('//*[@id="__SCROLLPOSITIONY"]/@value').extract_first(default='')
        # except Exception as e:print(e)

        try:view_state = response.xpath('//*[@id="__VIEWSTATE"]/@value').extract_first(default='')
        except Exception as e:print(e)

        headers = {
            "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
            "accept-encoding": "gzip, deflate, br",
            "accept-language": "en-US,en;q=0.9",
            "cache-control": "max-age=0",
            "content-type": "application/x-www-form-urlencoded",
            "origin": "https://www.cw-industrialgroup.com",
            "referer": "https://www.cw-industrialgroup.com/Contact/Distributors.aspx",
            "sec-fetch-mode": "navigate",
            "sec-fetch-site": "same-origin",
            "sec-fetch-user": "?1",
            "upgrade-insecure-requests": "1",
            "user-agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537.36"
        }

        formdata = {
            "manScript_HiddenField": ";;AjaxControlToolkit, Version=4.1.60919.0, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e:en-US:ee051b62-9cd6-49a5-87bb-93c07bc43d63:475a4ef5:effe2a26:7e63a579",
            "__EVENTTARGET": 'p$lt$ctl05$pageplaceholder$p$lt$ctl03$Filter$filterControl$drpProductFamily',
            "__EVENTARGUMENT": str(event_argument),
            "__LASTFOCUS": str(last_focus),
            "lng": "en-US",
            "__VIEWSTATEGENERATOR": str(view_state_generator),
            "__SCROLLPOSITIONX": str(scroll_position_x),
            "__SCROLLPOSITIONY": '200',
            "p$lt$ctl00$SearchBox$txtWord_exWatermark_ClientState": "",
            "p$lt$ctl00$SearchBox$txtWord": "",
            "p$lt$ctl04$MobileSearchBox$txtWord_exWatermark_ClientState": "",
            "p$lt$ctl04$MobileSearchBox$txtWord": "",
            "p$lt$ctl05$pageplaceholder$p$lt$ctl03$Filter$filterControl$drpProductFamily": "Electronic Throttle Controls",
            "p$lt$ctl05$pageplaceholder$p$lt$ctl03$Filter$filterControl$drpCountry": "##ALLCOUNTRIES##",
            "NwsListID": "57c2952d36",
            "NwsSiteName": "CWIG",
            "NwsEmail": "Email Address",
            "NwsInterest": "null",
            "__VIEWSTATE": str(view_state)
        }
        yield scrapy.FormRequest(url='https://www.cw-industrialgroup.com/Contact/Distributors.aspx',
                                 callback=self.data2, headers=headers, formdata=formdata, method='POST')


    def data2(self, response):
        print(response.url)

        countries = response.xpath('//*[contains(@value,"##ALLCOUNTRIES##")]/../option/@value').extract()
        del(countries[0])
        for country in countries:
            # try:event_target = response.xpath('//*[@id="__EVENTTARGET"]/@value').extract_first(default='')
            # except Exception as e:print(e)

            try:event_argument = response.xpath('//*[@id="__EVENTARGUMENT"]/@value').extract_first(default='')
            except Exception as e:print(e)

            try:last_focus = response.xpath('//*[@id="__LASTFOCUS"]/@value').extract_first(default='')
            except Exception as e:print(e)

            try:view_state_generator = response.xpath('//*[@id="__VIEWSTATEGENERATOR"]/@value').extract_first(default='')
            except Exception as e:print(e)

            try:scroll_position_x = response.xpath('//*[@id="__SCROLLPOSITIONX"]/@value').extract_first(default='')
            except Exception as e:print(e)

            # try:scroll_position_y = response.xpath('//*[@id="__SCROLLPOSITIONY"]/@value').extract_first(default='')
            # except Exception as e:print(e)

            try:view_state = response.xpath('//*[@id="__VIEWSTATE"]/@value').extract_first(default='')
            except Exception as e:print(e)

            headers = {
                "accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
                "accept-encoding":"gzip, deflate, br",
                "accept-language":"en-US,en;q=0.9",
                "cache-control":"max-age=0",
                "content-type":"application/x-www-form-urlencoded",
                "origin":"https://www.cw-industrialgroup.com",
                "referer":"https://www.cw-industrialgroup.com/Contact/Distributors.aspx",
                "sec-fetch-mode":"navigate",
                "sec-fetch-site":"same-origin",
                "sec-fetch-user":"?1",
                "upgrade-insecure-requests":"1",
                "user-agent":"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537."
            }

            data = {
                "manScript_HiddenField": ";;AjaxControlToolkit, Version=4.1.60919.0, Culture=neutral, PublicKeyToken=28f01b0e84b6d53e:en-US:ee051b62-9cd6-49a5-87bb-93c07bc43d63:475a4ef5:effe2a26:7e63a579",
                "__EVENTTARGET": 'p$lt$ctl05$pageplaceholder$p$lt$ctl03$Filter$filterControl$drpProductFamily',
                "__EVENTARGUMENT": str(event_argument),
                "__LASTFOCUS": str(last_focus),
                "lng": "en-US",
                "__VIEWSTATEGENERATOR": str(view_state_generator),
                "__SCROLLPOSITIONX": str(scroll_position_x),
                "__SCROLLPOSITIONY": "300",
                "p$lt$ctl00$SearchBox$txtWord_exWatermark_ClientState": "",
                "p$lt$ctl00$SearchBox$txtWord": "",
                "p$lt$ctl04$MobileSearchBox$txtWord_exWatermark_ClientState": "",
                "p$lt$ctl04$MobileSearchBox$txtWord": "",
                "p$lt$ctl05$pageplaceholder$p$lt$ctl03$Filter$filterControl$drpProductFamily": "Electronic Throttle Controls",
                "p$lt$ctl05$pageplaceholder$p$lt$ctl03$Filter$filterControl$drpCountry": str(country),
                # "p$lt$ctl05$pageplaceholder$p$lt$ctl03$Filter$filterControl$drpCountry": 'South Africa',
                "NwsListID": "57c2952d36",
                "NwsSiteName": "CWIG",
                "NwsEmail": "Email Address",
                "NwsInterest": "null",
                "__VIEWSTATE": str(view_state)
            }

            yield scrapy.FormRequest(url='https://www.cw-industrialgroup.com/Contact/Distributors.aspx',callback=self.data3, headers=headers,
                                     formdata=data, method='POST')


    def data3(self, response):
        divs = response.xpath('//div[@class="lst-wrp"]/div')
        if len(divs) > 1:
            del(divs[-1])
        for div in divs:
            try:store_name = div.xpath('./h3/text()').extract_first()
            except Exception as e:print(e)

            text = div.xpath('./p/text()').extract_first()

            # try:country = div.xpath('./p/text()').extract_first().split(',')[-1]
            # except Exception as e:print(e)

            try:zipcode = re.findall(r'\d{4,6}', text)[0]
            except:zipcode = ''

            try:
                address = div.xpath('./p/text()').extract_first().replace(str(zipcode),'').replace('Address:','').replace(',  ,','').replace(', ,','').replace('),',')').replace('H,','H').replace('i,','i').replace('E,','E').replace('-,','').replace('d,','d').replace('5,','5').replace('n,','n').replace('t,','t').replace('A,','A').replace('2,','2')
                if address == ',':
                    address = ''
            except Exception as e:print(e)

            try:phone_number = div.xpath('//*[contains(text(),"Phone")]/text()').extract_first().replace('Phone:','')
            except Exception as e:print(e)

            try:fax_number = div.xpath('//*[contains(text(),"Fax")]/text()').extract_first(default='').replace('Fax:','')
            except Exception as e:print(e)

            try:
                sites = div.xpath('.//p[@class="remove-bottom"]/a/text()').extract()
                try:
                    website_address = sites[0]
                    email_address = sites[-1]
                except:
                    website_address = ''
                    email_address = ''
            except Exception as e:
                print(e)

            item = StoreLocatorsItem()
            item['search_term'] = 'link'
            item['store_name'] = store_name
            item['address'] = address
            item['city'] = ''
            item['state'] = ''
            item['zip_code'] = zipcode
            item['phone_number'] = phone_number
            item['email_address'] = email_address
            item['fax_number'] = fax_number
            item['coming_soon'] = 0
            item['country'] = ''
            item['country_code'] = ''  # self.f1.country_dict.get(item['country'].lower())
            item['website_address'] = website_address
            item['source_url'] = response.url
            yield item

    def response_html_path(self, request):
        return request.meta['fpath']


# execute('''scrapy crawl store_129 -a list_id=129'''.split())