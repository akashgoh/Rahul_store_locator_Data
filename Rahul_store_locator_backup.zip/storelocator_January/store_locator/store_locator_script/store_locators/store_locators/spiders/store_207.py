# # -*- coding: utf-8 -*-
# # pip install scrapy-html-storage
# import re
#
# import scrapy,os,logging,hashlib
# import requests,json
# from scrapy.http import HtmlResponse
# from scrapy.cmdline import execute
# from store_locators.items import StoreLocatorsItem
# from store_locators.spiders.common_functions import Func
# import datetime
# from selenium import webdriver                    # Import module
# from selenium.webdriver.common.keys import Keys   # For keyboard keys
# import time                                       # Waiting function
#
#
# class sunandskiSpider(scrapy.Spider):
#     name = 'store_207'
#     allowed_domains = []
#     FIREFOX_GOCKO_DRIVER_PATH = "D:\\geckodriver"
#     not_export_data = True
#
#     def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
#         super().__init__(name, **kwargs)
#         self.list_id, self.proxy_type = list_id, proxy_type
#         self.f1 = Func()
#         self.run_date = str(datetime.datetime.today()).split()[0]
#         self.f1.set_details(self.list_id, self.run_date)
#
#     def start_requests(self):
#
#         try:
#
#             if self.f1.search_by != 'link':
#                 search_terms = self.f1.get_search_term(self.f1.search_by)
#                 print(search_terms)
#             # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)
#                 search_terms = ''
#                 for search_term in (search_terms):
#                     source_url = link = 'https://stretchlab.com/locations/'
#                     file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(search_term) + '_' + str(self.run_date) + '.html'
#                     if os.path.exists(file_path):
#                         link = 'file://' + file_path.replace('\\','/')
#                     yield scrapy.FormRequest(url=str(link), callback=self.get_store_list, meta={'source_url': source_url,'search_term': search_term,'file_path':file_path,'proxy_type': self.proxy_type})
#             else:
#                 source_url = link = "https://www.sunandski.com/locations"
#                 # source_url = link = 'https://www.sunandski.com/api/commerce/storefront/locationUsageTypes/SP/locations/?sortBy=name%20asc&filter=locationType.Code%20eq%20ST&includeAttributeDefinition=true'
#
#
#             file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
#                     self.run_date) + '.html'
#             yield scrapy.FormRequest(url=str(link), callback=self.parse,
#                                          meta={'source_url': source_url,
#                                                'file_path': file_path, 'proxy_type': self.proxy_type})
#         except Exception as e:
#             logging.log(logging.ERROR, e)
#
#
#     def parse(self, response):
#         try:
#             file_path=response.meta['file_path']
#             link = "https://www.sunandski.com/api/commerce/storefront/locationUsageTypes/SP/locations/?sortBy=name%20asc&filter=locationType.Code%20eq%20ST&includeAttributeDefinition=true"
#             yield scrapy.FormRequest(url=link,callback=self.get_store_list,meta={'file_path':file_path})
#         except Exception as e:
#             print("parse",e,response.url)
#
#
#
#     # Get data from the response
#     def get_store_list(self, response):
#         try:
#             if not response.url.startswith('file://'):
#                 self.f1.page_save(response.meta['file_path'],response.body)
#             store_data = json.loads(response.text)
#             length = len(store_data['items'])
#
#             for i in range(0,length):
#
#                 try:
#                     search_term = response.meta.get('search_term', '')
#                     try:
#                         store_name = "Sun & Ski Sports - "+store_data['items'][i]['name']
#                     except Exception as e:
#                         print("store_name",e,response.url)
#
#                     try:
#                         address = store_data['items'][i]['address']['address1']
#                     except Exception as e:
#                         print("address1", e, response.url)
#                     try:
#                         address_line_2 = store_data['items'][i]['address']['address2']
#                         if address_line_2 == None:
#                             address_line_2 = ''
#                         else:
#                             address_line_2 = address_line_2
#                     except Exception as e:
#                         print("address_line_2", e, response.url)
#
#                     try:
#                         city = store_data['items'][i]['address']['cityOrTown']
#                     except Exception as e:
#                         print("city", e, response.url)
#
#                     try:
#                         state = store_data['items'][i]['address']['stateOrProvince']
#                     except Exception as e:
#                         print("state", e, response.url)
#
#                     try:
#                         zip_code = store_data['items'][i]['address']['postalOrZipCode']
#                     except Exception as e:
#                         print("zip_code", e, response.url)
#
#                     try:
#
#                         latitude =  store_data['items'][i]['geo']['lat']
#                         longitude = store_data['items'][i]['geo']['lng']
#
#                     except Exception as e:
#                         print("latitude and longitude", e, response.url)
#
#                     try:
#                         email_address = store_data['items'][i]['shippingOriginContact']['email']
#                     except Exception as e:
#                         print("email_address", e, response.url)
#
#
#                     try:
#                         phone_number = store_data['items'][i]['phone']
#                     except Exception as e:
#                         print("phonenumber", e, response.url)
#
#
#
#
#                     try:
#                         sunday = store_data['items'][i]['regularHours']['sunday']['label']
#                         monday = store_data['items'][i]['regularHours']['monday']['label']
#                         tuesday = store_data['items'][i]['regularHours']['tuesday']['label']
#                         wednesday = store_data['items'][i]['regularHours']['wednesday']['label']
#                         thursday = store_data['items'][i]['regularHours']['thursday']['label']
#                         friday = store_data['items'][i]['regularHours']['friday']['label']
#                         saturday = store_data['items'][i]['regularHours']['saturday']['label']
#                         store_hours = "Sunday = "+sunday+"|"+"Monday = "+monday+"|"+"Tuesday = "+tuesday+"|"+"Wednesday = "+wednesday+"|"+"Thursday = "+thursday+"|"+"Friday = "+friday+"|"+"Saturday = "+saturday
#                     except Exception as e:
#                         print("store_hours",e,response.url)
#
#                     try:
#                         le1 = len(store_data['items'][i]['attributes'])
#                         for j in range(0,le1):
#                             if store_data['items'][i]['attributes'][j]['fullyQualifiedName'] == "tenant~store-details-url":
#                                 urltmp = store_data['items'][i]['attributes'][j]['values'][0]
#                                 if not "/" in urltmp:
#                                     url = "https://www.sunandski.com/" +urltmp
#                                 else:
#                                     url = "https://www.sunandski.com" + urltmp
#                     except Exception as e:
#                         print("source_url",e,response.url)
#
#                     try:
#                         service = []
#                         le1 = len(store_data['items'][i]['attributes'])
#                         for j in range(0, le1):
#                             if store_data['items'][i]['attributes'][j]['fullyQualifiedName'] == "tenant~services-content":
#                                 servicetmp = store_data['items'][i]['attributes'][j]['values'][0]
#                                 servicetmps = servicetmp.split("|")
#                                 for servicetmp in servicetmps:
#                                     servicetmp = servicetmp.split(":")[0]
#                                     service.append(servicetmp)
#                         service = "|".join(service)
#                     except Exception as e:
#                         print("Services", e, response.url)
#
#                     try:
#                         additional_info = {}
#                         firstname = store_data['items'][i]['shippingOriginContact']['firstName']
#                         lastname = store_data['items'][i]['shippingOriginContact']['lastNameOrSurname']
#                         if firstname == None:
#                             if lastname == None:
#                                 fullname = ''
#                             else:
#                                 fullname = firstname
#                         else:
#                             fullname = firstname+" "+lastname
#                         additional_info['Store Manager'] = fullname
#                     except Exception as e:
#                         print("additionalinfo",response.url,e)
#
#
#
#                     item = StoreLocatorsItem()
#                     item['search_term'] = search_term
#                     item['store_name']= store_name
#                     item['address'] = address
#                     item['address_line_2'] = address_line_2
#                     item['city'] = city
#                     item['state'] =state
#                     item['zip_code'] = zip_code
#                     item['phone_number'] =phone_number
#                     item['latitude'] = latitude
#                     item['longitude'] = longitude
#                     item['store_type'] = ''
#                     item['website_address'] = ''
#                     item['coming_soon'] = 0
#                     item['store_number'] = ''
#                     item['country_code'] = item['country'] = 'US' #self.f1.country_dict.get(item['country'].lower())
#                     item['email_address'] = email_address
#                     item['services'] = service
#                     item['source_url']=url
#                     item['store_hours'] = store_hours
#                     item['additional_info'] = json.dumps(additional_info)
#                     if item['country_code'] == 'US' and len(item['state']) > 2:
#                         item['state'] = self.f1.state_dict.get(state, '')
#                     check =0
#                     if url =="https://www.sunandski.com/avon":
#                         check = 1
#                     if "/san-pedro-square" in url:
#                         check = 1
#                     if check == 0:
#                         yield item
#                 except Exception as e:
#                     print(e)
#
#         except Exception as e:
#             logging.log(logging.ERROR, e)
#
#     def response_html_path(self, request):
#         return request.meta['fpath']
#
# execute('''scrapy crawl store_207 -a list_id=207'''.split())
