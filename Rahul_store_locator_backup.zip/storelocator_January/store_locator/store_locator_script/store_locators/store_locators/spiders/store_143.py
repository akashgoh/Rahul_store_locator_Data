# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import re

import html2text
import pgeocode as pgeocode
import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime


class VillageInnSpider(scrapy.Spider):
    name = 'store_143'
    allowed_domains = []

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        try:
            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                print(search_terms)
                for search_term in (search_terms):
                    source_url = link = 'https://www.villageinn.com/locations/'
                    file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(search_term) + '_' + str(self.run_date) + '.html'
                    if os.path.exists(file_path):
                        link = 'file://' + file_path.replace('\\','/')
                    yield scrapy.FormRequest(url=str(link), callback=self.get_store_list, meta={'source_url': source_url,'search_term': search_term,'file_path':file_path})
            else:
                source_url = link = 'https://www.villageinn.com/locations/'
                file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(self.run_date) + '.html'
                yield scrapy.FormRequest(url=str(link), callback=self.get_links, meta={'source_url': source_url,'file_path': file_path})

        except Exception as e:
            logging.log(logging.ERROR, e)

    def get_links(self, response):
        links = response.xpath('//*[@class="columns nine locations-list"]/ul/li/a/@href').getall()
        for link in links:
            yield scrapy.FormRequest(url=str(link), callback=self.get_store_list, meta=response.meta)
    # Get data from the response
    def get_store_list(self, response):
        surl = response.url
        try:
            if not response.url.startswith('file://'):
                self.f1.page_save(response.meta['file_path'],response.body)

            search_term = response.meta.get('search_term', '')
            source_url = response.meta.get('source_url', '')

            attributes = response.xpath('//*[@class="storelocator-container"]')


            additional_info = {}
            item = StoreLocatorsItem()
            try:
                store_name = response.xpath('//*[@class="columns twelve"]/h1/text()').get().strip()
            except Exception as e:
                print("store_name",e,response.url)

            try:
                phone_number = response.xpath('//*[@id="abrh-phone"]/text()').get().strip()
            except Exception as e:
                print("phone_number", e, response.url)

            try:
                address = response.xpath('//*[@itemprop="streetAddress"]/text()').get().strip()
            except Exception as e:
                print("address", e, response.url)

            try:
                address_line_2 = ''
                check = False

                for j in ['Unit', 'STE', 'Ste', 'SUITE', 'Suite', 'suite', 'Suit', 'SUIT', 'suit', 'UNIT',
                          'unit', 'ste']:
                    for aw in address.split():
                        if j == aw:
                            address1 = address.split(j)[0].strip().strip(',')
                            address_line_2 = j + ' ' + address.split(j)[-1].strip()
                            check = True
                            break

                if check == True:
                    address_line_2 = address_line_2
                    address = address1
                else:
                    address_line_2 = ''
                    address = address
            except Exception as e:
                print("address_line_2", e, response.url)

            try:
                city = response.xpath('//*[@itemprop="addressLocality"]/text()').get().strip()
            except Exception as e:
                print("city", e, response.url)

            try:
                state = response.xpath('//*[@itemprop="addressRegion"]/text()').get().strip()
            except Exception as e:
                print("state", e, response.url)

            try:
                zip_code = response.xpath('//*[@itemprop="postalCode"]/text()').get().strip()
            except Exception as e:
                print("zip_code", e, response.url)

            try:
                latitude = re.findall(r'lat:\s(.*?),', response.text)[0].strip()
                longitude = re.findall(r'lng:\s(.*?)}', response.text)[0].strip()

            except Exception as e:
                print("latitude and longitude", e, response.url)

            try:
                additional_info = ' '.join(response.xpath('//*[@class="columns ten offset-by-one"]/p//text()').getall())
            except Exception as e:
                print("additional_info",e,response.url)

            try:
                store_hours = 'Mon : ' + str(response.xpath('//*[@class="hours"]/li[1]/text()').get()).replace('\n','') + '|' + \
                              'Tue : ' + str(response.xpath('//*[@class="hours"]/li[2]/text()').get()).replace('\n','') + '|' + \
                              'Wed : ' + str(response.xpath('//*[@class="hours"]/li[3]/text()').get()).replace('\n','') + '|' + \
                              'Thu : ' + str(response.xpath('//*[@class="hours"]/li[4]/text()').get()).replace('\n','') + '|' + \
                              'Fri : ' + str(response.xpath('//*[@class="hours"]/li[5]/text()').get()).replace('\n','') + '|' + \
                              'Sat : ' + str(response.xpath('//*[@class="hours"]/li[6]/text()').get()).replace('\n','') + '|' + \
                              'Sun : ' + str(response.xpath('//*[@class="hours"]/li[7]/text()').get()).replace('\n','')
            except Exception as e:
                print("store_hours",e,response.url)


            item['search_term'] = 'link'
            item['store_name']= store_name
            item['address'] = address
            item['address_line_2'] = address_line_2
            item['city'] = city
            item['state'] =state
            item['zip_code'] = zip_code
            item['phone_number'] =phone_number
            item['latitude'] = latitude
            item['longitude'] = longitude
            item['store_type'] = ''
            item['website_address'] = ''
            item['coming_soon'] = 0
            item['store_number'] = ''
            item['country_code'] = item['country'] = 'US'
            item['email_address'] = ''
            item['services'] = ''
            item['products'] = ''
            item['store_hours'] = store_hours
            item['additional_info'] = additional_info
            item['source_url'] = surl


            if item['country_code'] == 'US' and len(item['state']) > 2:
                item['state'] = self.f1.state_dict.get(state, '')
            if city == 'Dededo':
                item['state'] = 'Guam'
            yield item
        except Exception as e:
            print(e)

    def response_html_path(self, request):
        return request.meta['fpath']

#execute('''scrapy crawl store_143 -a list_id=143'''.split())
