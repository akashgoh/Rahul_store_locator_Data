#-*- coding: utf-8 -*-
# pip install scrapy-html-storage
import re

import html2text
import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime


class supersavefoodsSpider(scrapy.Spider):
    name = 'supersavefoods'
    allowed_domains = []
    f1 = Func()

    def __init__(self, name=None, list_id="",proxy_type="",**kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type= list_id, proxy_type
        self.f1 = Func()

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            source_url = link = 'https://www.supersavefoods.com/StoreLocator/Store?L=479&M=&From=&S='
            self.f1.set_details(self.list_id, run_date)
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
                run_date) + '.html'
            if os.path.exists(file_path):
                link = 'file://' + file_path.replace('\\', '/')

            yield scrapy.FormRequest(url=str(link), callback=self.get_store_list,meta={'source_url': source_url,'file_path': file_path,'proxy_type': self.proxy_type})
        except Exception as e:
            print(e)


    def get_store_list(self,response):
        source_url = response.meta['source_url']
        file_path = response.meta['file_path']


        if not response.url.startswith('file://'):
            self.f1.page_save(response.meta['file_path'], response.body)
            source_url = response.meta.get('source_url', '')

        try:
            item = StoreLocatorsItem()
            # print(store_name)
            item['address'] = ''.join(response.xpath('//*[@class="Address"]//text()').extract()[3]).strip()

            addinfo = ''.join(response.xpath('//*[@class="Address"]//text()').extract()[-1]).strip()

            city = addinfo.split(',')[0].strip()
            state = addinfo.split(',')[1].split()[0]
            zipc = addinfo.split(',')[1].split()[1]

            item['store_name'] = 'Supersavefoods-' + city
            item['address_line_2'] = ''
            item['city'] = city
            item['state'] = state

            item['zip_code'] = zipc
            item['phone_number'] = response.xpath('//*[@class="phone_wrapper"]/p[1]/a/text()').extract_first(default='').strip()
            item['fax_number'] = response.xpath('//*[@class="phone_wrapper"]/p[2]/text()').extract_first(default='').strip()
            item['email_address'] = ''
            item['latitude'] = ''
            item['longitude'] = ''
            item['store_type'] = ''
            item['website_address'] = 'https://www.supersavefoods.com'
            item['coming_soon'] = 0
            item['store_number'] = ''
            # if item['store_number'] == 8184:
            #     pass
            item['country'] = 'US'
            item['source_url'] = response.url
            item['state'] = 'US'
            item['country_code'] = 'US'
            # print(item['state'])
            # if item['country_code'] == 'US' and len(item['state']) > 2:
            #     item['state'] = self.f1.state_dict.get(item['state'].lower(), '')
                # print('::,', item['state'])

            # h = html2text.HTML2Text()
            # h.ignore_links = True
            # h.ignore_emphasis = True
            # h.ignore_images = True
            # h.body_width = 0
            # h.ignore_links = True
            # h.ignore_emphasis = True

            # attr = []
            # for tr in response.xpath('//*[@class="c-location-hours-details"]/tbody/tr'):
            #     key = ''.join(tr.xpath('./td/text()').extract()).strip()
            #     value = ''.join(tr.xpath('./td[2]//text()').extract()).strip()
            #     # print(key, ' : ', value)
            #     if value:
            #         attr.append(str(key) + ':' + str(value))
            #
            # store_hours = '|'.join(attr)
            item['store_hours'] = ''

            add_info = dict()
            add_info['distance'] = ''
            add_info['thumb'] = ''
            add_info['description'] = ''
            item['additional_info'] = ''
            yield item
        except Exception as e:
            print(e)

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl supersavefoods -a list_id=202 -s HTTPCACHE_ENABLED=True'''.split())