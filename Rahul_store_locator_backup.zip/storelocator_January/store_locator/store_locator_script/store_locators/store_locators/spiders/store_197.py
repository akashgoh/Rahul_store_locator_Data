#-*- coding: utf-8 -*-
# pip install scrapy-html-storage
import re

import html2text
import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime

# from selenium.webdriver.firefox.options import Options
class store197Spider(scrapy.Spider):
    name = 'store_197'
    allowed_domains = []
    f1 = Func()

    def __init__(self, name=None, list_id="",proxy_type="",**kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type

        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        self.f1.set_details(self.list_id, run_date)
        # headers = {
        #     # "Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        #     # "Accept-Encoding":"gzip, deflate, br",
        #     # "Accept-Language":"en-US,en;q=0.9",
        #     # "Connection":"keep-alive",
        #     # "Host":"www.svyaznoy.ru",
        #     # "If-Modified-Since":"Fri, 19 Jun 2020 05:19:17 GMT",
        #     # "If-None-Match":'W/"5eec4ad5-183e1b"',
        #     # "Sec-Fetch-Dest":"document",
        #     # "Sec-Fetch-Mode":"navigate",
        #     # "Sec-Fetch-Site":"none",
        #     # "Sec-Fetch-User":"?1",
        #     # "Upgrade-Insecure-Requests":"1",
        #     # "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36"
        #     'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        #     'Accept-Encoding': 'gzip, deflate, br',
        #     'Accept-Language': 'en-US,en;q=0.9',
        #     'Cache-Control': 'max-age=0',
        #     'Connection': 'keep-alive',
        #     'Cookie': 'SITE_SESSID=4jntl7upruc3702iuo8mpd5fev; O_ZONE_ALIAS=msk; O_CITY_ID=133; SETCITY=133; branch=A; rerf=AAAAAF/W32NsWHnmAwjQAg==; ipp_uid2=kYaOUj5jxpnxAeDE/crAokWH2sMg+cs+RHas8+Q==; ipp_uid1=1607917410923; ipp_uid=1607917410923/kYaOUj5jxpnxAeDE/crAokWH2sMg+cs+RHas8+Q==; reuserid=c1610604-11f4-48e7-8106-c3e6fcb38c0a; favoriteProducts=%5B%5D; mindboxDeviceUUID=947fd39e-2f2c-4168-afcf-71c73b2ada02; directCrm-session=%7B%22deviceGuid%22%3A%22947fd39e-2f2c-4168-afcf-71c73b2ada02%22%7D; _gcl_au=1.1.192397910.1607917422; newUser=1; gdeslon.ru.__arc_domain=gdeslon.ru; gdeslon.ru.user_id=22918796-93f7-46d7-a838-519f708e9ef0; tmr_lvid=275cbf1551f938587b6c53a7039fd47e; tmr_lvidTS=1607917424093; top100_id=t1.4509384.198551578.1607917424163; _ym_uid=1607917424446180326; _ym_d=1607917424; _fbp=fb.1.1607917424455.363993039; tgCas=%28not%20set%29; g4c_x=1; flocktory-uuid=1e1eb756-8eee-4e2e-bbf8-3c469938f342-9; adid=160791742738737; ipp_sign=8e9e4d3adbf968646849d95d8e01a639_2145976332_4593a70faabe2df909f27c8ea7db6ff7; ipp_key=v1608522135867/v3394bd400b5e53a13cfc65163aeca6afa04ab3/4/GYNBz5R4s+Zr0dkpkFbA==; advcake_track_id=a698624a-5ecb-e675-7e22-e52d9d18227e; advcake_session_id=42f9eae4-bd4c-ca05-5c2a-f7673ba01506; AMP_TOKEN=%24NOT_FOUND; _gid=GA1.2.2052978577.1608522140; rete_session=true; _ym_visorc_200508=w; _ym_isad=2; searchPlaceholder=Samsung%2520Galaxy%2520A71; _ga_51XQ7KKEQY=GS1.1.1608522139.3.1.1608522482.0; _gat_owox=1; last_visit=1608502684450::1608522484450; _ga=GA1.2.1225894232.1607917417; _gat_UA-7040008-28=1; tmr_detect=0%7C1608522487010; tmr_reqNum=24',
        #     'Host': 'www.svyaznoy.ru',
        #     'If-Modified-Since': 'Mon, 21 Dec 2020 03:42:09 GMT',
        #     'If-None-Match': 'W/"5fe01991-10721a"',
        #     'Sec-Fetch-Dest': 'document',
        #     'Sec-Fetch-Mode': 'navigate',
        #     'Sec-Fetch-Site': 'none',
        #     'Sec-Fetch-User': '?1',
        #     'Upgrade-Insecure-Requests': '1',
        #     'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'
        # }
        # link = "https://www.svyaznoy.ru/shops"
        # # link = "https://www.svyaznoy.ru/shops?utm_referrer=&"
        # file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
        #     run_date) + '.html'
        # yield scrapy.FormRequest(url=link, callback=self.get_store_list, dont_filter=True,
        #                          meta={'source_url': link, 'file_path': file_path,
        #                                'proxy_type': self.proxy_type})
        yield scrapy.Request(url='file:///C:/Users/xbyte/Desktop/russianfed.html', callback=self.get_store_list)

    def get_store_list(self,response):
        try:
            address = re.findall(r's="b-shops-map__address-text">(.*?)<span class="b-',response.text)
            hours = response.xpath('//div[@class="b-shops-map__time"]/text()').getall()
            long = re.findall(r'ta-longitude="(.*?)"',response.text)
            lat = re.findall(r'data-latitude="(.*?)"', response.text)

            for address,hours,long,lat in zip(address,hours,long,lat):

                item = StoreLocatorsItem()
                store_hours = hours

                item['store_name'] = 'svyaznoy'
                item['address'] = address
                print(item['address'])
                item['latitude'] = lat
                item['longitude'] = long
                item['website_address'] = 'https://www.svyaznoy.ru/'
                item['coming_soon'] = 0
                # if item['store_number'] == 8184:
                #     pass
                item['country'] = 'RU'
                item['source_url'] = 'https://www.svyaznoy.ru/shops'
                # item['state'] = ''
                item['country_code'] = 'RU'
                item['store_hours'] = store_hours.strip()
                yield item
        except Exception as e:
            print(e)

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_197 -a list_id=197 -s HTTPCACHE_ENABLED=True'''.split())

