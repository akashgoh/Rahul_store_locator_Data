# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import random
import re


import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime

class Store122Spider(scrapy.Spider):
    name = 'store_122'
    allowed_domains = []
    not_export_data = True

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()


    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            self.f1.set_details(self.list_id,run_date)
            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                print(search_terms)
            # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)
                search_terms = ''
                for search_term in (search_terms):
                    source_url = link = 'https://www.workngear.com/store-locator'
                    file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(search_term) + '_' + str(run_date) + '.html'
                    if os.path.exists(file_path):
                        link = 'file://' + file_path.replace('\\','/')
                    yield scrapy.FormRequest(url=str(link), callback=self.data, meta={'source_url': source_url,'search_term': search_term,'file_path':file_path,'proxy_type': self.proxy_type})
            else:
                source_url = link = 'https://www.workngear.com/store-locator'
                file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(run_date) + '.html'
                yield scrapy.FormRequest(url=str(link), callback=self.data,
                                         meta={'source_url': source_url,
                                               'file_path': file_path, 'proxy_type': self.proxy_type})
        except Exception as e:
            logging.log(logging.ERROR, e)


    def data(self, response):
        divs = response.xpath('//div[@class="results-stores"]/ul')
        for div in divs:

            try:
                add1 = div.xpath('./div[@class="store-locator-address"]/li[1]/text()').extract_first()
                add = add1.split(',')
                city = add[0].strip()
                state = add[-1].strip()
                if len(state) > 2:
                    state = ''

                address = div.xpath('./div[@class="store-locator-address"]/li[2]/text()').extract_first()
                check = False
                for j in ['Unit', 'STE', 'Ste', 'SUITE', 'Suite', 'suite', 'Suit', 'SUIT', 'suit', 'UNIT', 'unit',
                          'ste']:
                    for aw in address.split():
                        if j == aw:
                            address1 = address.split(j)[0].strip().strip(',')
                            address_line_2 = j + ' ' + address.split(j)[-1].strip()
                            check = True
                            break
                if check == True:
                    address_line_2 = address_line_2
                    address = address1
                else:
                    address_line_2 = ''
                    address = address
            except Exception as e:
                print(e)

            try:store_name = "WORK 'N GEAR STORES-" + str(add1)
            except Exception as e:print(e)

            try:zip_code = div.xpath('./div[@class="store-locator-address"]/li[4]/text()').extract_first()
            except Exception as e:print(e)

            try:phone_number = div.xpath('./div[@class="store-locator-pno"]/li[2]/text()').extract_first()
            except Exception as e:print(e)

            try:store_hours = '|'.join(div.xpath('./div[@class="store-locator-hours"]/li/text()').extract())
            except Exception as e:print(e)


            item = StoreLocatorsItem()
            item['search_term'] = 'link'
            item['store_name'] = store_name
            item['address'] = address
            item['address_line_2'] = address_line_2
            item['city'] = city
            item['state'] = state
            item['zip_code'] = zip_code
            item['phone_number'] = phone_number
            item['website_address'] = ''
            item['coming_soon'] = 0
            item['country_code'] = item['country'] = 'US'  # self.f1.country_dict.get(item['country'].lower())
            item['email_address'] = 'info@workngear.com'
            item['store_hours'] = store_hours
            item['source_url'] = response.url
            yield item

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_122 -a list_id=122'''.split())