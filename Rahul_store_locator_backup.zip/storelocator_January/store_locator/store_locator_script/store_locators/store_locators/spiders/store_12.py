# -*- coding: utf-8 -*-
import re
import datetime
import pymysql
import requests
from scrapy.cmdline import execute
import scrapy
from scrapy.http import HtmlResponse
from store_locators.spiders.common_functions import Func
from store_locators.items import StoreLocatorsItem
import json

class Store12Spider(scrapy.Spider):
    name = 'store_12'
    f1 = Func()

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        link='https://www.airgas.com/store-finder'
        yield scrapy.FormRequest(url=link,callback=self.parse)

    def parse(self, response):
        links = response.xpath('//ul[@class="browse mb-xs-0"]/li/div/a/@href').getall()
        for link in links:
            yield scrapy.FormRequest(url=link, callback=self.parse1,dont_filter=True)

    def parse1(self,response):
        urls = response.xpath('//ul[@class="map-list"]/li/div/a/@href').getall()
        for link in urls:
            yield scrapy.FormRequest(url=link,callback= self.parse2,dont_filter=True)

    def parse2(self,response):
        url = response.xpath('//div[@class="map-list-links list-links mt-10"]/a[1]/@href').extract()
        for link in url:
            yield scrapy.FormRequest(url=link,callback=self.get_store_list,dont_filter=True)


    def get_store_list(self, response):
        try:
            # find_json = re.findall('<script type="application/ld\+json\">(.*?)</script>', response.text, re.DOTALL)[0].strip()
            # data = json.loads(find_json)
            # print(data)

            try:
                store_name = response.xpath('//div[@class="stores-nearby-header hide-mobile"]/h2/text()').get()
            except Exception as e:
                print("store_name",e,response.url)

            try:
                address = response.xpath('//p[@class="address mt-10 mb-10"]/span[1]/text()').get()
            except Exception as e:
                print("add", e, response.url)

            try:
                add1 = response.xpath('//p[@class="address mt-10 mb-10"]/span[2]/text()').get()
                city = add1.split(',')[0]
                add2 = add1.split(',')[1]
                state = add2.split(' ')[-2]
                zip_code = add2.split(' ')[-1]
            except Exception as e:
                print("add1", e, response.url)

            try:
                phone_number = response.xpath('//div[@class="map-list-links"]/a/text()').get()#.replace('\r','').replace('\n','').replace('\t','').strip()
            except Exception as e:
                print("phone_number", e, response.url)

            try:
                store_hour = re.findall('"openingHours": "(.*?)"',response.text)[0]
            except Exception as e:
                print("store_hour", e, response.url)

            try:
                latitude = re.findall('"latitude": "(.*?)"',response.text)[0].strip()
            except Exception as e:
                print("latitude", e, response.url)

            try:
                longitude = re.findall('"longitude": "(.*?)"',response.text)[0].strip()
            except Exception as e:
                print("longitude", e, response.url)

            try:
                service = '|'.join(response.xpath('//ul[@class="specialtyListContainer"]/li/text()').extract())
            except Exception as e:
                print("service", e, response.url)

            source_url = response.url

            if state =='QC' or state == 'BC' or state == 'ON':
                country_code = 'CA'
                country = 'Canada'
            else:
                country_code = 'US'
                country = ' US'

                item = StoreLocatorsItem()
                item['search_term'] = 'LINK'
                item['store_name']= store_name
                item['address'] = address
                item['city'] = city
                item['state'] =state
                item['zip_code'] = zip_code
                item['phone_number'] =phone_number
                # item['store_type'] = ''
                # item['website_address'] = ''
                item['coming_soon'] = 0
                # item['store_number'] = ''
                item['country_code'] = country_code
                item['country'] = country
                item['email_address'] = ''
                item['services'] = service
                item['store_hours'] = store_hour.replace('M',' | M').replace('T',' | W').replace('W',' | W').replace('W',' | W').replace('T',' | T').replace('F',' | F').replace('S',' | S')
                item['additional_info'] = ''
                item['latitude'] = latitude
                item['longitude'] = longitude
                # item['number_of_store'] =
                item['source_url'] = source_url
                # item['store_type']='Branch'
                # time.sleep(1)
                yield item
        except Exception as e :
            print('error')

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_12 -a list_id=12'''.split())
