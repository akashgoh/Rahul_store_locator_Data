# -*- coding: utf-8 -*-
import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime
import pandas as pd
from string import punctuation
import re
import html2text
run_date = str(datetime.datetime.today()).split()[0]

class YwcaCrawlerSpider(scrapy.Spider):
    name = 'store_106'
    allowed_domains = []
    f1 = Func()
    not_export_data = False

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type

        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            source_url = link = 'https://secure2.convio.net/ywca/map/locations.csv'
            head = {'Host': 'secure2.convio.net','User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0','Accept': '*/*','Accept-Language': 'en-GB,en;q=0.5','Accept-Encoding': 'gzip, deflate, br','X-Requested-With': 'XMLHttpRequest','Referer': 'https://secure2.convio.net/ywca/site/SPageServer;jsessionid=00000000.app226a?pagename=YWCA_Map&NONCE_TOKEN=926572BE5C235A720D80F2597F4EF5AD'}
            self.f1.set_details(self.list_id, run_date)
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(run_date) + '.html'
            if os.path.exists(file_path):
                link = 'file://' + file_path.replace('\\', '/')
            yield scrapy.FormRequest(url=str(link), callback=self.get_store_list, headers=head, meta={'source_url': source_url,'file_path': file_path, 'proxy_type': self.proxy_type})
        except Exception as e:
            print(e)

    def get_store_list(self,response):
        if not response.url.startswith('file://'):
            self.f1.page_save(response.meta['file_path'], response.body)
        try:
            data = response.text.split('\r\n')[1:]
            for df in data:
                temp = df.split(',')
                store_name = temp[0].strip(punctuation)
                if store_name =='YWCA Bethlehem':
                    address = temp[1].strip(punctuation).strip()
                    address_line_2 = temp[2].strip(punctuation).strip()
                    address_line_3 = temp[3].strip(punctuation).strip()
                    city = temp[4].strip(punctuation).strip()
                    state = temp[5].strip(punctuation).strip().split(' ')[0].strip()
                    zip_code = temp[5].strip(punctuation).strip().split(' ')[-1].strip()
                    country = country_code = 'US'
                    phone_number = temp[6].strip(punctuation).strip().replace(')','').replace('-',' ').replace(' ','.')
                    latitude = temp[7].strip(punctuation).strip()
                    longitude = temp[8].strip(punctuation).strip()
                    website = temp[9].strip(punctuation).strip()
                elif store_name =='YWCA Aurora':
                    address = temp[1].strip(punctuation).strip()
                    address_line_2 = ''
                    address_line_3 = ''
                    city = temp[4].strip(punctuation).strip()
                    state = temp[5].strip(punctuation).strip().split(' ')[0].strip()
                    zip_code = temp[5].strip(punctuation).strip().split(' ')[-1].strip()
                    country = country_code = 'US'
                    phone_number = temp[6].strip(punctuation).strip().replace(')', '').replace('-', ' ').replace(' ','.')
                    latitude = temp[7].strip(punctuation).strip()
                    longitude = temp[8].strip(punctuation).strip()
                    website = temp[9].strip(punctuation).strip()
                elif len(temp) == 8:
                    address = temp[1].strip(punctuation).strip()
                    address_line_2 = ''
                    address_line_3 = ''
                    city = temp[2].strip(punctuation).strip()
                    state = temp[3].strip(punctuation).strip().split(' ')[0].strip()
                    zip_code = temp[3].strip(punctuation).strip().split(' ')[-1].strip()
                    country = country_code = 'US'
                    phone_number = temp[4].strip(punctuation).strip().replace(')', '').replace('-', ' ').replace(' ','.')
                    latitude = temp[5].strip(punctuation).strip()
                    longitude = temp[6].strip(punctuation).strip()
                    website = temp[7].strip(punctuation).strip()
                elif len(temp)==9:
                    address = temp[1].strip(punctuation).strip()
                    address_line_2 = temp[2].strip(punctuation).strip()
                    address_line_3 = ''
                    city = temp[3].strip(punctuation).strip()
                    state = temp[4].strip(punctuation).strip().split(' ')[0].strip()
                    zip_code = temp[4].strip(punctuation).strip().split(' ')[-1].strip()
                    country = country_code = 'US'
                    phone_number = temp[5].strip(punctuation).strip().replace(')', '').replace('-', ' ').replace(' ','.')
                    latitude = temp[6].strip(punctuation).strip()
                    longitude = temp[7].strip(punctuation).strip()
                    website = temp[8].strip(punctuation).strip()
                if address == '21 First Street':
                    store_name = 'YWCA of the Greater Capital Region'
                    
                if 'Suite' in address:
                    ad = re.split('(Suite.*)', address.strip())
                    address = ad[0].strip(punctuation).strip()
                    address_line_2 = ad[1].strip(punctuation).strip()
                elif 'Ste' in address:
                    ad = re.split('(Ste.*)', address.strip())
                    address = ad[0].strip(punctuation).strip()
                    address_line_2 = ad[1].strip(punctuation).strip()

                try:
                    item = StoreLocatorsItem()
                    item['store_name'] = store_name
                    item['address'] = address
                    item['address_line_2'] = address_line_2
                    item['address_line_3'] = address_line_3
                    item['city'] = city
                    item['state'] = state
                    item['zip_code'] = zip_code
                    item['country'] = country
                    item['country_code'] = country_code
                    item['latitude'] = latitude
                    item['longitude'] = longitude
                    item['phone_number'] = phone_number
                    item['website_address'] = website
                    item['source_url'] = response.meta['source_url']
                    yield item
                except Exception as e:
                    logging.log(logging.ERROR, e)
        except Exception as e:
            logging.log(logging.ERROR,e)


# execute('''scrapy crawl store_106 -a list_id=106'''.split())#-s HTTPCACHE_ENABLED=True