# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import re

import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime


class Sixteen_handlesSpider(scrapy.Spider):
    name = 'store_2'
    allowed_domains = []
    not_export_data = False

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type

        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):

        try:

            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                print(search_terms)
            # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)
                search_terms = ''
                for search_term in (search_terms):
                    source_url = link = 'https://16handles.com/locations/'
                    file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(search_term) + '_' + str(self.run_date) + '.html'
                    if os.path.exists(file_path):
                        link = 'file://' + file_path.replace('\\','/')
                    yield scrapy.FormRequest(url=str(link), callback=self.get_store_list, meta={'source_url': source_url,'search_term': search_term,'file_path':file_path,'proxy_type': self.proxy_type})
            else:
                source_url = link = 'https://liveapi.yext.com/v2/accounts/me/answers/vertical/query?v=20190101&api_key=ced4d8e1cfeba3cec6f6889a1fd26886&jsLibVersion=v0.12.1&sessionTrackingEnabled=true&input=stores%20near%20me&experienceKey=16handles&version=PRODUCTION&verticalKey=locations&limit=40&offset=0&locale=en'
                file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
                    self.run_date) + '.html'
                yield scrapy.FormRequest(url=str(link), callback=self.firstlevel,
                                         meta={'source_url': source_url,
                                               'file_path': file_path, 'proxy_type': self.proxy_type})

        except Exception as e:
            logging.log(logging.ERROR, e)


    def firstlevel(self,response):
        try:
            source_url = response.meta['source_url']

            file_path = response.meta['file_path']
            proxy_type = response.meta['proxy_type']

            data = json.loads(response.text)
            le = len(data['response']['results'])
            for i in range(0,le):


                url = data['response']['results'][i]['data']['website']
                # services = '|'.join(div.xpath('./parent::div/div[3]/a/@title|./parent::div/div[2]/a/@title').extract())

                yield scrapy.FormRequest(url=url,callback=self.get_store_list,meta={'source_url':source_url,'file_path':file_path,'proxy_type':proxy_type,'services':''})


        except Exception as e:
            print("firstlevel",e,response.url)

    # Get data from the response
    def get_store_list(self, response):
        try:
            if not response.url.startswith('file://'):
                self.f1.page_save(response.meta['file_path'],response.body)

            search_term = response.meta.get('search_term', '')
            source_url = response.meta.get('source_url', '')


            try:
                additional_info = {}


                try:
                    store_name = response.xpath('//h2//text()').extract_first().strip()
                except Exception as e:
                    print("store_name",e,response.url)

                try:
                    phone_number = response.xpath('//span[@class="phone-text"]/text()').extract_first().strip()
                    # phone_number = phoneemail[0].strip().strip("-")
                except Exception as e:
                    print("phone_number", e, response.url)

                # try:
                #     email_address = phoneemail[1].strip().strip("-")
                # except Exception as e:
                #     print("email_address", e, response.url)

                try:
                    address = response.xpath('//span[@class="c-address-street-1"]/text()').extract_first().strip()
                except Exception as e:
                    print("address", e, response.url)

                try:
                    city = response.xpath('//span[@class="c-address-city"]/text()').extract_first().replace('FL 33431','').replace(', NY 11249','').strip()
                except Exception as e:
                    print("city", e, response.url)

                try:
                    state = response.xpath('//span[@itemprop="addressRegion"]/text()').extract_first().strip()
                except Exception as e:
                    print("state", e, response.url)
                try:
                    zip_code = response.xpath('//span[@itemprop="postalCode"]/text()').extract_first()\

                    if zip_code == None:
                        zip_code = '07699'
                    else:
                        zip_code = zip_code.strip()
                except Exception as e:
                    print("zip_code", e, response.url)
                try:
                    lat = re.findall('"latitude":(.*?),"',response.text)[0]
                    lng = re.findall('"longitude":(.*?)}',response.text)[0]
                except Exception as e:
                    print("latitude and longitude", e, response.url)

                try:
                    services = response.meta['services'].strip()

                except Exception as e:
                    print("services",e,response.url)

                try:
                    hourslist = []
                    store_hour_divs = response.xpath('//table[@class="hours lp-param lp-param-hours"]/tbody//tr')
                    for store_hour_div in store_hour_divs:
                        key = store_hour_div.xpath('./td[1]/text()').extract_first()
                        value = store_hour_div.xpath('./td[2]//text()').extract_first()
                        pair = key + "-->"+value
                        hourslist.append(pair)

                    store_hours = "|".join(hourslist)
                except Exception as e:
                    print("store_hours",e,response.url)



                try:
                    # geeksquad = ''.join(response.xpath('//div[@class="inner-module"]/div[2]/text()').extract()).replace('’',"'")
                    # geeksquad = re.sub('\s+', ' ', re.sub('\r|\n|\t', ' ',str(geeksquad)))
                    additional_info={}

                except Exception as e:
                    print("additional_info",e,response.url)
                item = StoreLocatorsItem()
                item['search_term'] = search_term
                item['store_name']= store_name
                item['address'] = address
                item['city'] = city
                item['state'] =state
                item['zip_code'] = zip_code
                item['phone_number'] =phone_number
                item['latitude'] = lat
                item['longitude'] = lng
                item['store_type'] = ''
                item['website_address'] = response.url
                item['coming_soon'] = 0
                item['store_number'] = ''
                item['country_code'] = item['country'] = 'US' #self.f1.country_dict.get(item['country'].lower())
                item['email_address'] = ''
                item['services'] = services

                item['store_hours'] = store_hours
                item['additional_info'] = json.dumps(additional_info)

                if item['country_code'] == 'US' and len(item['state']) > 2:
                    item['state'] = self.f1.state_dict.get(state, '')



                yield item
            except Exception as e:
                print(e)

        except Exception as e:
            logging.log(logging.ERROR, e)

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_2 -a list_id=2'''.split())
