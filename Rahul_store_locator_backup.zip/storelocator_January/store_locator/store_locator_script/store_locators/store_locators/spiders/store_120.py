# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import random
import re


import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime

class Store120Spider(scrapy.Spider):
    name = 'store_120'
    allowed_domains = []


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()


    def start_requests(self):
        print('-----')
        run_date = str(datetime.datetime.today()).split()[0]
        self.f1.set_details(self.list_id,run_date)

        self.headers = {

            "accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
            "accept-encoding":"gzip, deflate, br",
            "accept-language":"en-US,en;q=0.9",
            "cache-control":"max-age=0",
            "referer":"https://www.worldhotels.com/content/luxury-hotels/en_US/book/hotel-search.html",
            "cookie":'check=true; AMCVS_5834D36B545260EF0A4C98A7%40AdobeOrg=1; s_cc=true; __qca=P0-204360942-1603861343405; OptanonAlertBoxClosed=2020-10-28T05:02:26.464Z; _mibhv=anon-1603861346724-1069559608_4637; s_sq=%5B%5BB%5D%5D; ak_bmsc=7114BCCA6D9FEBD0A06D5F3154380B9F17D4FE270B4B0000B733995FBAF5C757~plUQY5y4ZTzpb5b1WNU9JkqO+ynTbaieDJg4aVvnuNluJnbM9OGQreOIZnJ+WOkcO2s021JMt+az1l175Yh3KlTWvpE4iBBieJbvr5L4bE2J1Yo5oHgfCe5OugrAwgZezowYlxW+CmxtmCLEg7WtHX2B6jjGuYrPpNX+z9FTdrrc6KN1lWJLkM4Stp4Q7UiBqbWYrs4z6gaqW2USiydupg+nfaW9uqoq7Dzhib7WGDVHI=; bm_sv=DE159BDCEAA9364FA2E28B16C9701BAE~tLr+UByQdxDlcbPWKg4BAjOlBEMf+Wp9+bIzxug5Pdw3y5YjHPRZeerEgTZm9Ao4nQcum9+6+zQ4+OF7H6egzpk+daUbkhIXm5eX+UI2WtQ1qTMwuRlkCwGg0itojtXVqunXkvdRYOBK0/PBz1tLV0MypdkjxgBU/nyANbAVqPw=; mbox=PC#88968f935628457691220526b3c68c69.31_0#1667106143|session#9d02d6962592493d9d1b0d0c3e2b850b#1603879162; OptanonConsent=isIABGlobal=false&datestamp=Wed+Oct+28+2020+14%3A58%3A23+GMT%2B0530+(India+Standard+Time)&version=6.5.0&hosts=&consentId=88e7a904-cdff-49e9-852c-34ec5287a6d0&interactionCount=1&landingPath=NotLandingPage&groups=C0004%3A1%2CC0003%3A1%2CC0001%3A1&geolocation=IN%3BGJ&AwaitingReconsent=false; prop_id=86121; utag_vnum=1606453343238&vn=5; utag_dslv=1603877303515; AMCV_5834D36B545260EF0A4C98A7%40AdobeOrg=-330454231%7CMCIDTS%7C18564%7CMCMID%7C49993893209975499262888018384187374913%7CMCAAMLH-1604482108%7C9%7CMCAAMB-1604482108%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1603884508s%7CNONE%7CvVersion%7C3.1.2; utag_main=v_id:01756d95ea21009ca897b2e4805803073003c06b009dc$_sn:5$_ss:0$_st:1603879120346$vapi_domain:worldhotels.com$ses_id:1603877302993%3Bexp-session$_pn:1%3Bexp-session; AKA_A2=A; RT="z=1&dm=worldhotels.com&si=b255c976-f689-4455-a0c8-7aee350885f2&ss=kgt0807y&sl=0&tt=0&bcn=%2F%2F36a3fec2.akstat.io%2F&ul=8ne35',
            "sec-fetch-dest":"document",
            "sec-fetch-mode":"navigate",
            "sec-fetch-site":"same-origin",
            "sec-fetch-user":"?1",
            "upgrade-insecure-requests":"1",
            "user-agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36"
        }

        link = 'https://www.worldhotels.com/content/luxury-hotels/en_US/find-hotel.html'
        # "https://www.worldhotels.com/content/luxury-hotels/en_US/find-hotel.html"
        yield scrapy.Request(url=link, callback=self.parse, headers=self.headers,dont_filter=True)


    def parse(self, response):
        s=response.url
        #https://www.worldhotels.com/content/luxury-hotels/en_US/find-hotel.html
        print(s)
        # links = response.xpath('//div[@class="textimage-text"]//a/@href').extract()
        links=re.findall('href="/content/luxury-hotels/en_US/book/(.*?)"',response.text,re.DOTALL)
        print(links)
        for j in links:
            if '.html' in j:

                mylink='https://www.worldhotels.com/content/luxury-hotels/en_US/book/' + j
                print(mylink)
                # resp = requests.get(mylink)

                # "https://www.worldhotels.com/content/luxury-hotels/en_US/book/hotels-in-bergen/bergen-bors-hotel/propertyCode.73137.html"
                # res = requests.get(url='https://www.worldhotels.com/content/luxury-hotels/en_US/book/hotel-details.86191.html')

               # response1 = HtmlResponse(url=resp, body=resp.content)

                response = requests.request("GET", mylink, headers=self.headers)

                try:
                    # store_name = response.xpath('//h1[@class="hotelName"]/text()').extract_first(default='').strip()
                    store_name=re.findall('<h2>(.*?)</h2>',response.text)[0]
                    print(store_name)
                except Exception as e:print(e)

                # text = response.xpath('//div[@class="container"]//div/p//text()').getall()
                text= ''.join(re.findall('<div class="container">(.*?)<p><a class="telInfo"',response.text,re.DOTALL))
                print(text)
                try:
                    address=re.findall('<p><span>(.*?)</span><br/>',text)[0]
                    print(address)
                except:
                    address=''.join(re.findall('<p><span>(.*?)</span><br/>',text,re.DOTALL))
                    print('sddresss---->',address)

                city=''.join(re.findall('</span>(.*?)&nbsp;',text,re.DOTALL))
                cit=city.split('<span>')
                city=cit[-1]
                ct=city.split(',')
                City=ct[0]

                zipcode=''.join(re.findall('&nbsp;(.*?)</span><br/>',text,re.DOTALL))
                if '.' in zipcode:
                    zipcode=''

                country=''.join(re.findall('</span><br/>(.*?)</span></p></span>',text,re.DOTALL))
                print(country)
                cont=country.split('<span>')
                country=cont[-1]

                # address = text[0].strip()
                #
                # country = text[-1].strip()
                # if country == "United States":
                #     city = text[2].strip().split(',')[-1].split()[0]
                #
                #     zipcode = text[2].strip().split(',')[-1].split()[-1]
                #
                #     try:
                #         phone_number = json.loads(response.xpath('//div[@id="brand-admin-data"]/@data-brand-list').get())
                #         phone_number = phone_number[0]['WHDI']['synxisPhoneNumber']
                #     except:
                #         phone_number = ''
                # else:
                #     city = text[2].strip().split(',')[0].strip()
                #
                #     zipcode = text[2].strip().split(',')[-1].strip()

                try:
                        # phone_number = json.loads(response.xpath('//div[@id="brand-admin-data"]/@data-brand-list').get())
                        # phone_number = phone_number[0]['WHDI']['synxisPhoneNumber']
                    phone_number=re.findall('PhoneNumber&#34;:&#34;(.*?)&#34;',response.text)[0]
                    print(phone_number)
                except:
                        phone_number = ''

                item = StoreLocatorsItem()
                item['search_term'] = 'link'
                item['store_name'] = store_name
                item['address'] = address
                item['city'] = City
                item['state'] = ''
                item['country'] = country
                item['phone_number'] = phone_number
                item['zip_code'] = zipcode
                item['coming_soon'] = 0
                item['services'] = ''
                item['country_code'] = ''
                item['source_url'] = response.url
                if store_name != '':
                    yield item


    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_120 -a list_id=120'''.split())