# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import random
import re


import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime

class Store128Spider(scrapy.Spider):
    name = 'store_128'
    allowed_domains = []


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()


    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            self.f1.set_details(self.list_id,run_date)
            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                print(search_terms)
            # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)
                search_terms = ''
                for search_term in (search_terms):
                    source_url = link = 'https://www.whitespot.ca/locations/all/'
                    file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(search_term) + '_' + str(run_date) + '.html'
                    if os.path.exists(file_path):
                        link = 'file://' + file_path.replace('\\','/')
                    yield scrapy.FormRequest(url=str(link), callback=self.first_level, meta={'source_url': source_url,'search_term': search_term,'file_path':file_path,'proxy_type': self.proxy_type})
            else:
                source_url = link = 'https://www.whitespot.ca/locations/all/'
                file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(run_date) + '.html'
                yield scrapy.FormRequest(url=str(link), callback=self.first_level,
                                         meta={'source_url': source_url, 'file_path': file_path, 'proxy_type': self.proxy_type})
        except Exception as e:
            logging.log(logging.ERROR, e)


    def first_level(self, response):
        links = response.xpath('//ul[@class="location-list"]/li/a/@href').extract()
        for link in links:
            yield scrapy.Request(url=link, callback=self.data)


    def data(self, response):
        try:store_name = 'White Sport Restaurant-'+response.xpath('//h1[@class="location__title"]/text()').extract_first()
        except Exception as e:print(e)

        try:address = response.xpath('//*[@class="location__address"]/text()').extract_first().split(',')[0].strip()
        except Exception as e:print(e)

        try:city = response.xpath('//*[@class="location__address"]/text()').extract_first().split(',')[1].strip()
        except Exception as e:print(e)

        try:zip_code = response.xpath('//*[@class="location__address"]/text()').extract_first().split(',')[-1].strip()
        except Exception as e:print(e)

        try:phone_number = response.xpath('//div[@class="location__phone"]/a/text()').extract_first()
        except Exception as e:print(e)

        try:email_address = response.xpath('//div[@class="location__email"]/a/text()').extract_first()
        except Exception as e:print(e)

        try:lat = response.xpath('//div[@class="marker"]/@data-lat').extract_first()
        except Exception as e:print(e)

        try:long = response.xpath('//div[@class="marker"]/@data-lng').extract_first()
        except Exception as e:print(e)

        try:
            store_hours = []
            store_days = response.xpath('//table[@class="location__hours"]/tr/td[1]/text()').extract()
            store_hrs = response.xpath('//table[@class="location__hours"]/tr/td[2]/text()').extract()
            for day,hr in zip(store_days, store_hrs):
                hour = str(day.strip()) + ' ' + str(hr.strip())
                store_hours.append(hour)
        except Exception as e:
            print(e)


        item = StoreLocatorsItem()
        item['search_term'] = 'link'
        item['store_name'] = store_name
        item['address'] = address
        item['city'] = city
        item['state'] = ''
        item['zip_code'] = zip_code
        item['phone_number'] = phone_number
        item['email_address'] = email_address
        item['latitude'] = lat
        item['longitude'] = long
        item['services'] = ''
        item['coming_soon'] = 0
        item['country_code'] = '' # self.f1.country_dict.get(item['country'].lower())
        item['store_hours'] = '|'.join(store_hours)
        item['source_url'] = response.url
        yield item

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_128 -a list_id=128'''.split())