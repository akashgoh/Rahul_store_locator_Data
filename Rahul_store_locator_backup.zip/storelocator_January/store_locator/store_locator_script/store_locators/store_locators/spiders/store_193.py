# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import re

import html2text
import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime
import xmltodict
import pprint
import json

class tempoeSpider(scrapy.Spider):
    name = 'store_193'
    allowed_domains = []

    f1 = Func()

    handle_httpstatus_list = [503, 403]

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        self.f1.set_details(self.list_id, run_date)
        try:
            source_url = link = 'https://tempoe.com/wp-content/plugins/superstorefinder-wp/ssf-wp-xml.php'

            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
                run_date) + '.html'
            if os.path.exists(file_path):
                link = 'file://' + file_path.replace('\\', '/')
            yield scrapy.FormRequest(url=str(link), callback=self.get_store_list,meta={'source_url': source_url,'file_path': file_path,'proxy_type': self.proxy_type})
        except Exception as e:
            print(e)

    def get_store_list(self,response):

        if not response.url.startswith('file://'):
            self.f1.page_save(response.meta['file_path'], response.body)
        source_url = response.meta.get('source_url', '')
        search_term = response.meta.get('search_term', '')

        try:
            text = xmltodict.parse(response.text.replace('New Jersey','New_Jersey'))
            texts = json.dumps(text)
            length = len(str(text).split('location'))

            # len = text['locator.store']['item']

            for store in range(0,int(length)):
                try:
                    additional_info = {}
                    item = StoreLocatorsItem()

                    item['search_term'] = search_term
                    item['store_name'] = text['locator']['store']['item'][store]['location'].encode('ascii','ignore').decode('utf8').strip()

                   # info = "2031 S. Mooney Blvd., #01425   Visalia,  CA 93277"
                    # a = text['locator']['store']['item'][store]['location']
                    # str = "6730 S RIVER ROAD   MARINE CITY,  MI 48039"

                    try:
                        strs = text['locator']['store']['item'][store]['address']

                        while "  ," in str(strs):
                            strs = str(strs).replace("  ,", ",")

                        while "   " in str(strs):
                            strs = str(strs).replace("   ", "  ")
                        try:
                            str1 = strs.rsplit(",", 1)
                            fulladdress = str1[0].rsplit("  ", 1)[0].strip()
                        except Exception as e:
                            fulladdress = ''

                        try:
                            str1 = strs.rsplit(",", 1)
                            city = str1[0].rsplit("  ", 1)[-1].strip()
                        except Exception as e:
                            city = ''
                        try:
                            str1 = strs.rsplit(",", 1)
                            state = str1[1].strip().split(" ")[0].strip()
                        except Exception as e:
                            state = ''
                        try:
                            str1 = strs.rsplit(",", 1)
                            zips = str1[1].strip().split(" ")[1].strip()
                        except Exception as E:
                            zips = ''
                    except Exception as e:
                        strs = ''
                        fulladdress = ''
                        city = ''
                        state = ''
                        zips = ''

                    # if len(info.split(',')) <= 2:
                    #     cityaddress = info.split(',')[0].strip()
                    #     state = info.split(',')[1].split()[0]
                    #     zipc = info.split(',')[1].split()[1]
                    #     city = cityaddress.split('  ')[-1]
                    # else:
                    #     cityaddress = info.split(',')[0].strip()
                    #     state = info.split(',')[-1].split()[0]
                    #     zipc = info.split(',')[-1].split()[1]
                    #     city = info.split(',')[1]


                    #''

                    try:
                        check = False
                        address = fulladdress
                        for i in ['Unit', 'Suite', 'Ste']:
                            for aw in address.split():
                                if i == aw:
                                    address1 = address.split(i)[0].strip(',')
                                    address_line_2 = i + ' ' + address.split(i)[-1].strip()
                                    check = True
                                    break

                        if check == True:
                            address_line_2 = address_line_2
                            address = address1
                        else:
                            address_line_2 = ''
                            address = address
                    except Exception as e:
                        print(e)

                    item['address'] = address.encode('ascii','ignore').decode('utf8').strip()

                    # item['address'] = address
                    # item['store_name'] = ''
                    item['address_line_2'] = address_line_2


                    # item['store_code'] = text['locator']['store']['item'][store]['storeId']
                    item['state'] = state
                    # try:
                    #     city = city.replace('  ',' ').replace('   ',' ').replace(' ',' ').strip()
                    #     city = city.replace('#120 Clearwater ','Clearwater').replace('6022 W. Crawfordsville Rd. Speedway','')
                    #     city = city.replace('#105C Carlsbad','Carlsbad').replace('#01425 Visalia','Visalia').replace('11111 San Jose Blvd. Suite 1 Jacksonville','Jacksonville')
                    #     city = city.replace('377 Sunvalley Mall Concord','Concord').replace('926 W Dallas St Buffalo','St Buffalo').replace('#351 Escondido','Escondido')
                    #     city = city.replace('3201 E. Colonial Dr.','Colonial').replace('#552 Cincinnati','Cincinnati').replace('#504 San Clemente','San Clemente')
                    #     city = city.replace('183 N Austin','Austin').replace('#1110A National City','National City').replace('#404 Modesto  ','Modesto').strip()
                    # except Exception as e:
                    #     city = ''

                    item['city'] = city
                    item['zip_code'] = zips

                    try:
                        latitude = text['locator']['store']['item'][store]['latitude']
                        longitude = text['locator']['store']['item'][store]['longitude']
                    except Exception as e:
                        latitude = ''
                        longitude = ''

                    item['latitude'] = latitude
                    item['longitude'] = longitude
                    item['store_type'] = ''
                    item['source_url'] = source_url
                    item['coming_soon'] = 0
                    item['store_number'] = ''

                    try:
                        store_code = text['locator']['store']['item'][store]['storeId']
                    except Exception as e:
                        store_code = ''
                    item['store_code'] = store_code


                    add_info = dict()
                    add_info['distance'] = ''
                    add_info['thumb'] = ''
                    add_info['description'] = ''
                    item['services'] = ''
                    item['website_address'] = 'https://tempoe.com'
                    item['country_code'] = 'US'
                    item['country'] = 'US'
                    item['number_of_store'] = '2510'

                    yield item

                except Exception as e:
                    print(e)

        except Exception as e:
            print(e)

    def response_html_path(self, request):
        return request.meta['fpath']
#
# execute('''scrapy crawl store_193 -a list_id=193'''.split())
# execute('''scrapy crawl tempoe -a list_id=193 -s HTTPCACHE_ENABLED=True'''.split())


