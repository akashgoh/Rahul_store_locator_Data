# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime
import requests
import zipcodes
import re
class Store15Spider(scrapy.Spider):
    name = 'store_15'
    allowed_domains = []


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            self.f1.set_details(self.list_id,run_date)
            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                print(search_terms)
            # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)

            else:
                source_url =link= 'https://store-locator-api.allsaints.com/shops?attributes='
                file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(run_date) + '.html'
                if os.path.exists(file_path):
                    link = 'file://' + file_path.replace('\\', '/')

                yield scrapy.FormRequest(url=source_url, callback=self.firstlevel,
                                         meta={'source_url': source_url,
                                               'file_path': file_path})
        except Exception as e:
            logging.log(logging.ERROR, e)

    # Get data from the response
    def firstlevel(self, response):
        try:
            source_url = response.meta['source_url']

            file_path = response.meta['file_path']
            #proxy_type = response.meta['proxy_type']

            l = response.body
            data = json.loads(l)
            le = len(data)
            for i in range(1, int(le)):
                country = data[i]['country_slug']
                city = data[i]['city_slug']
                name = data[i]['slug']
                link = 'https://store-locator-api.allsaints.com/' + country + '/' + city + '/' + name
                links = 'https://www.allsaints.com/store-locator/all-stores/' + country + '/' + city + '/' + name
                yield scrapy.FormRequest(url=link, callback=self.get_store_list,
                                         meta={'links': links, 'country': country, 'city': city,'source_url': source_url, 'file_path': file_path})
                # break
        except Exception as e:
            print("firstlevel", e, response.url)

    def get_store_list(self, response):
        try:
            if not response.url.startswith('file://'):

                self.f1.page_save(response.meta['file_path'],response.body)

            search_term = response.meta.get('search_term', '')
            source_url = response.meta.get('links', '')
            store = json.loads(response.text)

            # If you have search_by :zip_code/city/state/lat_lng then you need to add following condition and query to update log table
            additional_info = {}
            item = StoreLocatorsItem()

            item['search_term'] = 'link'
            item['store_name']= store.get('name','')
            add=store.get('address_line1', '')
            add2=store.get('address_line2', '')
            if add2!=None:
                ad=add+','+add2
            else:
                ad=add
            try:
                if ',' in ad:
                    add=ad.split(',')
                    addd=[]
                    for ads in add:

                        if 'floor' in ads.lower() or 'unit' in ads.lower() or 'level' in ads.lower():
                            item['address_line_2'] = ads.strip()
                        else:
                            addd.append(ads)
                    item['address']=' '.join(addd)

                else:
                    item['address'] =ad
                    item['address_line_2']=''
                    item['address_line_3'] = ''

            except Exception as e:
                print(e)
            l=len(item['address'])
            if l <8:
                item['address']=item['address']+' '+item['address_line_2']


            item['city'] = store.get('city','')
            item['state'] = store.get('state','')
            try:
                item['zip_code'] = store.get('post_code','').replace('-','').split(',')[-1].split('(')[0].replace('.','').replace('ON','').strip()
            except Exception as e:
                item['zip_code'] = store.get('address_line3','').split(',')[1]
            item['phone_number'] = store.get('phone','')
            item['latitude'] = store['coordinates']['latitude']



            item['longitude']=store['coordinates']['longitude']
            item['store_type'] = store.get('storeType', '')
            item['website_address'] = source_url
            item['coming_soon'] = 0
            item['phone_number'] = store['phone_number'].strip()
            item['store_number'] = store.get('id','')
            item['country'] = store.get('country').split(',')[-1].replace('Republic of Ireland','Ireland').replace('UAE','united arab emirates').strip() #
            item['country_code'] =self.f1.country_dict.get((item['country'].lower()))
            item['email_address'] = store.get('email','')
            item['services'] = ''
            if 'USA' in item['country']:
                item['country_code']='US'
            if item['country_code'] == 'US':
                zi = zipcodes.matching(''.join(re.findall('(\d+)',item['zip_code'])))
                state=''.join(re.findall("state': '(\w+)',",str(zi)))
                item['state'] = state
                # city = ''.join(re.findall("city': '(.*?)',", str(zi)))
                item['city'] = store.get('city', '')
                # item['city']=city
            try:
                item['zip_code'] = store.get('post_code', '').replace('-', '').split(',')[-1].split('(')[0].replace('.','').replace('ON', '').replace(''+str(item['state'])+'','').strip()
            except Exception as e:
                item['zip_code'] = store.get('address_line3','').split(',')[1]
            location_type = store.get('locationType','')
            item['address'] = item['address'].replace('' + item['city'] + '', '').replace('' + item['state'] + '', '').replace(''+item['zip_code']+'','').replace(''+item['country']+'','').replace(''+item['country_code']+'','')
            try:item['address_line_2'] = item['address_line_2'].replace('' + item['city'] + '', '').replace('' + item['state'] + '', '').replace(''+item['zip_code']+'','').replace(''+item['country']+'','').replace(''+item['country_code']+'','')
            except:item['address_line_2']=''

            hrs = []
            days = store['opening_hours']
            for d in days:
                try:
                    open = store['opening_hours'][d][0]['open']
                    close = store['opening_hours'][d][0]['close']
                    if open == None:
                        open = 'close'
                        day = str(d) + ':' + str(open)
                        hrs.append(day)
                    else:
                        # day = str(d) + ':' + str(open)
                        # hrs.append(day)
                        day = str(d) + ':' + str(open) + '-' + str(close)
                        hrs.append(day)
                except Exception as e:
                    print(e)
                    hrs=''
            item['store_hours'] = '|'.join(hrs)
            item['additional_info'] = json.dumps(additional_info, ensure_ascii=False)

            item['number_of_store'] = 262

            yield item
        except Exception as e:
            print(e)

        # except Exception as e:
        #     logging.log(logging.ERROR, e)

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_15 -a list_id=15 -a proxy_type=storm_proxy'''.split())
# execute('''scrapy crawl bestbuy_crawler -a list_id=49 -a proxy_type=storm_proxy -s CONCURRENT_REQUESTS=16 -s DOWNLOAD_DELAY=3'''.split())