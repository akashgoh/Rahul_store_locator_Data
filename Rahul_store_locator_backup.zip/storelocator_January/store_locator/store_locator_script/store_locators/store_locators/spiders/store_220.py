# -*- coding: utf-8 -*-
import datetime
import json
import re

import scrapy

from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func


class StanleysteemerSpider(scrapy.Spider):
    name = 'stanleysteemer'
    allowed_domains = ['stanleysteemer.com']
    start_urls = ['https://www.stanleysteemer.com/sitemap/sitemap.xml']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]

    def parse(self, response):
        self.f1.set_details(self.list_id, self.run_date)

        links = re.findall(r"<loc>(.*)</loc>", response.text)

        for link in links:
            if "location-details/" in link:
                yield scrapy.Request(
                    url=link,
                    callback=self.stores
                )

    def stores(self, response):

        item = StoreLocatorsItem()
        address = response.xpath('//h2[contains(text(), "Contact")]/following-sibling::text()').get('').split(', ')

        if len(address) == 0:
            item['address'] = ""
            item['address_line_2'] = ""

        if len(address) == 1:
            item['address'] = address[0].strip()
            item['address_line_2'] = ""

        if len(address) == 2:
            item['address'] = address[0].strip()
            item['address_line_2'] = address[1].strip()

        if 'Ste ' in item['address']:
            address = item['address'].split('Ste ')
            item['address'] = address[0].strip()
            item['address_line_2'] = f"Ste {address[1].strip()}"

        item['zip_code'] = response.xpath('//*[@id="locZipcode"]/text()').get('').strip()
        item['state'] = response.xpath('//*[@id="locState"]/text()').get('').strip()
        item['city'] = response.xpath('//*[@id="locCity"]/text()').get('').strip()

        item['store_name'] = response.xpath('//h1/text()').get('').strip()
        item['services'] = "|".join(response.xpath('//*[contains(text(), "Services Offered")]/following-sibling::ul/*[@class="bookmark-content is-active"]//ul//li/text()').getall())
        item['source_url'] = response.url
        item['country'] = item['country_code'] = "US"
        item['phone_number'] = response.xpath('//ul//a[contains(@href, "tel:")]/text()').get()
        item['store_hours'] = "|".join(response.xpath('//*[@class="store-hours"]//li/text()').getall()).strip()
        item['additional_info'] = json.dumps(
            {
                "fb_link": response.xpath('//ul//a[contains(@href, "facebook")]/@href').get('').strip()
            }
        )
        if item['store_name'] != "":
            yield item


# execute("scrapy crawl stanleysteemer -a list_id=220".split())
