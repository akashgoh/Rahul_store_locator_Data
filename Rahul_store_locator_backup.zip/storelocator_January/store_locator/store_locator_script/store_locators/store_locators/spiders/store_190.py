# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import re

import html2text
import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime


class store190Spider(scrapy.Spider):
    name = 'store_190'
    allowed_domains = []
    start_urls =['http://www.teuscherswisschocolates-sf.com/category-s/117.htm']
    f1 = Func()

    def __init__(self, name=None, list_id="",proxy_type="",**kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type= list_id, proxy_type

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            source_url = link = 'http://www.teuscherswisschocolates-sf.com/category-s/117.htm'
            self.f1.set_details(self.list_id, run_date)
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
                run_date) + '.html'
            if os.path.exists(file_path):
                link = 'file://' + file_path.replace('\\', '/')
            yield scrapy.FormRequest(url=str(source_url), callback=self.get_store_list,meta={'source_url': source_url,'file_path': file_path,'proxy_type': self.proxy_type})
        except Exception as e:
            print(e)

    def get_store_list(self,response):
        # if not response.url.startswith('file://'):
        self.f1.page_save(response.meta['file_path'], response.body)
        source_url = response.meta.get('source_url', '')
        a = response.url.split('/')[-1]
        try:
            item = StoreLocatorsItem()

            store_name = response.xpath('//li[@class="content-text__item content-text__item--title"]//text()').getall()
            store_name.insert(-1,'MUNICH, GERMANY')
            # store_name.insert('')
            if 'MUNICH, GERMANY' in store_name:
                item['store_name'] = 'teuscher - MUNICH, GERMANY'
                item['address'] = 'Theatinerstrasse 12'
                item['address_line_2'] = ''
                item['city'] = 'Munich'
                item['state'] = ''
                item['zip_code'] = '80333  '
                item['phone_number'] = '+89 4625 4100'
                item['fax_number'] = ''
                item['email_address'] = 'muenchen@teuscher-zurich.ch'
                item['store_type'] = ''
                item['website_address'] = 'https://www.teuscher.com/'
                item['coming_soon'] = 0
                item['store_number'] = ''
                item['country'] = ''
                item['source_url'] = 'http://www.teuscherswisschocolates-sf.com/category-s/117.htm'
                item['country_code'] = ''
                item['store_hours'] = ''
                add_info = dict()
                add_info['distance'] = ''
                add_info['thumb'] = ''
                add_info['description'] = ''
                item['additional_info'] = ''
                yield item

            if 'Beverly Hills, CA' in store_name:
                item['store_name'] = 'teuscher - Beverly Hills'
                item['address'] = '371 N. Camden Drive.'
                item['address_line_2'] = ''
                item['city'] = 'Beverly Hills'
                item['state'] = 'CA'
                item['zip_code'] = '90210 '
                item['phone_number'] = '(833) 247-9477'
                item['fax_number'] = ''
                item['email_address'] = 'tom@beverlyhillsteuscher.com'
                item['store_type'] = ''
                item['website_address'] = 'https://www.teuscher.com/'
                item['coming_soon'] = 0
                item['store_number'] = ''
                item['country'] = 'US'
                item['source_url'] = 'http://www.teuscherswisschocolates-sf.com/category-s/117.htm'
                item['country_code'] = 'US'
                item['store_hours'] = 'Monday–Saturday 10am–6pm | Sunday 11am-5pm'
                add_info = dict()
                add_info['distance'] = ''
                add_info['thumb'] = ''
                add_info['description'] = ''
                item['additional_info'] = ''
                yield item

            if 'Chicago, IL' in store_name:
                item['store_name'] = 'teuscher - CHICAGO, IL'
                item['address'] = '900 North Michigan Avenue'
                item['address_line_2'] = ''
                item['city'] = 'Chicago'
                item['state'] = 'IL'
                item['zip_code'] = '60611 '
                item['phone_number'] = '(312) 943 4400'
                item['fax_number'] = '(312) 943 4900'
                item['email_address'] = 'info@teuscherchicago.com'
                item['store_type'] = ''
                item['website_address'] = 'https://www.teuscher.com/'
                item['coming_soon'] = 0
                item['store_number'] = ''
                item['country'] = 'US'
                item['source_url'] = response.url
                item['country_code'] = 'US'
                item['store_hours'] = 'Monday–Saturday 10am–7pm | Sunday 12pm–6pm'
                add_info = dict()
                add_info['distance'] = ''
                add_info['thumb'] = ''
                add_info['description'] = ''
                item['additional_info'] = ''
                yield item

            if 'New York – Madison Avenue' in store_name:
                item['store_name'] = 'teuscher - New York – Madison Avenue'
                item['address'] = '25 East 61st Street'
                item['address_line_2'] = ''
                item['city'] = 'New York'
                item['state'] = 'NY'
                item['zip_code'] = '10021 '
                item['phone_number'] = '(800) 554-0624'
                item['fax_number'] = '(212) 751-0723'
                item['email_address'] = 'madisonavenue@teuscher.com'
                item['store_type'] = ''
                item['website_address'] = 'https://www.teuscher.com/'
                item['coming_soon'] = 0
                item['store_number'] = ''
                item['country'] = 'US'
                item['source_url'] = response.url
                item['country_code'] = 'US'
                item['store_hours'] = 'Monday–Saturday 10am–6pm'
                add_info = dict()
                add_info['distance'] = ''
                add_info['thumb'] = ''
                add_info['description'] = ''
                item['additional_info'] = ''
                yield item

            if 'Toronto, Canada' in store_name:
                item['store_name'] = 'teuscher - Toronto, Canada'
                item['address'] = '55 Bloor St. West'
                item['address_line_2'] = ''
                item['city'] = 'Toronto'
                item['state'] = 'ON'
                item['zip_code'] = 'M4W 3V1 '
                item['phone_number'] = '(416) 964 8200'
                item['fax_number'] = ''
                item['email_address'] = 'teuscher@williamashley.com'
                item['store_type'] = ''
                item['website_address'] = 'https://www.teuscher.com/'
                item['coming_soon'] = 0
                item['store_number'] = ''
                item['country'] = 'US'
                item['source_url'] = response.url
                item['country_code'] = 'US'
                item['store_hours'] = 'Monday–Wednesday 10:00–18:00 | Thursday–Friday 10:00–19:30 | Saturday 10:00–18:00 | Sunday Closed'
                add_info = dict()
                add_info['distance'] = ''
                add_info['thumb'] = ''
                add_info['description'] = ''
                item['additional_info'] = ''
                yield item

            if 'Boston, MA' in store_name:
                item['store_name'] = 'teuscher - BOSTON, MA'
                item['address'] = '230 Newbury Street'
                item['address_line_2'] = ''
                item['city'] = 'Boston'
                item['state'] = 'MA'
                item['zip_code'] = '02116 '
                item['phone_number'] = '617-536-1922'
                item['fax_number'] = '(617) 536 1787'
                item['email_address'] = 'teuscher.chocolates@verizon.net'
                item['store_type'] = ''
                item['website_address'] = 'https://www.teuscher.com/'
                item['coming_soon'] = 0
                item['store_number'] = ''
                item['country'] = 'US'
                item['source_url'] = response.url
                item['country_code'] = 'US'
                item['store_hours'] = 'Monday–Saturday 11am–7pm | Sunday 12pm– 5pm'
                add_info = dict()
                add_info['distance'] = ''
                add_info['thumb'] = ''
                add_info['description'] = ''
                item['additional_info'] = ''
                yield item

            if 'Berlin, Germany' in store_name:
                item['store_name'] = 'teuscher - Berlin, Germany'
                item['address'] = 'Tauentzienstrasse 21-24, 6th Floor'
                item['address_line_2'] = ''
                item['city'] = 'Berlin'
                item['state'] = ''
                item['zip_code'] = '10789 '
                item['phone_number'] = '++(49) 30 2121 2251'
                item['fax_number'] = ''
                item['email_address'] = ''
                item['store_type'] = ''
                item['website_address'] = 'https://www.teuscher.com/'
                item['coming_soon'] = 0
                item['store_number'] = ''
                item['country'] = 'US'
                item['source_url'] = response.url
                item['country_code'] = 'US'
                item['store_hours'] = 'Monday–Friday 10:00–20:00 | Saturday 9:30–20:00 | Sunday Closed'
                add_info = dict()
                add_info['distance'] = ''
                add_info['thumb'] = ''
                add_info['description'] = ''
                item['additional_info'] = ''
                yield item

            if 'ASERBAIDJAN' in store_name:
                item['store_name'] = 'teuscher - ASERBAIDJAN'
                item['address'] = '5 Niyazi St.'
                item['address_line_2'] = ''
                item['city'] = ''
                item['state'] = ''
                item['zip_code'] = '1004 '
                item['phone_number'] = ' +994 12 492 5141'
                item['fax_number'] = ''
                item['email_address'] = 'info@teuscherbaku.az'
                item['store_type'] = ''
                item['website_address'] = 'https://www.teuscher.com/'
                item['coming_soon'] = 0
                item['store_number'] = ''
                item['country'] = ''
                item['source_url'] = response.url
                item['country_code'] = ''
                item['store_hours'] = 'Daily 10:00–20:00'
                add_info = dict()
                add_info['distance'] = ''
                add_info['thumb'] = ''
                add_info['description'] = ''
                item['additional_info'] = ''
                yield item

            if 'Philadelphia, PA' in store_name:
                item['store_name'] = 'teuscher - Philadelphia, PA'
                item['address'] = '200 South Broad Street'
                item['address_line_2'] = ''
                item['city'] = 'Philadelphia'
                item['state'] = 'PA'
                item['zip_code'] = '19102 '
                item['phone_number'] = ' (215) 546-7600'
                item['fax_number'] = ''
                item['email_address'] = 'info@teuschernyc.com'
                item['store_type'] = ''
                item['website_address'] = 'https://www.teuscher.com/'
                item['coming_soon'] = 0
                item['store_number'] = ''
                item['country'] = 'US'
                item['source_url'] = response.url
                item['country_code'] = 'US'
                item['store_hours'] = 'Monday–Saturday 10am–6pm | Sunday 12pm–5pm'
                add_info = dict()
                add_info['distance'] = ''
                add_info['thumb'] = ''
                add_info['description'] = ''
                item['additional_info'] = ''
                yield item

            if 'San Diego, CA' in store_name:
                item['store_name'] = 'teuscher - SAN DIEGO, CA'
                item['address'] = '7863 Girard Ave #204'
                item['address_line_2'] = ''
                item['city'] = 'La Jolla'
                item['state'] = 'CA'
                item['zip_code'] = '92037 '
                item['phone_number'] = '(858) 230-6337'
                item['fax_number'] = ''
                item['email_address'] = 'teuschersandiego@gmail.com'
                item['store_type'] = ''
                item['website_address'] = 'https://www.teuscher.com/'
                item['coming_soon'] = 0
                item['store_number'] = ''
                item['country'] = 'US'
                item['source_url'] = response.url
                item['country_code'] = 'US'
                item['store_hours'] = 'Monday  by appointment | Tuesday to Sunday: 1 to 4pm'
                add_info = dict()
                add_info['distance'] = ''
                add_info['thumb'] = ''
                add_info['description'] = ''
                item['additional_info'] = ''
                yield item

            if 'San Francisco, CA' in store_name:
                item['store_name'] = 'teuscher - San Francisco, CA'
                item['address'] = '307 Sutter St'
                item['address_line_2'] = ''
                item['city'] = 'San Francisco'
                item['state'] = 'CA'
                item['zip_code'] = '94108 '
                item['phone_number'] = '(415) 834 0850'
                item['fax_number'] = '(415) 834 0860'
                item['email_address'] = 'info@teuschersf.com'
                item['store_type'] = ''
                item['website_address'] = 'https://www.teuscher.com/'
                item['coming_soon'] = 0
                item['store_number'] = ''
                item['country'] = 'US'
                item['source_url'] = response.url
                item['country_code'] = 'US'
                item['store_hours'] = 'Tuesday-Saturday 12:00pm-5:00Pm | Sunday-Monday Closed'
                add_info = dict()
                add_info['distance'] = ''
                add_info['thumb'] = ''
                add_info['description'] = ''
                item['additional_info'] = ''
                yield item

            if 'Geneva, Switzerland' in store_name:
                item['store_name'] = 'teuscher - Geneva, Switzerland'
                item['address'] = 'Rue de la Corraterie 16 1204 Geneva'
                item['address_line_2'] = ''
                item['city'] = ''
                item['state'] = ''
                item['zip_code'] = ' '
                item['phone_number'] = '++41 (022) 310 8778'
                item['fax_number'] = '++41 (022) 310 8779'
                item['email_address'] = 'teuscher.geneve@bluewin.ch'
                item['store_type'] = ''
                item['website_address'] = 'https://www.teuscher.com/'
                item['coming_soon'] = 0
                item['store_number'] = ''
                item['country'] = 'US'
                item['source_url'] = response.url
                item['country_code'] = 'US'
                item['store_hours'] = 'Monday 10:00–18:30 | Tuesday–Friday 9:30–18:30 | Saturday 9:30–17:30'
                add_info = dict()
                add_info['distance'] = ''
                add_info['thumb'] = ''
                add_info['description'] = ''
                item['additional_info'] = ''
                yield item

            if 'Zürich, Switzerland' in store_name:
                for i in range(1,4):
                    if i==1:
                        item['store_name'] = 'teuscher - ZÜRICH, SWITZERLAND'
                        item['address'] = 'Storchengasse 9'
                        item['address_line_2'] = ''
                        item['city'] = 'Zurich'
                        item['state'] = ''
                        item['zip_code'] = '8001 '
                        item['phone_number'] = '++41 (044) 211 5153'
                        item['fax_number'] = '++41 (044) 212 2958'
                        item['email_address'] = 'teuscher.zuerich@teuscher.com'
                        item['store_type'] = ''
                        item['website_address'] = 'https://www.teuscher.com/'
                        item['coming_soon'] = 0
                        item['store_number'] = ''
                        item['country'] = 'US'
                        item['source_url'] = response.url
                        item['country_code'] = 'US'
                        item['store_hours'] = 'Monday–Friday 9am–7pm | Saturday 10am –6pm | Sunday 4pm–6pm'
                        add_info = dict()
                        add_info['distance'] = ''
                        add_info['thumb'] = ''
                        add_info['description'] = ''
                        item['additional_info'] = ''
                        yield item
                    if i==2:
                        item['store_name'] = 'teuscher - ZÜRICH, SWITZERLAND'
                        item['address'] = 'Bellevueplatz 5'
                        item['address_line_2'] = ''
                        item['city'] = 'Zurich'
                        item['state'] = ''
                        item['zip_code'] = '8001 '
                        item['phone_number'] = '+41 (044) 251 80 60'
                        item['fax_number'] = '+41 (044) 251 80 91'
                        item['email_address'] = 'info@felixambellevue.ch'
                        item['store_type'] = ''
                        item['website_address'] = 'https://www.teuscher.com/'
                        item['coming_soon'] = 0
                        item['store_number'] = ''
                        item['country'] = 'US'
                        item['source_url'] = response.url
                        item['country_code'] = 'US'
                        item['store_hours'] = 'Monday–Thursday 7:30–21:00 | Friday 7:30–22: 00 (Nov.+Dez. 23:00) | Saturday 8:00–22:00 (Nov.+Dez. 23:00) | Sunday 9:00–20:00 (Dez. 22:00)'
                        add_info = dict()
                        add_info['distance'] = ''
                        add_info['thumb'] = ''
                        add_info['description'] = ''
                        item['additional_info'] = ''
                        yield item

                    if i==3:
                        item['store_name'] = 'teuscher - ZÜRICH, SWITZERLAND'
                        item['address'] = 'Bahnhofstrasse 46 – CH-8001 Zürich'
                        item['address_line_2'] = ''
                        item['city'] = ''
                        item['state'] = ''
                        item['zip_code'] = ''
                        item['phone_number'] = '++41(044) 211 13 90'
                        item['fax_number'] = '++41(044)212 29 58'
                        item['email_address'] = ''
                        item['store_type'] = ''
                        item['website_address'] = 'https://www.teuscher.com/'
                        item['coming_soon'] = 0
                        item['store_number'] = ''
                        item['country'] = 'US'
                        item['source_url'] = response.url
                        item['country_code'] = 'US'
                        item['store_hours'] = 'Monday–Wednesday 9am–7pm | Thursday–Friday 9am–8pm | Saturday 9am–6pm | Sunday 1pm–4pm'
                        add_info = dict()
                        add_info['distance'] = ''
                        add_info['thumb'] = ''
                        add_info['description'] = ''
                        item['additional_info'] = ''
                        yield item

            if 'New York – Fifth Avenue ' in store_name:
                item['store_name'] = 'teuscher - New York – Fifth Avenue'
                item['address'] = '620 Fifth Avenue'
                item['address_line_2'] = ''
                item['city'] = 'New York'
                item['state'] = 'NY'
                item['zip_code'] = '10020'
                item['phone_number'] = '(212) 246 4416'
                item['fax_number'] = '(212) 765 8134'
                item['email_address'] = 'fifthavenue@teuscher.com'
                item['store_type'] = ''
                item['website_address'] = 'https://www.teuscher.com/'
                item['coming_soon'] = 0
                item['store_number'] = ''
                item['country'] = 'US'
                item['source_url'] = response.url
                item['country_code'] = 'US'
                item['store_hours'] = 'Monday–Wednesday 10am–6pm | Thursday 10am–7pm | Friday–Saturday 10am–6pm  | Sunday 11am–5:30pm'
                add_info = dict()
                add_info['distance'] = ''
                add_info['thumb'] = ''
                add_info['description'] = ''
                item['additional_info'] = ''
                yield item

            if 'Abu Dhabi' in store_name:
                item['store_name'] = 'teuscher - Abu Dhabi'
                item['address'] = 'Nation Galleria, Corniche'
                item['address_line_2'] = ''
                item['city'] = 'Abu Dhabi'
                item['state'] = ''
                item['zip_code'] = ''
                item['phone_number'] = '00971 2 681 1108'
                item['fax_number'] = '00971 2 681 1107'
                item['email_address'] = 'info@teuscherabudhabi.com'
                item['store_type'] = ''
                item['website_address'] = 'https://www.teuscher.com/'
                item['coming_soon'] = 0
                item['store_number'] = ''
                item['country'] = 'US'
                item['source_url'] = response.url
                item['country_code'] = 'US'
                item['store_hours'] = 'Sunday–Wednesday 10am–10pm | Thursday–Saturday 10am–12 Midnight'
                add_info = dict()
                add_info['distance'] = ''
                add_info['thumb'] = ''
                add_info['description'] = ''
                item['additional_info'] = ''
                yield item

            if 'Tokyo, Japan' in store_name:
                item['store_name'] = 'teuscher - Tokyo, Japan'
                item['address'] = 'Takashimaya Dept. Store Nihombashi International Gourmet Dept.'
                item['address_line_2'] = ''
                item['city'] = ''
                item['state'] = ''
                item['zip_code'] = ''
                item['phone_number'] = ''
                item['fax_number'] = ''
                item['email_address'] = ''
                item['store_type'] = ''
                item['website_address'] = 'https://www.teuscher.com/'
                item['coming_soon'] = 0
                item['store_number'] = ''
                item['country'] = ''
                item['source_url'] = response.url
                item['country_code'] = ''
                item['store_hours'] = ''
                add_info = dict()
                add_info['distance'] = ''
                add_info['thumb'] = ''
                add_info['description'] = ''
                item['additional_info'] = ''
                yield item

            if 'Shanghai, China' in store_name:
                item['store_name'] = 'teuscher - Shanghai, China'
                item['address'] = '2nd Floor #213 99 Beijing East Road'
                item['address_line_2'] = ''
                item['city'] = 'Huangpu'
                item['state'] = 'Shanghai'
                item['zip_code'] = ''
                item['phone_number'] = '+86 21 5035 0557'
                item['fax_number'] = '+86 21 5035 0557'
                item['email_address'] = ''
                item['store_type'] = ''
                item['website_address'] = 'https://www.teuscher.com/'
                item['coming_soon'] = 0
                item['store_number'] = ''
                item['country'] = ''
                item['source_url'] = response.url
                item['country_code'] = ''
                item['store_hours'] = 'Monday–Saturday 10am–11pm'
                add_info = dict()
                add_info['distance'] = ''
                add_info['thumb'] = ''
                add_info['description'] = ''
                item['additional_info'] = ''
                yield item

            if 'South Korea' in store_name:
                item['store_name'] = 'teuscher - South Korea'
                item['address'] = 'Ground floor, 66 Suha-Dong, Jung-Gu, Seoul'
                item['address_line_2'] = ''
                item['city'] = ''
                item['state'] = ''
                item['zip_code'] = ''
                item['phone_number'] = '82-2-755-5004'
                item['fax_number'] = '82-2-755-5004'
                item['email_address'] = ''
                item['store_type'] = ''
                item['website_address'] = 'https://www.teuscher.com/'
                item['coming_soon'] = 0
                item['store_number'] = ''
                item['country'] = ''
                item['source_url'] = response.url
                item['country_code'] = ''
                item['store_hours'] = 'Monday–Saturday 10:00am–7:30pm'
                add_info = dict()
                add_info['distance'] = ''
                add_info['thumb'] = ''
                add_info['description'] = ''
                item['additional_info'] = ''
                yield item

            if 'Doha,KATAR' in store_name:
                item['store_name'] = 'teuscher - Doha,KATAR'
                item['address'] = ''
                item['address_line_2'] = ''
                item['city'] = 'Doha'
                item['state'] = 'KATAR'
                item['zip_code'] = ''
                item['phone_number'] = ''
                item['fax_number'] = ''
                item['email_address'] = ''
                item['store_type'] = ''
                item['website_address'] = 'https://www.teuscher.com/'
                item['coming_soon'] = 1
                item['store_number'] = ''
                item['country'] = ''
                item['source_url'] = response.url
                item['country_code'] = ''
                item['store_hours'] = ''
                add_info = dict()
                add_info['distance'] = ''
                add_info['thumb'] = ''
                add_info['description'] = ''
                item['additional_info'] = ''
                yield item

            if 'RIYADH, SAUDI ARABIA' in store_name:
                item['store_name'] = 'teuscher - RIYADH, SAUDI ARABIA'
                item['address'] = ''
                item['address_line_2'] = ''
                item['city'] = 'RIYADH'
                item['state'] = 'SAUDI ARABIA'
                item['zip_code'] = ''
                item['phone_number'] = ''
                item['fax_number'] = ''
                item['email_address'] = ''
                item['store_type'] = ''
                item['website_address'] = 'https://www.teuscher.com/'
                item['coming_soon'] = 1
                item['store_number'] = ''
                item['country'] = ''
                item['source_url'] = response.url
                item['country_code'] = ''
                item['store_hours'] = ''
                add_info = dict()
                add_info['distance'] = ''
                add_info['thumb'] = ''
                add_info['description'] = ''
                item['additional_info'] = ''
                yield item

            else:
                item['store_name'] = 'teuscher - MUNICH, GERMANY'
                item['address'] = 'Theatinerstrasse 12'
                item['address_line_2'] = ''
                item['city'] = 'Munich'
                item['state'] = ''
                item['zip_code'] = '80333 '
                item['phone_number'] = '+89 4625 4100'
                item['fax_number'] = ''
                item['email_address'] = 'muenchen@teuscher-zurich.ch'
                item['store_type'] = ''
                item['website_address'] = 'https://www.teuscher.com/'
                item['coming_soon'] = 0
                item['store_number'] = ''
                item['country'] = ''
                item['source_url'] = response.url
                item['country_code'] = ''
                item['store_hours'] = ''
                add_info = dict()
                add_info['distance'] = ''
                add_info['thumb'] = ''
                add_info['description'] = ''
                item['additional_info'] = ''
                yield item
        except Exception as e:
            print(e)

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_190 -a list_id=190 -s HTTPCACHE_ENABLED=False'''.split())