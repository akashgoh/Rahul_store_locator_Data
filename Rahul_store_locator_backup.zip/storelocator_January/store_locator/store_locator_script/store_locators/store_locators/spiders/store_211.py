# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import re
import urllib

import scrapy,os,logging,hashlib
import requests,json
from lxml import html
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime


class stroeckSpider(scrapy.Spider):
    name = 'store_211'
    allowed_domains = []
    not_export_data = False
    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):

        try:

            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                print(search_terms)
            # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)
                search_terms = ''
                for search_term in (search_terms):
                    source_url = link = 'https://stretchlab.com/locations/'
                    file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(search_term) + '_' + str(self.run_date) + '.html'
                    if os.path.exists(file_path):
                        link = 'file://' + file_path.replace('\\','/')
                    yield scrapy.FormRequest(url=str(link), callback=self.get_store_list, meta={'source_url': source_url,'search_term': search_term,'file_path':file_path,'proxy_type': self.proxy_type})
            else:

                source_url = link = 'https://cms.stroeck.at/wp-json/strk/v1/filialen/'
                file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
                    self.run_date) + '.html'
                yield scrapy.FormRequest(url=str(link), callback=self.get_store_list,
                                         meta={'source_url': source_url,
                                               'file_path': file_path, 'proxy_type': self.proxy_type})

        except Exception as e:
            logging.log(logging.ERROR, e)



    # Get data from the response
    def get_store_list(self, response):
        try:
            if not response.url.startswith('file://'):
                self.f1.page_save(response.meta['file_path'], response.body)


            try:
                store_data = json.loads(response.text)
                le = len(store_data['data']['items'])
                for i in range(0, le):
                    # break
                    try:
                        store_name = store_data['data']['items'][i]['props']['title']
                    except Exception as e:
                        print("store_name", e, response.url)

                    try:
                        phone_number = store_data['data']['items'][i]['props']['phone']
                    except Exception as e:
                        print("phonenumber", e, response.url)

                    try:
                        latitude = store_data['data']['items'][i]['props']['gmaps']['placeData']['geometry']['location']['lat']
                        longitude =store_data['data']['items'][i]['props']['gmaps']['placeData']['geometry']['location']['lng']
                    except Exception as e:
                        print("latitude and longitude", e, response.url)

                    try:
                        city= store_data['data']['items'][i]['props']['city']
                    except Exception as e:
                        print("city", e, response.url)

                    try:
                        zipcode = store_data['data']['items'][i]['props']['zip']
                    except Exception as e:
                        print("zipcode", e, response.url)

                    try:
                        address = store_data['data']['items'][i]['props']['address']
                    except Exception as e:
                        print("address", e, response.url)

                    try:

                        slug= store_data['data']['items'][i]['props']['link']['params']['slug']
                        url ="https://stroeck.at/de/filialen/"+slug
                    except Exception as e:
                        print("slug")


                    try:

                        store_hourslist = []
                        if len(store_data['data']['items'][i]['props']['openingHours']['periods']) == 0:
                            store_hours = ''

                        else:
                            if len(store_data['data']['items'][i]['props']['openingHours']['periods']) == 7:
                                end_sat = store_data['data']['items'][i]['props']['openingHours']['periods'][5]['close']['time']
                                start_sat =  store_data['data']['items'][i]['props']['openingHours']['periods'][5]['open']['time']
                                end_sun =store_data['data']['items'][i]['props']['openingHours']['periods'][6]['close']['time']
                                start_sun =  store_data['data']['items'][i]['props']['openingHours']['periods'][6]['open']['time']
                                end_mon = store_data['data']['items'][i]['props']['openingHours']['periods'][0]['close']['time']
                                start_mon =  store_data['data']['items'][i]['props']['openingHours']['periods'][0]['open']['time']
                                end_tue = store_data['data']['items'][i]['props']['openingHours']['periods'][1]['close']['time']
                                start_tue = store_data['data']['items'][i]['props']['openingHours']['periods'][1]['open']['time']
                                end_wed = store_data['data']['items'][i]['props']['openingHours']['periods'][2]['close']['time']
                                start_wed =  store_data['data']['items'][i]['props']['openingHours']['periods'][2]['open']['time']
                                end_thu = store_data['data']['items'][i]['props']['openingHours']['periods'][3]['close']['time']
                                start_thu =  store_data['data']['items'][i]['props']['openingHours']['periods'][3]['open']['time']
                                end_fri =store_data['data']['items'][i]['props']['openingHours']['periods'][4]['close']['time']
                                start_fri =  store_data['data']['items'][i]['props']['openingHours']['periods'][4]['open']['time']
                            elif len(store_data['data']['items'][i]['props']['openingHours']['periods']) == 5:
                                start_sun = ""
                                start_sat = ""
                                end_mon = store_data['data']['items'][i]['props']['openingHours']['periods'][0]['close'][
                                    'time']
                                start_mon = store_data['data']['items'][i]['props']['openingHours']['periods'][0]['open'][
                                    'time']
                                end_tue = store_data['data']['items'][i]['props']['openingHours']['periods'][1]['close'][
                                    'time']
                                start_tue = store_data['data']['items'][i]['props']['openingHours']['periods'][1]['open'][
                                    'time']
                                end_wed = store_data['data']['items'][i]['props']['openingHours']['periods'][2]['close'][
                                    'time']
                                start_wed = store_data['data']['items'][i]['props']['openingHours']['periods'][2]['open'][
                                    'time']
                                end_thu = store_data['data']['items'][i]['props']['openingHours']['periods'][3]['close'][
                                    'time']
                                start_thu = store_data['data']['items'][i]['props']['openingHours']['periods'][3]['open'][
                                    'time']
                                end_fri = store_data['data']['items'][i]['props']['openingHours']['periods'][4]['close'][
                                    'time']
                                start_fri = store_data['data']['items'][i]['props']['openingHours']['periods'][4]['open'][
                                    'time']
                            else:
                                end_sat = store_data['data']['items'][i]['props']['openingHours']['periods'][5]['close'][
                                    'time']
                                start_sat = store_data['data']['items'][i]['props']['openingHours']['periods'][5]['open'][
                                    'time']
                                start_sun = ''
                                end_mon = store_data['data']['items'][i]['props']['openingHours']['periods'][0]['close'][
                                    'time']
                                start_mon = store_data['data']['items'][i]['props']['openingHours']['periods'][0]['open'][
                                    'time']
                                end_tue = store_data['data']['items'][i]['props']['openingHours']['periods'][1]['close'][
                                    'time']
                                start_tue = store_data['data']['items'][i]['props']['openingHours']['periods'][1]['open'][
                                    'time']
                                end_wed = store_data['data']['items'][i]['props']['openingHours']['periods'][2]['close'][
                                    'time']
                                start_wed = store_data['data']['items'][i]['props']['openingHours']['periods'][2]['open'][
                                    'time']
                                end_thu = store_data['data']['items'][i]['props']['openingHours']['periods'][3]['close'][
                                    'time']
                                start_thu = store_data['data']['items'][i]['props']['openingHours']['periods'][3]['open'][
                                    'time']
                                end_fri = store_data['data']['items'][i]['props']['openingHours']['periods'][4]['close'][
                                    'time']
                                start_fri = store_data['data']['items'][i]['props']['openingHours']['periods'][4]['open'][
                                    'time']


                            if len(start_sun)>=1:

                                day_sun = "Sunday: " + start_sun[0:2]+":"+start_sun[2:] + " - " + end_sun[0:2]+":"+end_sun[2:]
                                store_hourslist.append(day_sun)
                            else:
                                day_sun = "Sunday: Closed"
                                store_hourslist.append(day_sun)

                            if len(start_mon) >= 1:

                                day_mon = "Monday: " + start_mon[0:2] + ":" + start_mon[2:] + " - " + end_mon[
                                                                                                      0:2] + ":" + end_mon[2:]
                                store_hourslist.append(day_mon)
                            else:
                                store_hourslist = ''

                            if len(start_tue) >= 1:

                                day_tue = "Tueday: " + start_tue[0:2] + ":" + start_tue[2:] + " - " + end_tue[
                                                                                                      0:2] + ":" + end_tue[2:]
                                store_hourslist.append(day_tue)
                            else:
                                store_hourslist = ''
                            if len(start_wed) >= 1:

                                day_wed = "Wednesday: " + start_wed[0:2] + ":" + start_wed[2:] + " - " + end_wed[
                                                                                                      0:2] + ":" + end_wed[2:]
                                store_hourslist.append(day_wed)
                            else:
                                store_hourslist = ''
                            if len(start_thu) >= 1:

                                day_thu = "Thursday: " + start_thu[0:2] + ":" + start_thu[2:] + " - " + end_thu[
                                                                                                      0:2] + ":" + end_thu[2:]
                                store_hourslist.append(day_thu)
                            else:
                                store_hourslist = ''
                            if len(start_fri) >= 1:

                                day_fri = "Friday: " + start_fri[0:2] + ":" + start_fri[2:] + " - " + end_fri[0:2] + ":" + end_fri[2:]
                                store_hourslist.append(day_fri)
                            else:
                                store_hourslist = ''
                            if len(start_sat) >= 1:

                                day_sat = "Saturday: " + start_sat[0:2] + ":" + start_sat[2:] + " - " + end_sat[
                                                                                                      0:2] + ":" + end_sat[2:]
                                store_hourslist.append(day_sat)
                            else:
                                day_sat = 'Saturday: Closed'
                                store_hourslist.append(day_sat)

                            store_hours = "|".join(store_hourslist)


                    except Exception as e:
                        print("store_hours",e,store_name)

                    try:
                        additional_info = {}
                        servicelist = []
                        serlen = len(store_data['data']['items'][i]['props']['taxonomies'][0]['terms'])
                        for j in range(0,serlen):
                            service = store_data['data']['items'][i]['props']['taxonomies'][0]['terms'][j]['name']
                            servicelist.append(service)




                        services= '|'.join(servicelist)


                        additional_info['Angebote'] = services


                    except Exception as e:
                        print("additional_info",e,response.url)


                    item = StoreLocatorsItem()
                    item['search_term'] = ''
                    item['store_name']= store_name
                    item['address'] = address
                    item['city'] = city
                    item['state'] =''
                    item['zip_code'] = zipcode
                    item['phone_number'] =phone_number
                    item['latitude'] = latitude
                    item['longitude'] = longitude
                    item['store_type'] = ''
                    item['website_address'] = ''
                    item['coming_soon'] = 1
                    item['store_number'] = ''
                    item['country_code'] = item['country'] = 'AT' #self.f1.country_dict.get(item['country'].lower())
                    item['email_address'] = ''
                    item['services'] = ''
                    item['source_url']=url
                    item['store_hours'] = store_hours
                    item['additional_info'] = json.dumps(additional_info)
                    yield item
            except Exception as e:
                print(e,"store_error",store_name)

        except Exception as e:
            logging.log(logging.ERROR, e)

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_211 -a list_id=211'''.split())
