# # -*- coding: utf-8 -*-
# # pip install scrapy-html-storage
# import calendar
#
# import scrapy,os,logging,hashlib
# import requests,json
# from scrapy.http import HtmlResponse
# from scrapy.cmdline import execute
# from store_locators.items import StoreLocatorsItem
# from store_locators.spiders.common_functions import Func
# import datetime
# import re
# # import html2text
# from pprint import pprint as pp
#
#
# # Done
# class Store18Spider(scrapy.Spider):
#     name = 'store_18'
#     allowed_domains = []
#     # not_export_data = True
#
#
#     def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
#         super().__init__(name, **kwargs)
#         self.list_id, self.proxy_type = list_id, proxy_type
#         self.f1 = Func()
#
#
#     def start_requests(self):
#         run_date = str(datetime.datetime.today()).split()[0]
#         self.f1.set_details(self.list_id, run_date)
#         try:
#             source_url = link = 'https://www.amatos.com/wp-admin/admin-ajax.php?action=store_search&lat=43.6541567&lng=-70.2802294&max_results=75&search_radius=500&autoload=1'
#             header = {
#                 "authority":"www.amatos.com",
#                 "method":"GET",
#                 "path":"/wp-admin/admin-ajax.php?action=store_search&lat=43.6541567&lng=-70.2802294&max_results=75&search_radius=500&autoload=1",
#                 "scheme":"https",
#                 "accept":"*/*",
#                 "accept-encoding":"gzip, deflate, br",
#                 "accept-language":"en-US,en;q=0.9",
#                 # "cookie":"tk_or=%22%22; tk_lr=%22%22; _ga=GA1.2.1170586548.1602652870; _fbp=fb.1.1602652870752.451179266; _hjTLDTest=1; _hjid=819d32db-c93a-47c4-95cb-14148f9cbc06",
#                 "referer":"https://www.amatos.com/locations-menus/",
#                 "sec-fetch-dest":"empty",
#                 "sec-fetch-mode":"cors",
#                 "sec-fetch-site":"same-origin",
#                 "user-agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36",
#                 "x-requested-with":"XMLHttpRequest"
#             }
#
#             self.f1.set_details(self.list_id, run_date)
#             file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(run_date) + '.html'
#             if os.path.exists(file_path):
#                 link = 'file://' + file_path.replace('\\', '/')
#
#             yield scrapy.FormRequest(url=str(link), callback=self.get_store_list,headers=header,meta={'source_url': source_url,
#                                                                                         'file_path': file_path,
#                                                                                         'proxy_type': self.proxy_type})
#
#         except Exception as e:
#
#             logging.log(logging.ERROR, e)
#
#     def get_store_list(self, response):
#         try:
#             # if not response.url.startswith('file://'):
#             #     self.f1.page_save(response.meta['file_path'], response.body)
#             search_term = response.meta.get('search_term', '')
#             source_url = response.meta.get('source_url', '')
#
#             body = json.loads(response.body)
#             if body != '':
#                 le = len(body)
#                 for i in range(0, le):
#                     try:
#                         store_number = body[i]['id']
#                     except Exception as e:
#                         print(e)
#                     try:
#                         store_name1= body[i]['store']
#                         store_name = store_name1.replace('&#8217;s',' s')
#                     except Exception as e:
#                         print(e)
#
#                     try:
#                         address =body[i]['address']
#                         # try:
#                         #     address_detail = address
#                         #     address_line_2 = ''
#                         #     for j in ['Unit', 'STE', 'Ste', 'SUITE', 'Suite', 'suite', 'Suit', 'Units', 'units', 'SUIT',
#                         #               'suit', 'UNIT',
#                         #               'unit', 'ste']:
#                         #         for aw in address_detail.split(' '):
#                         #             if j == aw:
#                         #                 if address_detail.split(' ').index(aw) != 0:
#                         #                     address = address_detail.split(j)[0].strip()
#                         #                     address_line_2 = j + ' ' + address_detail.split(j)[-1].strip()
#                         #                     break
#                         # except Exception as e:
#                         #     address_line_2 = body[i]['address2']
#                         #     # address = ''
#                         #     print(e)
#                     except Exception as e:
#                         print(e)
#
#
#                     try:
#                         address_line_2 = body[i]['address2']
#                     except Exception as e:
#                         address_line_2 = ''
#                         print(e)
#
#
#                     try:
#                         zip_code = body[i]['zip']
#                     except Exception as e:
#                         zip_code =''
#                         print(e)
#
#                     try:
#                         city = body[i]['city']
#                     except Exception as e:
#                         city =''
#                         print(e)
#
#                     try:
#                         phone_number = body[i]['phone']
#                     except Exception as e:
#                         print(e)
#
#                     try:
#                         latitude = body[i]['lat']
#                         longitude = body[i]['lng']
#                     except Exception as e:
#                         latitude = ''
#                         longitude = ''
#
#                     try:
#                         state = body[i]['state']
#                     except Exception as e:
#                         print(e)
#
#                     try:
#                         email_address = body[i]['email']
#                     except Exception as e:
#                         email_address = ''
#
#                     try:
#                         fax_number = body[i]['fax']
#                     except Exception as e:
#                         fax_number = ''
#
#                     try:
#                         s1 = body[i]['store_uber_eats_link']
#                         s2 = body[i]['store_door_dash_link']
#                         services = "store_uber_eats_link:"+s1 + "|" + "store_door_dash_link:"+s2
#                     except Exception as e:
#                         services= ''
#                         print(e)
#
#                     try:
#                         source_url = body[i]['permalink']
#                     except Exception as e:
#                         source_url = ''
#
#
#                     try:
#                         l12= []
#                         store_hours =body[i]['wpsl_hours']
#                         store_hours = re.findall('"(.*?)";',store_hours,re.DOTALL)
#                         keys = store_hours[0:14:2]
#                         values = store_hours[1:14:2]
#                         for i in keys:
#                             for j in values:
#                                 keyvalues = i + ":"+ j
#                                 keyvalues = keyvalues.replace(',','-')
#                             l12.append(keyvalues)
#                         store_hours = '|'.join(l12)
#                         # while store_hours.endswith("|"):
#                         #     store_hours = store_hours[:-1]
#
#                     except Exception as e:
#                         store_hours = ''
#                         print(e)
#
#
#
#                     try:
#                         additional_info3 = ''
#                     except Exception as e:
#                         print(e)
#
#                     item = StoreLocatorsItem()
#                     additional_info = {}
#                     item['search_term'] = search_term
#                     item['store_name'] = store_name
#                     item['address'] = address
#                     item['address_line_2'] = address_line_2
#                     item['city'] = city
#                     item['state'] = state
#                     item['zip_code'] = zip_code
#                     item['phone_number'] = phone_number
#                     item['latitude'] = latitude
#                     item['longitude'] = longitude
#                     item['store_type'] = ''
#                     item['country'] ="United States"
#                     item['country_code'] ='US'
#                     item['website_address'] = ''
#                     item['coming_soon'] = 0
#                     item['store_number'] = store_number
#                     item['fax_number'] = fax_number
#                     item['email_address'] = email_address
#                     item['services'] = services
#                     item['store_hours'] = store_hours
#
#                     if additional_info3 != "":
#                         additional_info = dict()
#                         additional_info['info'] = additional_info3
#                         item['additional_info'] = json.dumps(additional_info, ensure_ascii=False)
#                     else:
#                         item['additional_info'] = json.dumps(additional_info, ensure_ascii=False)
#
#                     item['source_url'] = source_url
#                     yield item
#
#         except Exception as e:
#             logging.log(logging.ERROR, e)
#
#
#
#
# execute('''scrapy crawl store_18 -a list_id=18'''.split())
#
#
