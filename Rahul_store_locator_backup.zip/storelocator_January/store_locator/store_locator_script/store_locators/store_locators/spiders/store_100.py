# # -*- coding: utf-8 -*-
# import scrapy,os,logging,hashlib
# from funcy import flatten, isa
# import requests,json
# from scrapy.http import HtmlResponse
# from scrapy.cmdline import execute
# from store_locators.items import StoreLocatorsItem
# from store_locators.spiders.common_functions import Func
# import datetime
# import html2text
# h = html2text.HTML2Text()
#
# class ZoupCrawlerSpider(scrapy.Spider):
#     name = 'store_100'
#     allowed_domains = []
#     not_export_data = False
#
#     def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
#         super().__init__(name, **kwargs)
#         self.list_id, self.proxy_type = list_id, proxy_type
#         self.f1 = Func()
#
#     def start_requests(self):
#         run_date = str(datetime.datetime.today()).split()[0]
#         try:
#             self.f1.set_details(self.list_id,run_date)
#             head = {'Host': 'www.zoup.com',
#                     'Accept': 'application/json, text/javascript, */*; q=0.01',
#                     'X-Requested-With': 'XMLHttpRequest',
#                     'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36',
#                     'Referer': 'https://www.zoup.com/Locations',
#                     # 'Accept-Encoding': 'gzip, deflate, br',
#                     'Accept-Language': 'en-US,en;q=0.9'}
#             source_url = link = 'https://www.zoup.com/ajax.Location.php?action=initialize'
#             file_path = ''
#             yield scrapy.FormRequest(url=str(link), callback=self.parse, headers=head,
#                                      meta={'source_url': source_url,'file_path': file_path,
#                                            'proxy_type': self.proxy_type})
#         except Exception as e:
#             logging.log(logging.ERROR, e)
#
#     def parse(self, response):
#         try:
#             data = json.loads(response.text)
#             df = data[3]
#             keys = df.keys()
#             values = [df[str(k)] for k in df.keys()]
#             for gh in df:
#                 state = gh
#                 cities = list(flatten(df[state]))
#                 for city in cities:
#                     url = f"https://www.zoup.com/ajax.Location.php?action=locations&zipcode=&state={str(state)}&city={str(city)}"
#                     yield scrapy.FormRequest(url=str(url), callback=self.get_store_list,
#                                              meta=response.meta)
#         except Exception as e:
#             print(e)
#
#     # Get data from the response
#     def get_store_list(self, response):
#         try:
#             # if not response.url.startswith('file://'):
#             #     self.f1.page_save(response.meta['file_path'],response.body)
#
#             source_url = response.meta.get('source_url', '')
#             store_data = json.loads(response.text)
#             if store_data[0]==[]:
#                 pass
#             else:
#                 for df in store_data[0]:
#                     try:
#                         item = StoreLocatorsItem()
#                         try:
#                             item['latitude'] = df['latitude']
#                             item['longitude'] = df['longitude']
#                         except Exception as e:
#                             logging.log(logging.ERROR,e)
#                         item['store_number'] = df['id']
#                         item['store_code'] = df['number']
#                         item['store_name'] = df['companyname']
#                         item['address'] = h.handle(df['address1']).strip()
#                         item['address_line_2'] = h.handle(df['address2']).strip()
#                         item['address_line_3'] = h.handle(df['address3']).strip()
#                         item['city'] = df['city']
#                         item['state'] = df['state']
#                         item['zip_code'] = df['zip']
#                         item['country'] = 'US'
#                         item['country_code'] = 'US'
#                         if 'Coming Soon' in df['hours']:
#                             print()
#                         item['store_hours'] = h.handle(df['hours']).strip().replace('  \n','|') if not 'Coming Soon' in h.handle(df['hours']).strip().replace('  \n','|') else ''
#                         item['coming_soon'] = '1' if item['store_hours']=='' else '0'
#                         item['phone_number'] = df['phonenumber'].strip('(').strip(')').strip().replace(' ','-').replace('-','.').replace(')','')
#                         item['source_url'] = "https://www.zoup.com/Locations"
#                         item['source_url'] = response.url
#                         item['additional_info'] = json.dumps({'cateringlink':df['cateringlink']}) if df['cateringlink']!='' else ''
#                         yield item
#                     except Exception as e:
#                         logging.log(logging.ERROR, e)
#         except Exception as e:
#             logging.log(logging.ERROR,e)
#
# execute('''scrapy crawl store_100 -a list_id=100 -a proxy_type=luminati_us'''.split())#-s HTTPCACHE_ENABLED=True


# -*- coding: utf-8 -*-
import re

import scrapy,os,logging,hashlib
from funcy import flatten, isa
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime
import html2text
h = html2text.HTML2Text()

class ZoupCrawlerSpider(scrapy.Spider):
    name = 'store_100'
    allowed_domains = []
    not_export_data = False

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.f1.set_details(self.list_id, self.run_date)
    def start_requests(self):

        try:
            # head = {'Host': 'www.zoup.com',
            #         'Accept': 'application/json, text/javascript, */*; q=0.01',
            #         'X-Requested-With': 'XMLHttpRequest',
            #         'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36',
            #         'Referer': 'https://www.zoup.com/Locations',
            #         # 'Accept-Encoding': 'gzip, deflate, br',
            #         'Accept-Language': 'en-US,en;q=0.9'}
            source_url = link = 'https://www.zoup.com/'
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
                self.run_date) + '.html'
            yield scrapy.FormRequest(url=str(link), callback=self.parse,meta={'source_url': source_url,'file_path': file_path,'proxy_type': self.proxy_type})
        except Exception as e:
            logging.log(logging.ERROR, e)

    def parse(self, response):
        try:
            links = response.xpath('//a[@class="plain"]/@href').getall()
            for link in links:
                url = 'https://www.zoup.com' + str(link)
            # data = json.loads(response.text)
            # df = data[3]
            # keys = df.keys()
            # values = [df[str(k)] for k in df.keys()]
            # for gh in df:
            #     state = gh
            #     cities = list(flatten(df[state]))
            #     for city in cities:
            #         url = f"https://www.zoup.com/ajax.Location.php?action=locations&zipcode=&state={str(state)}&city={str(city)}"
                yield scrapy.FormRequest(url=url, callback=self.get_store_list,meta=response.meta)

        except Exception as e:
            print(e)

    # Get data from the response
    def get_store_list(self, response):
        try:
            store_link = response.xpath('//div[@class="location-card one-third px-3"]/a[1]/@href').getall()
            for stores in store_link:
                URL = 'https://www.zoup.com' +str(stores)
                yield scrapy.FormRequest(url=URL, callback=self.store_data, meta=response.meta)
        except Exception as e:
            logging.log(logging.ERROR,e)

    def store_data(self,response):
        try:
            if not response.url.startswith('file://'):
                self.f1.page_save(response.meta['file_path'], response.body)

            item = StoreLocatorsItem()
            try:
                store_name1 = response.xpath('//div[@class="flex flex-column"]/h3/text()').get()
                store_name2 = response.xpath('//div[@class="flex flex-column"]/h2/text()').get()
                store_name = str(store_name1) + '-' + str(store_name2)
            except Exception as e:
                store_name = ''
                print(e)

            try:
                Address = response.xpath('//div[@class="flex flex-column"]/address/text()[1]').get().strip()
                city = str(re.findall(r'"addressLocality": "(.*?)"', response.text))
                state = str(re.findall(r'"addressRegion": "(.*?)"', response.text))
                zip_code = str(re.findall(r'"postalCode": "(.*?)"', response.text))
                country = str(re.findall(r'"addressCountry": "(.*?)"', response.text))

            except Exception as e:
                Address = ''
                city = ''
                state = ''
                zip_code = ''
                country = ''
                print(e)

            try:
                phone_number = response.xpath('//div[@class="flex flex-column"]/address/text()[2]').get().strip()
            except Exception as e:
                phone_number = ''
                print(e)

            try:
                services = response.xpath('//div[@class="flex flex-column"]/address/span/text()').get().strip()
            except Exception as e:
                services = ''
                print(e)

            try:
                latitude = str(re.findall(r'"latitude": (.*?),', response.text))
                longitude = str(re.findall(r'"longitude": (.*?),', response.text))
            except Exception as e:
                latitude = ''
                longitude = ''
                print(e)

            try:
                store_hours = ' || '.join(response.xpath('//div[@class="flex flex-column"]/div[@class="row"]//text()').getall())
            except Exception as e:
                store_hours = ''
                print(e)

            item['store_name'] = store_name
            item['Address'] = Address
            item['city'] = city.replace("'","").replace("[","").replace("]","").replace('"',"")
            item['state'] = state.replace("'","").replace("[","").replace("]","").replace('"',"")
            item['zip_code'] = zip_code.replace("'","").replace("[","").replace("]","").replace('"',"")
            item['country'] = item['country_code'] = country.replace("'","").replace("[","").replace("]","").replace('"',"")
            item['phone_number'] = phone_number.replace("(","").replace(")","").replace(" ","").replace("-","")
            item['services'] = services
            item['latitude'] = latitude.replace("'","").replace("[","").replace("]","").replace('"',"")
            item['longitude'] = longitude.replace("'","").replace("[","").replace("]","").replace('"',"").replace("}","")
            item['store_hours'] = store_hours
            item['source_url'] = response.url

            yield item

        except Exception as e:
            logging.log(logging.ERROR,e)

# execute('''scrapy crawl store_100 -a list_id=100 -a proxy_type=luminati_us'''.split())#-s HTTPCACHE_ENABLED=True