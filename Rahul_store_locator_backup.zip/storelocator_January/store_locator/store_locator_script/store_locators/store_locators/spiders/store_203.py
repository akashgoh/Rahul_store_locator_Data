# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import re

import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime
import itertools


class store203Spider(scrapy.Spider):
    name = 'store_203'
    allowed_domains = []
    f1 = Func()

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            self.f1.set_details(self.list_id,run_date)
            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                print(search_terms)
            # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)

                search_terms = ''
                for search_term in (search_terms):
                    source_url = link = f"https://www.bestbuy.com/browse-api/2.0/store-locator/{search_term}"
                    file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(search_term) + '_' + str(run_date) + '.html'
                    if os.path.exists(file_path):
                        link = 'file://' + file_path.replace('\\','/')
                    yield scrapy.FormRequest(url=str(link), callback=self.get_store_list, meta={'source_url': source_url,'search_term': search_term,'file_path':file_path,'proxy_type': self.proxy_type})
            else:
                source_url = link = 'https://sunshinehouse.com/find-a-location/'
                file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(self.name) + '_' + str(run_date) + '.html'
                yield scrapy.FormRequest(url=str(link), callback=self.get_store,meta={'source_url': source_url,'file_path': file_path,'proxy_type': self.proxy_type})

        except Exception as e:
            logging.log(logging.ERROR, e)

    def get_store(self,response):
        source_url = response.meta['source_url']
        file_path = response.meta['file_path']
        a = re.findall(r'&quot;Url&quot;:&quot;(.*?)&quot;',response.text)
        for u in a:
            u = 'https://sunshinehouse.com' + u.replace('&quot;','"')
            yield scrapy.Request(url=str(u), callback=self.get_store_list, meta={'source_url': source_url,'file_path': file_path,'proxy_type': self.proxy_type})


    # Get data from the response
    def get_store_list(self, response):
        try:
            if not response.url.startswith('file://'):
                self.f1.page_save(response.meta['file_path'],response.body)

            search_term = response.meta.get('search_term', '')
            source_url = response.meta.get('source_url', '')

            # s = ''.join(response.text).split('data-markers="')[1].replace('&quot;','"')
            # q = s.split('" data-icon="/media/4yadqqnq/sunshine-marker-2.png">')[0]
            # store_data = json.loads(q)
            # print(len(store_data))

            s = ''.join(response.text).split('<script type="application/ld+json">')[1].replace('&quot;','"').strip()
            q = s.split('</script>')[0]
            store_data = json.loads(q)
            print(len(store_data))

            # If you have search_by :zip_code/city/state/lat_lng then you need to add following condition and query to update log table
            if len(store_data) == 0:
                Func.update_log_table(self.f1,search_term)
            else:
                try:
                    store_data = json.loads(q)
                    additional_info = {}
                    item = StoreLocatorsItem()
                    item['search_term'] = search_term

                    # STATE = {"Andhra Pradesh":"AD","Arunachal Pradesh":"AR","ASSAM":"AS","Assam":"AS","Bihar":"BR","Chhattisgarh":"CG","Delhi - Vasant Kunj":"DL","Delhi - Janakpuri":"D:","New Delhi":"DL","Delhi - Shahdara":"DL","DELHI":"DL","Delhi":"DL","Goa":"GA","Gujarat":"GJ","Haryana":"HR","Himachal Pradesh":"HP","Jammu & Kashmir":"JK","Jammu and Kashmir":"JK","Jharkhand":"JH","Karnataka":"KA","Kerala":"KL","Lakshadweep Islands":"LD","Madhya Pradesh":"MP","MADHYA PRADESH":"MH","Maharashtra":"MH","MAHARASHTRA":"MH","Manipur":"MN","Meghalaya":"ML","Mizoram":"MZ","Nagaland":"NL","Odisha":"OD","Pondicherry":"PY","Punjab":"PB","Rajasthan":"RJ","Sikkim":"SK","TAMIL NADU":"TN","Tamil Nadu":"TN","Telangana":"TS","TELANGANA":"TS","Tripura":"TR","Uttar Pradesh":"UP","Uttarpradesh":"UP","Uttarakhand":"UK","West Bengal":"WB","WestBengal":"WB","Andaman and Nicobar Islands":"AN","Chandigarh":"CH","Dadra and Nagar Haveli":"DN","Daman and Diu":"DD","Other Territory":"OT"}
                    # st = store_data[store]['stateOrProvinceName']
                    # for element in STATE:
                    #     if st == element:
                    #         stt = st.values()

                    # stt = dict((k, v) for k, v in STATE.items()).get(st)
                    # print(store_data['address']['addressRegion'])
                    item['state'] = store_data['address']['addressRegion']
                    item['store_name'] = store_data['name']
                    item['address'] = store_data['address']['streetAddress']
                    item['city'] = store_data['address']['addressLocality']

                    item['zip_code'] = store_data['address']['postalCode']

                    try:
                        phone_number = store_data['contactPoint']['telephone']

                        if "center/bucking-horse/" in response.url:
                            phone_number = ''
                        else:
                            phone_number = phone_number
                    except Exception as e:
                        phone_number = ''

                    item['phone_number'] = phone_number
                    # item['latitude'] = store_data['Latitude']
                    # item['longitude'] = store_data['Longitude']
                    item['store_type'] = ''
                    item['source_url'] = store_data['url']
                    item['coming_soon'] = 0
                    item['store_number'] = ''
                    item['country_code'] = 'US' #self.f1.country_dict.get(item['country'].lower())

                    q = ''.join(response.xpath("//*[contains(text(),'Features')]/../div//text()").extract()).strip().replace('\n\n','').replace('\n','|')
                    item['services'] = q.replace('Enrichment Programs:','|Enrichment Programs:').strip()
                    item['country'] = 'US'
                    # except Exception as e:

                    store_hour = ''.join(response.xpath('//*[@class="fas fa-clock"]/parent::p//text()').extract()).strip()
                    item['store_hours'] = store_hour
                    item['email_address'] = store_data['contactPoint']['email']

                    item['additional_info'] = '|'.join(response.xpath("//*[contains(text(),'Advantages')]/../div/ul/li/text()").extract())
                    item['number_of_store'] = '98'
                    yield item
                except Exception as e:
                    print(e)

        except Exception as e:
            logging.log(logging.ERROR, e)

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_203 -a list_id=203'''.split())
# execute('''scrapy crawl bestbuy_crawler -a list_id=49 -a proxy_type=storm_proxy -s CONCURRENT_REQUESTS=16 -s DOWNLOAD_DELAY=3'''.split())