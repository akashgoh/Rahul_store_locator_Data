# # -*- coding: utf-8 -*-
# # pip install scrapy-html-storage
# from string import punctuation
#
# import scrapy,os,logging,hashlib
# import requests,json
# from scrapy.http import HtmlResponse
# from scrapy.cmdline import execute
# from store_locators.items import StoreLocatorsItem
# from store_locators.spiders.common_functions import Func
# import datetime
# import re
# # import html2text
# from pprint import pprint as pp
#
#
# # manual enter in csv missing data .. okay
# class Store14Spider(scrapy.Spider):
#     name = 'store_14'
#     allowed_domains = []
#     # not_export_data = True
#
#     def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
#         super().__init__(name, **kwargs)
#         self.list_id, self.proxy_type = list_id, proxy_type
#         self.f1 = Func()
#
#     def start_requests(self):
#         run_date = str(datetime.datetime.today()).split()[0]
#         self.f1.set_details(self.list_id, run_date)
#         try:
#             source_url = link = 'https://www.allbirds.com/pages/stores'
#             self.f1.set_details(self.list_id, run_date)
#             file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(run_date) + '.html'
#             if os.path.exists(file_path):
#                 link = 'file://' + file_path.replace('\\', '/')
#
#             yield scrapy.FormRequest(url=str(link), callback=self.get_store_list, meta={'source_url': source_url,
#                                                                                         'file_path': file_path,
#                                                                                         'proxy_type': self.proxy_type})
#
#         except Exception as e:
#             logging.log(logging.ERROR, e)
#
#     def get_store_list(self, response):
#        try:
#            if not response.url.startswith('file://'):
#                self.f1.page_save(response.meta['file_path'], response.body)
#            divs = response.xpath('//div[@class="StoresPageSection"]')
#            for div in divs:
#                try:
#                    item = StoreLocatorsItem()
#                    item['store_name'] = div.xpath('.//h2/text()').extract_first(default='')
#                    address = item['address'] = ''.join(div.xpath('.//h3[contains(text(),"Location")]/following-sibling::p[1]/text()').getall())
#                    address = item['address'] = (re.sub('\s+', ' ', re.sub('\t|\r|\n', ' ', address))).strip()
#                    address_split_params = ('unit ', 'suit ', 'ste ', 'suite ', 'units ', 'ste. ')
#                    for address_split_param in address_split_params:
#                        if address_split_param in (address.lower()):
#                            item['address'] = (item['address'].lower()).split(address_split_param)[0]
#                            item['address_line_2'] = f"{address_split_param} {((address.lower()).split(address_split_param)[1])}"
#                            break
#                    map_link = div.xpath('//a[contains(text(),"See Map")]/@href').get(default='')
#                    if '@' in map_link and ','in map_link:
#                        (lat, lng) = map_link.split('@')[1].split(',')[:2]
#                        item['latitude'] = lat
#                        item['longitude'] = lng
#                    else:
#                        pass
#
#                    item['coming_soon'] = 0
#                    item['store_hours'] = '|'.join(div.xpath('.//p[contains(text()," Hours")]/following-sibling::p/text()').getall())
#                    try:
#                         item['phone_number'] = div.xpath('.//p[contains(text(),"Phone")]/following-sibling::p/text()').get(default='')
#                    except Exception as e:
#                        item['phone_number'] = ''
#                        print(e)
#
#                    item['source_url'] = response.meta.get('source_url', '')
#                    add_info = dict()
#                    add_info['decs'] = div.xpath('.//p[1]/text()').get(default='')
#                    item['additional_info'] = json.dumps(add_info, ensure_ascii=False)
#                    yield item
#
#                except Exception as e:
#                    print(e)
#
#        except Exception as e:
#            print(e)
#
#     def response_html_path(self, request):
#         return request.meta['fpath']
#
# execute('''scrapy crawl store_14 -a list_id=14'''.split())
#
#
#
