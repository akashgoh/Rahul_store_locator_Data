import re

import scrapy
import json
from store_locators.spiders.common_functions import Func
from store_locators.items import StoreLocatorsItem
import datetime
import html2text,os

class Store153Spider(scrapy.Spider):
    name = 'store_153'
    f1 = Func()

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            source_url = link = 'https://unclejulios.com/locations/'

            self.f1.set_details(self.list_id, run_date)
            # file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(run_date) + '.html'
            # if os.path.exists(file_path):
            #     link = 'file://' + file_path.replace('\\', '/')

            yield scrapy.FormRequest(url=str(link), callback=self.get_store_links, meta={'source_url': source_url, 'proxy_type': self.proxy_type})#'file_path': file_path,

        except Exception as e:
            print(e)


    def get_store_links(self,response):

        # file_path = response.meta['file_path']
        details = set(response.xpath('//ul[@class="restaurants__sublist"]//li//a//@href').getall())
        for detail in details:
            if 'http' in detail:
                yield scrapy.FormRequest(url=detail,callback=self.get_store)
            else:
                print('')

    def get_store(self,response):
        data=response.xpath('//script[@type="application/ld+json"]//text()').get(default='')
        data=json.loads(data)

        address = data['address']['streetAddress']
        city = data['address']['addressLocality']
        state = data['address']['addressRegion']
        zip_code =data['address']['postalCode']
        store_name =data['name'] +' '+data['address']['addressLocality']
        phone_number = data['telephone']
        latitude = data['geo']['latitude']
        longitude = data['geo']['longitude']
        hour=[]
        try:
            d=data['openingHoursSpecification'][0]['dayOfWeek']
            for i in d:

                op=data['openingHoursSpecification'][0]['opens']
                cl=data['openingHoursSpecification'][0]['closes']
                hr=i+':'+op+':'+cl
                hour.append(hr)
            hrs='|'.join(hour)

            try:
                hrs=hrs+'|'+str(data['openingHoursSpecification'][1]['dayOfWeek'])+':'+str(data['openingHoursSpecification'][1]['opens'])+':'+str(data['openingHoursSpecification'][1]['closes'])
            except Exception as e:
                print()
                hrs=hrs
            try:
                hrs=hrs+'|'+data['openingHoursSpecification'][2]['dayOfWeek']+':'+data['openingHoursSpecification'][2]['opens']+':'+data['openingHoursSpecification'][2]['closes']
            except:
                hrs=hrs
            try:
                hrs=hrs+'|'+data['openingHoursSpecification'][3]['dayOfWeek']+':'+data['openingHoursSpecification'][3]['opens']+':'+data['openingHoursSpecification'][3]['closes']
            except:
                hrs=hrs
        except:
            hrs=''
        check = False
        for i in ['Unit', 'STE', 'Ste', 'Suite']:
            for aw in address.split():
                if i == aw:
                    address1 = address.split(i)[0].strip(',')
                    address_line_2 = i + ' ' + address.split(i)[-1].strip()
                    check = True
                    break
        if check == True:
            address_line_2 = address_line_2
            address = address1
        else:
            address_line_2 = ''
            address = address

        item = StoreLocatorsItem()

        try:
            item['address'] = address.strip()
            item['address_line_2'] = address_line_2
            item['city'] = city.strip()
            item['state'] = state.strip()
            item['zip_code'] = zip_code.strip()
            item['country'] = 'United States'
            item['country_code'] = 'US'
            item['store_name'] = store_name.strip()
            item['phone_number'] = phone_number.strip()
            item['latitude'] = latitude.strip()
            item['longitude'] = longitude.strip()
            item['store_type'] = 'Restaurant'
            item['coming_soon'] = 0
            item['source_url'] = response.url
            item['store_hours'] = hrs

            yield item
        except Exception as e:
            print(e)
from scrapy.cmdline import execute
# execute('''scrapy crawl store_153 -a list_id=153 -s HTTPCACHE_ENABLED=False'''.split())


