# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import re

import html2text
import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime


class Store192Spider(scrapy.Spider):
    name = 'store_192'
    allowed_domains = []
    # f1 = Func()

    def __init__(self, name=None, list_id="",proxy_type="",**kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type= list_id, proxy_type
        self.f1 = Func()


    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            source_url = link = 'https://www.ourcoop.com/Locations'
            self.f1.set_details(self.list_id, run_date)
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
                run_date) + '.html'
            if os.path.exists(file_path):
                link = 'file://' + file_path.replace('\\', '/')

            yield scrapy.FormRequest(url=str(source_url), callback=self.get_store,meta={'source_url': source_url,'file_path': file_path,'proxy_type': self.proxy_type})
        except Exception as e:
            print(e)

    def get_store(self,response):
        source_url = response.meta['source_url']
        file_path = response.meta['file_path']
        urls = response.xpath('//*[@class="get-directions-link showDetail"]/@href').getall()
        for url in urls:
            u = 'https://www.ourcoop.com' + url
            print(u)
            # u= 'https://www.ourcoop.com/Locations/Overton-Farmers-Byrdstown'
            yield scrapy.Request(url=str(u), callback=self.get_store_list, meta={'source_url': source_url,'file_path': file_path,'proxy_type': self.proxy_type})


    def get_store_list(self,response):
        if not response.url.startswith('file://'):
            self.f1.page_save(response.meta['file_path'], response.body)
            source_url = response.meta.get('source_url', '')
            search_term = response.meta.get('search_term', '')
        # try:
            item = StoreLocatorsItem()
            item['search_term'] = search_term
            item['store_name'] = response.xpath('//*[@class="m-location-info"]/h2/text()').extract_first(default='')
            # item['address'] = ''.join(re.findall(r'ocation-info__icon"></span>(.*?)<br/>',response.text)).strip()
            item['address'] = response.xpath('//*[@class="m-location-info"]/p[1]/text()[1]').get()

            # addinfo = ''.join(re.findall(r'<br/>(.*?)</p>',response.text)).strip()
            addinfo = response.xpath('//*[@class="m-location-info"]/p[1]/text()[2]').get()
            city = addinfo.split(',')[0]
            state = addinfo.split(',')[1].split()[0]
            zip = addinfo.split(',')[1].split()[1]
            if '-' in zip:
                zip = zip.split('-')[0]

            item['address_line_2'] = ''
            item['city'] = city
            item['state'] = state

            item['zip_code'] = zip.replace('TN','37034')
            item['phone_number'] = ''.join(re.findall(r'<span class="fa fa-phone m-location-info__icon"></span>(.*?)</a></p>',response.text)).strip()
            # item['phone_number'] =  response.xpath('//*[@class="m-location-info"]/p[2]/a/text()').get()
            fax_number = ''.join(re.findall(r'Fax: (.*\d+)',response.text))
            # fax_number = response.xpath().get
            if 'day'  in fax_number:
                fax_number = ''.join(response.xpath('//*[@class="m-location-info__hours"]/text()').extract()).strip()

            item['fax_number'] = fax_number
            item['email_address'] = ''
            item['store_type'] = ''
            item['website_address'] = source_url
            item['coming_soon'] = 0
            item['store_number'] = ''
            # if item['store_number'] == 8184:
            #     pass
            item['country'] = 'US'
            item['source_url'] = response.url

            item['country_code'] = 'US'
            # print(item['state'])
            if item['country_code'] == 'US' and len(item['state']) > 2:
                item['state'] = self.f1.state_dict.get(item['state'].lower(), '')
                # print('::,', item['state'])


            attr = []
            a = ''.join(response.xpath('//*[contains(text(),"Hours")]/following-sibling::p/text()').extract())
            if 'Fax' in a:
                item['store_hours'] = re.sub(r'\s+', ' ', ''.join(response.xpath('//*[@class="m-location-info__icon-label"][2]/text()').extract())).strip()
            else:
                item['store_hours'] = re.sub(r'\s+', ' ', a).strip()

            item['services'] = '|'.join(response.xpath('//*[@class="m-location-info__services"]/li/text()').extract())
            item['number_of_store'] = '164'
            add_info = dict()

            add_info['distance'] = ''
            add_info['thumb'] = ''
            add_info['description'] = ''

            #//*[@class="m-location-info__services"]/li/text()
            item['additional_info'] = ''
            # latitude = response.xpath('')
            yield item
        # except Exception as e:
        #     print(e)

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_192 -a list_id=192  -s HTTPCACHE_ENABLED=True'''.split())