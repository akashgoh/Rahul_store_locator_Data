# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import re

import html2text
import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse, response
from scrapy.cmdline import execute
from scrapy.utils.response import open_in_browser

from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime


class tedscafeSpider(scrapy.Spider):
    name = 'store_194'
    allowed_domains = []

    def __init__(self, name=None, list_id="",proxy_type="",**kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type= list_id, proxy_type
        self.f1 = Func()


    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        self.f1.set_details(self.list_id, run_date)
        try:
            source_url = link = 'https://tedscafe.com/locations/'

            self.f1.set_details(self.list_id, run_date)
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
                run_date) + '.html'
            print(link)
            yield scrapy.FormRequest(url=str(link), callback=self.storedetail,meta={'source_url': source_url,'file_path': file_path})
        except Exception as e:
            print(e)

    def storedetail(self, response):


        if not response.url.startswith('file://'):
            self.f1.page_save(response.meta['file_path'], response.body)
            source_url = response.meta.get('source_url', '')

        try:

            item = StoreLocatorsItem()
            page_source = ''.join(response.text).strip()

            hour1 = response.xpath('//*[@class="heading-date uael-business-day"]')
            del hour1[0:3]

            day = hour1.xpath('./span/text()').extract()

            hour2 = response.xpath('//*[@class="heading-time uael-business-time"]')
            del hour2[0:3]

            ttym = hour2.xpath('./span/span/text()').extract()

            q = []
            for day, ttym in zip(day,ttym):
                a = day + ':' + ttym
                q.append(a)
                hours = '|'.join(q)

            title = response.xpath('//*[@class="elementor-widget-container"]/h3/text()').extract()
            info_source = re.findall(r'elementor-clearfix"><h4>(.*?)data-location', page_source, re.DOTALL)
            for info,title in zip(info_source,title):

                if '<br />' in info:
                    address = info.split('<br />')[0]
                    telephone = re.findall(r'"tel:(\d+)',info,re.DOTALL)[0]
                    codeaddress = ''.join(re.findall(r'<br />(.*?)</h4>',info,re.DOTALL)[0])
                    if not codeaddress:
                        codeaddress = re.findall(r'/>(.*?)</h4><h5><a href="tel:',info)[0]
                    city = codeaddress.split(',')[0].strip()
                    state = codeaddress.split(',')[1].split()[0]
                    zipc = codeaddress.split(',')[1].split()[1]

                item['search_term'] = ''
                item['store_name'] = "Ted's - " + title.strip()
                item['address'] = address.replace('&#8217;s','')
                item['city'] = city
                item['state'] = state
                item['zip_code'] = zipc
                item['phone_number'] = telephone
                item['fax_number'] = ''
                item['email_address'] = ''
                item['store_type'] = ''
                item['website_address'] = source_url
                item['coming_soon'] = 0
                item['store_number'] = ''
                item['country'] = 'US'
                item['source_url'] = response.url
                item['state'] = state
                item['country_code'] = 'US'
                item['store_hours'] = hours
                print(hours)

                add_info = dict()
                add_info['distance'] = ''
                add_info['thumb'] = ''
                add_info['description'] = ''
                item['additional_info'] = ''
                item['number_of_store'] = '10'
                yield item
        except Exception as e:
            print(e)


# execute('''scrapy crawl store_194 -a list_id=194 -s HTTPCACHE_ENABLED=False'''.split())