# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import random
import re


import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime

USER_AGENT = 'Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; Googlebot/2.1; +http://www.google.com/bot.html) Safari/537.36'
# USER_AGENT = 'FeedFetcher-Google; (+http://www.google.com/feedfetcher.html)'


class Store132(scrapy.Spider):
    name = 'store_132'
    allowed_domains = []

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()


    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]

        self.f1.set_details(self.list_id,run_date)
        if self.f1.search_by != 'link':
            search_terms = self.f1.get_search_term(self.f1.search_by)
            print(search_terms)
        # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)
            search_terms = ''
            for search_term in (search_terms):
                source_url = link = 'https://international.warn.com/authorized-service-centers'
                file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(search_term) + '_' + str(run_date) + '.html'
                if os.path.exists(file_path):
                    link = 'file://' + file_path.replace('\\','/')
                yield scrapy.FormRequest(url=str(link), callback=self.data, meta={'source_url': source_url,'search_term': search_term,'file_path':file_path,'proxy_type': self.proxy_type})
        else:
            headers = {
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
                "Accept-Encoding": "gzip, deflate, br",
                "Accept-Language": "en-US,en;q=0.9",
                "Cache-Control": "max-age=0",
                "Connection": "keep-alive",
                "Host": "international.warn.com",
                "Sec-Fetch-Mode": "navigate",
                "Sec-Fetch-Site": "none",
                "Sec-Fetch-User": "?1",
                "Upgrade-Insecure-Requests": "1",
                "User-Agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36"
            }
            yield scrapy.Request(url='https://international.warn.com/authorized-service-centers', callback=self.data, headers=headers)


    def data(self, response):
        divs = response.xpath('//div[@class="pb-address-box"]/div')
        for div in divs:

            try:store_name = div.xpath('./h4/text()').extract_first()
            except Exception as e:print(e)

            try:address = div.xpath('./p[1]/text()').extract_first().strip()
            except Exception as e:print(e)

            check = False
            for j in ['Unit', 'STE', 'Ste', 'SUITE', 'Suite', 'suite', 'Suit', 'SUIT', 'suit', 'UNIT', 'unit', 'ste']:
                for aw in address.split():
                    if j == aw:
                        address1 = address.split(j)[0].strip().strip(',')
                        address_line_2 = j + ' ' + address.split(j)[-1].strip()
                        check = True
                        break
            if check == True:
                address_line_2 = address_line_2
                address = address1
            else:
                address_line_2 = ''
                address = address

            address1 = ','.join(div.xpath('./p[1]/text()|./p[2]/text()').extract())

            try:city = div.xpath('./p[2]/text()').extract_first().split(',')[0].replace('CA','').replace(' FL 33166','')
            except:city = ''

            try:
                stext = div.xpath('./p[2]/text()').extract_first()
                state = re.findall(r'([A-Z]{2})', stext)[0]
            except:
                state = 'NS'

            try:
                zip_code = address1.split(state)[-1].strip().replace(',','')
                if 'N.S.' in zip_code:
                    zip_code = 'B3B 1M7'
            except Exception as e:
                print(e)

            try:
                res = re.findall(r'\d{5}', zip_code)[0]
                if res != '':
                    country = 'US'
                    country_code = 'US'
            except:
                country = 'CA'
                country_code = 'CA'

            try:phone_number = div.xpath('./p[3]/text()').extract_first().strip()
            except:phone_number = ''

            text = div.xpath('./p/text()').extract()
            for t in text:
                if '(fax)' in t or '(Fax)' in t:
                    fax = ''.join(re.findall(r'(.*)\(fax\)|(.*)\(Fax\)', t)[0]).strip()
                else:
                    fax = ''
                if 'www.' in t:
                    website_address = t.strip()
                else:
                    website_address = ''

            if address == '1665 Shawson Drive':
                fax = '905-564-5799'


            item = StoreLocatorsItem()
            item['search_term'] = 'link'
            item['store_name']= store_name
            item['address'] = address
            item['address_line_2'] = address_line_2
            item['city'] = city
            item['state'] =state
            item['country'] = country
            item['country_code'] = country_code
            item['zip_code'] = zip_code
            item['phone_number'] = phone_number
            item['fax_number'] = fax
            item['website_address'] = website_address
            item['coming_soon'] = 0
            item['source_url'] = response.url
            yield item

        yield scrapy.Request(url='http://apps.warn.com/wwwapps/dealerlocator/dealerLocator.htm', callback=self.data2)


    def data2(self, response):
        headers = {
            "Accept": "application/json, text/javascript, */*; q=0.01",
            "Accept-Encoding": "gzip, deflate",
            "Accept-Language": "en-US,en;q=0.9",
            "ADRUM": "isAjax:true",
            "Connection": "keep-alive",
            "Cookie": "_ga=GA1.2.158285109.1568351285; _gid=GA1.2.1352282379.1569835121; ADRUM=s=1570014328823&r=http%3A%2F%2Fapps.warn.com%2Fwwwapps%2Fdealerlocator%2FdealerLocator.htm%3F0",
            "Host": "apps.warn.com",
            "Referer": "http://apps.warn.com/wwwapps/dealerlocator/dealerLocator.htm",
            "User-Agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36",
            "X-Requested-With": "XMLHttpRequest"
        }
        urls=[
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-122.676601&ctrLat=45.33331004164318&swLng=-131.026210375&swLat=40.71473702321898&neLng=-114.326991625&neLat=49.9518830600673',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=106.6296638&ctrLat=10.823030603099816&swLng=106.36873850703125&swLat=10.620701647662315&neLng=106.89058909296875&neLat=11.025359558537318',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-66.90360629999998&ctrLat=10.4131265317371&swLng=-75.25321567499998&swLat=3.9446175437829667&neLng=-58.55399692499998&neLat=16.881635519691233',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-56.16453139999999&ctrLat=-34.856666078340375&swLng=-60.33933608749999&swLat=-37.559251641030365&neLng=-51.98972671249999&neLat=-32.154080515650385',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-1.8298330000000078&ctrLat=52.47435877040684&swLng=-2.351683585937508&swLat=52.22341406393968&neLng=-1.3079824140625078&neLat=52.725303476874004',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=55.270782800000006&ctrLat=25.168362344724308&swLng=51.095978112500006&swLat=22.1873109893538&neLng=59.445587487500006&neLat=28.149413700094815',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=30.523400000000038&ctrLat=50.26422099711482&swLng=22.173790625000038&swLat=46.06516273269526&neLng=38.87300937500004&neLat=54.463279261534375',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=30.523400000000038&ctrLat=50.43846530340697&swLng=28.435997656250038&swLat=49.389106295961746&neLng=32.61080234375004&neLat=51.487824310852204',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=28.813054599999987&ctrLat=39.956128110343386&swLng=20.463445224999987&swLat=34.91896564151576&neLng=37.16266397499999&neLat=44.993290579171',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-61.41728389999997&ctrLat=10.540845849042503&swLng=-65.59208858749997&swLat=7.302411886659191&neLng=-57.24247921249997&neLat=13.779279811425814',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=100.50176510000006&ctrLat=13.734463502963795&swLng=96.32696041250006&swLat=10.534670154196382&neLng=104.67656978750006&neLat=16.934256851731206',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=8.541694000000007&ctrLat=47.18830972377772&swLng=0.19208462500000678&swLat=42.7237280160118&neLng=16.891303375000007&neLat=51.652891431543644',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=18.286705799999936&ctrLat=59.16445763020779&swLng=9.937096424999936&swLat=55.798556602748604&neLng=26.636315174999936&neLat=62.53035865766697',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-55.2038278&ctrLat=5.81378338229512&swLng=-63.553437175&swLat=-0.7295402808311399&neLng=-46.854218425&neLat=12.35710704542138',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=79.86124300000006&ctrLat=6.881924750978741&swLng=71.51163362500006&swLat=0.35221682658097253&neLng=88.21085237500006&neLat=13.41163267537651',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-3.7038321999999653&ctrLat=40.23008949112727&swLng=-12.053441574999965&swLat=35.21321509611632&neLng=4.645777175000035&neLat=45.24696388613822',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=126.97796919999996&ctrLat=37.520758126741825&swLng=122.80316451249996&swLat=34.90864798621826&neLng=131.15277388749996&neLat=40.13286826726539',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=18.424055299999964&ctrLat=-33.88100593298527&swLng=14.249250612499964&swLat=-36.6152749656674&neLng=22.598859987499964&neLat=-31.14673690030313',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=28.080078200000003&ctrLat=-26.188607179681377&swLng=23.905273512500003&swLat=-29.144221663260804&neLng=32.2548828875&neLat=-23.232992696101952',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=4.486331800000016&ctrLat=52.03895411787704&swLng=-3.8632775749999837&swLat=47.99861923941452&neLng=12.835941175000016&neLat=56.07928899633955',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=4.486331800000016&ctrLat=52.176416805728124&swLng=0.3115271125000163&swLat=50.15707402959737&neLng=8.661136487500016&neLat=54.19575958185888',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=4.486331800000016&ctrLat=52.03895411787704&swLng=-3.8632775749999837&swLat=47.99861923941452&neLng=12.835941175000016&neLat=56.07928899633955',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=46.67529569999999&ctrLat=24.570165250795803&swLng=38.32568632499999&swLat=18.590700022697224&neLng=55.02490507499999&neLat=30.549630478894382',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=37.617299900000035&ctrLat=55.711740045046085&swLng=33.442495212500035&swLat=53.856694613893325&neLng=41.792104587500035&neLat=57.566785476198845',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=24.551439200000004&ctrLat=46.349649448362555&swLng=16.201829825000004&swLat=41.81486052472819&neLng=32.901048575000004&neLat=50.884438371996914',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=51.53103979999992&ctrLat=25.139631211084723&swLng=43.18143042499992&swLat=19.18773219650383&neLng=59.88064917499992&neLat=31.091530225665615',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-66.03524900000002&ctrLat=18.21065491075284&swLng=-70.21005368750002&swLat=15.08172879443216&neLng=-61.86044431250002&neLat=21.33958102707352',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-8.629105299999992&ctrLat=40.970549231445986&swLng=-16.978714674999992&swLat=36.00908011675976&neLng=-0.279495924999992&neLat=45.93201834613222',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=23.50302350000004&ctrLat=53.22489640132204&swLng=15.15341412500004&swLat=49.29278235542047&neLng=31.85263287500004&neLat=57.15701044722361',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=121.04370029999995&ctrLat=14.65283725021974&swLng=116.86889561249995&swLat=11.46600323229551&neLng=125.21850498749995&neLat=17.83967126814397',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=121.03553750000003&ctrLat=14.578833692167265&swLng=116.86073281250003&swLat=11.390924997005543&neLng=125.21034218750003&neLat=17.766742387328986',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-77.042754&ctrLat=-12.027049559578833&swLng=-81.2175586875&swLat=-15.248747333929515&neLng=-72.8679493125&neLat=-8.80535178522815',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-57.57592599999998&ctrLat=-25.118014984525516&swLng=-65.92553537499998&swLat=-31.07097114491944&neLng=-49.22631662499998&neLat=-19.165058824131595',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-80.782127&ctrLat=8.482606072668206&swLng=-89.131736375&swLat=1.9775666103895977&neLng=-72.432517625&neLat=14.987645534946816',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=10.87334809999993&ctrLat=59.77401881237395&swLng=2.52373872499993&swLat=56.468360652845234&neLng=19.22295747499993&neLat=63.079676971902664',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=3.379205700000057&ctrLat=6.513692156169053&swLng=-0.7955989874999432&swLat=3.240897203166352&neLng=7.554010387500057&neLat=9.786487109171754',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-86.23617439999998&ctrLat=12.037587519359308&swLng=-94.58578377499998&swLat=5.6055303543697095&neLng=-77.88656502499998&neLat=18.469644684348907',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-86.23617439999998&ctrLat=12.037587519359308&swLng=-94.58578377499998&swLat=5.6055303543697095&neLng=-77.88656502499998&neLat=18.469644684348907',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=175.27925300000004&ctrLat=-37.741131882542206&swLng=171.10444831250004&swLat=-40.34550239907742&neLng=179.45405768750004&neLat=-35.136761366007',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=166.43934479999996&ctrLat=-22.093744922387764&swLng=158.08973542499996&swLat=-28.186172673998968&neLng=174.78895417499996&neLat=-16.001317170776563',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=4.63180060000002&ctrLat=52.08074934730469&swLng=-3.7178087749999804&swLat=48.04419944844289&neLng=12.98140997500002&neLat=56.11729924616649',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=4.486331800000016&ctrLat=52.03895411787704&swLng=-3.8632775749999837&swLat=47.99861923941452&neLng=12.835941175000016&neLat=56.07928899633955',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=106.90574390000006&ctrLat=47.83926271890613&swLng=102.73093921250006&swLat=45.62890223891863&neLng=111.08054858750006&neLat=50.04962319889362',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-103.18268620000003&ctrLat=20.393935932867315&swLng=-111.53229557500003&swLat=14.230557347222524&neLng=-94.83307682500003&neLat=26.557314518512104',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=101.518461&ctrLat=3.068212902274933&swLng=97.3436563125&swLat=-0.22114212342394154&neLng=105.6932656875&neLat=6.3575679279738075',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=35.50177669999994&ctrLat=33.71887251665608&swLng=27.152167324999937&swLat=28.251775951422395&neLng=43.85138607499994&neLat=39.18596908188976',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=47.993597499999964&ctrLat=29.180053039448985&swLng=39.643988124999964&swLat=23.4404729561648&neLng=56.343206874999964&neLat=34.91963312273317',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=35.91063499999996&ctrLat=31.784298877305766&swLng=27.561025624999957&swLat=26.196766643520345&neLng=44.26024437499996&neLat=37.37183111109118',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-87.94858049999999&ctrLat=42.958796002437346&swLng=-96.29818987499999&swLat=38.150158541719485&neLng=-79.59897112499999&neLat=47.76743346315521',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-87.94858049999999&ctrLat=42.958796002437346&swLng=-96.29818987499999&swLat=38.150158541719485&neLng=-79.59897112499999&neLat=47.76743346315521',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=10.925226899999984&ctrLat=44.45797401499078&swLng=2.575617524999984&swLat=39.76839934668481&neLng=19.274836274999984&neLat=49.147548683296755',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=34.90454399999999&ctrLat=32.476083717645956&swLng=30.729739312499987&swLat=29.697586171921152&neLng=39.07934868749999&neLat=35.25458126337076',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=34.90454399999999&ctrLat=32.34774979036209&swLng=26.554934624999987&swLat=26.794643872148832&neLng=43.25415337499999&neLat=37.90085570857535',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=106.84559899999999&ctrLat=-6.198584934578539&swLng=102.67079431249999&swLat=-9.47338768196099&neLng=111.02040368749999&neLat=-2.9237821871960894',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=77.59456269999998&ctrLat=12.889082743994463&swLng=69.24495332499998&swLat=6.47820742153666&neLng=85.94417207499998&neLat=19.299958066452266',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=114.16936110000006&ctrLat=22.318783537906757&swLng=113.64751051406256&swLat=21.937663908842016&neLng=114.69121168593756&neLat=22.6999031669715',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-58.1551255&ctrLat=6.756930008476716&swLng=-66.504734875&swLat=0.22551092967499356&neLng=-49.805516125&neLat=13.288349087278439',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-90.23075899999998&ctrLat=15.75868926425294&swLng=-94.40556368749998&swLat=12.588547190612397&neLng=-86.05595431249998&neLat=18.92883133789348',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=23.727538800000048&ctrLat=37.80042557501959&swLng=15.377929425000048&swLat=32.60766756720602&neLng=32.07714817500005&neLat=42.99318358283315',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-0.18696439999996528&ctrLat=5.59451688179604&swLng=-4.361769087499965&swLat=2.3161424305324463&neLng=3.9878402875000347&neLat=8.872891333059634',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=11.431135700000027&ctrLat=49.93971266120131&swLng=3.081526325000027&swLat=45.71206053040824&neLng=19.780745075000027&neLat=54.167364791994395',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=2.1052869999999757&ctrLat=48.85574782950506&swLng=-6.244322375000024&swLat=44.53356520954767&neLng=10.454896374999976&neLat=53.17793044946246',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=24.754852400000004&ctrLat=60.696887269326254&swLng=20.580047712500004&swLat=59.08534071706332&neLng=28.929657087500004&neLat=62.30843382158918',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-89.21819110000001&ctrLat=13.60617704014094&swLng=-97.56780047500001&swLat=7.214242576066964&neLng=-80.86858172500001&neLat=19.998111504214915',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=31.23571160000006&ctrLat=29.88071127519064&swLng=22.88610222500006&swLat=24.180885819731913&neLng=39.58532097500006&neLat=35.58053673064937',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-78.46783820000002&ctrLat=-0.17946418788089913&swLng=-86.81744757500002&swLat=-6.756734898810999&neLng=-70.11822882500002&neLat=6.3978065230492005',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-69.9312117&ctrLat=18.45758529369065&swLng=-74.1060163875&swLat=15.333129039732222&neLng=-65.7564070125&neLat=21.582041547649073',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-90.41148720000001&ctrLat=38.51021057534548&swLng=-94.58629188750001&swLat=35.93315137481516&neLng=-86.23668251250001&neLat=41.08726977587581',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-90.41148720000001&ctrLat=38.37210601197073&swLng=-98.76109657500001&swLat=33.219905603213235&neLng=-82.06187782500001&neLat=43.52430642072822',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=10.438500599999998&ctrLat=55.05604046603288&swLng=2.0888912249999976&swLat=51.29429284092101&neLng=18.788109974999998&neLat=58.81778809114476',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=13.373637099999996&ctrLat=49.69169916185491&swLng=9.198832412499996&swLat=47.561439471809955&neLng=17.548441787499996&neLat=51.82195885189988',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=4.486331800000016&ctrLat=52.03895411787704&swLng=-3.8632775749999837&swLat=47.99861923941452&neLng=12.835941175000016&neLat=56.07928899633955',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-84.09072459999999&ctrLat=9.864012657547617&swLng=-92.44033397499999&swLat=3.384360843753977&neLng=-75.74111522499999&neLat=16.343664471341256',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-74.072092&ctrLat=4.680120092465676&swLng=-82.421701375&swLat=-1.8751563431941947&neLng=-65.722482625&neLat=11.235396528125547',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=116.40739630000007&ctrLat=39.85758177581878&swLng=112.23259161250007&swLat=37.32948562135654&neLng=120.58220098750007&neLat=42.38567793028102',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-70.6692655&ctrLat=-33.40533039219217&swLng=-74.8440701875&swLat=-36.15475959843711&neLng=-66.4944608125&neLat=-30.655901185947226',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=24.74529039999993&ctrLat=41.94723884783245&swLng=16.39568102499993&swLat=37.06011278521671&neLng=33.09489977499993&neLat=46.834364910448194',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-50.32635600000003&ctrLat=-27.659603865279287&swLng=-58.67596537500003&swLat=-33.48249191257435&neLng=-41.97674662500003&neLat=-21.836715817984217',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-46.63330939999997&ctrLat=-23.41224854135846&swLng=-54.98291877499997&swLat=-29.445938244690794&neLng=-38.28370002499997&neLat=-17.37855883802612',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=4.486331800000016&ctrLat=52.03895411787704&swLng=-3.8632775749999837&swLat=47.99861923941452&neLng=12.835941175000016&neLat=56.07928899633955',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-63.15608529999997&ctrLat=-17.704674599084637&swLng=-71.50569467499997&swLat=-23.96917598462807&neLng=-54.80647592499997&neLat=-11.440173213541206',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=4.521964799999978&ctrLat=51.01727652789013&swLng=-3.827644575000022&swLat=46.88508759410809&neLng=12.871574174999978&neLat=55.14946546167217',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=13.012416400000006&ctrLat=47.691951170583096&swLng=4.662807025000006&swLat=43.269989405546994&neLng=21.362025775000006&neLat=52.113912935619204',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=145.273282&ctrLat=-37.82292361792398&swLng=136.923672625&swLat=-43.014095235981614&neLng=153.622891375&neLat=-32.63175199986635',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=145.31600000000003&ctrLat=-37.75612449193101&swLng=141.14119531250003&swLat=-40.35996706110427&neLng=149.49080468750003&neLat=-35.15228192275775',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-122.676601&ctrLat=45.47510075720381&swLng=-126.8514056875&swLat=43.16587436211881&neLng=-118.5017963125&neLat=47.78432715228882',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-122.676601&ctrLat=45.33331004164318&swLng=-131.026210375&swLat=40.71473702321898&neLng=-114.326991625&neLat=49.95188306006738',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-121.29500969999998&ctrLat=51.459719369338735&swLng=-129.64461907499998&swLat=47.36714975008854&neLng=-112.94540032499998&neLat=55.552288988588934',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-121.29500969999998&ctrLat=51.459719369338735&swLng=-129.64461907499998&swLat=47.36714975008854&neLng=-112.94540032499998&neLat=55.552288988588934',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-122.30446970000003&ctrLat=48.86306217031127&swLng=-130.65407907500003&swLat=44.541512303059534&neLng=-113.95486032500003&neLat=53.18461203756301',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-122.30446970000003&ctrLat=49.00353253359877&swLng=-126.47927438750003&swLat=46.84325189806739&neLng=-118.12966501250003&neLat=51.16381316913016',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-122.30446970000003&ctrLat=49.00353253359877&swLng=-126.47927438750003&swLat=46.84325189806739&neLng=-118.12966501250003&neLat=51.16381316913016',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-125.27333529999999&ctrLat=49.846751110740605&swLng=-133.62294467499999&swLat=45.61093252681164&neLng=-116.92372592499999&neLat=54.08256969466957',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-125.27333529999999&ctrLat=49.846751110740605&swLng=-133.62294467499999&swLat=45.61093252681164&neLng=-116.92372592499999&neLat=54.08256969466957',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-125.27333529999999&ctrLat=49.846751110740605&swLng=-133.62294467499999&swLat=45.61093252681164&neLng=-116.92372592499999&neLat=54.08256969466957',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-125.27333529999999&ctrLat=49.846751110740605&swLng=-133.62294467499999&swLat=45.61093252681164&neLng=-116.92372592499999&neLat=54.08256969466957',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-125.27333529999999&ctrLat=49.846751110740605&swLng=-133.62294467499999&swLat=45.61093252681164&neLng=-116.92372592499999&neLat=54.08256969466957',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-122.676601&ctrLat=45.47510075720381&swLng=-126.8514056875&swLat=43.16587436211881&neLng=-118.5017963125&neLat=47.78432715228882',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-125.27333529999999&ctrLat=49.846751110740605&swLng=-133.62294467499999&swLat=45.61093252681164&neLng=-116.92372592499999&neLat=54.08256969466957',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-125.27333529999999&ctrLat=49.846751110740605&swLng=-133.62294467499999&swLat=45.61093252681164&neLng=-116.92372592499999&neLat=54.08256969466957',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-125.27333529999999&ctrLat=49.9864726870144&swLng=-129.44813998749999&swLat=47.86916647907299&neLng=-121.09853061249999&neLat=52.103778894955816',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-125.27333529999999&ctrLat=49.846751110740605&swLng=-133.62294467499999&swLat=45.61093252681164&neLng=-116.92372592499999&neLat=54.08256969466957',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-125.27333529999999&ctrLat=49.846751110740605&swLng=-133.62294467499999&swLat=45.61093252681164&neLng=-116.92372592499999&neLat=54.08256969466957',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-125.27333529999999&ctrLat=49.9864726870144&swLng=-129.44813998749999&swLat=47.86916647907299&neLng=-121.09853061249999&neLat=52.103778894955816',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-125.27333529999999&ctrLat=49.9864726870144&swLng=-129.44813998749999&swLat=47.86916647907299&neLng=-121.09853061249999&neLat=52.103778894955816',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-125.27333529999999&ctrLat=49.846751110740605&swLng=-133.62294467499999&swLat=45.61093252681164&neLng=-116.92372592499999&neLat=54.08256969466957',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-125.27333529999999&ctrLat=49.846751110740605&swLng=-133.62294467499999&swLat=45.61093252681164&neLng=-116.92372592499999&neLat=54.08256969466957',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-125.27333529999999&ctrLat=49.846751110740605&swLng=-133.62294467499999&swLat=45.61093252681164&neLng=-116.92372592499999&neLat=54.08256969466957',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-125.27333529999999&ctrLat=49.846751110740605&swLng=-133.62294467499999&swLat=45.61093252681164&neLng=-116.92372592499999&neLat=54.08256969466957',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-125.27333529999999&ctrLat=49.846751110740605&swLng=-133.62294467499999&swLat=45.61093252681164&neLng=-116.92372592499999&neLat=54.08256969466957',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-125.27333529999999&ctrLat=49.846751110740605&swLng=-133.62294467499999&swLat=45.61093252681164&neLng=-116.92372592499999&neLat=54.08256969466957',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-125.27333529999999&ctrLat=49.9864726870144&swLng=-129.44813998749999&swLat=47.86916647907299&neLng=-121.09853061249999&neLat=52.103778894955816',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-125.27333529999999&ctrLat=49.846751110740605&swLng=-133.62294467499999&swLat=45.61093252681164&neLng=-116.92372592499999&neLat=54.08256969466957',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-125.27333529999999&ctrLat=49.846751110740605&swLng=-133.62294467499999&swLat=45.61093252681164&neLng=-116.92372592499999&neLat=54.08256969466957',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-125.27333529999999&ctrLat=49.846751110740605&swLng=-133.62294467499999&swLat=45.61093252681164&neLng=-116.92372592499999&neLat=54.08256969466957',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-125.27333529999999&ctrLat=49.846751110740605&swLng=-133.62294467499999&swLat=45.61093252681164&neLng=-116.92372592499999&neLat=54.08256969466957',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-125.27333529999999&ctrLat=49.9864726870144&swLng=-129.44813998749999&swLat=47.86916647907299&neLng=-121.09853061249999&neLat=52.103778894955816',
            'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-125.27333529999999&ctrLat=49.846751110740605&swLng=-133.62294467499999&swLat=45.61093252681164&neLng=-116.92372592499999&neLat=54.08256969466957'

        ]
        for url in urls:
            # url =  "http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-122.676601&ctrLat=45.33331004164318&swLng=-131.026210375&swLat=40.71473702321898&neLng=-114.326991625&neLat=49.95188306006738"
            # gurl = "'http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-122.676601&ctrLat=45.52228088060879&swLng=-122.93752629296876&swLat=45.37795563687331&neLng=-122.41567570703126&neLat=45.66660612434427"
            yield scrapy.Request(url=url, callback=self.data3, headers=headers)

    def data3(self, response):

        # url = ["http://apps.warn.com/wwwapps/api/dealerlocator/v1/dealer?ctrLng=-113.7627354&ctrLat=53.55205053882575&swLng=-114.02366069296875&swLat=53.42967173550453&neLng=-113.50181010703125&neLat=53.67442934214698"]

        json_text = json.loads(response.text)
        le = len(json_text)
        for i in range(0, le):
            try:store_name = json_text[i]['name']
            except:store_name = ''

            try:address = json_text[i]['address1']
            except:address = ''

            # try:address_line_2 = json_text[i]['address2']
            # except:address_line_2 = ''

            check = False
            for j in ['Unit', 'STE', 'Ste', 'SUITE', 'Suite', 'suite', 'Suit', 'SUIT', 'suit', 'UNIT', 'unit', 'ste']:
                for aw in address.split():
                    if j == aw:
                        address1 = address.split(j)[0].strip().strip(',')
                        address_line_2 = j + ' ' + address.split(j)[-1].strip()
                        check = True
                        break
            if check == True:
                address_line_2 = address_line_2
                address = address1
            else:
                address_line_2 = ''
                address = address

            try:
                country = json_text[i]['country']
                if country == "":
                    country = "US"
                else:
                    country = country
            except Exception as e:
                print("country",e)

            try:city = json_text[i]['city']
            except:city = ''

            try:state = json_text[i]['stateorprovince']
            except:state = ''

            try:zip_code = json_text[i]['postalCode']
            except:zip_code = ''

            try:phone_number = json_text[i]['phone']
            except:phone_number = ''

            try:latitude = json_text[i]['geoLat']
            except:latitude = ''

            try:longitude = json_text[i]['geoLong']
            except:longitude = ''

            try:
                wesite = json_text[i]['website']
                if "." in wesite:
                    wesite = wesite.replace('1200 N. Weinbach Ave','').replace('1621 n.e. 51 ave','').replace('460 VAN HORNE ST., CRANBROOK, B.C., CANADA','')
                else:
                    wesite = ''
            except:
                wesite = ''

            item = StoreLocatorsItem()
            item['search_term'] = 'link'
            item['store_name'] = store_name
            item['address'] = address
            item['address_line_2'] = address_line_2
            item['city'] = city
            item['state'] = state
            item['country'] = item['country_code'] = country
            item['zip_code'] = zip_code
            item['phone_number'] = phone_number
            item['fax_number'] = ''
            item['latitude'] = latitude
            item['longitude'] = longitude
            item['website_address'] = wesite
            item['coming_soon'] = 0
            item['source_url'] = response.url
            # item['country'] = 'United States' if item['zip_code'].replace('-', '').isdigit() else 'Canada'
            # item['country_code'] = self.f1.country_dict.get(item['country'].lower())

            yield item

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_132 -a list_id=132'''.split())
