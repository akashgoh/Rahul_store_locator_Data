# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime
import itertools


class TanishqCrawlerSpider(scrapy.Spider):
    name = 'store_195'
    allowed_domains = []
    f1 = Func()

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            self.f1.set_details(self.list_id,run_date)
            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                print(search_terms)
            # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)

                search_terms = ''
                for search_term in (search_terms):
                    source_url = link = f"https://www.bestbuy.com/browse-api/2.0/store-locator/{search_term}"
                    file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(search_term) + '_' + str(run_date) + '.html'
                    if os.path.exists(file_path):
                        link = 'file://' + file_path.replace('\\','/')
                    yield scrapy.FormRequest(url=str(link), callback=self.get_store_list, meta={'source_url': source_url,'search_term': search_term,'file_path':file_path,'proxy_type': self.proxy_type})
            else:
                source_url = link = 'https://www.tanishq.co.in/wps/proxy/https/wc-services.crown.in/wcs/resources/store/10151/storelocator/byCityOrZip?isServiceCenter=false&siteLevelStoreSearch=false&supportedBrand=TQ'
                file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(self.name) + '_' + str(run_date) + '.html'
                yield scrapy.FormRequest(url=str(link), callback=self.get_store_list,meta={'source_url': source_url,'file_path': file_path,'proxy_type': self.proxy_type})

        except Exception as e:
            logging.log(logging.ERROR, e)

    # Get data from the response
    def get_store_list(self, response):
        try:
            if not response.url.startswith('file://'):
                self.f1.page_save(response.meta['file_path'],response.body)

            search_term = response.meta.get('search_term', '')
            source_url = response.meta.get('source_url', '')
            store_data = json.loads(response.text)['PhysicalStore']
            print(len(store_data))

            # If you have search_by :zip_code/city/state/lat_lng then you need to add following condition and query to update log table
            if len(store_data) == 0:
                Func.update_log_table(self.f1,search_term)
            else:
                for store in range(len(store_data)):
                    try:
                        additional_info = {}
                        item = StoreLocatorsItem()

                        item['search_term'] = search_term

                        STATE = {"Andhra Pradesh":"AD","Arunachal Pradesh":"AR","ASSAM":"AS","Assam":"AS","Bihar":"BR","Chhattisgarh":"CG","Delhi - Vasant Kunj":"DL","Delhi - Janakpuri":"D:","New Delhi":"DL","Delhi - Shahdara":"DL","DELHI":"DL","Delhi":"DL","Goa":"GA","Gujarat":"GJ","Haryana":"HR","Himachal Pradesh":"HP","Jammu & Kashmir":"JK","Jammu and Kashmir":"JK","Jharkhand":"JH","Karnataka":"KA","Kerala":"KL","Lakshadweep Islands":"LD","Madhya Pradesh":"MP","MADHYA PRADESH":"MH","Maharashtra":"MH","MAHARASHTRA":"MH","Manipur":"MN","Meghalaya":"ML","Mizoram":"MZ","Nagaland":"NL","Odisha":"OD","Pondicherry":"PY","Punjab":"PB","Rajasthan":"RJ","Sikkim":"SK","TAMIL NADU":"TN","Tamil Nadu":"TN","Telangana":"TS","TELANGANA":"TS","Tripura":"TR","Uttar Pradesh":"UP","Uttarpradesh":"UP","Uttarakhand":"UK","West Bengal":"WB","WestBengal":"WB","Andaman and Nicobar Islands":"AN","Chandigarh":"CH","Dadra and Nagar Haveli":"DN","Daman and Diu":"DD","Other Territory":"OT"}
                        st = store_data[store]['stateOrProvinceName']
                        # for element in STATE:
                        #     if st == element:
                        #         stt = st.values()

                        stt = dict((k, v) for k, v in STATE.items()).get(st)

                        item['state'] = stt
                        item['store_name'] = store_data[store]['storeName']
                        fulladdress = store_data[store]['addressLine'][0]

                        try:
                            check = False
                            address = fulladdress
                            for i in ['Unit', 'Suite', 'Ste']:
                                for aw in address.split():
                                    if i == aw:
                                        address1 = address.split(i)[0].strip(',')
                                        address_line_2 = i + ' ' + address.split(i)[-1].strip()
                                        check = True
                                        break

                            if check == True:
                                address_line_2 = address_line_2
                                address = address1
                            else:
                                address_line_2 = ''
                                address = address
                        except Exception as e:
                            print(e)

                        item['address'] = address.strip()
                        item['address_line_2'] = address_line_2.strip()
                        item['city'] = store_data[store]['city']

                        item['zip_code'] = store_data[store]['postalCode'].strip()
                        phone_number = store_data[store]['telephone1']

                        if not phone_number:
                            phone_number = ''

                        item['phone_number'] = phone_number

                        item['latitude'] = store_data[store]['latitude']
                        item['longitude'] = store_data[store]['longitude']
                        item['store_type'] = ''
                        item['source_url'] = source_url
                        item['coming_soon'] = 0
                        item['store_number'] = ''
                        item['country_code'] = 'IN' #self.f1.country_dict.get(item['country'].lower())
                        item['services'] = ''
                        item['country'] = 'IN'

                        # if item['country_code'] == 'IN' and len(item['state']) > 2:
                        #     item['state'] = self.f1.state_dict.get(store.get(item['state'].lower(), '')) #getting  us state code

                        try:
                            store_hours_list = store_data[store]['Attribute'][4:]
                            if store_hours_list != '':
                                store_hours_list_temp = []

                                # list(filter(lambda i: i['Attribute'] != 6, store_hours_list))
                                for store_hour in store_hours_list[:7]:

                                    store_hours_list_temp.append(store_hour['displayName'] + ' : ' + store_hour['displayValue'])

                                store_hours = '|'.join(store_hours_list_temp)

                                if 'Store Manager Mobile' in store_hours:
                                    for store_hour in store_hours_list[:8]:
                                        store_hours_list_temp.append(
                                            store_hour['displayName'] + ' : ' + store_hour['displayValue'])

                                    store_hours = '|'.join(store_hours_list_temp).replace('Store Manager Mobile : NA|','')

                                item['store_hours'] = store_hours

                                # print('|'.join(store_hours_list_temp))
                            else:
                                item['store_hours'] = ''
                        except Exception as e:
                            item['store_hours'] = ''
                        # print(store_data[store]['Attribute'][1]['value'])
                        email_address = store_data[store]['Attribute'][1]['value']

                        if 'https:/' in email_address:
                            email_address = ''

                        item['email_address'] = email_address

                        item['additional_info'] = store_data[store]['Description'][0]['displayStoreName']
                        item['number_of_store'] = len(store_data)

                        yield item
                    except Exception as e:
                        print(e)

        except Exception as e:
            logging.log(logging.ERROR, e)

    def response_html_path(self, request):
        return request.meta['fpath']

#
# execute('''scrapy crawl store_195 -a list_id=195'''.split())
