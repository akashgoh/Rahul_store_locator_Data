# -*- coding: utf-8 -*-
import scrapy,os,logging,hashlib
import requests,json, usaddress
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime
from collections import OrderedDict
import re
import html2text
from string import punctuation
run_date = str(datetime.datetime.today()).split()[0]
h = html2text.HTML2Text()

class store_103Spider(scrapy.Spider):
    name = 'store_103'
    allowed_domains = []
    f1 = Func()

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            # source_url = link = 'https://www.powr.io/plugins/map/wix_view.json?cacheKiller=1570619584999&compId=comp-jyozp6q9&currency=USD&deviceType=desktop&height=405&instance=gTNYBh5oUepAtTVfv08w7DBP0VMT7xt5Iaef_0W20Wo.eyJpbnN0YW5jZUlkIjoiZGE2MmZiOTMtZTNhYS00OTE5LWFmYTgtMTNiYzA0MjIyOTRlIiwiYXBwRGVmSWQiOiIxMzQwYzVlZC1hYWM1LTIzZWYtNjkzYy1lZDIyMTY1Y2ZkODQiLCJzaWduRGF0ZSI6IjIwMTktMTAtMTBUMDc6MTQ6NDEuOTM1WiIsInVpZCI6bnVsbCwicGVybWlzc2lvbnMiOm51bGwsImlwQW5kUG9ydCI6IjEyMy4yMDEuNjUuODUvNTMwMDgiLCJ2ZW5kb3JQcm9kdWN0SWQiOiJidXNpbmVzcyIsImRlbW9Nb2RlIjpmYWxzZSwiYWlkIjoiODdhMjNjODQtNWJhNS00YTFmLWFmNTktNTdlZTQxZDFlYWNmIiwic2l0ZU93bmVySWQiOiI1MTczMzVkYS02ODU0LTQ1M2EtYjI4Ni0xZjVlMWI5OWI3ZDMifQ&locale=en&pageId=hejda&siteRevision=260&tz=America%2FLos_Angeles&viewMode=site&width=980'
            source_url = link = 'https://www.powr.io/wix/map/public.json?instance=MKOukliPtCHuOpzeZkVevU7qN1Sg966I5-kf9NCAzyQ.eyJpbnN0YW5jZUlkIjoiZGE2MmZiOTMtZTNhYS00OTE5LWFmYTgtMTNiYzA0MjIyOTRlIiwiYXBwRGVmSWQiOiIxMzQwYzVlZC1hYWM1LTIzZWYtNjkzYy1lZDIyMTY1Y2ZkODQiLCJzaWduRGF0ZSI6IjIwMjAtMTEtMjVUMDQ6MTg6NDMuOTM0WiIsInZlbmRvclByb2R1Y3RJZCI6ImJ1c2luZXNzIiwiZGVtb01vZGUiOmZhbHNlLCJhaWQiOiIyYTk4MzEzMS03OGMyLTQ0ZjgtODJiZC02YzM4YTcxYzJmNGIiLCJzaXRlT3duZXJJZCI6IjUxNzMzNWRhLTY4NTQtNDUzYS1iMjg2LTFmNWUxYjk5YjdkMyJ9&pageId=rda7c&compId=comp-k8s2ixwy&viewerCompId=comp-k8s2ixwy&siteRevision=956&viewMode=site&deviceType=desktop&locale=en&commonConfig=%7B%22brand%22%3A%22wix%22%2C%22bsi%22%3A%22d048a52e-ac0a-4a55-9230-a41e3b5bf38a%7C1%22%2C%22BSI%22%3A%22d048a52e-ac0a-4a55-9230-a41e3b5bf38a%7C1%22%7D&tz=America%2FLos_Angeles&vsi=befdba91-3d1e-42e5-859a-ed6a093aa972&currency=USD&currentCurrency=USD&width=980&height=635&url=https://www.zerodegreescompany.com/locations'
            self.f1.set_details(self.list_id, run_date)
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(run_date) + '.html'
            if os.path.exists(file_path):
                link = 'file://' + file_path.replace('\\', '/')
            yield scrapy.FormRequest(url=str(link), callback=self.get_store_list,meta={'source_url': source_url,'file_path': file_path, 'proxy_type': self.proxy_type})

        except Exception as e:
            print(e)

    def get_store_list(self,response):
        if not response.url.startswith('file://'):
            self.f1.page_save(response.meta['file_path'], response.body)
        try:
            # res = requests.get('https://www.powr.io/plugins/map/wix_view.json?cacheKiller=1570710228478&compId=comp-jyozp6q9&currency=USD&deviceType=desktop&height=405&instance=5F3KhnSOfOZM5vulBhg_PV4Ky8SUs2WftnqRBGIQEag.eyJpbnN0YW5jZUlkIjoiZGE2MmZiOTMtZTNhYS00OTE5LWFmYTgtMTNiYzA0MjIyOTRlIiwiYXBwRGVmSWQiOiIxMzQwYzVlZC1hYWM1LTIzZWYtNjkzYy1lZDIyMTY1Y2ZkODQiLCJzaWduRGF0ZSI6IjIwMTktMTAtMTBUMTI6Mzk6NDIuMzEyWiIsInVpZCI6bnVsbCwiaXBBbmRQb3J0IjoiMjE5LjkxLjE5Ni4yMzUvMTE4NjgiLCJ2ZW5kb3JQcm9kdWN0SWQiOiJidXNpbmVzcyIsImRlbW9Nb2RlIjpmYWxzZSwiYWlkIjoiZGZlMzlmOGYtNmE5YS00OGVhLThjMjgtMjg0YTBkNWM1NjY3Iiwic2l0ZU93bmVySWQiOiI1MTczMzVkYS02ODU0LTQ1M2EtYjI4Ni0xZjVlMWI5OWI3ZDMifQ&locale=en&pageId=hejda&siteRevision=261&tz=America%2FLos_Angeles&viewMode=site&width=980')
            res = requests.get('https://www.powr.io/wix/map/public.json?instance=MKOukliPtCHuOpzeZkVevU7qN1Sg966I5-kf9NCAzyQ.eyJpbnN0YW5jZUlkIjoiZGE2MmZiOTMtZTNhYS00OTE5LWFmYTgtMTNiYzA0MjIyOTRlIiwiYXBwRGVmSWQiOiIxMzQwYzVlZC1hYWM1LTIzZWYtNjkzYy1lZDIyMTY1Y2ZkODQiLCJzaWduRGF0ZSI6IjIwMjAtMTEtMjVUMDQ6MTg6NDMuOTM0WiIsInZlbmRvclByb2R1Y3RJZCI6ImJ1c2luZXNzIiwiZGVtb01vZGUiOmZhbHNlLCJhaWQiOiIyYTk4MzEzMS03OGMyLTQ0ZjgtODJiZC02YzM4YTcxYzJmNGIiLCJzaXRlT3duZXJJZCI6IjUxNzMzNWRhLTY4NTQtNDUzYS1iMjg2LTFmNWUxYjk5YjdkMyJ9&pageId=rda7c&compId=comp-k8s2ixwy&viewerCompId=comp-k8s2ixwy&siteRevision=956&viewMode=site&deviceType=desktop&locale=en&commonConfig=%7B%22brand%22%3A%22wix%22%2C%22bsi%22%3A%22d048a52e-ac0a-4a55-9230-a41e3b5bf38a%7C1%22%2C%22BSI%22%3A%22d048a52e-ac0a-4a55-9230-a41e3b5bf38a%7C1%22%7D&tz=America%2FLos_Angeles&vsi=befdba91-3d1e-42e5-859a-ed6a093aa972&currency=USD&currentCurrency=USD&width=980&height=635&url=https://www.zerodegreescompany.com/locations')
            response = HtmlResponse(url=res.url, body=res.content)
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(run_date) + '.html'
            if not response.url.startswith('file://'):
                self.f1.page_save(file_path, response.body)
            df = json.loads(response.text)
            loop = df['content']['locations']
            for loc in loop:
                try:
                    item = StoreLocatorsItem()
                    a = usaddress.tag(loc['address'].strip(), tag_mapping={'Recipient': 'recipient','AddressNumber': 'address1','AddressNumberPrefix': 'address1','AddressNumberSuffix': 'address1','StreetName': 'address1','StreetNamePreDirectional': 'address1','StreetNamePreModifier': 'address1','StreetNamePreType': 'address1','StreetNamePostDirectional': 'address1','StreetNamePostModifier': 'address1','StreetNamePostType': 'address1','CornerOf': 'address1','IntersectionSeparator': 'address1','LandmarkName': 'address1','USPSBoxGroupID': 'address1','USPSBoxGroupType': 'address1','USPSBoxID': 'address1','USPSBoxType': 'address1','BuildingName': 'address2','OccupancyType': 'address2','OccupancyIdentifier': 'address2','SubaddressIdentifier': 'address2','SubaddressType': 'address2','PlaceName': 'city','StateName': 'state','ZipCode': 'zip_code',})
                    add1 = a[0].get('address1') if a[0].get('address1')!=None else ''
                    add2 = a[0].get('address2') if a[0].get('address2')!=None else ''
                    city = a[0].get('city') if a[0].get('city')!=None else ''
                    state = a[0].get('state') if a[0].get('state')!=None else ''
                    zip_code = a[0].get('zip_code') if a[0].get('zip_code')!=None else ''

                    temp = h.handle(loc['description']).strip()
                    if "Coming Soon" in temp:
                        item['coming_soon'] = 1
                        item['phone_number'] = ''
                        item['additional_info'] = ''
                    else:
                        item['coming_soon'] = 0
                        item['phone_number'] = temp.strip().split('\n\n')[-1].split('|')[0].strip().replace(')','').replace('-','').replace(' ','').strip(punctuation)
                        if re.match('(\D+)',item['phone_number']):
                            item['phone_number']=''
                        item['additional_info'] = json.dumps({'additional_info':'|'.join(set(re.findall('\[(.*?)\]',temp) + re.findall('>?\s+/|(Uber.*)</p',temp)))})

                    item['store_name'] = 'Zero Degrres - '+h.handle(loc['name']).strip().replace('*','')
                    item['address'] = add1
                    if item['address']=='1315 NW 185th Ave':
                        item['additional_info'] = json.dumps({'additional_info': '|'.join(set(re.findall('\[(.*?)\]', temp) + ['UberEATS'] ))})
                    item['address_line_2'] = add2
                    item['address_line_3'] = ''
                    item['city'] = city
                    item['state'] = state
                    item['zip_code'] = zip_code
                    item['country'] = 'US'
                    item['country_code'] = 'US'
                    item['latitude'] = loc['lat']
                    item['longitude'] = loc['lng']
                    item['source_url'] = 'https://www.zerodegreescompany.com/locations'
                    yield item
                except Exception as e:
                    logging.log(logging.ERROR, e)
        except Exception as e:
            logging.log(logging.ERROR, e)


# execute('''scrapy crawl store_103 -a list_id=103 '''.split())#-s HTTPCACHE_ENABLED=True
