# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import re
import pgeocode
import scrapy, os, logging, hashlib
import requests, json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from selenium import webdriver
from selenium.webdriver.firefox.options import Options
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime


class Store16Spider(scrapy.Spider):
    name = 'store_16'
    allowed_domains = []

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
    def start_requests(self):
        try:
            self.f1.set_details(self.list_id, self.run_date)
            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                print(search_terms)
                # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)
                search_terms = ''
                for search_term in (search_terms):
                    source_url = link = 'https://16handles.com/locations/'
                    file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(search_term) + '_' + str(
                        self.run_date) + '.html'
                    if os.path.exists(file_path):
                        link = 'file://' + file_path.replace('\\', '/')
                    yield scrapy.FormRequest(url=str(link), callback=self.get_store_list,
                                             meta={'source_url': source_url, 'search_term': search_term,
                                                   'file_path': file_path, 'proxy_type': self.proxy_type})
            else:
                header = {"accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
                          "accept-encoding": "gzip, deflate, br",
                          "accept-language": "en-US,en;q=0.9",
                          "sec-fetch-mode": "navigate",
                          "sec-fetch-site": "none",
                          "user-agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36"}
                source_url = link = 'https://www.dillons.com/storelocator-sitemap.xml'
                file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
                    self.run_date) + '.html'
                yield scrapy.FormRequest(url=str(link), callback=self.firstlevel, headers=header,
                                         meta={'source_url': source_url,
                                               'file_path': file_path, 'proxy_type': self.proxy_type})
        except Exception as e:
            logging.log(logging.ERROR, e)

    def firstlevel(self, response):
        try:
            response.selector.remove_namespaces()
            source_url = response.meta['source_url']
            file_path = response.meta['file_path']
            proxy_type = response.meta['proxy_type']
            links = response.xpath('/urlset/url/loc/text()').extract()
            for link in links:
                header = {
                    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3",
                    "accept-encoding": "gzip, deflate, br",
                    "accept-language": "en-US,en;q=0.9",
                    "sec-fetch-mode": "navigate",
                    "sec-fetch-site": "none",
                    "user-agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36"}
                yield scrapy.FormRequest(url=link, callback=self.get_store_list, headers=header,
                                         meta={'source_url': source_url, 'file_path': file_path,
                                               'proxy_type': proxy_type})
        except Exception as e:
            print("firstlevel", e, response.url)

    # Get data from the response
    def get_store_list(self, response):
        try:
            if not response.url.startswith('file://'):
                self.f1.page_save(response.meta['file_path'], response.body)
            search_term = response.meta.get('search_term', '')
            try:
                item = StoreLocatorsItem()
                try:
                    store_type = response.xpath('//h2/text()').extract()[-1].strip()
                except Exception as e:
                    store_type=''
                    print(e)
                try:
                    store_name = ''.join(response.xpath('//h1/text()').extract())
                except Exception as e:
                    print("store_name", e, response.url)

                try:
                    phone_number = response.xpath('//*[@data-qa="phoneNumber"]/text()').extract_first().strip()
                except Exception as e:
                    print("phone_number", e, response.url)

                try:
                    add = response.xpath('//*[@type="application/ld+json"]/text()').extract_first().replace('&quot;', '"')
                    add_data = json.loads(add)
                    address_detail = address = add_data["address"]["streetAddress"]
                    address_line_2 = ''
                    for i in ['Unit', 'STE', 'Ste', 'SUITE', 'Suite', 'suite', 'Suit', 'SUIT', 'suit', 'UNIT', 'unit','ste']:
                        for aw in address_detail.split(' '):
                            if i == aw:
                                if address_detail.split(' ').index(aw) != 0:
                                    address = address_detail.split(i)[0].strip()
                                    address_line_2 = i + ' ' + address_detail.split(i)[-1].strip()
                                    break
                    city = add_data["address"]["addressLocality"]
                    state = add_data["address"]["addressRegion"]
                    zip_code = add_data["address"]["postalCode"]
                    latitude = add_data["geo"]["latitude"]
                    longitude = add_data["geo"]["longitude"]
                except Exception as e:
                    print("address", e, response.url)

                try:
                    store_hour = '|'.join(add_data["openingHours"])
                except Exception as e:
                    print("store_hours", e, response.url)

                try:
                    pharm = response.xpath('//*[@class="StoreInformation-pharmacyWrapper mb-12"]')
                    if len(pharm)>0:
                        pharmacy = 1
                        pharmacy_phone_number = response.xpath('//*[@class="StoreInformation-pharmacyPhone whitespace-no-wrap"]//span[@data-qa="phoneNumber"]/text()').extract_first()
                        pharma_hours = []
                        pharm_hours = response.xpath('//*[@class="StoreInformation-pharmacyHours mt-4"]/div/div')
                        for hour in pharm_hours:
                            pharma_hours.append(hour.xpath('.//*[@class="StoreInformation-day font-medium"]/text()').extract_first() + hour.xpath('.//*[@class="StoreInformation-day font-medium"]/following-sibling::span/text()').extract_first())
                        pharmacy_hours = '|'.join(pharma_hours)
                    else:
                        pharmacy = 0
                        pharmacy_hours = ''
                        pharmacy_phone_number = ''
                except Exception as e:
                    print("pharmacy", e, response.url)

                try:
                    services = '|'.join(response.xpath('//*[@class="StoreServices-departmentsList"]/li/text()').extract())
                except Exception as e:
                    print(e)


                item['search_term'] = search_term
                item['store_type'] = store_type
                item['store_name'] = store_name
                item['address'] = address
                item['address_line_2'] = address_line_2
                item['city'] = city
                item['state'] = state
                item['zip_code'] = zip_code
                item['phone_number'] = phone_number
                item['latitude'] = latitude
                item['longitude'] = longitude
                item['pharmacy'] = pharmacy
                item['pharmacy_phone_number'] = pharmacy_phone_number
                item['pharmacy_hours'] = pharmacy_hours
                item['services'] = services
                item['coming_soon'] = 0
                item['source_url'] = response.url
                item['country_code'] = item['country'] = 'US'  # self.f1.country_dict.get(item['country'].lower())
                item['store_hours'] = store_hour.strip('|')
                if item['country_code'] == 'US' and len(item['state']) > 2:
                    item['state'] = self.f1.state_dict.get(state, '')
                yield item
            except Exception as e:
                print(e)

        except Exception as e:
            logging.log(logging.ERROR, e)

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_16 -a list_id=16 -a proxy_type='''.split())
# run only on ipvanish