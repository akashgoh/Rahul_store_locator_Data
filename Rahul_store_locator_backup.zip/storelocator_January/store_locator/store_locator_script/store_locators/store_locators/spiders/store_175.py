# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import re
import pgeocode
import scrapy, os, logging, hashlib
import requests, json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime


class Store175Spider(scrapy.Spider):
    name = 'store_175'
    allowed_domains = []


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]

    def start_requests(self):
        self.f1.set_details(self.list_id, self.run_date)
        try:
            source_url = ['https://www.tileforlessutah.com/', 'https://tileforlessnw.com/locations/']#
            for url in source_url:
                file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(self.run_date) + '.html'
                yield scrapy.FormRequest(url=str(url), callback=self.firstlevel,
                                         meta={'source_url': url,
                                               'file_path': file_path, 'proxy_type': self.proxy_type})


        except Exception as e:
            logging.log(logging.ERROR, e)

    def firstlevel(self, response):
        source_url = response.meta['source_url']
        file_path = response.meta['file_path']
        proxy_type = response.meta['proxy_type']
        if 'tileforlessutah' in response.url:
            try:

                Store_links = response.xpath('//*[contains(text(),"Locations")]/../..//ul/li/a/@href').extract()
                for link in Store_links:

                    yield scrapy.FormRequest(url=link, callback=self.get_store_list,
                                             meta={'source_url': source_url, 'file_path': file_path,
                                                   'proxy_type': proxy_type})
            except Exception as e:
                print("firstlevel", e, response.url)
        else:
            try:
                store_data = response.xpath('//*[@class="panel-row-style panel-row-style-for-1298-1"]/div')
                for data in store_data:
                    if not response.url.startswith('file://'):
                        self.f1.page_save(response.meta['file_path'], response.body)
                    search_term = response.meta.get('search_term', '')

                    item = StoreLocatorsItem()
                    try:
                        store_name = data.xpath('.//strong/text()').extract_first(default='').strip().title()
                    except Exception as e:
                        print("store_name", e, response.url)

                    try:
                        phone_number = data.xpath('.//*[contains(text(),"Phone")]/text()').extract_first(default='').strip().split(':')[-1]
                    except Exception as e:
                        print("phone_number", e, response.url)


                    try:
                        address = data.xpath('.//p/text()').extract_first().strip()
                    except Exception as e:
                        print("address", e, response.url)

                    try:
                        city = data.xpath('.//p/text()[2]').extract_first().strip().split(',')[0].strip()
                    except Exception as e:
                        print("city", e, response.url)

                    try:
                        zip_code = data.xpath('.//p/text()[2]').extract_first().strip().split(',')[-1].strip().split(' ')[-1]
                    except Exception as e:
                        print("zip_code", e, response.url)

                    try:
                        state = data.xpath('.//p/text()[2]').extract_first().strip().split(',')[-1].strip().split(' ')[0]
                    except Exception as e:
                        state = ''
                        print("state", e, response.url)

                    try:
                        latlong = ''.join(re.findall(r'll=(.*?)&|@(.*?),3a',data.xpath('.//*[contains(@href,"google.com")]/@href').extract_first())[0]).split(',')
                        latitude = latlong[0]
                        longitude = latlong[-1]
                    except Exception as e:
                        print("latitude and longitude", e, response.url)

                    try:
                        store_hours = 'Open Mon-Fri 7AM-6PM and Sat 9AM-5PM (Closed Sunday)'
                    except Exception as e:
                        print("store_hours", e, response.url)

                    item['search_term'] = search_term
                    item['store_name'] = store_name
                    item['address'] = address
                    item['city'] = city
                    item['state'] = state
                    item['zip_code'] = zip_code
                    item['phone_number'] = phone_number
                    item['latitude'] = latitude
                    item['longitude'] = longitude
                    item['store_type'] = ''
                    item['coming_soon'] = 0
                    item['source_url'] = response.url
                    item['country_code'] = item['country'] = 'CA'  # self.f1.country_dict.get(item['country'].lower())
                    item['store_hours'] = store_hours.strip('|')
                    if item['country_code'] == 'US' and len(item['state']) > 2:
                        item['state'] = self.f1.state_dict.get(state, '')
                    yield item

            except Exception as e:
                print(e)

    # Get data from the response
    def get_store_list(self, response):
        try:
            if not response.url.startswith('file://'):
                self.f1.page_save(response.meta['file_path'], response.body)
            search_term = response.meta.get('search_term', '')
            try:
                item = StoreLocatorsItem()
                try:
                    store_name = response.xpath('//h1/text()').extract_first().strip().title()
                except Exception as e:
                    print("store_name", e, response.url)
                add = ''.join(response.xpath('//*[@class="address"]/address/text()').extract()).strip().split('\n')
                try:
                    phone_number = add[2].strip()
                except Exception as e:
                    print("phone_number", e, response.url)

                try:

                    address = add[0].split('\n')[0].strip()
                except Exception as e:
                    print("address", e, response.url)

                try:
                    city = add[1].strip().split(',')[0]
                except Exception as e:
                    print("city", e, response.url)

                try:
                    zip_code = add[1].strip().split(',')[-1].strip().split(' ')[-1].strip()
                except Exception as e:
                    print("zip_code", e, response.url)

                try:
                    state = add[1].strip().split(',')[-1].strip().split(' ')[0].strip()
                except Exception as e:
                    state = ''
                    print("state", e, response.url)

                try:
                    ll = response.xpath('//iframe/@src').extract_first()
                    latlong = re.findall(r'-(.*?)!3m',ll)[0].split('!3d')
                    latitude = latlong[-1]
                    longitude = latlong[0]
                except Exception as e:
                    print("latitude and longitude", e, response.url)

                try:
                    store_hours = add[3].replace('Store Hours:', '').strip()
                except Exception as e:
                    print("store_hours", e, response.url)


                item['search_term'] = search_term
                item['store_name'] = store_name
                item['address'] = address
                item['city'] = city
                item['state'] = state
                item['zip_code'] = zip_code
                item['phone_number'] = phone_number
                item['latitude'] = latitude
                item['longitude'] = longitude
                item['store_type'] = ''
                item['coming_soon'] = 0
                item['source_url'] = response.url
                item['country_code'] = item['country'] = 'CA'  # self.f1.country_dict.get(item['country'].lower())
                item['store_hours'] = store_hours.strip('|')
                if item['country_code'] == 'US' and len(item['state']) > 2:
                    item['state'] = self.f1.state_dict.get(state, '')
                yield item
            except Exception as e:
                print(e)

        except Exception as e:
            logging.log(logging.ERROR, e)

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_175 -a list_id=175 -a proxy_type=luminaty'''.split())