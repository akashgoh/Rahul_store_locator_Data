# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import re

import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime


class stiga_seSpider(scrapy.Spider):
    name = 'store_216'
    allowed_domains = []
    not_export_data = True

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.f1.set_details(self.list_id, self.run_date)
    def start_requests(self):
        try:

            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                print(search_terms)
            # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)
                search_terms = ''
                for search_term in (search_terms):
                    source_url = link = 'https://16handles.com/locations/'
                    file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(search_term) + '_' + str(self.run_date) + '.html'
                    if os.path.exists(file_path):
                        link = 'file://' + file_path.replace('\\','/')
                    yield scrapy.FormRequest(url=str(link), callback=self.get_store_list, meta={'source_url': source_url,'search_term': search_term,'file_path':file_path,'proxy_type': self.proxy_type})
            else:
                source_url = link = 'https://www.stiga.com/se/hitta-en-aterforsaljare/?shop_type=shop&address=&lat=&lng='
                file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
                    self.run_date) + '.html'
                yield scrapy.FormRequest(url=str(link), callback=self.firstlevel,
                                         meta={'source_url': source_url,
                                               'file_path': file_path, 'proxy_type': self.proxy_type})

        except Exception as e:
            logging.log(logging.ERROR, e)


    def firstlevel(self,response):
        try:
            source_url = response.meta['source_url']

            file_path = response.meta['file_path']
            proxy_type = response.meta['proxy_type']
            divs = response.xpath('//span[@name="leftLocation"]')
            for div in divs:
                url = div.xpath('./a/@href').extract_first()
                phone = div.xpath('.//a[@class="color-light text-underline storelocator-phone"]/@href').extract_first()
                if phone == None:
                    phone = ''
                else:
                    phone = phone.replace("tel:",'').strip()

                email = div.xpath('.//a[@class="color-light storelocator-email"]/@href').extract_first()
                if email == None:
                    email = ''
                else:
                    email = email.replace('mailto:','').strip()

                latitude = div.xpath('./@data-lat').extract_first()
                longitude = div.xpath('./@data-lng').extract_first()

                yield scrapy.FormRequest(url=url,callback=self.get_store_list,meta={'source_url':source_url,'file_path':file_path,'proxy_type':proxy_type,'email':email,'phone':phone,'latitude':latitude,'longitude':longitude})


        except Exception as e:
            print("firstlevel",e,response.url)


    def get_store_list(self, response):
        try:
            if not response.url.startswith('file://'):
                self.f1.page_save(response.meta['file_path'],response.body)

            search_term = response.meta.get('search_term', '')
            source_url = response.meta.get('source_url', '')


            try:
                additional_info = {}
                item = StoreLocatorsItem()

                try:
                    store_name = response.xpath('//h1[@class="heading-2 store-name"]//text()').extract_first().strip()
                except Exception as e:
                    print("store_name",e,response.url)

                try:
                    phone_number = response.meta['phone']
                except Exception as e:
                    print("phone_number", e, response.url)

                try:
                    email_address = response.meta['email']
                except Exception as e:
                    print("email_address", e, response.url)

                try:
                    address = response.xpath('//p[@class="store-address"]//text()').extract_first()
                    if address == None:
                        address = ''
                    else:
                        address  = address.strip()
                except Exception as e:
                    print("address", e, response.url)

                try:
                    cityzipcode = response.xpath('//p[@class="store-city"]//text()').extract_first()
                    if cityzipcode == None:
                        city = ''
                        zip_code = ''
                    else:
                        cityzipcode1 = cityzipcode.strip().split()
                        zip_code = cityzipcode1[0].strip()
                        city = cityzipcode1[1].strip()

                except Exception as e:
                    print("city", e, response.url)

                try:
                   latitude = response.meta['latitude']
                   longitude = response.meta['longitude']

                except Exception as e:
                    print("latitude and longitude", e, response.url)

                try:
                    services = '|'.join(response.xpath('//div[@class="store-advanced-information row"]/div/ul/li/span/span//text()').extract())

                except Exception as e:
                    print("services",e,response.url)

                try:

                    store_hours = ''

                except Exception as e:
                    print("store_hours",e,response.url)



                try:
                    Website = response.xpath('//a[@class="store-mail storelocator-website"]/@href').extract_first()
                    if Website == None:

                        Website = ''
                    else:
                        Website = Website
                    additional_info = {}


                except Exception as e:
                    print("additional_info",e,response.url)








                item['search_term'] = search_term
                item['store_name']= store_name
                item['address'] = address
                if city == "95":
                    city = "Ydre"
                if city == "52":
                    city = "Kallinge"
                if city == "32":
                    city = "Karlshamn"
                item['city'] = city
                item['state'] =''
                if zip_code == "372":
                    zip_code = "372 52"
                if zip_code == "573":
                    zip_code = "573 95"
                if zip_code == "374":
                    zip_code = "374 32"
                item['zip_code'] = zip_code
                item['phone_number'] =phone_number
                item['latitude'] = latitude
                item['longitude'] = longitude
                item['store_type'] = ''
                item['website_address'] = Website
                item['coming_soon'] = 0
                item['store_number'] = ''
                item['country_code'] = item['country'] = 'SE' #self.f1.country_dict.get(item['country'].lower())
                item['email_address'] = email_address
                item['services'] = services
                item['source_url'] = response.url
                item['store_hours'] = store_hours
                item['additional_info'] = json.dumps(additional_info)


                yield item
            except Exception as e:
                print("get_store_list",e,response.url)


        except Exception as e:
            logging.log(logging.ERROR, e)

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_216 -a list_id=216'''.split())
