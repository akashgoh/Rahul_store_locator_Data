import hashlib
import re
import scrapy
import json
from store_locators.spiders.common_functions import Func
from store_locators.items import StoreLocatorsItem
import datetime
import html2text,os


class Store158Spider(scrapy.Spider):
    name = 'store_158'
    start_urls = ['https://tupelohoneycafe.com/locations/']
    f1 = Func()
    # def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
    #     super().__init__(name, **kwargs)
    #     self.list_id, self.proxy_type = list_id, proxy_type
    #     self.f1 = Func()
    #
    # def parse(self, response):
    #     run_date = str(datetime.datetime.today()).split()[0]
    #     self.f1.set_details(self.list_id, run_date)
    #     links = response.xpath('//*[@id="SubMenu-1"]//a/@href').extract()
    #     for link in links:
    #         url = "https://www.eatearthburger.com" + link
    #         yield scrapy.Request(url=url, callback=self.get_store_list)

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            source_url = link = 'https://tupelohoneycafe.com/locations/'

            self.f1.set_details(self.list_id, run_date)
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(run_date) + '.html'
            if os.path.exists(file_path):
                link = 'file://' + file_path.replace('\\', '/')

            yield scrapy.FormRequest(url=str(link), callback=self.get_store_links, meta={'source_url': source_url,'file_path': file_path, 'proxy_type': self.proxy_type})

        except Exception as e:
            print(e)


    def get_store_links(self,response):

        head = "https://tupelohoneycafe.com"
        file_path = response.meta['file_path']
        Blocks = response.xpath('//div[@class="main_menu_locations_aligner"]//li')
        try:
            for blk in Blocks:
                link = blk.xpath('./a/@href').get()
                if head not in link and link != '#':
                    print("allow")
                    link = head+link
                    yield scrapy.Request(link,self.InsideStore,meta={'file_path':file_path})
        except Exception as e:
            print(e)

    def InsideStore(self,response):

        if not response.url.startswith('file://'):
            self.f1.page_save(response.meta['file_path'], response.body)

        try:
            tmpStoreName1 = response.xpath('//title/text()').get()
            if 'Coming Soon' in tmpStoreName1 or 'Coming Soon' in response.xpath('//div[@id="tupelo_location"]/a/text()').get():
                tmpStoreName = tmpStoreName1.replace('Coming Soon to','').replace('&amp;','&')
                store_name = tmpStoreName.replace('|',',').strip()
            else:
                store_name = tmpStoreName1.split('|')[0]

            try:
                if 'Coming Soon' in tmpStoreName1 or 'Coming Soon' in response.xpath('//div[@id="tupelo_location"]/a/text()').get():
                    coming = 1

                    info = response.xpath('//div[@class="columns"]').extract()[0]
                    text_maker = html2text.HTML2Text()
                    text_maker.ignore_images = True
                    text_maker.ignore_links = True
                    text_maker.ignore_emphasis = True
                    text_maker.ignore_tables = True
                    text_maker.body_width = 0
                    additional_info = text_maker.handle(info)

                    address = response.xpath('//span[@itemprop="streetAddress"]/text()').get()
                    if not address:
                        address = ''
                    city = response.xpath('//span[@itemprop="addressLocality"]/text()').get()
                    state = response.xpath('//span[@itemprop="addressRegion"]/text()').get()
                    zip_code = response.xpath('//span[@itemprop="postalCode"]/text()').get()
                    if zip_code == None or not zip_code:
                        zip_code = ''
                    phone_number = response.xpath('//span[@itemprop="telephone"]/text()').get()
                    if 'Coming Soon' in phone_number:
                        phone_number = ''

                    try:
                        Hours = []
                        tmpHrs = response.xpath('//div[@class="four columns"][2]//text()').extract()
                        for tmp in tmpHrs:
                            if tmp.strip() and 'Restaurant Hours:' not in tmp and tmp != 'Hours':
                                Hours.append(tmp.strip())
                        Hours = '|'.join(Hours)
                    except Exception as e:
                        print('Hours in comng soon 1',e,response.url)

                    services = response.xpath('//h6[contains(text(),"Service")]/following-sibling::p//text()').extract()
                    services = '|'.join(services)


                else:

                    coming = 0
                    services = ''

                    tmp = response.xpath('//div[@class="columns"]').extract()
                    info = tmp[0]+tmp[-1]
                    text_maker = html2text.HTML2Text()
                    text_maker.ignore_images = True
                    text_maker.ignore_links = True
                    text_maker.ignore_emphasis = True
                    text_maker.ignore_tables = True
                    text_maker.body_width = 0
                    additional_info = text_maker.handle(info)

                    try:
                        address = response.xpath('//span[@itemprop="streetAddress"]/text()').get()
                        city = response.xpath('//span[@itemprop="addressLocality"]/text()').get()
                        state = response.xpath('//span[@itemprop="addressRegion"]/text()').get()
                        zip_code = response.xpath('//span[@itemprop="postalCode"]/text()').get()
                        tmpPhn = response.xpath('//span[@itemprop="telephone"]/text()').get()
                        tmpPhn = re.findall('(\d+)',tmpPhn)
                        phone_number = '('+tmpPhn[0]+')'+tmpPhn[1]+'-'+tmpPhn[2]
                    except Exception as e:
                        print('Address',e)

                    store_number = int(hashlib.md5(store_name.encode('ascii','ignore')).hexdigest(), 16)% (10 ** 16)

                    Hours = []
                    tmpHrs = response.xpath('//div[@class="four columns"][2]//text()').extract()
                    for tmp in tmpHrs:
                        if tmp.strip() and 'Restaurant Hours:' not in tmp and tmp != 'Hours':
                            Hours.append(tmp.strip())
                    Hours = '|'.join(Hours)
            except Exception as e:
                print(e)

            check = False
            # address = fulladdress[0].strip()
            for i in ['. Ste', 'Suite', ', Ste', 'Ste ', 'Ste.', 'Ste']:
                for aw in address.split():
                    if i == aw:
                        address1 = address.split(i)[0].strip(',')
                        address_line_2 = i + ' ' + address.split(i)[-1].strip()
                        check = True
                        break
            if check == True:
                address_line_2 = address_line_2
                address = address1
            else:
                address_line_2 = ''
                address = address

            # if 'Suite' in address:
            #     address_line_2 = 'Suite '+address.split('Suite')[-1].strip()
            #     address = address.split('Suite')[0].strip()
            # else:
            #     address_line_2 = ''

            item = StoreLocatorsItem()

            item['services'] = services
            item['address'] = address.strip()
            item['address_line_2'] = address_line_2
            item['city'] = city.strip()
            item['state'] = state.strip()
            item['zip_code'] = zip_code
            item['country'] = 'United States'
            item['country_code'] = 'US'
            item['store_name'] = store_name.strip()
            item['phone_number'] = phone_number
            item['latitude'] = 0
            item['longitude'] = 0
            item['store_type'] = 'Restaurant'
            item['coming_soon'] = coming
            # item['store_number'] = store_number
            item['source_url'] = response.url
            item['additional_info'] = additional_info.strip()
            item['store_hours'] = Hours

            yield item
        except Exception as e:
            print("Problem in yield item",e,response.url)

from scrapy.cmdline import execute
# execute('''scrapy crawl store_158 -a list_id=158 '''.split())
# execute('''scrapy crawl store_158 -a list_id=158 -s HTTPCACHE_ENABLED=False'''.split())


