

import json

import pymysql
import scrapy
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime
import  _json


class ViaeroSpiders(scrapy.Spider):
    name = 'store_146'
    # allowed_domains = ['']
    start_urls = ['']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]

    def start_requests(self):
        try:
            run_date = str(datetime.datetime.today()).split()[0]
            self.f1.set_details(self.list_id, run_date)
            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                # print(search_terms)
                for search_term in (search_terms):
                    print(search_term)
                    lat = search_term.split("_")[0]
                    lng = search_term.split("_")[1]


            #============= fetch on localhost =============================#

            # self.con = pymysql.connect('localhost', 'root', 'xbyte', 'ziptable')
            # self.crsr = self.con.cursor()
            # qry = f"select * from {'ziptable'}.{'us_zipcode_old_csv'}"
            # self.crsr.execute(qry)
            # result = self.crsr.fetchall()
            # # result = ['https://youtube.com/channel/UC0v-tlzsn0QZwJnkiaUSJVQ/about']
            # # print(len(result))
            # for search_term in result:
            #     lat = search_term[4]
            #     print(lat)
            #     lng = search_term[5]
            #     print(lng)

                    source_url = link =  'https://stores.viaero.com/modules/multilocation/?near_lat=' + str(lat) + '&near_lon=' + str(lng) + '&services__in=&within_business=true'
                    # source_url = link = 'https://stores.viaero.com/modules/multilocation/?near_lat=23.022505&near_lon=72.5713621&services__in=&within_business=true'
                    # source_url = link = f'https://stores.viaero.com/modules/multilocation/?near_lat={ll[0]}&near={ll[1]}&&services__in=&within_business=true'
                    print(source_url)
                    # source_url = link = 'https://stores.viaero.com/modules/multilocation/?near_lat=23.022505&near_lon=72.5713621&services__in=&within_business=true'
                    # source_url = link = 'https://stores.viaero.com/modules/multilocation/?near_lat=40.783060299999995&near_lon=-73.9712488&services__in=&within_business=true'
                    #         file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
                    #             self.run_date) + '.html'
                    yield scrapy.FormRequest(url=link, callback=self.get_store_list)
        except Exception as e:
            print("error che bhai")
            print(e)

    def get_store_list(self,response):

        # if not response.url.startswith('file://'):
        #     self.f1.page_save(response.meta['file_path'], response.body)
        search_term = response.meta.get('search_term', '')
        # source_url = response.meta.get('source_url', '')
        data = response.text
        body = json.loads(data)
        # print(body)
        y = len(body['objects'])
        for i in range(0, y):
            item = StoreLocatorsItem()
            try:
                h1 = body['objects'][0]['formatted_hours']['primary']['days'][0]['label'] + ':' + body['objects'][i]['formatted_hours']['primary']['days'][0]['content']
                h2 = body['objects'][0]['formatted_hours']['primary']['days'][1]['label'] +':'+ body['objects'][i]['formatted_hours']['primary']['days'][1]['content']
                h3 = body['objects'][0]['formatted_hours']['primary']['days'][2]['label'] + ':' + body['objects'][i]['formatted_hours']['primary']['days'][2]['content']
                h4 = body['objects'][0]['formatted_hours']['primary']['days'][3]['label'] + ':' + body['objects'][i]['formatted_hours']['primary']['days'][3]['content']
                h5= body['objects'][0]['formatted_hours']['primary']['days'][4]['label'] + ':' + body['objects'][i]['formatted_hours']['primary']['days'][4]['content']
                h6 = body['objects'][0]['formatted_hours']['primary']['days'][5]['label'] + ':' + body['objects'][i]['formatted_hours']['primary']['days'][5]['content']
                h7 = body['objects'][0]['formatted_hours']['primary']['days'][6]['label'] + ':' + body['objects'][i]['formatted_hours']['primary']['days'][6]['content']

                hours = str(h1)+'|'+ str(h2)+'|' + str(h3)+'|' +  str(h4)+'|' + str(h5)+'|' + str(h6)+'|' + str(h7)

                item['search_term'] = search_term
                store_name = body['objects'][i]['location_name']
                print(store_name)
                item['store_name'] = store_name
                address1 = body['objects'][i]['formatted_address']
                item['address'] = address1
                item['city'] = body['objects'][i]['city']
                item['state'] = body['objects'][i]['state_name']
                item['zip_code'] = body['objects'][i]['postal_code']
                item['phone_number'] = body['objects'][i]['phonemap_e164']['phone']
                item['latitude'] = body['objects'][i]['lat']
                item['longitude'] = body['objects'][i]['lon']
                item['store_hours'] = hours
                item['website_address'] = body['objects'][i]['location_url']
                item['country'] = body['objects'][i]['country']
                yield item
            except Exception as e:
                print("item ma error")
                print(e)
#
from scrapy.cmdline import execute
# execute('scrapy crawl store_146 -a list_id=146'.split())


                #================================  old  Code   ==================================#

#
# import json
#
# import scrapy
# from store_locators.items import StoreLocatorsItem
# from store_locators.spiders.common_functions import Func
# import datetime
# import  _json
#
#
# class ViaeroSpiders(scrapy.Spider):
#     name = 'viaero'
#     # allowed_domains = ['']
#     start_urls = ['']
#
#     # def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
#     #     super().__init__(name, **kwargs)
#     #     self.list_id, self.proxy_type = list_id, proxy_type
#     #     self.f1 = Func()
#     def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
#         super().__init__(name, **kwargs)
#         self.list_id, self.proxy_type = list_id, proxy_type
#         self.f1 = Func()
#         self.run_date = str(datetime.datetime.today()).split()[0]
#
#     def start_requests(self):
#         try:
#             self.f1.set_details(self.list_id, self.run_date)
#             # source_url = link = 'https://stores.viaero.com/modules/multilocation/?near_location=United%20States&services__in=&within_business=true'
#             # source_url = link = 'https://stores.viaero.com/modules/multilocation/?near_lat=23.022505&near_lon=72.5713621&services__in=&within_business=true'
#             source_url = link = 'https://stores.viaero.com/modules/multilocation/?near_lat=40.783060299999995&near_lon=-73.9712488&services__in=&within_business=true'
#
#             file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
#                 self.run_date) + '.html'
#             yield scrapy.FormRequest(url=link, callback=self.get_store_list,
#                                      meta={'source_url': source_url,
#                                            'file_path': file_path, 'proxy_type': self.proxy_type})
#         except Exception as e:
#             print("error che bhai")
#             print(e)
#
#     def get_store_list(self,response):
#
#         if not response.url.startswith('file://'):
#             self.f1.page_save(response.meta['file_path'], response.body)
#         search_term = response.meta.get('search_term', '')
#         source_url = response.meta.get('source_url', '')
#         data = response.text
#         body = json.loads(data)
#         # print(body)
#         y = len(body['objects'])
#         for i in range(0, y):
#             item = StoreLocatorsItem()
#             try:
#
#                 h1 = body['objects'][0]['formatted_hours']['primary']['days'][0]['label'] + ':' + body['objects'][i]['formatted_hours']['primary']['days'][0]['content']
#                 h2 = body['objects'][0]['formatted_hours']['primary']['days'][1]['label'] +':'+ body['objects'][i]['formatted_hours']['primary']['days'][1]['content']
#                 h3 = body['objects'][0]['formatted_hours']['primary']['days'][2]['label'] + ':' + body['objects'][i]['formatted_hours']['primary']['days'][2]['content']
#                 h4 = body['objects'][0]['formatted_hours']['primary']['days'][3]['label'] + ':' + body['objects'][i]['formatted_hours']['primary']['days'][3]['content']
#                 h5= body['objects'][0]['formatted_hours']['primary']['days'][4]['label'] + ':' + body['objects'][i]['formatted_hours']['primary']['days'][4]['content']
#                 h6 = body['objects'][0]['formatted_hours']['primary']['days'][5]['label'] + ':' + body['objects'][i]['formatted_hours']['primary']['days'][5]['content']
#                 h7 = body['objects'][0]['formatted_hours']['primary']['days'][6]['label'] + ':' + body['objects'][i]['formatted_hours']['primary']['days'][6]['content']
#
#                 hours = str(h1)+'|'+ str(h2)+'|' + str(h3)+'|' +  str(h4)+'|' + str(h5)+'|' + str(h6)+'|' + str(h7)
#
#                 item['search_term'] = search_term
#                 store_name = body['objects'][i]['location_name']
#                 print(store_name)
#                 item['store_name'] = store_name
#                 address1 = body['objects'][i]['formatted_address']
#                 item['address'] = address1
#                 item['city'] = body['objects'][i]['city']
#                 item['state'] = body['objects'][i]['state_name']
#                 item['zip_code'] = body['objects'][i]['postal_code']
#                 item['phone_number'] = body['objects'][i]['phonemap_e164']['phone']
#                 item['latitude'] = body['objects'][i]['lat']
#                 item['longitude'] = body['objects'][i]['lon']
#                 item['store_hours'] = hours
#                 item['website_address'] = body['objects'][i]['location_url']
#                 item['country'] = body['objects'][i]['country']
#                 yield item
#             except Exception as e:
#                 print("item ma error")
#                 print(e)
#
# #
# from scrapy.cmdline import execute
# execute('scrapy crawl viaero -a list_id=146 -s HTTPCACHE_ENABLED=True'.split())
