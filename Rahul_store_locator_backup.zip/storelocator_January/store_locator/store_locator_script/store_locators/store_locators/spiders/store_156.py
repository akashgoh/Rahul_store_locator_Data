import hashlib
import re
from scrapy.http import HtmlResponse
import requests
import scrapy
import json
from store_locators.spiders.common_functions import Func
from store_locators.items import StoreLocatorsItem
import datetime
import html2text,os

class Store156Spider(scrapy.Spider):
    name = 'store_156'
    f1 = Func()

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            source_url = link = 'https://www.twistedrootburgerco.com/locations'

            self.f1.set_details(self.list_id, run_date)
            # file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(run_date) + '.html'
            # if os.path.exists(file_path):
            #     link = 'file://' + file_path.replace('\\', '/')

            yield scrapy.FormRequest(url=str(link), callback=self.get_store_links, meta={'source_url': source_url, 'proxy_type': self.proxy_type})#,'file_path': file_path

        except Exception as e:
            print(e)


    def get_store_links(self,response):

        head = "https://www.twistedrootburgerco.com"
        # file_path = response.meta['file_path']
        Blocks = response.xpath('//div[@class="item itemPreview hasImg squareImages hasHoverEffect hasHoverEffect--grayscale hasImgEffect hasImgEffect--color"]')
        try:
            for blk in Blocks:
                link = blk.xpath('.//h2/a/@href').get()
                city = blk.xpath('.//h2/a/text()').get()
                if 'Winter Park' in city:
                    city = 'Winter Park'
                if 'Deep Ellum' in city:
                    city = 'Dallas'
                if 'TEMP CLOSED' in city or 'temp closed' in city:
                    city = city.split('-')[0].strip()
                if head not in link:
                    link = head+link
                    # link = 'https://www.twistedrootburgerco.com/locations/winter-park-florida-now-open'
                yield scrapy.Request(link,self.InsideStore,meta={'CT':city})#'file_path':file_path,
        except Exception as e:
            print(e)

    def InsideStore(self,response):
        item = StoreLocatorsItem()
        try:
            # if not response.url.startswith('file://'):
            #     self.f1.page_save(response.meta['file_path'], response.body)

            try:
                store_name = response.xpath('//div[@class="blockText"]//h2[@class="contentTitle"]/text()').get().replace('- NOW OPEN!','')
                info = response.xpath('//div[@class="blockText"]//div[@class="maxWidth--content"]').extract()
                if len(info) > 0:
                    info = info[0]
                    text_maker = html2text.HTML2Text()
                    text_maker.ignore_images = True
                    text_maker.ignore_links = True
                    text_maker.ignore_emphasis = True
                    text_maker.ignore_tables = True
                    text_maker.body_width = 0
                    additional_info = text_maker.handle(info)
                    item['additional_info'] = additional_info.strip()

                AddrPh = response.xpath('//h2[contains(text(),"Location")]//following-sibling::div//ul//li//text()').extract()
                if len(AddrPh)>1:
                    tmpPhn = AddrPh[-1].strip()
                    tmpPhn = re.findall('(\d+)',tmpPhn)
                    try:
                        phone_number = '('+tmpPhn[0]+')'+tmpPhn[1]+'-'+tmpPhn[2]
                    except : phone_number = ''
                    city = response.meta['CT']
                    if len(AddrPh) > 2:
                        AddrPh = ''.join(AddrPh[0:-1])
                    else:
                        AddrPh = AddrPh[0]
                    tmpAddr = AddrPh.split(',')
                    address = ''.join(tmpAddr[0:-1])
                    try:
                        state = re.findall('([A-Z]{2,2})',tmpAddr[-1])[0]
                    except : state = 'TX'
                    zip_code = re.findall('(\d{5})',tmpAddr[-1])[0]
                else:
                    try:
                        Addr = response.xpath('//h2[contains(text(),"Location")]//following-sibling::div//p//text()').get().split(',')
                        address = Addr[0].strip()
                        city = response.meta['CT']
                        state = re.findall('([A-Z]{2,2})', Addr[-1])[0]
                        zip_code = re.findall('(\d{5})', Addr[-1])[0]
                        phone_number = ''
                    except:
                        address = ''
                        city = ''
                        state = ''
                        zip_code = ''
                Hours = '|'.join(response.xpath('//h2[contains(text(),"Hours")]//following-sibling::div//ul//li//text()|//h2[contains(text(),"Hours")]//following-sibling::div//p//text()').extract())

            except Exception as e:
                print('Address',e,response.url)

            check = False
            for i in ['Unit', 'STE', 'Ste', 'Suite', 'suite']:
                for aw in address.split():
                    if i == aw:
                        address1 = address.split(i)[0].strip(',')
                        address_line_2 = i + ' ' + address.split(i)[-1].strip()
                        check = True
                        break
            if check == True:
                address_line_2 = address_line_2
                address = address1
            else:
                address_line_2 = ''
                address = address

            latlong_url = response.xpath('//h2[contains(text(),"Location")]//following-sibling::div//li[1]/a/@href').extract_first()
            if latlong_url:
                res1 = requests.get(latlong_url)
                response1 = HtmlResponse(url=res1.url, body=res1.content)
                ll_text = re.findall(r'll=(.*?)\" itemprop=\"image\"\>', response1.text, re.DOTALL)
                if len(ll_text) > 0:
                    ll_text1 = ll_text[0].split(',')
                    latitude = ll_text1[0]
                    longitude = ll_text1[1]
                else:
                    ll_text = re.findall(r'center=(.*?)&amp', response1.text, re.DOTALL)
                    if len(ll_text) > 0:
                        ll_text1 = ll_text[0].split('%2C')
                        latitude = ll_text1[0]
                        longitude = ll_text1[1]
                print(latlong_url)
            else:
                latitude, longitude = 0, 0

            item['address'] = address.replace(city.strip(),'').replace(state.strip(),'').strip()
            item['address_line_2'] = address_line_2.replace(city.strip(),'').replace(state.strip(),'').strip()
            item['city'] = city.strip()
            item['state'] = state.strip()
            item['zip_code'] = zip_code.strip()
            item['country'] = 'United States'
            item['country_code'] = 'US'
            item['store_name'] = 'Twisted Root Burger - '+store_name.strip()
            item['phone_number'] = phone_number.strip()
            item['latitude'] = latitude
            item['longitude'] = longitude
            item['store_type'] = ''
            item['coming_soon'] = 0
            item['source_url'] = response.url
            item['store_hours'] = Hours
            if 'DFW Airport' in city:
                item['email_address'] = "jason@twistedrootburgerco.com"
            else:
                item['email_address'] = ''
            yield item
        except Exception as e:
            print("Problem in yield item",e)

from scrapy.cmdline import execute
# execute('''scrapy crawl store_156 -a list_id=156 '''.split())
# execute('''scrapy crawl twistedrootburgerco -a list_id=156 -s HTTPCACHE_ENABLED=False'''.split())


