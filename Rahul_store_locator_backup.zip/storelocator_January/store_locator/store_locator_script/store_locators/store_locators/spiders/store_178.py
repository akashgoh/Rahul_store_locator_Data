# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import re
import pgeocode
import scrapy, os, logging, hashlib
import requests, json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from w3lib.html import remove_tags

from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime


class Store178Spider(scrapy.Spider):
    name = 'store_178'
    allowed_domains = []


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]

    def start_requests(self):
        try:
            self.f1.set_details(self.list_id, self.run_date)
            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                print(search_terms)
                # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)
                search_terms = ''
                for search_term in (search_terms):
                    source_url = link = 'https://16handles.com/locations/'
                    file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(search_term) + '_' + str(self.run_date) + '.html'
                    if os.path.exists(file_path):
                        link = 'file://' + file_path.replace('\\', '/')
                    yield scrapy.FormRequest(url=str(link), callback=self.get_store_list,
                                             meta={'source_url': source_url, 'search_term': search_term,
                                                   'file_path': file_path, 'proxy_type': self.proxy_type})
            else:
                source_url = link = 'https://www.originalmattress.com/find-a-store'
                file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(self.run_date) + '.html'
                yield scrapy.FormRequest(url=str(link), callback=self.firstlevel,
                                         meta={'source_url': source_url,
                                               'file_path': file_path, 'proxy_type': self.proxy_type})
        except Exception as e:
            logging.log(logging.ERROR, e)

    def firstlevel(self, response):
        try:
            source_url = response.meta['source_url']
            file_path = response.meta['file_path']
            proxy_type = response.meta['proxy_type']
            Store_links = response.xpath('//h2/a/@href').extract()
            for link in Store_links:
                store_link = 'https://www.originalmattress.com' + link
                yield scrapy.FormRequest(url=store_link, callback=self.get_store_list,
                                         meta={'source_url': source_url, 'file_path': file_path,
                                               'proxy_type': proxy_type})
        except Exception as e:
            print("firstlevel", e, response.url)

    # Get data from the response
    def get_store_list(self, response):
        try:
            if not response.url.startswith('file://'):
                self.f1.page_save(response.meta['file_path'], response.body)
            search_term = response.meta.get('search_term', '')
            try:
                item = StoreLocatorsItem()
                try:
                    store_name = 'The Original Mattress Factory - ' + response.xpath('//h1/text()').extract_first().strip().title()
                except Exception as e:
                    print("store_name", e, response.url)

                try:
                    phone_number = ''.join(response.xpath('//*[@itemprop="telephone"]/a/text()|//*[@class="store-phone"]/a/text()').extract_first(default='')).strip()
                    if not phone_number:
                        phone_number = ''.join(response.xpath('//*[contains(text(),"Phone")]/a/text()|//*[contains(text(),"Phone")]/text()').extract()).replace('Phone:', '').strip()
                except Exception as e:
                    print("phone_number", e, response.url)

                text = re.findall(r'Get Directions(.*?)Phone', response.text, re.DOTALL)[0].replace('<br />',',').replace('<div>',',').replace('</p>',',').replace('\r','').replace('\n','')
                address_text = remove_tags(text).strip(',').strip().split(',')
                if len(address_text) == 4:
                    address_detail = address = address_text[0].strip() + ' ' + address_text[1].strip()
                    city = address_text[2].strip()
                    state = re.findall(r'(\w{2})', address_text[-1])[0]
                    zip_code = re.findall(r'(\d+)', address_text[-1])[0]
                else:
                    address_detail = address = address_text[0].strip()
                    city = address_text[1].strip()
                    state = re.findall(r'(\w{2})',address_text[-1])[0]
                    zip_code = re.findall(r'(\d+)',address_text[-1])[0]

                address_line_2 = ''
                for i in ['unit', 'suite', 'suit', 'ste']:
                    for aw in address_detail.split(' '):
                        if i.title() == aw:
                            address = address_detail.split(i.title())[0].strip()
                            address_line_2 = i.title() + ' ' + address_detail.split(i.title())[-1].strip()
                            break
                try:
                    ll = response.xpath('//*[@class="map-wrapper"]/iframe/@src').extract_first()
                    latlong = re.findall(r'&q=(.*?)&', ll)[0].split(',')
                    latitude = latlong[0]
                    longitude = latlong[-1].strip('+')
                except Exception as e:
                    print("latitude and longitude", e, response.url)

                try:
                    store_hours = '|'.join(response.xpath('//*[@class="store-hours"]/text()').extract()).replace('Store Hours:','').strip(':')
                    if not store_hours:
                        store_hours = '|'.join(response.xpath('//*[contains(text(),"Store Hours:")]/following-sibling::div/text()|//*[contains(text(),"Store Hours:")]/following-sibling::p/text()').extract()[:3]).strip(':')
                except Exception as e:
                    print("store_hours", e, response.url)

                try:
                    additional_info = {}
                    Credit_Cards = response.xpath('//*[@class="store-credit-cards"]/text()').extract_first()
                    if Credit_Cards:
                        additional_info['Credit Cards Accepted:'] = Credit_Cards
                    Reference_Point = response.xpath('//*[@class="store-reference-point"]/text()').extract_first()
                    if Reference_Point:
                        additional_info['Reference Point:'] = Reference_Point
                    Financing_Available = response.xpath('//*[contains(text(),"Financing Available")]/text()').extract_first(default='')
                    if Financing_Available:
                        additional_info['Financing Available'] = Financing_Available.split('—')[-1].strip()
                    additional_info = json.dumps(additional_info)
                except Exception as e:
                    print('additional_info', e, response.url)

                item['search_term'] = search_term
                item['store_name'] = store_name
                item['address'] = address.strip()
                item['address_line_2'] = address_line_2
                item['city'] = city
                item['state'] = state.upper()
                item['zip_code'] = zip_code
                item['phone_number'] = phone_number
                item['latitude'] = latitude
                item['longitude'] = longitude
                item['store_type'] = ''
                item['coming_soon'] = 0
                item['source_url'] = response.url
                item['country_code'] = item['country'] = 'US'  # self.f1.country_dict.get(item['country'].lower())
                item['store_hours'] = store_hours.strip('|')
                item['additional_info'] = additional_info
                if item['country_code'] == 'US' and len(item['state']) > 2:
                    item['state'] = self.f1.state_dict.get(state, '')
                yield item
            except Exception as e:
                print(e)

        except Exception as e:
            logging.log(logging.ERROR, e)

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_178 -a list_id=178 -a proxy_type='''.split())