# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import re
import urllib

import scrapy,os,logging,hashlib
import requests,json
from lxml import html
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime
import  pandas as pd


class stickyfingersSpider(scrapy.Spider):
    name = 'store_218'
    allowed_domains = []
    not_export_data = True


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        try:
            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                print(search_terms)
            # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)
                search_terms = ''
                for search_term in (search_terms):
                    source_url = link = ''
                    file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(search_term) + '_' + str(self.run_date) + '.html'
                    if os.path.exists(file_path):
                        link = 'file://' + file_path.replace('\\','/')
                    yield scrapy.FormRequest(url=str(link), callback=self.get_store_list, meta={'source_url': source_url,'search_term': search_term,'file_path':file_path,'proxy_type': self.proxy_type})
            else:
                source_url = link = 'https://www.stickyfingers.com/locations/'
                file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
                    self.run_date) + '.html'
                yield scrapy.FormRequest(url=str(link), callback=self.get_store_list,
                                         meta={'source_url': source_url,
                                               'file_path': file_path, 'proxy_type': self.proxy_type})

        except Exception as e:
            logging.log(logging.ERROR, e)


    def get_store_list(self, response):
        try:
            if not response.url.startswith('file://'):
                self.f1.page_save(response.meta['file_path'],response.body)

            search_term = response.meta.get('search_term', '')
            csv_path = "\\192.168.1.36\\d\\Page_Save\\csv_files\\Sticky_Finges.csv"
            csv_path = csv_path.replace("\\","\\\\")
            df = pd.read_csv(csv_path,encoding="ISO-8859-1")
            for i, row in df.iterrows():
                print()





            # divs = response.xpath('//div[@class="hotspot-info "]')
            # for div in divs:
            #     try:
            #         store_name1tmp = div.xpath('./h2/text()').extract_first()
            #         store_name1 = store_name1tmp.split(',')[0]
            #         store_name2tmp = div.xpath('./h2/text()').extract_first().split(',')[1]
            #
            #         store_name2tmp2 = re.findall('\(.*?\)',store_name2tmp)
            #         if len(store_name2tmp2)>=1:
            #             store_name = "Stickyfingers-"+store_name1+" "+store_name2tmp2[0]
            #         else:
            #             store_name = "Stickyfingers-" + store_name1
            #     except Exception as e:
            #         print("store_name",e,response.url)
            #
            #     try:
            #         addressphone = div.xpath('./div/p[1]/span/text()').extract()
            #         phone_number = addressphone[1].strip()
            #         if phone_number == None:
            #             phone_number = ''
            #         else:
            #             phone_number = phone_number.replace('-RIBS','').replace('-PORK','').strip()
            #     except Exception as e:
            #         print("phone_number", e, response.url)
            #
            #     try:
            #         email_address = ''
            #     except Exception as e:
            #         print("email_address", e, response.url)
            #
            #     try:
            #         address = div.xpath('./div/p[1]//a//text()').extract_first()
            #         if address == None:
            #             address = ''
            #         else:
            #             address = address.strip().strip(',').strip()
            #             address = re.sub('\s+', ' ', re.sub('\r|\n|\t', ' ', address))
            #
            #         citystatezipcode = addressphone[0].strip()
            #         city = citystatezipcode.split(',')[0]
            #         statezipcode = citystatezipcode.split(',')[1].strip()
            #         state = statezipcode.split()[0]
            #         zip_code = statezipcode.split()[1]
            #
            #
            #     except Exception as e:
            #         print("address", e, response.url)
            #
            #
            #
            #     try:
            #        checklist = []
            #
            #        link = div.xpath('./div/p[1]//a/@href').extract_first()
            #        latitudelongitude = re.findall('@(.*?)z',link)
            #        latitude = latitudelongitude[0].split(',')[0].strip()
            #
            #        longitude = latitudelongitude[0].split(',')[1].strip()
            #     except Exception as e:
            #         print("latitude and longitude", e, response.url)
            #
            #     try:
            #         services = ''
            #     except Exception as e:
            #         print("services",e,response.url)
            #
            #     try:
            #
            #         store_hours = ''
            #
            #     except Exception as e:
            #         print("store_hours",e,response.url)
            #
            #
            #
            #     try:
            #         additional_info = {}
            #     except Exception as e:
            #         print("additional_info",e,response.url)
            #

                item = StoreLocatorsItem()

                item['search_term'] = search_term
                item['store_name']= row['store_name']
                item['address'] = row['address']
                item['city'] = row['city']
                item['state'] =row['state']
                item['zip_code'] = row['zip_code']
                item['phone_number'] =row['phone_number']
                item['latitude'] = ''
                item['longitude'] = ''
                item['store_type'] = ''
                item['website_address'] = ''
                item['coming_soon'] = 0
                item['store_number'] = ''
                item['country_code'] = item['country'] = 'US' #self.f1.country_dict.get(item['country'].lower())
                item['email_address'] = ''
                item['services'] = ''
                item['source_url'] = 'https://www.stickyfingers.com/locations/'
                item['store_hours'] = ''
                item['additional_info'] = ''



                # if store_name1tmp == None:
                #     pass
                # else:
                yield item




        except Exception as e:
            logging.log(logging.ERROR, e)

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_218 -a list_id=218'''.split())
