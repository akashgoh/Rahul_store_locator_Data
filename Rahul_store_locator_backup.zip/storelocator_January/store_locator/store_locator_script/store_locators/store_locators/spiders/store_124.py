# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import random
import re


import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from w3lib.html import remove_tags

from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime

class Store124Spider(scrapy.Spider):
    name = 'store_124'
    allowed_domains = []


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            self.f1.set_details(self.list_id,run_date)
            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                print(search_terms)
            # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)
                search_terms = ''
                for search_term in (search_terms):
                    source_url = link = 'https://www.wingsetc.com/locations/'
                    file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(search_term) + '_' + str(run_date) + '.html'
                    if os.path.exists(file_path):
                        link = 'file://' + file_path.replace('\\','/')
                    yield scrapy.FormRequest(url=str(link), callback=self.get_store_list, meta={'source_url': source_url,'search_term': search_term,'file_path':file_path,'proxy_type': self.proxy_type})
            else:
                source_url = link = 'https://www.wingsetc.com/locations/'
                file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(run_date) + '.html'
                yield scrapy.FormRequest(url=str(link), callback=self.data,
                                         meta={'source_url': source_url,
                                               'file_path': file_path, 'proxy_type': self.proxy_type})
        except Exception as e:
            logging.log(logging.ERROR, e)


    def data(self, response):
        headers = {
            "accept":"*/*",
            # "accept-encoding":"gzip, deflate, br",
            "accept-language":"en-US,en;q=0.9",
            "referer":"https://wingsetc.com/locations/",
            "sec-fetch-dest":"empty",
            "sec-fetch-mode":"cors",
            "sec-fetch-site":"same-origin",
            "user-agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36",
            "x-requested-with":"XMLHttpRequest"
        }
        yield scrapy.FormRequest(url='https://wingsetc.com/wp-admin/admin-ajax.php?action=store_search&lat=41.07927&lng=-85.13935&max_results=1000&search_radius=1000&autoload=1', headers=headers, callback=self.parse_data)


    def parse_data(self, response):
        data = json.loads(response.text)
        for i in range(0, 100):
            try:store_name = data[i]['store']
            except:store_name = ''

            try:telephone = data[i]['phone']
            except:telephone = ''

            try:address = data[i]['address']
            except:address = ''

            try:address_line_2 = data[i]['address2']
            except:address_line_2 = ''

            try:city = data[i]['city']
            except:city = ''

            try:state = data[i]['state']
            except:state = ''

            try:zip_code = data[i]['zip']
            except:zip_code = ''

            try:latitude = data[i]['lat']
            except:latitude = 0.00

            try:longitude = data[i]['lng']
            except:longitude = 0.00

            try:store_hours = remove_tags(data[i]['hours']).replace('PM','PM|').strip('|')
            except:store_hours = ''

            try:store_number = data[i]['store_number']
            except:store_number = ''


            item = StoreLocatorsItem()
            item['search_term'] = 'link'
            item['store_name'] = store_name
            item['store_number'] = store_number
            item['address'] = address
            item['address_line_2'] = address_line_2
            item['city'] = city
            item['state'] = state
            item['country'] = 'USA'
            item['latitude'] = latitude
            item['longitude'] = longitude
            item['website_address'] = ''
            item['zip_code'] = zip_code
            item['coming_soon'] = 0
            item['country_code'] = 'US'  # self.f1.country_dict.get(item['country'].lower())
            item['store_hours'] = store_hours
            item['phone_number'] = telephone
            item['source_url'] = 'https://wingsetc.com/locations/'
            # if item['country_code'] == 'US' and len(item['state']) > 2:
            #     item['state'] = self.f1.state_dict.get(state, '')
            if store_name != '':
                yield item

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_124 -a list_id=124'''.split())