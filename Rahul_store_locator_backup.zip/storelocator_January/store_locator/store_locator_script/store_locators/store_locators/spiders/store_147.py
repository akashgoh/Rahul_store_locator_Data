# -*- coding: utf-8 -*-
import scrapy
import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime
import html2text
from geopy.geocoders import Nominatim
import pgeocode



class Store147Spider(scrapy.Spider):
    name = 'store_147'
    allowed_domains = []
    # start_urls = ['https://venuefinancial.com/locations/']
    f1 = Func()
    not_export_data = False

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type

        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
            self.run_date) + '.html'
        source_url = link = 'https://venuefinancial.com/locations/'
        yield scrapy.FormRequest(url=str(link), callback=self.parse,meta={'source_url': source_url,'file_path': file_path, 'proxy_type': self.proxy_type})



    def parse(self, response):

        run_date = str(datetime.datetime.today()).split()[0]

        self.f1.set_details(self.list_id, run_date)

        all_links = response.xpath('//p/a/@href').extract()



        for link in all_links:
            # link = 'https://venuefinancial.com/locations/victoria/'
            yield scrapy.Request(url=link,callback=self.get_store_data)


    def get_store_data(self, response):
        if response.url == 'https://venuefinancial.com/locations/penticton/':
            full_address = '368 Main Street'
            city = 'Penticton'
            state = 'BC'
            zip_code = 'V2A 5C3'
        elif response.url == 'https://venuefinancial.com/locations/fort-st-john/':
            full_address = '106 - 9317 96 St'
            city = 'Fort St John'
            state = 'BC'
            zip_code = 'V1J 6V5'
        elif response.url =='https://venuefinancial.com/locations/vernon/':
            full_address = '2601 BC-6'
            city = 'Vernon'
            state = 'BC'
            zip_code = 'V1T 5G4'

        else:
            address= '|'.join(response.xpath('//p//a[contains(@href,"tel:")]/../text()[position()<4]').extract()).replace('|Phone:','').strip()
            full_address = ''.join(address.split('|')[0])
            city_state_zip = ''.join(address.split('|')[-1]).replace('BC', '')
            city = city_state_zip.split(',')[0]
            zip_code = ''.join(city_state_zip.split(',')[-1]).strip()
            state = 'BC'

        if full_address == '805 Victoria St':
            print()

        store_name = response.xpath('//meta[@property="og:site_name"]/@content').extract_first(default='').strip()
        # full_address = ' '.join(response.xpath('//div[@class="wp-block-column"]//p[2]/text()[position()<3]').extract())
        description = response.xpath('//meta[@property="og:description"]/@content').extract_first(default='').strip()
        email_address = response.xpath('//p//a[contains(@href,"mailto")]/text()').extract_first(default='').strip()
        phone_number = response.xpath('//p//a[contains(@href,"tel:")]/text()').extract_first(default='').strip()
        fax_number = response.xpath('//p//a[contains(@href,"tel:")]/following-sibling::text()').extract_first(default='').replace('Fax:','').strip()
        store_hours = '|'.join(response.xpath('//*[contains(text(),"Hours of Operation")]//following-sibling::text()').extract())

        nomi = pgeocode.Nominatim('ca')
        try:
            longitude = nomi.query_postal_code(str(zip_code)).longitude
            latitude =  nomi.query_postal_code(str(zip_code)).latitude
        except Exception as e:
            print()
        try:
            print()
            run_date = str(datetime.datetime.today()).split()[0]
        except Exception as e:
            print(e)


        try:
            item = StoreLocatorsItem()
            item['search_term'] = 'link'
            item['store_name'] = store_name
            item['address'] = full_address
            item['address_line_2'] = ''
            item['city'] = city
            item['state'] = state
            item['zip_code'] = zip_code
            item['phone_number'] = phone_number
            item['fax_number'] = fax_number
            item['email_address'] = email_address
            item['latitude'] = latitude
            item['longitude'] = longitude
            item['store_type'] = ''
            item['website_address'] = 'www.venuefinancial.com'
            item['coming_soon'] = 0
            item['store_number'] = ''
            item['country'] = 'canada'  #
            item['country_code'] = 'ca'
            item['store_hours'] = store_hours
            item['source_url'] = response.url
            add_info = dict()
            add_info['distance'] = ''
            add_info['thumb'] = ''
            add_info['description'] = description
            item['additional_info'] = json.dumps(add_info, ensure_ascii=False)
            yield item
        except Exception as e:
            print(e)


# execute('''scrapy crawl store_147 -a list_id=147'''.split())
