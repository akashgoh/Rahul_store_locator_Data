# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
import os
import logging
import pymysql
from datetime import timedelta, datetime
from store_locators.db_config import *
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
from store_locators.export_data import export_data
import re
import hashlib


class StoreLocatorsPipeline(object):
    insert_count = 0

    def open_spider(self, spider):
        self.con = spider.f1.con
        self.cursor = spider.f1.cursor
        # self.con = pymysql.connect(db_host, db_user, db_password, db_name)
        # self.cursor = self.con.cursor()
        self.cursor.execute('SET GLOBAL local_infile = "ON";')
        try:
            create_table = "CREATE TABLE IF NOT EXISTS " + db_zip_table + """ (zip_code varchar(10) NOT NULL,
                                                                                city varchar(250) NOT NULL,
                                                                                state varchar(250) NOT NULL,
                                                                                latitude varchar(250) NOT NULL,
                                                                                longitude varchar(250) NOT NULL,
                                                                                lat_lng varchar(250) NOT NULL,
                                                                                timezone varchar(250),
                                                                                dst varchar(250),
                                                                                country_code varchar(50) NOT NULL,
                                                                                PRIMARY KEY (zip_code)
                                                                                )"""
            self.cursor.execute(create_table)

        except Exception as e:
            print("Can't Create table :" + str(e))

        try:
            create_table = "CREATE TABLE IF NOT EXISTS " + db_qa_log_table + """ (list_id int(10) NOT NULL,
                                                                                file_name longtext NOT NULL,
                                                                                website_url varchar(250) NOT NULL,
                                                                                developer_name varchar(250) NOT NULL,
                                                                                agg_data_count varchar(250),
                                                                                xbyte_count varchar(250),
                                                                                last_build_date varchar(250) NOT NULL,
                                                                                present_count varchar(250) NOT NULL,
                                                                                diff_agg_data_present_count varchar(250) NOT NULL,
                                                                                diff_xbyte_present_count varchar(250) NOT NULL,
                                                                                is_validated varchar(250) NOT NULL,
                                                                                is_validated_qa_team varchar(250) NULL,
                                                                                log_date_time DATETIME  NOT NULL
                                                                                )"""
            self.cursor.execute(create_table)

        except Exception as e:
            print("Can't Create table :" + str(e))

        try:
            create_table = "CREATE TABLE IF NOT EXISTS " + db_master_table + """ (list_id int(10) NOT NULL,
                                                                                file_name longtext NOT NULL,
                                                                                website_url varchar(250) NOT NULL,
                                                                                country_codes varchar(250) NULL,
                                                                                search_by varchar(250) NOT NULL,
                                                                                developer_name varchar(250) NOT NULL,
                                                                                developer_email_id longtext NOT NULL,
                                                                                PRIMARY KEY (list_id)
                                                                                )"""
            self.cursor.execute(create_table)
        except Exception as e:
            print("Can't create master table :" + str(e))

        try:
            create_table = "CREATE TABLE IF NOT EXISTS " + db_log_table + """ (search_term varchar(150) NOT NULL,
                                                                                list_id int NOT NULL,
                                                                                country_code varchar(50) NOT NULL,
                                                                                number_of_store int(10) DEFAULT -1, 
                                                                                error_desc varchar(250) DEFAULT NULL,
                                                                                run_date date NOT NULL,
                                                                                developer_name varchar(25) DEFAULT NULL,
                                                                                 UNIQUE `unique_index`(search_term,list_id,country_code,run_date)
                                                                                );"""
            self.cursor.execute(create_table)
        except Exception as e:
            print("Can't create log table :" + str(e))

        try:
            create_table = "CREATE TABLE IF NOT EXISTS " + db_output_table + """ (store_hash_id varchar(32) NOT NULL, 
                                                                                                address_hash_id varchar(32) NOT NULL, 
                                                                                                store_type varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                                                store_number varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                                                store_node varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                                                store_code varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                                                store_name varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                                                store_location varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                                                address longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                                                address_line_2 longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                                                address_line_3 longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                                                city varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci ,
                                                                                                state varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci ,
                                                                                                zip_code varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci ,
                                                                                                country varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci ,
                                                                                                country_code varchar(2),
                                                                                                latitude DECIMAL(11, 8) DEFAULT NULL, 
                                                                                                longitude DECIMAL(11, 8) DEFAULT NULL,
                                                                                                store_hours longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                                                coming_soon boolean DEFAULT 0,
                                                                                                county varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                                                distributor_name varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                                                distributor boolean DEFAULT 0,
                                                                                                drive_through_hours longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                                                email_address varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                                                fax_number varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                                                gas boolean DEFAULT 0,

                                                                                                gas_hours longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                                                open_date varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                                                pharmacy boolean DEFAULT 0,
                                                                                                pharmacy_fax_number varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                                                pharmacy_hours varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                                                pharmacy_phone_number varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                                                phone_number varchar(25) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                                                products longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                                                services longtext CHARACTER SET utf8 COLLATE utf8_general_ci  DEFAULT NULL,
                                                                                                website_address longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                                                process_date date, 
                                                                                                list_id varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                                                search_term varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                                                additional_info longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                                                source_url longtext,
                                                                                                PRIMARY KEY (store_hash_id)
                                                                                                )"""
            self.cursor.execute(create_table)
        except Exception as e:
            print("Can't create output table :" + str(e))

        try:
            create_table = "CREATE TABLE IF NOT EXISTS " + db_data_count_table + """ (timestamp datetime NOT NULL,
                                                                                        list_id varchar(10) NOT NULL,
                                                                                        website_url longtext default null,
                                                                                        total_count int NOT NULL,
                                                                                        start_time datetime NOT NULL,
                                                                                        end_time  datetime DEFAULT NULL,
                                                                                        duration varchar(250) DEFAULT NULL,
                                                                                        developer_name varchar(250) NOT NULL,
                                                                                        store_type varchar(250) default null,
                                                                                        store_number varchar(250) default null,
                                                                                        store_node varchar(250) default null,
                                                                                        store_code varchar(250) default null,
                                                                                        store_name varchar(250) default null,
                                                                                        store_location varchar(250) default null,
                                                                                        address varchar(250) default null,
                                                                                        address_line_2 varchar(250) default null,
                                                                                        address_line_3 varchar(250) default null,
                                                                                        city varchar(250) default null,
                                                                                        state varchar(250) default null,
                                                                                        zip_code varchar(250) default null,
                                                                                        country varchar(250) default null,
                                                                                        country_code varchar(250) default null,
                                                                                        latitude varchar(250) default null,
                                                                                        longitude varchar(250) default null,
                                                                                        store_hours varchar(250) default null,
                                                                                        coming_soon varchar(250) default null,
                                                                                        county varchar(250) default null,
                                                                                        distributor_name varchar(250) default null,
                                                                                        distributor varchar(250) default null,
                                                                                        drive_through_hours varchar(250) default null,
                                                                                        email_address varchar(250) default null,
                                                                                        fax_number varchar(250) default null,
                                                                                        gas varchar(250) default null,
                                                                                        gas_hours varchar(250) default null,
                                                                                        open_date varchar(250) default null,
                                                                                        pharmacy varchar(250) default null,
                                                                                        pharmacy_fax_number varchar(250) default null,
                                                                                        pharmacy_hours varchar(250) default null,
                                                                                        pharmacy_phone_number varchar(250) default null,
                                                                                        phone_number varchar(250) default null,
                                                                                        products varchar(250) default null,
                                                                                        services varchar(250) default null,
                                                                                        website_address varchar(250) default null,
                                                                                        process_date varchar(250) default null,
                                                                                        search_term varchar(250) default null,
                                                                                        additional_info varchar(250) default null,
                                                                                        source_url longtext
                                                                                        )"""
            self.cursor.execute(create_table)
        except Exception as e:
            print("Can't Data Count table :" + str(e))

        try:
            create_table = "CREATE TABLE IF NOT EXISTS " + db_country_table + """ (country_code varchar(50) NOT NULL,
                                                                                        country_name varchar(250) NOT NULL
                                                                                        )"""
            self.cursor.execute(create_table)
        except Exception as e:
            print("Can't Data db_country_table  :" + str(e))
        try:
            create_table = "CREATE TABLE IF NOT EXISTS " + db_us_state_table + """ (state_code varchar(50) NOT NULL,
                                                                                        state_name varchar(250) NOT NULL,
                                                                                        PRIMARY KEY (state_code)
                                                                                        )"""
            self.cursor.execute(create_table)
        except Exception as e:
            print("Can't Data db_country_table  :" + str(e))

    def normalize_text(self, text):
        if (type(text)) == str:
            text = re.sub('<[^<]+?>', '', str(text))
            text = re.sub('\s+', ' ', re.sub('\t|\n|\r', ' ', str(text))).strip().strip(',')
        return text

    def process_item(self, item, spider):

        if isinstance(item, StoreLocatorsItem):
            try:
                dir_path = os.path.dirname(os.path.realpath(__file__))
                # dir_path = os.path.join(dir_path,'')

                item['list_id'] = spider.f1.list_id
                item['process_date'] = spider.f1.run_date
                for itm in item.items():
                    if itm[1]:
                        item[itm[0]] = self.normalize_text(itm[1])

                store_hash_id = bytes(
                    f"{item.get('store_number', '')}{item.get('store_name', '')} {item.get('address', '')} {item.get('address_line_2', '')}"
                    f" {item.get('address_line_3', '')} {item.get('city', '')} {item.get('state', '')} "
                    f"{item.get('zip_code', '')} {item.get('latitude', '')} {item.get('longitude', '')}"
                    f" {item.get('process_date', '')} ", encoding='utf-8')

                item['store_hash_id'] = int(hashlib.md5(store_hash_id).hexdigest(), 16) % (10 ** 16)
                item['address_hash_id'] = int(hashlib.md5((bytes(
                    f"{item.get('address', '')}{item.get('city', '')}{item.get('state', '')}",
                    encoding='utf-8'))).hexdigest(), 16) % (10 ** 16)

                field_list = []
                value_list = []

                for field in item:
                    if field != 'number_of_store' and item[field]:
                        field_list.append(str(field))
                        value_list.append(str(item[field]).replace("'", "’"))
                value_list = list(map(self.normalize_text, value_list))

                fields = ','.join(field_list)
                values = "','".join(value_list)
                insert_db = "insert into " + db_output_table + "( " + fields + " ) values ( '" + values + "' )"
                self.cursor.execute(insert_db)
                self.con.commit()
                self.insert_count += 1
                print(f"\rData Inserted ...{self.insert_count}", end='')
            except pymysql.IntegrityError as e:
                print('Duplicate entry ', str(e))
            except Exception as e:
                print('problem in Data insert ', str(e))
                log_file = f"{spider.list_id}_logs.txt"
                log_msg = f"{datetime.now()} : {item.get('address', '')} {item.get('zip_code', '')} : {e}\n"
                with open(log_file, 'a+') as f:
                    f.write(log_msg)

            try:
                if item.get('number_of_store', '') and int(item['number_of_store']) > 0:
                    update_log = f"UPDATE {db_log_table} set  number_of_store = {item['number_of_store']} " \
                                 f"where search_term ='{item['search_term']}' and list_id = '{item['list_id']}' and run_date = '{item['process_date']}'"
                    self.cursor.execute(update_log)
                    self.con.commit()
            except Exception as e:
                print('problem in log table updating', str(e))

        return item

    def close_spider(self, spider):
        # pass
        # "if not use not export data then default goes in else part"
        try:
            (spider.not_export_data)
        except AttributeError:
            try:
                stat = spider.crawler.stats.get_stats()
                start_time = stat['start_time'] + timedelta(hours=5, minutes=30)
                end_time = datetime.now()
                export_data(spider.f1, start_time, end_time)
            except Exception as e:
                print(e)
                logging.log(logging.ERROR, e)
        else:
            if spider.not_export_data:
                print('no call export data')
            else:
                try:
                    stat = spider.crawler.stats.get_stats()
                    start_time = stat['start_time'] + timedelta(hours=5, minutes=30)
                    end_time = datetime.now()
                    export_data(spider.f1, start_time, end_time)
                except Exception as e:
                    print(e)
                    logging.log(logging.ERROR, e)





