def make_part(no_part=5,st=10_000_000,total=100_000_000,concurrent=0,timeout=2):
    import os

    size_s = 0
    for fc in range(1,6):
        with open(f'run_{fc}.bat', 'w') as f:

            for i in range(no_part):
                proxy_dict = {
                    0: "luminaty_es",
                    1: "luminaty_de",
                    2: "luminaty_au",
                    3: "luminaty_us",
                    4: "luminaty_jp",
                    5: "luminaty_ru"
                }


                # cmd_st = f'scrapy crawl aaha_crawler -a list_id=19  -a st_id={size_s}\n'
                cmd_st = f'scrapy crawl aaha_crawler -a list_id=19  -a st_id={0} -a proxy_type={proxy_dict.get((i%5))}\n'
                if timeout > 0:
                    cmd_st += 'timeout '+str(timeout)+'\n'
                if concurrent == 1:
                    cmd_st = 'start '+cmd_st
                # os.system(cmd_st)
                f.write(cmd_st)
                print(cmd_st)
                size_s += 200





make_part(no_part=7,st=100000, total=20000,concurrent =0,timeout=0)