import pandas as pd
import dropbox
import json
import hashlib
from store_locators.db_config import *
import os
import numpy as np
from json2html import *
import datetime
import datacompy
pd.options.display.float_format = '{:,.0f}'.format

def gen_mail_string(mail_string):
    mail_content = list()
    mail_content.append("<html>")
    mail_content.append("<head>")
    mail_content.append("<style>")
    mail_content.append("table,th,td {border : 2px solid black;border-collapse: collapse;padding: 10px;}")
    mail_content.append("</style>")
    mail_content.append("</head>")
    mail_content.append("<body>")
    mail_content.append(mail_string)
    mail_content.append('</body></html>')
    return ''.join(mail_content)


def upload_file_db(content, file_name):
    """
    upload file to dropbox
    :param content: string content of the file
    :param file_name: name of the file on the dropbox
    :return:
    """
    try:
        access_token = 'CUfJO7qYu2AAAAAAAAA0Dp9t8EZdAImrwo2K85bkJlqHNSf-Sbu8r963qHCrAZmE'
        file_to = '/agg_store_locator/compare_file/' + file_name  # The full path to upload the file to, including the file name
        dbx = dropbox.Dropbox(access_token)
        dbx.files_upload(content.encode('utf-8'), file_to, mode=dropbox.files.WriteMode.overwrite)
        print('File Uploaded To :' + file_to)
        # Below Code is for getting the link of uploaded File
        # dbx.sharing_create_shared_link_with_settings(file_to)
        result = dbx.sharing_create_shared_link(file_to)
        print('CSV Path : ' + result.url)
        return result.url
    except Exception as e:
        print(str(e)) + ': in Uploading to Dropbox'
        return ''


def gen_hash_id(str_id):
    store_hash_id = bytes(str_id, encoding='utf-8')
    return int(hashlib.md5(store_hash_id).hexdigest(), 16) % (10 ** 16)


def make_identifier(df):
    str_id = df.apply(lambda x: '_'.join(map(str, x)), axis=1)
    store_hash_id = str_id.apply(lambda x: gen_hash_id(x))
    return store_hash_id


def download_db(path):
    """Download file from dropbox """
    try:
        access_token = 'CUfJO7qYu2AAAAAAAAA0Dp9t8EZdAImrwo2K85bkJlqHNSf-Sbu8r963qHCrAZmE'
        dbx = dropbox.Dropbox(access_token)
        download_path = f"{compare_directory}{path.split('/')[-1]}"
        dbx.files_download_to_file(download_path, '/' + path)
        return download_path
    except Exception as e:
        print(e)
        return ''


def compare_file(file_path, master_dict):
    """Compare previous  and current file"""
    try:
        file_name = (master_dict.get('file_name', '')).strip()
        df = pd.read_csv(file_path, encoding="ISO-8859-1", converters={'zip code': lambda x: str(x)})
        dbx_path = f'agg_store_locator/csv_file/{file_name}.csv'
        download_path = download_db(dbx_path)

        if download_path:

            old_df = pd.read_csv(download_path, encoding="ISO-8859-1", converters={'zip code': lambda x: str(x)})
            hash_columns = ['store number', 'store name', 'address', 'address line 2', 'address line 3', 'city', 'state',
                            'zip code', 'latitude', 'longitude']

            # Generate store_id for comparision
            df['store_id'] = make_identifier(df[hash_columns])
            new_file_path = compare_directory + file_name + '_new.csv'
            df.drop(['process date'], axis=1, inplace=True)
            df.to_csv(new_file_path, index=False)

            old_df['store_id'] = make_identifier(old_df[hash_columns])
            old_file_path = compare_directory + file_name + '_old.csv'
            old_df.drop(['process date'], axis=1, inplace=True)
            old_df.to_csv(old_file_path, index=False)

            # Get difference details from previous and current file using data compy module
            try:
                csv_compare = datacompy.Compare(
                    old_df,
                    df,
                    join_columns='store_id',  # You can also specify a list of columns
                    abs_tol=0,  # Optional, defaults to 0
                    rel_tol=0,  # Optional, defaults to 0
                    df1_name='Original',  # Optional, defaults to 'df1'
                    df2_name='New'  # Optional, defaults to 'df2'
                )
                csv_compare.matches(ignore_extra_columns=False)
                # False

                # This method prints out a human-readable report summarizing and sampling differences
                compare_report = csv_compare.report(sample_count=100)
                compare_report_file_name = f"{file_name}_compare.txt"
                compare_report_path = f"{compare_directory}{compare_report_file_name}"
                with open(compare_report_path, 'wb') as f:
                    f.write(compare_report.encode('utf-8'))
                compare_report_dbx = upload_file_db(compare_report, compare_report_file_name)
            except Exception as e:
                compare_report_dbx = ''
                print(e)

            # Get State and country wise difference details of new file
            state_new_df = df.groupby('state').size().reset_index()
            state_new_df.columns = ['state', 'count']

            country_new_df = df.groupby('country').size().reset_index()
            country_new_df.columns = ['country', 'count']

            # Get State and country wise difference details of previous file
            state_old_df = old_df.groupby('state').size().reset_index()
            state_old_df.columns = ['state', 'count']

            country_old_df = old_df.groupby('country').size().reset_index()
            country_old_df.columns = ['country', 'count']

            # state wise diff html
            state_df = pd.merge(state_old_df, state_new_df, how='outer', on=['state'],suffixes=('_old','_new'))
            # state_df.fillna(0,inplace=True)
            state_df['difference'] = state_df['count_old'] - state_df['count_new']
            state_df['diff_percentage'] = (state_df['difference'] * 100) / state_df['count_old']
            state_df_html = state_df.to_html(index=False, na_rep='0', justify='center', border=1)

            # country wise diff html
            country_df = pd.merge(country_old_df, country_new_df, how='outer', on=['country'], suffixes=('_old', '_new'))
            # country_df.fillna(0,inplace=True)
            country_df['difference'] = country_df['count_old'] - country_df['count_new']
            country_df['diff_percentage'] = (country_df['difference'] * 100) / country_df['count_old']
            country_df_html = country_df.to_html(index=False, na_rep='0', justify='center', border=1)

            # Data Count SummaryStore Number wise diff Json File
            new_data_counts = df.count(axis=0).to_dict()
            old_data_counts = old_df.count(axis=0).to_dict()

            count_df = (pd.DataFrame.from_dict([old_data_counts, new_data_counts])).T
            count_df.columns = ['count_old', 'count_new']
            count_df['difference'] = count_df['count_old'] - count_df['count_new']
            count_df['diff_percentage'] = (count_df['difference'] * 100) / count_df['count_old']
            count_df_html = count_df.to_html(na_rep='0', justify='center', border=1)

            #  Store Number wise difference details
            store_num_diff_dict = dict()
            store_number_bdx = ''
            if len(df['store number'].dropna()) and len(old_df['store number'].dropna()):

                try:
                    csv_compare = datacompy.Compare(
                        old_df,
                        df,
                        join_columns='store number',  # You can also specify a list of columns
                        abs_tol=0,  # Optional, defaults to 0
                        rel_tol=0,  # Optional, defaults to 0
                        df1_name='Original',  # Optional, defaults to 'df1'
                        df2_name='New'  # Optional, defaults to 'df2'
                    )
                    csv_compare.matches(ignore_extra_columns=False)
                    # False

                    # This method prints out a human-readable report summarizing and sampling differences
                    compare_report = csv_compare.report(sample_count=100)
                    compare_report_file_name = f"{file_name}_store_number_compare.txt"
                    compare_report_path = f"{compare_directory}{compare_report_file_name}"
                    with open(compare_report_path, 'wb') as f:
                        f.write(compare_report.encode('utf-8'))
                    compare_report_number_dbx = upload_file_db(compare_report, compare_report_file_name)
                except Exception as e:
                    compare_report_number_dbx = ''
                    print(e)

            # Generate Mail Content
            master_dict['old_file_count'] = len(old_df.index)
            master_dict['new_file_count'] = len(df.index)
            master_dict['diff_in_count'] = master_dict['old_file_count'] - master_dict['new_file_count']

            master_dict['data_count'] = len(df.index)
            master_dict['diff_between_agg-data_xbyte_count'] = int(
                (master_dict.get('agg_data_count', '')) - master_dict['data_count'])

            details_dict = dict()
            desired_key_from_master = (
                'list_id', 'file_name', 'website_url', 'developer_name', 'agg_data_count', 'xbyte_count',
                'last_build_date')

            for key in master_dict.keys():
                if key in desired_key_from_master:
                    if type(master_dict[key]) == np.float64:
                        val = int(master_dict[key])
                    else:
                        val = master_dict[key]
                    details_dict[(key.replace('_', ' ').title())] = val

            details_dict['Present Count'] = len(df.index)
            details_dict['Difference Between Agg Count and Present Count'] = int(
                (master_dict.get('agg_data_count', '')) - details_dict['Present Count'])
            details_dict['Difference Between Xbyte Count and Present Count '] = int(
                (master_dict.get('xbyte_count', '')) - details_dict['Present Count'])

            mail_string = '<br><h3>Details</h3>'
            mail_string += json2html.convert(json=details_dict)

           # add store number wise difference details
            if len(df['store number'].dropna()) and len(old_df['store number'].dropna()):
                mail_string += "<h3>Store Number Wise Difference Details</h3>"
                mail_string += (json2html.convert(json=store_num_diff_dict))
                # mail_string += f"<p><a href='{store_number_bdx}'>Store Number wise diff Json File</a></p>"
                mail_string += f"<p><a href='{compare_report_number_dbx}'>Store Number wise comparision</a></p>"

            mail_string += (f"<p><a href='{compare_report_dbx}'>Comparioson Report</a></p>")
            mail_string += ("<br><h3>State Wise Comparision</h3>")
            mail_string += (state_df_html)

            mail_string += ("<br><h3>Country Wise Comparision</h3>")
            mail_string += (country_df_html)

            mail_string += ("<br><h3>Data Count Comparision</h3>")
            mail_string += (count_df_html)

        else:
            mail_string = '<br><h3>Details</h3>'
            mail_string += json2html.convert(json=master_dict)
            mail_string += f"<h3>Please provide previous file for {master_dict.get('file_name', '')}.</h3>"

        dev_email = master_dict.get('developer_email_id', '').split(',')
        cc_ids = master_dict.get('cc_id', '').split(',')
        today = datetime.datetime.strftime(datetime.datetime.now(), "%m/%d/%Y %I:%M %p")

        mail_content = gen_mail_string(mail_string)
        mail_content = mail_content.replace('<td>nan</td>','<td>0</td>')
        compare_mail_html_path = f"{compare_directory}{file_name}_compare_mail.html"
        with open(compare_mail_html_path,'w') as f:
            f.write(mail_content)
        mail_subject = f"agg store locator comparision: {master_dict.get('file_name', '')} {today}"

        send_mail(dev_email, mail_content, cc_ids, mail_subject)
    except Exception as e:
        print('error during compare file',e)


def send_mail(email_ids,mail_content,cc_ids,mail_subject):
    """
    send email
    :param email_ids: To email ids
    :param mail_content: mail content to be send
    :param cc_ids: CC ids
    :param mail_subject:  subject line of mail
    :return:
    """
    import smtplib
    from email.mime.multipart import MIMEMultipart
    from email.mime.text import MIMEText

    from_email_id = "alerts@xbyte.io"
    from_email_password = "xbyte123"

    body = "".join(mail_content)
    try:
        msg = MIMEMultipart()
        msg['From'] = from_email_id
        msg['To'] = ",".join(email_ids)
        msg['CC'] = ",".join(cc_ids)
        msg['Subject'] = mail_subject
        msg.attach(MIMEText(body, 'html'))
        s = smtplib.SMTP("mail.xbyte.io", 587)
        s.starttls()
        email_ids.extend(cc_ids)
        s.login(from_email_id, from_email_password)
        text = msg.as_string()
        s.sendmail(from_email_id, email_ids, text)
        print("Mail Sent ...")
        s.quit()
    except Exception as e:
        print(e)
