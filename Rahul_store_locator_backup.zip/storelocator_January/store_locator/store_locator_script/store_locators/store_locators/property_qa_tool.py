import pandas as pd
import numpy as np
import datetime
import pymysql
import validators
import re
import math
import json
import os
from json2html import *
# from store_locators.db_config import *
from db_config import *
import dropbox
import socket

from store_locators.db_config import master_file


def gen_mail_string(mail_string):
    """Generate html mail string"""
    mail_content = list()
    mail_content.append("<html>")
    mail_content.append("<head>")
    mail_content.append("<style>")
    mail_content.append("table,th,td {border : 2px solid black;border-collapse: collapse;padding: 10px;}")
    mail_content.append("</style>")
    mail_content.append("</head>")
    mail_content.append("<body>")
    mail_content.append(mail_string)
    mail_content.append('</body></html>')
    return ''.join(mail_content)


def upload_file_db(csv_path,db_file_path):
    """upload file to dropbox """
    try:
        access_token = 'CUfJO7qYu2AAAAAAAAA0Dp9t8EZdAImrwo2K85bkJlqHNSf-Sbu8r963qHCrAZmE'
        file_from = csv_path
         # The full path to upload the file to, including the file name
        file_to = db_file_path
        dbx = dropbox.Dropbox(access_token)
        with open(file_from, 'rb') as f:
            dbx.files_upload(f.read(), file_to, mode=dropbox.files.WriteMode.overwrite)
        print('File Uploaded To :' + file_to)
        # Below Code is for getting the link of uploaded File
        result = dbx.sharing_create_shared_link(file_to)
        print('CSV Path : ' + result.url)
        return result.url
    except Exception as e:
        print(str(e)) + ': in Uploading to Dropbox'
        return ''


def check_us_zip(txt):
    """check us zip code"""
    if not (pd.isna(txt)):
        if re.match('\d{5}\-\d{4}',txt):
            return True
        elif re.match('\d{5}', txt):
            return True
        else:
            return False
    else:
        return True


def not_normalize_text(txt):
    """Check normalize text"""
    return True if not(pd.isna(txt)) and (re.findall('<[^<]+?>', str(txt)) or re.findall('\r|\t|\n',str(txt)) ) else False


def if_digit_in(txt):
    """check digit"""
    return True if not(pd.isna(txt)) and re.findall('\d',str(txt)) else False


def check_url(url):
    """Validate urls"""
    try:
        if not (pd.isna(url)):
            if validators.url(url):
                return True
            else:
                return False
        else:
            return True
    except Exception as e:
        print(e)
        return True


def check_mail(email):
    """validate text if it is valid email id"""
    try:
        if not (pd.isna(email)):
            if validators.email(email):
                return True
            else:
                return False
        else:
            return True
    except Exception as e:
        print(e)
        return True


def perform_qa(list_id,file_path=""):
    """
    perform qa on the given file
    :param list_id: list id mentioned in google sheet
    :param file_path: file you want to perform qa
    :return: None
    """
    # get data from master table google sheet
    master_df = pd.read_csv(master_file)
    master_df_item = master_df[master_df['list_id'] == list_id]
    if master_df_item.empty:
        print('Please provide exist list id.')
        return False
    master_df_item.fillna(0, inplace=True)
    master_dict = master_df_item.iloc[0, :].to_dict()
    master_dict['cc_id'] = master_df['cc_id'][0]
    headers = set(master_dict['headers'].split(','))

    if not re.findall(r'\S._.\d{1,2}-\d{1,2}-\d{1,2}\.csv', file_path):
        print('Please provide valid file name ')
        return False
    df = pd.read_csv(file_path, encoding="ISO-8859-1")

    # Check length of file
    if (len(df.index)) == 0:
        print(f'File: {file_path}  has no records.Please provide valid file.')
        return False

    try:
        db_file_path = f'/agg_store_locator/output_file/{file_path.split("/")[0]}'
        output_file_path = upload_file_db(file_path,db_file_path)
        # output_file_path = "upload_file_db(file_path,db_file_path)"
        columns = set(df.columns)
        missing_columns = headers - columns

        df.index += 1

        # Find duplicates in df
        duplicate_rows_html = ''
        duplicate_rows_df = df[df.duplicated()]
        if not duplicate_rows_df.empty:
            duplicate_rows_html = duplicate_rows_df.to_html(na_rep='',justify='center',border=1)

        # check normalized text
        nor_dict = {'column' :'row number'}

        nor_df = df.applymap(not_normalize_text)
        for (columnName, columnData) in nor_df.iteritems():
            nor_list = nor_df.index[columnData].to_list()
            if nor_list:
                t_nor_list = [str(item) for item in nor_list]
                nor_dict[columnName] = ', '.join(t_nor_list)

        less_count_error = list()
        print(f"validating {file_path} ...")

        count_error = dict()
        data_counts = df.count(axis=0).to_dict()
        for data_count in data_counts.items():
            if 0 < data_count[1] < (len(df.index) * .95):
                count_error[data_count[0]] = data_count[1]
                less_count_error.append(data_count[0])

        details_dict = dict()
        desired_key_from_master = ('list_id', 'file_name', 'website_url', 'developer_name', 'agg_data_count', 'xbyte_count', 'last_build_date')

        for key in master_dict.keys():
            if key in desired_key_from_master:
                if type(master_dict[key]) == np.float64:
                    val = int(master_dict[key])
                else:
                    val = master_dict[key]
                details_dict[(key.replace('_',' ').title())] = val

        details_dict['Present Count'] = len(df.index)
        details_dict['Difference Between Agg Count and Present Count'] = int((master_dict.get('agg_data_count','')) - details_dict['Present Count'])
        details_dict['Difference Between Xbyte Count and Present Count '] = int((master_dict.get('xbyte_count','')) - details_dict['Present Count'])

        mail_string = '<br><h3>Details</h3>'
        mail_string += json2html.convert(json=details_dict)
        mail_string += f"<h3><a href='{output_file_path}'>Output File Path</a> </h3>"


        if missing_columns:
            mail_string += f"<h4>Missing Columns : {', '.join(missing_columns)}</h4>"
            mail_string += f"<h4>Desired Columns : {master_dict.get('headers','')}</h4>"

        if duplicate_rows_html:
            mail_string += (f"<br><h3>Duplicate Records </h3><br>{duplicate_rows_html}")

        if len(nor_dict) > 1:
            mail_string += (
                f"<br><h3>Please check below rows.Those are not normalized</h3><br>{json2html.convert(json=nor_dict)}")


        # Data count summary
        mail_string += ("<br><h3>Data Count Summary.</h3>")
        mail_string += (json2html.convert(json=data_counts))

        # generate mail content
        mail_content = gen_mail_string(mail_string)

        # save mail content as html
        with open('property_qa_mail.html','w') as f:
            f.write((mail_content))

        cc_ids = master_dict.get('cc_id', '').split(',')

        dev_email = master_dict.get('developer_email_id', '').split(',')

        today = datetime.datetime.strftime(datetime.datetime.now(), "%m/%d/%Y %I:%M %p")
        mail_subject = f"agg-data store locator : {master_dict.get('file_name', '')} {today}"

        if master_dict.get('last_build_date'):
            mail_subject += ' - Rerun'
        else:
            mail_subject += ' - New'

        send_mail(dev_email, mail_content, cc_ids, mail_subject)
    except Exception as e:
        print(e)


def send_mail(email_ids,mail_content,cc_ids,mail_subject):
    import smtplib
    import socket
    from email.mime.multipart import MIMEMultipart
    from email.mime.text import MIMEText

    from_email_id = "alerts@xbyte.io"
    from_email_password = "xbyte123"

    body = "".join(mail_content)
    try:
        msg = MIMEMultipart()
        msg['From'] = from_email_id
        msg['To'] = ",".join(email_ids)
        msg['CC'] = ",".join(cc_ids)
        msg['Subject'] = mail_subject
        msg.attach(MIMEText(body, 'html'))
        s = smtplib.SMTP("mail.xbyte.io", 587)
        s.starttls()
        email_ids.extend(cc_ids)
        s.login(from_email_id, from_email_password)
        text = msg.as_string()
        s.sendmail(from_email_id, email_ids, text)
        print("Mail Sent ...")
        s.quit()
    except Exception as e:
        print(e)

perform_qa(list_id=420,file_path="bayer_properties_02-11-20.csv")