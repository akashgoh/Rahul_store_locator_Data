import re
import pandas as pd
import numpy as np
import datetime
import pymysql
import math
import json
import sys
import os
from json2html import *
import collections
import validators
from store_locators.db_config import config
import dropbox
from store_locators.compare_file import compare_file
import socket

master_file_sheet_id = "1WuCniaa8TQRffZHwfS2zURyT02aJAX3-laXI4AMGkc0"
master_file_tab_id = "2011677482"
master_file = f'https://docs.google.com/spreadsheets/d/{master_file_sheet_id}/export?gid={master_file_tab_id}&format=csv'

length_file_tab_id = "1389275692"
length_file = f'https://docs.google.com/spreadsheets/d/{master_file_sheet_id}/export?gid={length_file_tab_id}&format=csv'

address_split_param = ('unit ', 'suit ', 'ste ', 'suite ', 'units ', 'ste. ')


def upload_file_db(csv_path,file_name):
    try:
        access_token = 'CUfJO7qYu2AAAAAAAAA0Dp9t8EZdAImrwo2K85bkJlqHNSf-Sbu8r963qHCrAZmE'
        file_from = csv_path
        file_to = '/agg_store_locator/log_file/' + file_name  # The full path to upload the file to, including the file name
        dbx = dropbox.Dropbox(access_token)
        with open(file_from, 'rb') as f:
            dbx.files_upload(f.read(), file_to, mode=dropbox.files.WriteMode.overwrite)
        print('File Uploaded To :' + file_to)
        # Below Code is for getting the link of uploaded File
        result = dbx.sharing_create_shared_link(file_to)
        print('CSV Path : ' + result.url)
        return result.url
    except Exception as e:
        print(str(e)) + ': in Uploading to Dropbox'
        return ''


def check_us_zip(txt):
    if not (pd.isna(txt)):
        if re.match('\d{5}\-\d{4}',txt):
            return True
        elif re.match('\d{5}', txt):
            return True
        else:
            return False
    else:
        return True


def address_split(txt):
    if not (pd.isna(txt)):
        return any(x in (str(txt).lower()) for x in address_split_param)
    return False


def not_normalize_text(txt):
    return True if not(pd.isna(txt)) and (re.findall('<[^<]+?>', str(txt)) or re.findall('\r|\t|\n',str(txt)) ) else False


def if_digit_in(txt):
    return True if not(pd.isna(txt)) and re.findall('\d',str(txt)) else False


def check_url(url):
    try:
        if not (pd.isna(url)):
            if validators.url(url):
                return True
            else:
                return False
        else:
            return True
    except Exception as e:
        print(e)
        return True


def check_mail(email):
    try:
        if not (pd.isna(email)):
            if validators.email(email):
                return True
            else:
                return False
        else:
            return True
    except Exception as e:
        print(e)
        return True

def flatten(d, parent_key='', sep='_'):
    items = []
    for k, v in d.items():
        new_key = parent_key + sep + k if parent_key else k
        if isinstance(v, collections.MutableMapping):
            items.extend(flatten(v, new_key, sep=sep).items())
        else:
            items.append((new_key, v))
    return dict(items)


def perform_qa(list_id,file_path=""):

    # Get details regarding list id
    master_df = pd.read_csv(master_file)
    master_df_item = master_df[master_df['list_id'] == list_id]
    if master_df_item.empty:
        print('Please provide exist list id.')
        return False
    master_df_item.fillna(0, inplace=True)
    master_dict = master_df_item.iloc[0, :].to_dict()
    master_dict['cc_id'] = master_df['cc_id'][0]

    try:
        okay = False
        # Check File name
        if not re.findall(r'\S._.\d{1,2}-\d{1,2}-\d{1,2}\.csv', file_path):
            print('Please provide valid file name ')
            return False

        df = pd.read_csv(file_path,encoding = "ISO-8859-1",converters={'zip code': lambda x: str(x)})

        # Check length of file
        if (len(df.index)) == 0:
            print(f'File: {file_path}  has no records.Please provide valid file.')
            return False

        # check column names
        not_valid_column = [column for column in list(df.columns) if '_' in column]
        if not_valid_column:
            print(f"Please provide valid column names without '_' : {not_valid_column}")
            return False

        df.index += 1

        # Find duplicates in df
        duplicate_rows_html = ''
        duplicate_rows_df = df[df.duplicated()]
        if not duplicate_rows_df.empty:
            duplicate_rows_html = duplicate_rows_df.to_html(na_rep='',justify='center',border=1)

        # Length error
        length_df = pd.read_csv(config.length_file)
        max_length_dict = pd.Series(length_df['max_length'].values,index=length_df['header']).to_dict()
        length_err_dict = dict()
        for (columnName, columnData) in df.iteritems():
            if columnName in ['latitude','longitude']:
                continue
            len_list = df.index[columnData.astype('str').str.len() > max_length_dict.get(columnName, 0)].to_list()
            if len_list:
                length_err_dict[columnName] = ', '.join([str(len_item) for len_item in len_list])

        # Store hour length
        store_hour_length = ''
        store_hour_df = df['store hours'].dropna().astype('str')
        if not store_hour_df.empty:
            max_store_hour_len = math.ceil(store_hour_df.str.len().mean())
            store_hour_length = store_hour_df.index[store_hour_df.str.len() > max_store_hour_len].to_list()

        # digit in city state
        digit_in_city = df.index[df['city'].apply(if_digit_in)].to_list()
        digit_in_state = df.index[df['state'].apply(if_digit_in)].to_list()

        # duplicate phone
        dup_phone = df['phone number'].dropna().duplicated()
        dup_phone_num = dup_phone.index[dup_phone].to_list()

        # duplicate address
        dup_address = df['address hash id'].dropna().duplicated()
        dup_address_num = dup_address.index[dup_address].to_list()

        # check normalized text
        nor_dict = dict()
        nor_df = df.applymap(not_normalize_text)
        for (columnName, columnData) in nor_df.iteritems():
            nor_list = nor_df.index[columnData].to_list()
            if nor_list:
                nor_dict[columnName] = nor_list

        # us invalid state and city
        us_states = set(length_df['us_state'])
        us_cities = set(length_df['us_city'])
        us_df = df[df['country code'] == 'US']
        if not us_df.empty:
            invalid_us_state = us_df.index[~us_df['state'].isin(us_states)].to_list()
            invalid_us_city = us_df.index[~us_df['city'].str.lower().isin(us_cities)].to_list()
            invalid_us_lat = us_df.index[us_df['latitude'] < 0].to_list()
            invalid_us_lng = us_df.index[us_df['longitude'] > 0].to_list()
            invalid_us_zip = us_df.index[~us_df['zip code'].apply(check_us_zip)].to_list()
        else:
            invalid_us_state = invalid_us_city = invalid_us_lat = invalid_us_lng = invalid_us_zip = ''

        # Not Null error
        null_state = df.index[df['state'].isna()].tolist()
        null_city = df.index[df['city'].isna()].tolist()
        null_store_name = df.index[df['store name'].isna()].tolist()
        null_address = df.index[df['address'].isna()].tolist()
        null_zip_code = df.index[df['zip code'].isna()].tolist()
        null_country = df.index[df['country'].isna()].tolist()
        null_country_code = df.index[df['country code'].isna()].tolist()
        null_phone_number = df.index[df['phone number'].isna()].tolist()
        null_longitude = df.index[df['longitude'].isna()].tolist()
        null_latitude = df.index[df['latitude'].isna()].tolist()

        # Invalid error
        invalid_country_code = df.index[df['country code'].astype('str').str.len() != 2].to_list()

        # address split error
        address_split_error = df.index[df['address'].apply(address_split)].to_list()

        # email address error
        email_error = df.index[~df['email address'].apply(check_mail)].to_list()

        # website address error
        website_address_error = df.index[~df['website address'].apply(check_url)].to_list()


        less_count_error = list()
        print(f"validating {file_path} ...")

        count_error = dict()
        data_counts = df.count(axis=0).to_dict()
        for data_count in data_counts.items():
            if 0 < data_count[1] < (len(df.index) * .95):
                count_error[data_count[0]] = data_count[1]
                less_count_error.append(data_count[0])

        error_dict = {
            "Store Hour Length Exceeds Avg. Length": store_hour_length,
            "Digit In City": digit_in_city,
            "Digit In State": digit_in_state,
            "Duplicate Phone Numbers": dup_phone_num,
            "Duplicate Address ":dup_address_num,
            "Invalid US State": invalid_us_state,
            "Invalid US City": invalid_us_city,
            "Invalid US Latitude": invalid_us_lat,
            "Invalid US Longitude": invalid_us_lng,
            "Invalid US Zip": invalid_us_zip,
            "Null State": null_state,
            "Null City": null_city,
            "Null Store Name": null_store_name,
            "Null Address": null_address,
            "Null Zip Code": null_zip_code,
            "Null Country": null_country,
            "Null Country Code": null_country_code,
            "Null Phone Number": null_phone_number,
            "Null Latitude": null_latitude,
            "Null Longitude": null_longitude,
            "Address Split Error": address_split_error,
            "Email Error": email_error,
            "Website Address Error": website_address_error,
            "Less Count Error":less_count_error,
            "Invalid Country Code": invalid_country_code,
        }

        error_summary = dict()
        for key, val in error_dict.items():
            if type(val) == list and len(val) > 0:
                error_summary[key] = len(val)

        if not (duplicate_rows_html or length_err_dict or nor_dict or count_error) :
            okay = True

        for key in error_dict.copy():
            if not error_dict[key]:
                del error_dict[key]
            elif key not in ['error']:
                if type(error_dict[key]) == list :
                    if key:
                        error_dict[key] = ', '.join([str(error_dict_key) for error_dict_key in error_dict[key]])
                    okay = False

        # Get Log table
        if master_dict.get('search_by','') != 'link':
            db_con = pymysql.connect(config.db_host, config.db_user, config.db_password, config.db_name)
            run_date = str(datetime.datetime.today()).split()[0]
            db_crsr = db_con.cursor()
            pending_search_terms_cnt = f"SELECT COUNT(*) FROM {config.db_log_table} WHERE list_id = '{list_id}' AND run_date = '{run_date}' AND number_of_store < 0 "
            db_crsr.execute(pending_search_terms_cnt)
            pending_search_terms_cnt = db_crsr.fetchone()[0]
            done_search_terms_cnt = f"SELECT COUNT(*) FROM {config.db_log_table} WHERE list_id = '{list_id}' AND run_date = '{run_date}' AND number_of_store > -1 "
            db_crsr.execute(done_search_terms_cnt)
            done_search_terms_cnt = db_crsr.fetchone()[0]

            log_cnt_dict = {"done search terms count": done_search_terms_cnt, "pending search terms count": pending_search_terms_cnt}

            pending_search_terms = f"select * from  {config.db_log_table} WHERE list_id = '{list_id}' AND run_date = '{run_date}' AND number_of_store < 0 limit 10 "
            pending_search_terms_df = pd.read_sql(pending_search_terms,db_con)
            pending_search_terms_df.index += 1

            done_search_terms = f"select * from  {config.db_log_table} WHERE list_id = '{list_id}' AND run_date = '{run_date}' AND number_of_store > -1 limit 10 "
            done_search_terms_df = pd.read_sql(done_search_terms, db_con)
            done_search_terms_df.index += 1

        log_file_path = config.dir_path + f"{list_id}_logs.txt"
        dbx_log_file_path = ''
        if os.path.exists(log_file_path):
            try:
                dbx_log_file_path = upload_file_db(log_file_path,f"{list_id}_logs.txt")
            except Exception as e:
                print(e)

        mail_content = list()
        mail_content.append("<html>")
        mail_content.append("<head>")
        mail_content.append("<style>")
        mail_content.append(
            "table {font-family: arial, sans-serif;  border-collapse: collapse;  width: 70%;} td, th {  border: 1px "
            "solid #dddddd;  text-align: left;  padding: 8px;} .suc{ color : #4CAF50} .fail {color : #c22f25}")
        mail_content.append("</style>")
        mail_content.append("</head>")
        mail_content.append("<body>")
        mail_content.append(f"<p>List id : {int(master_dict.get('list_id',''))}</p>")
        mail_content.append(f"<p>File Name : {master_dict.get('file_name','')}</p>")
        mail_content.append(f"<p>Developer Name : {master_dict.get('developer_name','')}</p>")
        mail_content.append(f"<p>website_url : {master_dict.get('website_url','')}</p>")
        mail_content.append(f"<p>Agg Data Count : {int(master_dict.get('agg_data_count',0))}</p>")
        mail_content.append(f"<p>Present Data Count : {int(len(df.index))}</p>")
        mail_content.append(f"<p>Difference in  Data Count : {int((master_dict.get('agg_data_count',''))-(len(df.index)))}</p>")

        # Get Local IP Address
        socket_obj = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        socket_obj.connect(('8.8.8.8', 1))
        local_ip_address = socket_obj.getsockname()[0]

        if okay:
            mail_content.append(
                f"<p class='suc'>Congratulations ! \\{local_ip_address}\\{file_path} is Validated Successfully by QA Tool.</p>")
            print(f"Congratulations ! {file_path} : Validated Successfully...")

        else:
            mail_content.append(
                f"<p class='fail'>Sorry ! {local_ip_address}\\{file_path} file is not Validated by QA Tool. Please check below details.</p>")
            print(f"Sorry ! {file_path} : Not Validated... Please Find {file_path}_error.Json for more ...")

            # Generating json error file
            with open(file_path + "_error.json", "w") as f:
                f.write(json.dumps(error_dict))

            if duplicate_rows_html:
                mail_content.append(f"<br><h3>Duplicate Records </h3><br>{duplicate_rows_html}")

            if length_err_dict:
                mail_content.append(f"<br><h3>Please check length of following fields</h3>{json2html.convert(json=length_err_dict)}")
                mail_content.append(f"<p>Please Find Length details at below URl : <a href='https://docs.google.com/spreadsheets/d/1WuCniaa8TQRffZHwfS2zURyT02aJAX3-laXI4AMGkc0/edit#gid=1389275692'>field length sheet</a></p>")

            if nor_dict:
                mail_content.append(f"<br><h3>Please check below rows.Those are not normalized</h3><br>{json2html.convert(json=nor_dict)}")

            if error_summary:
                mail_content.append("<br><h3>Error Summary.</h3>")
                mail_content.append(json2html.convert(json=error_summary))

            if error_dict:
                error_dict_header = {"error":"row number"}
                mail_content.append(f"<br><h3>You have following error in the above mentioned file.Please check it.</h3>")
                mail_content.append(json2html.convert(json=error_dict_header))
                mail_content.append(json2html.convert(json=error_dict))

            if count_error:
                mail_content.append(
                    "<br><h3>Please check the following columns. Their counts are less than 95% of total records</h3>")
                mail_content.append(json2html.convert(json=count_error))

            if master_dict.get('search_by','') != 'link':
                mail_content.append("<h3>Log Table Summary*</h3>")
                mail_content.append(json2html.convert(json=log_cnt_dict))
                mail_content.append("<h3>Log Table Pending Details</h3>")
                mail_content.append(pending_search_terms_df.to_html(na_rep='',justify='center',border=1))
                mail_content.append("<h3>Log Table Done Details</h3>")
                mail_content.append(done_search_terms_df.to_html(na_rep='', justify='center', border=1))

        # Data count summary
        mail_content.append("<br><h3>Data Count Summary.</h3>")
        mail_content.append(json2html.convert(json=data_counts))

        # Log File Path
        try:
            if dbx_log_file_path:
                mail_content.append(f'<a href="{dbx_log_file_path}">Log File Path</a>')
        except Exception as e:
            print('While uploading log file to dropbox',e)

        mail_content.append("</body></html>")

        with open('qa_mail.html','w') as f:
            f.write((''.join(mail_content)))


        cc_ids = master_dict.get('cc_id','').split(',')

        dev_email = master_dict.get('developer_email_id','').split(',')

        today = datetime.datetime.strftime(datetime.datetime.now(), "%m/%d/%Y %I:%M %p")
        mail_subject = f"agg store locator : {master_dict.get('file_name','')} {today}"
        send_mail(dev_email, mail_content, cc_ids,mail_subject)
        compare_file(file_path, master_dict)
        return okay

    except Exception as e:
        print(e)
        return False


def send_mail(email_ids,mail_content,cc_ids,mail_subject):
    import smtplib
    import socket
    from email.mime.multipart import MIMEMultipart
    from email.mime.text import MIMEText

    from_email_id = "alerts@xbyte.io"
    from_email_password = "xbyte123"

    body = "".join(mail_content)
    try:
        msg = MIMEMultipart()
        msg['From'] = from_email_id
        msg['To'] = ",".join(email_ids)
        msg['CC'] = ",".join(cc_ids)
        msg['Subject'] = mail_subject
        msg.attach(MIMEText(body, 'html'))
        s = smtplib.SMTP("mail.xbyte.io", 587)
        s.starttls()
        email_ids.extend(cc_ids)
        s.login(from_email_id, from_email_password)
        text = msg.as_string()
        s.sendmail(from_email_id, email_ids, text)
        print("Mail Sent ...")
        s.quit()
    except Exception as e:
        print(e)

# files = sys.argv[1].split(',')
# for file_path in files:
#     print(f"Validation for {file_path} : is started")
#     doQA(file_path=file_path)