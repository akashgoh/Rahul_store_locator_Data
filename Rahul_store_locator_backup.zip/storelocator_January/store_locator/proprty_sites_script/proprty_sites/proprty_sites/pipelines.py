# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html
import os
import re

import pymysql

from proprty_sites.property_qa_tool import perform_qa
from proprty_sites.spiders import common_functions
from proprty_sites.db_config import db_master_table, db_country_table, db_us_state_table, db_output_table, db_host, \
    db_user, db_password, db_name
from proprty_sites.items import ProprtySitesItem
import logging
import pymysql
from datetime import timedelta, datetime

from proprty_sites.export_data import export_data
import re
import hashlib


class ProprtySitesPipeline(object):
    insert_count = 0

    def process_item(self, item, spider):
        self.tablename = spider.table_name
        if isinstance(item, ProprtySitesItem):
            try:

                for itm in item.items():
                    if itm[1]:
                        item[itm[0]] = self.normalize_text(itm[1])

                hash_list = []
                for field_tmp in item:
                    hash_list.append(str(item[field_tmp]).replace("'", "’"))

                store_hash_id = bytes(','.join(hash_list), encoding='utf-8')

                item['hash'] = int(hashlib.md5(store_hash_id).hexdigest(), 16) % (10 ** 16)
                self.con = spider.f1.con
                self.cursor = spider.f1.cursor

                field_list = []
                value_list = []
                for field in item:
                    field_list.append(str(field))
                    value_list.append(str(item[field]).replace("'", "’"))

                fields = ','.join(field_list)
                values = "','".join(value_list)
                insert_db = "insert into " + self.tablename + "( " + fields + " ) values ( '" + values + "' )"
                self.cursor.execute(insert_db)
                self.con.commit()
                self.insert_count += 1
                print(f"\rData Inserted ...{self.insert_count}", end='')
            except pymysql.IntegrityError as e:
                print('Duplicate entry ', str(e))
            except Exception as e:
                print('problem in Data insert ', str(e))

    def normalize_text(self, text):
        if (type(text)) == str:
            text = re.sub('<[^<]+?>', '', str(text))
            text = re.sub('\s+', ' ', re.sub('\t|\n|\r', ' ', str(text))).strip().strip(',')
        return text

    def close_spider(self, spider):
        # pass
        tablename = spider.table_name
        try:
            (spider.not_export_data)
        except AttributeError:
            try:
                stat = spider.crawler.stats.get_stats()
                start_time = stat['start_time'] + timedelta(hours=5, minutes=30)
                end_time = datetime.now()
                perform_qa(spider.f1,tablename)
            except Exception as e:
                print(e)
                logging.log(logging.ERROR, e)
        else:
            if spider.not_export_data:
                print('no call export data')
            else:
                try:
                    stat = spider.crawler.stats.get_stats()
                    start_time = stat['start_time'] + timedelta(hours=5, minutes=30)
                    end_time = datetime.now()
                    # perform_qa(spider.f1, start_time, end_time)
                    perform_qa(spider.f1, tablename)
                except Exception as e:
                    print(e)
                    logging.log(logging.ERROR, e)
