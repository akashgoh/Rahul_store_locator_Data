import re
import pandas as pd
import numpy as np
import datetime
import pymysql
import math
import json
import sys
import os
from json2html import *
import collections
import validators
from proprty_sites.db_config import *
import dropbox
# from store_locators.compare_file import compare_file
from proprty_sites.compare_file_data_compy import compare_file
import socket

master_file_sheet_id = "1WuCniaa8TQRffZHwfS2zURyT02aJAX3-laXI4AMGkc0"
master_file_tab_id = "2011677482"
master_file = f'https://docs.google.com/spreadsheets/d/{master_file_sheet_id}/export?gid={master_file_tab_id}&format=csv'

length_file_tab_id = "1389275692"
length_file = f'https://docs.google.com/spreadsheets/d/{master_file_sheet_id}/export?gid={length_file_tab_id}&format=csv'

address_split_param = ('unit ', 'suit ', 'ste ', 'suite ', 'units ', 'ste. ')

def gen_mail_string(mail_string):
    mail_content = list()
    mail_content.append("<html>")
    mail_content.append("<head>")
    mail_content.append("<style>")
    mail_content.append("table,th,td {border : 2px solid black;border-collapse: collapse;padding: 10px;}")
    mail_content.append("</style>")
    mail_content.append("</head>")
    mail_content.append("<body>")
    mail_content.append(mail_string)
    mail_content.append('</body></html>')
    return ''.join(mail_content)


def upload_file_db(csv_path,db_file_path):
    try:
        access_token = 'CUfJO7qYu2AAAAAAAAA0Dp9t8EZdAImrwo2K85bkJlqHNSf-Sbu8r963qHCrAZmE'
        file_from = csv_path
         # The full path to upload the file to, including the file name
        file_to = db_file_path
        dbx = dropbox.Dropbox(access_token)
        with open(file_from, 'rb') as f:
            dbx.files_upload(f.read(), file_to, mode=dropbox.files.WriteMode.overwrite)
        print('File Uploaded To :' , file_to)
        # Below Code is for getting the link of uploaded File
        result = dbx.sharing_create_shared_link(file_to)
        print('CSV Path : ' + result.url)
        return result.url
    except Exception as e:
        print(str(e)) + ': in Uploading to Dropbox'
        return ''


def check_us_zip(txt):
    if not (pd.isna(txt)):
        if re.match('\d{5}\-\d{4}',txt):
            return True
        elif re.match('\d{5}', txt):
            return True
        else:
            return False
    else:
        return True


def address_split(txt):
    if not (pd.isna(txt)):
        return any(x in (str(txt).lower()) for x in address_split_param)
    return False


def not_normalize_text(txt):
    return True if not(pd.isna(txt)) and (re.findall('<[^<]+?>', str(txt)) or re.findall('\r|\t|\n',str(txt)) ) else False


def if_digit_in(txt):
    return True if not(pd.isna(txt)) and re.findall('\d',str(txt)) else False


def check_url(url):
    try:
        if not (pd.isna(url)):
            if validators.url(url):
                return True
            else:
                return False
        else:
            return True
    except Exception as e:
        print(e)
        return True


def check_mail(email):
    try:
        if not (pd.isna(email)):
            if validators.email(email):
                return True
            else:
                return False
        else:
            return True
    except Exception as e:
        print(e)
        return True

def flatten(d, parent_key='', sep='_'):
    items = []
    for k, v in d.items():
        new_key = parent_key + sep + k if parent_key else k
        if isinstance(v, collections.MutableMapping):
            items.extend(flatten(v, new_key, sep=sep).items())
        else:
            items.append((new_key, v))
    return dict(items)


def perform_qa(list_id,file_path="",master_dict={}):

    try:
        if not master_dict:
            master_df = pd.read_csv(master_file)
            master_df_item = master_df[master_df['list_id'] == list_id]
            if master_df_item.empty:
                print('Please provide existing list id.')
                return False
            master_df_item.fillna(0, inplace=True)
            master_dict = master_df_item.iloc[0, :].to_dict()
            master_dict['cc_id'] = master_df['cc_id'][0]

        okay = False
        # Check File name
        if not re.findall(r'\S._.\d{1,2}-\d{1,2}-\d{1,2}\.csv', file_path):
            print('Please provide valid file name ')
            return False

        output_file_name = os.path.split(file_path)[-1]
        db_file_path = f'/agg_store_locator/output_file/{output_file_name}'
        output_file_path = upload_file_db(file_path,db_file_path)

        df = pd.read_csv(file_path,encoding = "ISO-8859-1",converters={'zip code': lambda x: str(x)})

        # Check length of file
        if (len(df.index)) == 0:
            print(f'File: {file_path}  has no records.Please provide valid file.')
            return False

        # check column names
        not_valid_column = [column for column in list(df.columns) if '_' in column]
        if not_valid_column:
            print(f"Please provide valid column names without '_' : {not_valid_column}")
            return False

        df.index += 1

        print(f"validating {file_path} ...")
        # Find duplicates in df
        duplicate_rows_html = ''
        duplicate_rows_df = df[df.duplicated()]
        if not duplicate_rows_df.empty:
            duplicate_rows_html = duplicate_rows_df.to_html(na_rep='',justify='center',border=1)

        # Length error
        length_df = pd.read_csv(length_file)
        max_length_dict = pd.Series(length_df['max_length'].values,index=length_df['header']).to_dict()
        length_err_dict = dict()
        for (columnName, columnData) in df.iteritems():
            if columnName in ['latitude','longitude']:
                continue
            len_list = df.index[columnData.astype('str').str.len() > max_length_dict.get(columnName, 0)].to_list()
            if len_list:
                length_err_dict[columnName] = ', '.join([str(len_item) for len_item in len_list])

        # Store hour length
        store_hour_length = ''
        store_hour_df = df['store hours'].dropna().astype('str')
        if not store_hour_df.empty:
            max_store_hour_len = math.ceil(store_hour_df.str.len().mean())
            store_hour_length = store_hour_df.index[store_hour_df.str.len() > max_store_hour_len].to_list()

        # digit in city state
        digit_in_city = df.index[df['city'].apply(if_digit_in)].to_list()
        digit_in_state = df.index[df['state'].apply(if_digit_in)].to_list()

        # duplicate phone
        dup_phone = df['phone number'].dropna().duplicated()
        dup_phone_num = dup_phone.index[dup_phone].to_list()

        # duplicate address
        dup_address = df['address hash id'].dropna().duplicated()
        dup_address_num = dup_address.index[dup_address].to_list()

        # check normalized text
        nor_dict = {'column':'row number'}
        nor_df = df.applymap(not_normalize_text)
        for (columnName, columnData) in nor_df.iteritems():
            nor_list = nor_df.index[columnData].to_list()
            if nor_list:
                t_nor_list = [str(item) for item in nor_list]
                nor_dict[columnName] = ', '.join(t_nor_list)

        # us invalid state and city
        us_states = set(length_df['us_state'])
        us_cities = set(length_df['us_city'])
        us_df = df[df['country code'] == 'US']
        if not us_df.empty:
            invalid_us_state = us_df.index[~us_df['state'].isin(us_states)].to_list()
            invalid_us_city = us_df.index[~us_df['city'].str.lower().isin(us_cities)].to_list()
            invalid_us_lat = us_df.index[us_df['latitude'] < 0].to_list()
            invalid_us_lng = us_df.index[us_df['longitude'] > 0].to_list()
            invalid_us_zip = us_df.index[~us_df['zip code'].apply(check_us_zip)].to_list()
        else:
            invalid_us_state = invalid_us_city = invalid_us_lat = invalid_us_lng = invalid_us_zip = ''

        # Not Null error
        null_state = df.index[df['state'].isna()].tolist()
        null_city = df.index[df['city'].isna()].tolist()
        null_store_name = df.index[df['store name'].isna()].tolist()
        null_address = df.index[df['address'].isna()].tolist()
        null_zip_code = df.index[df['zip code'].isna()].tolist()
        null_country = df.index[df['country'].isna()].tolist()
        null_country_code = df.index[df['country code'].isna()].tolist()
        null_phone_number = df.index[df['phone number'].isna()].tolist()
        null_longitude = df.index[df['longitude'].isna()].tolist()
        null_latitude = df.index[df['latitude'].isna()].tolist()

        # Invalid error
        invalid_country_code = df.index[((df['country code'].astype('str').str.len() > 3) |
                                         (df['country code'].astype('str').str.len() < 2)) &
                                        (df['country code'].astype('str').str.len() > 0)
                                            ].to_list()
        # address split error
        address_split_error = df.index[df['address'].apply(address_split)].to_list()

        # email address error
        email_error = df.index[~df['email address'].apply(check_mail)].to_list()

        # website address error
        website_address_error = df.index[~df['website address'].apply(check_url)].to_list()

        # generate dictionary for less number of records
        less_count_error = list()
        count_error = dict()
        data_counts = df.count(axis=0).to_dict()
        for data_count in data_counts.items():
            if data_count[0] not in('address line 2','address line 3','fax number'):
                if 0 < data_count[1] < (len(df.index) * .95):
                    count_error[data_count[0]] = data_count[1]
                    less_count_error.append(data_count[0])

        error_dict = {
            "Store Hour Length Exceeds Avg. Length": store_hour_length,
            "Digit In City": digit_in_city,
            "Digit In State": digit_in_state,
            "Duplicate Phone Numbers": dup_phone_num,
            "Duplicate Address ":dup_address_num,
            "Invalid US State": invalid_us_state,
            "Invalid US City": invalid_us_city,
            "Invalid US Latitude": invalid_us_lat,
            "Invalid US Longitude": invalid_us_lng,
            "Invalid US Zip": invalid_us_zip,
            "Null State": null_state,
            "Null City": null_city,
            "Null Store Name": null_store_name,
            "Null Address": null_address,
            "Null Zip Code": null_zip_code,
            "Null Country": null_country,
            "Null Country Code": null_country_code,
            "Null Phone Number": null_phone_number,
            "Null Latitude": null_latitude,
            "Null Longitude": null_longitude,
            "Address Split Error": address_split_error,
            "Email Error": email_error,
            "Website Address Error": website_address_error,
            "Less Count Error":less_count_error,
            "Invalid Country Code": invalid_country_code,
        }

        # generate error summary
        error_summary = dict()
        for key, val in error_dict.items():
            if type(val) == list and len(val) > 0:
                error_summary[key] = len(val)

        if not (duplicate_rows_html or length_err_dict or count_error or (len(nor_dict) >1) ):
            okay = True

        for key in error_dict.copy():
            if not error_dict[key]:
                del error_dict[key]
            elif key not in ['error']:
                if type(error_dict[key]) == list :
                    if key:
                        error_dict[key] = ', '.join([str(error_dict_key) for error_dict_key in error_dict[key]])
                    okay = False

        # Get Log table
        if master_dict.get('search_by','') != 'link':
            db_con = pymysql.connect(db_host, db_user, db_password, db_name)
            run_date = str(datetime.datetime.today()).split()[0]
            db_crsr = db_con.cursor()
            pending_search_terms_cnt = f"SELECT COUNT(*) FROM {db_log_table} WHERE list_id = '{list_id}' AND run_date = '{run_date}' AND number_of_store < 0 "
            db_crsr.execute(pending_search_terms_cnt)
            pending_search_terms_cnt = db_crsr.fetchone()[0]
            done_search_terms_cnt = f"SELECT COUNT(*) FROM {db_log_table} WHERE list_id = '{list_id}' AND run_date = '{run_date}' AND number_of_store > -1 "
            db_crsr.execute(done_search_terms_cnt)
            done_search_terms_cnt = db_crsr.fetchone()[0]

            log_cnt_dict = {"done search terms count": done_search_terms_cnt, "pending search terms count": pending_search_terms_cnt}

            pending_search_terms = f"select * from  {db_log_table} WHERE list_id = '{list_id}' AND run_date = '{run_date}' AND number_of_store < 0 limit 10 "
            pending_search_terms_df = pd.read_sql(pending_search_terms,db_con)
            pending_search_terms_df.index += 1

            done_search_terms = f"select * from  {db_log_table} WHERE list_id = '{list_id}' AND run_date = '{run_date}' AND number_of_store > -1 limit 10 "
            done_search_terms_df = pd.read_sql(done_search_terms, db_con)
            done_search_terms_df.index += 1

        log_file_name = f"{list_id}_logs.txt"
        log_file_path = os.path.join(spider_path, log_file_name)
        dbx_log_file_path = ''
        if os.path.exists(log_file_path):
            try:
                db_file_path = '/agg_store_locator/log_file/' + log_file_name
                dbx_log_file_path = upload_file_db(log_file_path,db_file_path)
            except Exception as e:
                print(e)

        master_dict['data_count'] = len(df.index)
        master_dict['diff_between_agg-data_xbyte_count'] = int((master_dict.get('agg_data_count','')) - master_dict['data_count'])

        details_dict = dict()
        desired_key_from_master = (
        'list_id', 'file_name', 'website_url', 'developer_name', 'agg_data_count', 'xbyte_count', 'last_build_date')

        for key in master_dict.keys():
            if key in desired_key_from_master:
                if type(master_dict[key]) == np.float64:
                    val = int(master_dict[key])
                else:
                    val = master_dict[key]
                details_dict[(key.replace('_', ' ').title())] = val

        details_dict['Present Count'] = len(df.index)
        details_dict['Difference Between Agg Count and Present Count'] = int(
            (master_dict.get('agg_data_count', '')) - details_dict['Present Count'])
        details_dict['Difference Between Xbyte Count and Present Count '] = int(
            (master_dict.get('xbyte_count', '')) - details_dict['Present Count'])

        mail_string = '<br><h3>Details</h3>'
        mail_string += json2html.convert(json=details_dict)
        mail_string += f"<h3><a href='{output_file_path}'>Output File Path</a> </h3>"

        # Get Local IP Address
        socket_obj = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        socket_obj.connect(('8.8.8.8', 1))
        local_ip_address = socket_obj.getsockname()[0]

        if okay:
            mail_string += (
                f"<p class='suc'>Congratulations ! \\{local_ip_address}\\{file_path} is Validated Successfully by QA Tool.</p>")
            print(f"Congratulations ! {file_path} : Validated Successfully...")

        else:
            mail_string += (
                f"<p class='fail'>Sorry ! {local_ip_address}\\{file_path} file is not Validated by QA Tool. Please check below details.</p>")
            print(f"Sorry ! {file_path} : Not Validated... Please Find {file_path}_error.Json for more ...")

            if master_dict.get('search_by','') != 'link':
                mail_string += ("<h3>Log Table Summary*</h3>")
                mail_string += (json2html.convert(json=log_cnt_dict))
                mail_string += ("<h3>Log Table Pending Details</h3>")
                mail_string += (pending_search_terms_df.to_html(na_rep='',justify='center',border=1))
                mail_string += ("<h3>Log Table Done Details</h3>")
                mail_string += (done_search_terms_df.to_html(na_rep='', justify='center', border=1))

            # Generating json error file
            with open(file_path + "_error.json", "w") as f:
                f.write(json.dumps(error_dict))

            if duplicate_rows_html:
                mail_string += (f"<br><h3>Duplicate Records </h3><br>{duplicate_rows_html}")

            if length_err_dict:
                mail_string += (f"<br><h3>Please check length of following fields</h3>{json2html.convert(json=length_err_dict)}")
                mail_string += (f"<p>Please Find Length details at below URl : <a href='https://docs.google.com/spreadsheets/d/1WuCniaa8TQRffZHwfS2zURyT02aJAX3-laXI4AMGkc0/edit#gid=1389275692'>field length sheet</a></p>")

            if len(nor_dict) >1:
                mail_string +=  (f"<br><h3>Please check below rows.Those are not normalized</h3><br>{json2html.convert(json=nor_dict)}")

            if error_summary:
                mail_string += ("<br><h3>Error Summary.</h3>")
                mail_string += (json2html.convert(json=error_summary))

            if error_dict:
                error_dict_header = {"error":"row number"}
                mail_string += (f"<br><h3>You have following error in the above mentioned file.Please check it.</h3>")
                mail_string += (json2html.convert(json=error_dict_header))
                mail_string += (json2html.convert(json=error_dict))

            if count_error:
                mail_string += ( "<br><h3>Please check the following columns. Their counts are less than 95% of total records</h3>")
                mail_string += (json2html.convert(json=count_error))



        # Data count summary
        mail_string += ("<br><h3>Data Count Summary.</h3>")
        mail_string += (json2html.convert(json=data_counts))

        # Log File Path
        try:
            if dbx_log_file_path:
                mail_string += (f'<a href="{dbx_log_file_path}">Log File Path</a>')
        except Exception as e:
            print('While uploading log file to dropbox',e)

        mail_content = gen_mail_string(mail_string)

        qa_mail_html_path = f"{compare_directory}{master_dict.get('file_name','')}_qa_mail.html"
        with open(qa_mail_html_path,'w') as f:
            f.write((mail_content))

        cc_ids = master_dict.get('cc_id','').split(',')

        dev_email = master_dict.get('developer_email_id','').split(',')

        today = datetime.datetime.strftime(datetime.datetime.now(), "%m/%d/%Y %I:%M %p")
        mail_subject = f"agg-data store locator : {master_dict.get('file_name','')} {today}"

        if master_dict.get('last_build_date'):
            mail_subject += ' - Rerun'
        else:
            mail_subject += ' - New'

        send_mail(dev_email, mail_content, cc_ids,mail_subject)

        if master_dict.get('last_build_date',''):
            compare_file(file_path, master_dict)

        return okay

    except Exception as e:
        print(e)
        return False


def send_mail(email_ids,mail_content,cc_ids,mail_subject):
    import smtplib
    import socket
    from email.mime.multipart import MIMEMultipart
    from email.mime.text import MIMEText

    from_email_id = "alerts@xbyte.io"
    from_email_password = "xbyte123"

    body = "".join(mail_content)
    try:
        msg = MIMEMultipart()
        msg['From'] = from_email_id
        msg['To'] = ",".join(email_ids)
        msg['CC'] = ",".join(cc_ids)
        msg['Subject'] = mail_subject
        msg.attach(MIMEText(body, 'html'))
        s = smtplib.SMTP("mail.xbyte.io", 587)
        s.starttls()
        email_ids.extend(cc_ids)
        s.login(from_email_id, from_email_password)
        text = msg.as_string()
        s.sendmail(from_email_id, email_ids, text)
        print("Mail Sent ...")
        s.quit()
    except Exception as e:
        print(e)

# files = sys.argv[1].split(',')
# for file_path in files:
#     print(f"Validation for {file_path} : is started")
#     doQA(file_path=file_path)