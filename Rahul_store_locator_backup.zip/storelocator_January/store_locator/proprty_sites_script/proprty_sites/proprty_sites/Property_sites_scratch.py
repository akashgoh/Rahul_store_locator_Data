import pandas as pd
from os import listdir
from os.path import isfile, join
import xlsxwriter,re
# from IPython.core.display import display
try:

    dir = "\\\\192.168.1.234\\e\\store_locator\\Property_sites_script\\proprty_sites_script\\proprty_sites\\proprty_sites\\spiders\\"
# "E:\store_locator\store_locator\store_locator_script\store_locators\store_locators\spiders"
    id = []
    problems = []
    exists, not_exists, not_exists_info,execute_lines = [], [],[],[]
    rerun_sheet = 'https://docs.google.com/spreadsheets/d/1qSFUVVc7yeCbPGWZn-vRw-tPkJg82Ed5_crdd_JeK8g/export?gid=1449776857&format=csv'
    rr = pd.read_csv(rerun_sheet, error_bad_lines=False)
    names = rr['List Name']
    dfr = []
    # names = ["Akwesasne Mohawk Casino", "Aqua-Tots", "Big Yellow Self Storage UK", "GNC", "Hilton Hotels", "HNT Chicken", "HSBC Bank USA", "Invisalign", "LA Fitness", "Marriott", "Oxxo", "Pokeworks", "The New Stand", "Toshiba America Business Solutions", "TradePoint UK", "Tri-Ed", "Tupelo Honey", "Twisted Root Burger", "Vie Athletics", "Zebco", "Zoup!", "CREIT", "Yogurtlandia", "Epic Burger", "gusto!", "fresh&co", "The Halal Shack", "Oil & Vinegar", "CVS HealthHUB", "DIXY", "Magnit", "Perekrestok", "Baba's Mediterranean Grill", "IBERIABANK", "Harford Bank", "Mr. & Mrs. Crab", "Daiquiri Deck", "100 Montaditos", "Bikini Village", "Rana Furniture", "Autopart International", "Bada Bean Cawfee", "B-Bop's", "Beyond Juicery+Eatery", "Big Air Trampoline Park", "Blanco Tacos & Tequila", "Best Western International", "Sarita's Grill & Cantina", "Glory Days Grill", "Lou Malnati's Pizzeria", "Carali's Rotisserie Chicken", "Vanguard Truck Centers", "Tucanos Brazilian Grill", "Salvation Army", "Billiard Factory", "O'Reilly Auto Parts - ASE Certified", "Rogers Ice Cream & Burgers", "Manna Development Group", "UltiMattress", "Erewhon Market", "Garfields Restaurant and Pub"]
    try:
        gsheet = f'https://docs.google.com/spreadsheets/d/1WuCniaa8TQRffZHwfS2zURyT02aJAX3-laXI4AMGkc0/export?gid=0&format=csv'
        df = pd.read_csv(gsheet)
        for name in names:
            tmp = df[df['List Name'] == str(name)].index.tolist()
            try:
                a = df.loc[tmp[0]]
                b= a['CMD Line']
                execute_lines.append(a['CMD Line'])
                dfr.append([name,a['Developer Name'],a['CMD Line'],""])
            except Exception as e:
                problems.append(name)
                dfr.append([name,a['Developer Name'], "", "Problem"])
                print(e)
            print()
        df = pd.DataFrame(dfr,columns=['Name','Developer Name','Eline','Issue'])
        df.to_csv("abc.csv",index=None)
        # display(df)
        print()

        gh = df[df['Eline'].isna()]
        gh.to_csv('nan.csv')

        with open(f"december_full_property_rerun.bat",'w')as f:
            tmp = [f"start {line}" for line in execute_lines]
            f.write('\n'.join(tmp))
    except Exception as e:
        print(e,"for batch from sheet")


        # -----------------------------get list id   and  spider exist or does not exists list ---------------#

    # try:
    #     gsheet = f'https://docs.google.com/spreadsheets/d/1WuCniaa8TQRffZHwfS2zURyT02aJAX3-laXI4AMGkc0/export?gid=0&format=csv'
    #     df = pd.read_csv(gsheet)
    #     for name in names:
    #         tmp = df[df['List Name'] == str(name)].index.tolist()
    #         try:
    #             a = df.loc[tmp[0]]
    #             b= int(a['List ID'])
    #             id.append(int(a['List ID']))
    #         except Exception as e:
    #             problems.append(name)
    #             print(e)
    #         print()
    #     print(id)
    #     print(len(id))
    # except Exception as e:
    #     print(e)
    #
    #
    #
    # onlyfiles = [f for f in listdir(dir) if isfile(join(dir, f))]
    #
    # try:
    #     execute_lines = []
    #
    #     for single in id:
    #         if len(str(single))==1:
    #             single=str(single).zfill(2)
    #         if f"store_{str(single)}.py" in onlyfiles:
    #             exists.append(f"store_{str(single)}.py")
    #             tmp = df[df['List ID'] == int(single)].index.tolist()
    #             try:
    #                 a = df.loc[tmp[0]]
    #                 execute_lines.append(a['CMD Line'])
    #             except Exception as e:
    #                 print(e)
    #         else:
    #             not_exists.append(f"store_{str(single)}.py")
    #             tmp = df[df['List ID'] == int(single)].index.tolist()
    #             try:
    #                 a = df.loc[tmp[0]]
    #                 not_exists_info.append(a)
    #             except Exception as e:
    #                 print(e)
    #     print(not_exists)
    #     print(len(not_exists))
    # except Exception as e:
    #     print(e)


    # try:
    #
    #     with open(f"{dir}may_rerun.bat",'w')as f:
    #         tmp = [f"start {line}" for line in execute_lines]
    #         f.write('\n'.join(tmp))
    #
    #     # nex = pd.DataFrame(not_exists_info,index=None)
    #     # nex.to_csv(f"{dir}may_rerun_not_in_path.csv")
    #
    #     print()
    # except Exception as e:
    #     print(e)
except Exception as e:
    print(e)