# -*- coding: utf-8 -*-
import datetime
import scrapy, json, requests, re
import html2text
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func

class PhillipsedisonSpider(scrapy.Spider):
    name = 'store_483'
    # allowed_domains = ['phillipsedison.com']
    # start_urls = ['https://www.phillipsedison.com/properties/property-search-results']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):

        headers = {
            'Connection': 'keep-alive',
            'Cache-Control': 'max-age=0',
            'DNT': '1',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.87 Safari/537.36',
            'Sec-Fetch-User': '?1',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
            'Sec-Fetch-Site': 'same-origin',
            'Sec-Fetch-Mode': 'navigate',
            'Accept-Encoding': 'gzip, deflate, br',
            'Accept-Language': 'en-US,en;q=0.9',
        }
        yield scrapy.Request(
            url="https://www.phillipsedison.com/properties/property-search-results",
            headers=headers
        )

    def parse(self, response):
        print(response.url)
        for rel_url in response.xpath('//*[@class="col-1"]//@href').getall():
            abs_url = response.urljoin(rel_url)
            yield scrapy.FormRequest(
                url=abs_url,
                callback=self.process_properties
            )

    def process_properties(self, response):

        address = [i.strip() for i in response.xpath('//*[@class="text-center location-address"]//text()').getall()]

        item = ProprtySitesItem()
        item['Property_Name'] = response.xpath('//h1/text()').get('')
        item['Address'] = address[0].strip()
        item['City'] = address[1].split(",")[0].strip()
        item['State'] = address[1].split(",")[1].strip().split()[0].strip()
        item['Zip'] = address[1].split(",")[1].strip().split()[1].strip()
        item['GLA'] = response.xpath('//*[@type="text/javascript"]//text()').re('var n =(.*?);')[0]
        item['Description'] = "".join(response.xpath('//*[text()="Highlights"]/following-sibling::ul//text()').getall())
        item['Leasing_Contact_Name'] = response.xpath('//p[text()="Primary Leasing Contact"]//following-sibling::text()').get('')
        item['Leasing_Contact_Phone'] = response.xpath('//p[text()="Primary Leasing Contact"]//following-sibling::*[contains(@href, "tel")]/text()').get('')
        item['Leasing_Contact_Email'] = response.xpath('//p[text()="Primary Leasing Contact"]//following-sibling::*[@data-mailto]/@data-mailto').get('')
        print(item['Leasing_Contact_Email'])
        item['Property_Manager_Name'] = response.xpath('//p[text()="Property Manager"]//following-sibling::text()').get('')
        item['Property_Manager_Phone'] = response.xpath('//p[text()="Property Manager"]//following-sibling::*[contains(@href, "tel")]/text()').get('')
        item['Property_Manager_Email'] = response.xpath('//p[text()="Property Manager"]//following-sibling::*[@data-mailto]/@data-mailto').get('')
        item['Site_Plan_URL'] = response.xpath('//*[contains(@alt, "Site Plan")]/@src').get()
        if item['Site_Plan_URL']:
            item['Site_Plan_URL'] = response.urljoin(item['Site_Plan_URL'])
        else:
            item['Site_Plan_URL'] = ""

        item['Property_URL'] = response.url
        yield item


name = "phillips_edison_and_company"
today = datetime.datetime.now().strftime("%m-%d-%Y")
from scrapy.cmdline import execute
# execute("scrapy crawl store_483 -a list_id=483".split())
