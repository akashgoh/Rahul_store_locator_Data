# -*- coding: utf-8 -*-
import scrapy,re, json
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func
import datetime

from scrapy.cmdline import execute

class turnberrySpider(scrapy.Spider):
    name = 'store_812'
    allowed_domains = []
    start_urls = ['https://www.turnberry.com/portfolio/retail/']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)


    def parse(self, response):

        link=response.xpath('//div[@class="content portfolio-89"]//div[@class="grilla"]/a/@href').extract()

        for i in link:
            url = i
            print('url----->',url)

            yield scrapy.FormRequest(url=url,callback=self.extract,dont_filter=True)

    def extract(self,response):


            pname=' '.join(response.xpath('//h1//text()').extract())
            print(pname)

            if pname=="AVENTURA MALL":
                addres='19501 BISCAYNE BOULEVARD, AVENTURA'
                city='Miami'
                state='FL'
                des=''.join(response.xpath('//div[@class="text-col"]//text()').extract())
                print(des)
                website='https://www.aventuramall.com/'
                zipcode='33180'
                Mall_Phone='305-935-1110'
                leasing='Jory Thomas'
                leasingphone='305-914-8215'
                leasing_email='leasing@turnberry.com'


            elif pname=='DESTIN COMMONS':
                addres='4100 Legendary Drive Destin'
                city = 'Destin'
                state = 'FL'
                des = ''.join(response.xpath('//div[@class="text-col"]//text()').extract())
                print(des)
                website='http://www.destincommons.com/'
                zipcode='32541'
                Mall_Phone='850-337-8700'
                leasing = 'Heather Ruiz'
                leasingphone = '850-269-5704'
                leasing_email = 'HRuiz@turnberry.com'



            elif pname=='TOWN CENTER AVENTURA':
                addres='18701 Biscayne Blvd. Aventura'
                city = 'Miami'
                state = 'FL'
                des = ''.join(response.xpath('//div[@class="text-col"]//text()').extract())
                print(des)
                website = 'http://www.towncenteraventura.com/'
                zipcode = '32541'
                Mall_Phone = '305-933-5577'
                leasing = 'George Radu'
                leasingphone = '305-914-8211'
                leasing_email = 'gradu@turnberry.com'


            elif pname=='Town Square Las Vegas':
                addres=''
                city = 'Las Vegas'
                state = 'NV'
                des = ''.join(response.xpath('//div[@class="text-col"]//text()').extract())
                print(des)
                website = ''
                zipcode = ''
                Mall_Phone = ''
                leasing = ''
                leasingphone = ''
                leasing_email = ''


            elif pname == 'The Village at Solé Mia':
                addres='2321 Laguna Circle North Miami'
                city = 'Miami'
                state = 'FL'
                des = ''.join(response.xpath('//div[@class="text-col"]//text()').extract())
                print(des)
                zipcode="33181"
                website='http://solemiamiami.com/shopping'
                Mall_Phone = '305-961-1010'
                leasing = 'George Radu'
                leasingphone = '305-914-8211'
                leasing_email = 'gradu@turnberry.com'

            else:
                pass


            item = ProprtySitesItem()
            item['Address']=addres
            item['Property_name'] = pname
            item['city'] = city
            item['state'] = state
            item['Description']=des
            item['country'] = 'US'
            item['URL'] = response.url
            item['Zipcode'] = zipcode
            item['Mall_Phone'] = Mall_Phone
            item['website'] = website
            item['Leasing'] = leasing
            item['Leasing_phone'] = leasingphone
            item['Leasing_email'] =  leasing_email
            yield item


# execute("scrapy crawl store_812 -a list_id=812".split())