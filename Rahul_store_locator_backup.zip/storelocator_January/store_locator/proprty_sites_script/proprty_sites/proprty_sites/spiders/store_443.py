# -*- coding: utf-8 -*-
import datetime
import json
import re
from pydoc import html

import requests
import scrapy
from scrapy.http import HtmlResponse

from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func


class Store443Spider(scrapy.Spider):
    name = 'store_443'
    allowed_domains = []
    start_urls = ['https://madisonmarquette.com/locations/']
    # start_urls = ['https://madisonmarquette.com/properties/']
    not_export_data = False


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)


    def parse(self, response):
        links = response.xpath('//div[@class="fg-row row    "]/div/a/@href').getall()
        for link in links:
            yield scrapy.Request(url=link, callback=self.parse2)

        #---- manual for checking -------------------#
        #
        # link = 'https://madisonmarquette.com/locations/seattle/'
        # yield scrapy.Request(url=link, callback=self.parse2)

    def parse2(self, response):
        text = response.xpath('//b[contains(text(),"Contact")]/../../following-sibling::div[2]//p/text()|//b[contains(text(),"CONTACT")]/../../following-sibling::div[2]//p/text() | //b[contains(text(),"CONTACT")]/../../../following-sibling::div/div//p/text()').getall()

        try:property_name = response.xpath('//h1[@style="text-align: center"]/span/text()').get(default='').strip()
        except Exception as e:print(e)

        try:address = text[0].strip()
        except Exception as e:print(e)

        if len(text) == 4:
            try:city = text[2].split(',')[0].strip()
            except Exception as e:print(e)

            try:zipcode = text[2].split(',')[-1].split()[-1].strip()
            except Exception as e:print(e)

            try:state = text[2].split(',')[-1].split()[0].strip()
            except Exception as e:print(e)
        elif len(text) == 3:
            try:city = text[1].split(',')[0].strip()
            except Exception as e:print(e)

            try:zipcode = text[1].split(',')[-1].split()[-1].strip()
            except Exception as e:print(e)

            try:state = text[1].split(',')[-1].split()[0].strip()
            except Exception as e:print(e)

        try:
            leasing_contact = text[-1].strip()
        except Exception as e:
            print(e)
            leasing_contact=''

        property_url = response.url


        item = ProprtySitesItem()
        item['Property_Name'] = property_name
        item['Address'] = address
        item['City'] = property_name.title()
        item['State'] = state
        item['ZipCode'] = zipcode
        item['Leasing_Contact_Phone'] = leasing_contact
        item['Property_URL'] = property_url
        yield item

    #======================--------------------- NEW code 17-11-2020  -------##############################

    # def parse(self, response):
    #     # link = 'https://madisonmarquette.com/wp-content/themes/ark/json/properties.1605548807.json'
    #     link = 'https://madisonmarquette.com/wp-content/themes/ark/json/properties.1605653455.json'
    #     yield scrapy.FormRequest(url=link,callback=self.parse2,dont_filter=True)
    #
    # def parse2(self,response):
    #     data = response.text
    #     val = json.loads(data)
    #
    #     for i in range(0,210):
    #         try:
    #             url = val[i]['url']
    #             # print(url)
    #         except Exception as e:
    #             print(e)
    #             url=''
    #
    #         try:
    #             add = val[i]['location']['address']
    #             # print(add)
    #         except Exception as e:
    #             print(e)
    #             add=''
    #
    #         try:
    #             city =  val[i]['location']['city']
    #             # print(city)
    #         except Exception as e:
    #             print(e)
    #             city=''
    #         try:
    #             zip = val[i]['location']['zip']
    #             # print(zip)
    #         except Exception as e:
    #             print(e)
    #             zip=''
    #
    #         try:
    #             country = val[i]['location']['county']
    #             # print(country)
    #         except Exception as e:
    #             print(e)
    #             country=''
    #
    #         try:
    #             state = val[i]['property-state'][0]['slug'].upper()
    #             # print(state)
    #         except Exception as e:
    #             print(e)
    #             state=''
    #
    #         try:
    #             lat = val[i]['location']['lat']
    #             # print(lat)
    #         except Exception as e:
    #             print(e)
    #             lat=''
    #
    #         try:
    #             long = val[i]['location']['lng']
    #             # print(long)
    #         except Exception as e:
    #             print(e)
    #             long=''
    #
    #         try:
    #             id = int(val[i]['brokers'][0])
    #             # print(id)
    #
    #         except Exception as e:
    #             print(e)
    #             id = ''
    #
    #         item = ProprtySitesItem()
    #
    #         item['Address'] = add
    #         item['City'] = city
    #         item['State'] = state
    #         item['ZipCode'] = zip
    #         yield scrapy.FormRequest(url=url,callback=self.parse3,dont_filter=True,meta={'item':item,'id':id})
    #
    # def parse3(self,response):
    #     item = response.meta['item']
    #     id = response.meta['id']
    #     # print(id)
    #
    #     try:
    #         Name = re.findall(r'name":"(.*?)"',response.text)[1]
    #         # print(Name)
    #     except Exception as e:
    #         print(e)
    #         Name = ''
    #
    #     url = response.url
    #
    #     try:
    #         br = response.url.split("/")[-2]
    #         # print(br)
    #         br = br.replace('-','').replace(' ','')
    #         # print(br)
    #
    #         li = f'https://{br}.sharplaunch.com/'
    #         # print(li)
    #
    #         li1 = requests.get(url=li)
    #         # print(li1)
    #         response1 = HtmlResponse(url=li, body=li1.content)
    #         print(response1)
    #     except Exception as e:
    #         print(e)
    #
    #     try:
    #         Brochure = response1.xpath('//div[@class="availability__row-buttons"]/a/@href').extract_first()
    #         # print(Brochure)
    #     except Exception as e:
    #         print(e)
    #         Brochure = ''
    #
    #
    #
    #     item['Property_Name'] = Name
    #     item['Brochure_url'] = Brochure
    #
    #     # yield scrapy.FormRequest(url='https://madisonmarquette.com/wp-content/themes/ark/json/agents.1605548807.json',callback=self.parse4,dont_filter=True,meta={'item':item,'id':id,'url':url})
    #     yield scrapy.FormRequest(url='https://madisonmarquette.com/wp-content/themes/ark/json/agents.1605653455.json',callback=self.parse4,dont_filter=True,meta={'item':item,'id':id,'url':url})
    #
    #
    # def parse4(self,response):
    #     global l_name, l_email, l_phone
    #     id = response.meta['id']
    #     item = response.meta['item']
    #     url = response.meta['url']
    #
    #     data1 = response.text
    #     va = json.loads(data1)
    #     finallists = va
    #
    #     for finallist in finallists:
    #         if finallist['id'] == id:
    #             try:
    #                 l_name = finallist['name']
    #                 # print(l_name)
    #                 # break
    #             except Exception as e:
    #                 print(e)
    #                 l_name = ''
    #
    #             try:
    #                 l_email = finallist['email']
    #                 # print(l_email)
    #                 # break
    #             except Exception as e:
    #                 print(e)
    #                 l_email=''
    #
    #             try:
    #                 l_phone = finallist['phone']
    #                 # print(l_phone)
    #                 break
    #             except Exception as e:
    #                 print(e)
    #                 l_phone = ''
    #
    #     item['Leasing_Contact'] = l_name
    #     item['Leasing_Contact_email'] = l_email
    #     item['Leasing_Contact_Phone'] = l_phone
    #     item['Property_URL'] = url
    #     yield item

from scrapy.cmdline import execute
# execute('scrapy crawl store_443 -a list_id=443'.split())
