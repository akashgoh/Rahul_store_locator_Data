# -*- coding: utf-8 -*-
import datetime
import re

import scrapy

from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func


class Store441Spider(scrapy.Spider):
    name = 'store_441'
    allowed_domains = []
    start_urls = ['http://www.lamarco.com/properties/portfolio/']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def parse(self, response):
        links = response.xpath('//*[contains(text(),"Property Details")]/@href').getall()
        for link in links:
            headers = {
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
                "Accept-Encoding": "gzip, deflate",
                "Accept-Language": "en-US,en;q=0.9",
                "Cache-Control": "max-age=0",
                "Connection": "keep-alive",
                "Host": "www.lamarco.com",
                "Referer": "http://www.lamarco.com/properties/portfolio/",
                "Upgrade-Insecure-Requests": "1",
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Safari/537.36"
            }
            yield scrapy.Request(url=link, callback=self.parse2, headers=headers)
            # yield scrapy.Request(url='http://www.lamarco.com/properties/portfolio/bryan-towne-center/', callback=self.parse2)


    def parse2(self, response):
        text = response.xpath('//div[@class="et_pb_text_inner"]/text()').getall()

        property_name = text[0].strip()

        address = text[1].strip()

        city = text[2].split(',')[0].strip()

        try:zip_code = re.findall(r'(\d{5})', text[2])[0]
        except:zip_code = ''

        state = text[2].split(',')[-1].strip().replace(zip_code,'').strip()

        try:description = ','.join(response.xpath('//div[@class="et_pb_text_inner"]/ul/li/text()').getall())
        except Exception as e:print(e)

        try:GLA = response.xpath('//h4[@class="et_pb_module_header"]/span/text()').getall()[1].strip()
        except:GLA = ''

        try:leasing_contact = response.xpath('//p[contains(text(),"Leasing Contact")]/../../following-sibling::div/div/text()').get(default='').strip()
        except Exception as e:print(e)

        try:leasing_phone = response.xpath('//p[contains(text(),"Leasing Contact")]/../../following-sibling::div[2]/div/text()').get(default='').strip()
        except Exception as e:print(e)

        try:leasing_email = response.xpath('//a[contains(text(),"@")]/text()').get(default='').strip()
        except Exception as e:print(e)

        property_url = response.url

        try:brochure_url = response.xpath('//a[contains(text(),"Brochure")]/@href').get(default='').strip()
        except Exception as e:print(e)

        item = ProprtySitesItem()
        item['Property_Name'] = property_name
        item['Address'] = address
        item['City'] = city
        item['State'] = state
        item['ZipCode'] = zip_code
        item['Description'] = description
        item['GLA'] = GLA
        item['Leasing_Contact_Name'] = leasing_contact
        item['Leasing_Contact_Phone'] = leasing_phone
        item['Leasing_Contact_Email'] = leasing_email
        item['Property_URL'] = property_url
        item['Brochure_URL'] = brochure_url
        yield item

# from scrapy.cmdline import execute
# execute('scrapy crawl store_441 -a list_id=441'.split())
