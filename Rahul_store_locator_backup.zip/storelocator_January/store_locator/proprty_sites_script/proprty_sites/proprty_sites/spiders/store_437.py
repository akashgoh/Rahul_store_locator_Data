# -*- coding: utf-8 -*-
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
import html2text
h = html2text.HTML2Text()
import datetime
import scrapy, json, requests, re
import html2text
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func

class JbgsmithSpider(scrapy.Spider):
    name = 'store_437'
    allowed_domains = []
    start_urls = ['https://www.jenel.net/select-portfolio']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def parse(self, response):
        try:
           # links = response.xpath('//div[contains(@id,"itemsContainer")]//a/@href').extract()
           links = response.xpath('//div[@class="_2-Q1H _1O3_3"]/a/@href').extract()
           for link in links:
               link = link.replace("./","/")
               link = 'https://www.jenel.net' + str(link)
               print(link)
               yield scrapy.FormRequest(url=link,callback=self.extract,dont_filter=True)
        except Exception as e:
            print(e)

    def extract(self,response):
        try:
            temp = response.xpath('//h2[@class="font_2"][1]//span/text()').extract_first(default='').strip().split(',')
            desc = response.xpath('//span[contains(@style,"font-family:wfont_9f2361_821a099c1bec47988a9b2c59787b5f17")][1]/text()').extract_first(default='').strip()
            gla_temp = response.xpath('//span[contains(text(),"square")]/text()').extract_first(default='').strip()
            if gla_temp!='':
                gla = gla_temp.split(' ')[0].strip().replace('square','').replace('Located','').replace('Jenel','').replace('Constructed','').strip()
            else:gla=''
            try:l_name = response.xpath('//span[contains(text(),"Leasing Contact")]/ancestor::div[1]/following::div[1]//span/text()').extract_first(default='').strip().split(';')[0].strip()
            except:l_name=''

            item = ProprtySitesItem()
            item['Property_Name'] = temp[0].strip()
            item['Address'] = temp[0].strip()
            item['City'] = temp[1].strip()
            item['State'] = temp[2].strip()
            item['Description'] = desc
            item['GLA'] = gla
            item['Leasing_Contact'] = l_name
            item['Property_URL'] = response.url
            yield item
        except Exception as e:
            print(e)

# execute("scrapy crawl store_437 -a list_id=437".split())