# # -*- coding: utf-8 -*-
# import datetime
# import scrapy, json, requests, re
# import html2text
# from proprty_sites.items import ProprtySitesItem
# from proprty_sites.spiders.common_functions import Func
#
#
# class Store304Spider(scrapy.Spider):
#     name = 'store_304'
#     allowed_domains = []
#     # not_export_data = True
#     def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
#         super().__init__(name, **kwargs)
#         self.list_id, self.proxy_type = list_id, proxy_type
#         self.f1 = Func()
#         self.run_date = str(datetime.datetime.today()).split()[0]
#         self.table_name = self.f1.set_details(self.list_id, self.run_date)
#
#     def start_requests(self):
#         try:
#             source_url = link = f'http://bcwoodproperties.propertycapsule.com/property/output/find/search'
#             file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
#                 self.run_date) + '.html'
#             yield scrapy.FormRequest(url=str(link), callback=self.firstlevel,
#                                      meta={'source_url': source_url, 'file_path': file_path,
#                                            'proxy_type': self.proxy_type})
#         except Exception as e:
#             print(e)
#
#     def firstlevel(self, response):
#         try:
#             source_url = response.meta['source_url']
#             file_path = response.meta['file_path']
#             proxy_type = response.meta['proxy_type']
#             divs = response.xpath('//a[@class="property-detail"]/@href').extract()
#             for i in divs:
#                 url = i
#                 yield scrapy.FormRequest(url=url, callback=self.get_store_list,
#                                          meta={'source_url': source_url, 'file_path': file_path,
#                                                'proxy_type': proxy_type})
#         except Exception as e:
#             print("firstlevel", e, response.url)
#
#     # Get data from the response
#     def get_store_list(self, response):
#         try:
#             # if not response.url.startswith('file://'):
#             #     self.f1.page_save(response.meta['file_path'], response.body)
#
#             try:
#                 try:
#                     Property_Name = response.xpath(
#                         '//h2[@class="property-metadata p-label"]/text()').extract_first().strip()
#                 except Exception as e:
#                     print("Property_Name", e, response.url)
#
#                 try:
#                     sitemapid = re.findall('/sitemap_ID:(.*?)/', response.text)[0].strip()
#                     Site_Plan_URL = "http://bcwoodproperties.propertycapsule.com/property/capsule_data/513/property/sitemap_image/" + str(
#                         sitemapid) + ".png".strip()
#                 except Exception as e:
#                     Site_Plan_URL = ''
#                     print("Site_Plan_URL", e, response.url)
#
#                 try:
#                     address = response.xpath(
#                         '//span[@class="h-adr"]//span[@class="p-street-address"]/text()').extract_first().strip()
#                 except Exception as e:
#                     print("address", e, response.url)
#
#                 try:
#                     city = response.xpath(
#                         '//span[@class="h-adr"]//span[@class="p-locality"]/text()').extract_first().strip()
#                 except Exception as e:
#                     print("city", e, response.url)
#
#                 try:
#                     state = response.xpath(
#                         '//span[@class="h-adr"]//span[@class="p-region"]/text()').extract_first().strip()
#                 except Exception as e:
#                     print("state", e, response.url)
#
#                 try:
#                     zip_code = response.xpath(
#                         '//span[@class="h-adr"]//span[@class="p-postal-code"]/text()').extract_first().strip()
#                 except Exception as e:
#                     print("zip_code", e, response.url)
#
#                 try:
#                     County = re.findall('County: <strong>(.*?)</strong>', response.text)[0].strip()
#                 except Exception as e:
#                     print("County", e, response.url)
#
#                 try:
#                     Type = re.findall('Type: <strong>(.*?)</strong>', response.text)[0].strip()
#                 except Exception as e:
#                     Type = ''
#                     print("Type", e, response.url)
#
#                 try:
#                     Total_SF = re.findall('Total SF: <strong>(.*?)</strong>', response.text)[0].strip()
#                 except Exception as e:
#                     Total_SF = ''
#                     print("Total_SF", e, response.url)
#
#                 try:
#                     Year_Renovated = re.findall('Year Renovated: <strong>(.*?)</strong>', response.text)[0].strip()
#                 except Exception as e:
#                     Year_Renovated = ''
#                     # print("Year_Renovated", e, response.url)
#
#                 try:
#                     Units = re.findall('Units: <strong>(.*?)</strong>', response.text)[0].strip()
#                 except Exception as e:
#                     Units =''
#                     print("Units", e, response.url)
#
#                 try:
#                     bunch11 = (response.text).split('window.agents = [', 1)[1]
#                     bunch11 = bunch11.split("}];", 1)[0]
#                 except Exception as e:
#                     bunch11 = ''
#                     print("bunch11", e, response.url)
#
#                 try:
#                     Contact = re.findall('"name":"(.*?)"', str(bunch11))[0].strip()
#                 except Exception as e:
#                     Contact = ''
#                     print("Contact", e, response.url)
#
#                 try:
#                     Leasing_Phone = re.findall('"phone":"(.*?)"', str(bunch11))[0].strip()
#                 except Exception as e:
#                     Leasing_Phone = ''
#                     print("Leasing_Phone", e, response.url)
#
#                 try:
#                     Leasing_Fax = re.findall('"fax":"(.*?)"', str(bunch11))[0].strip()
#                 except Exception as e:
#                     Leasing_Fax = ''
#                     print("Leasing_Fax", e, response.url)
#
#                 try:
#                     Leasing_Email = re.findall('"email":"(.*?)"', str(bunch11))[0].strip()
#                 except Exception as e:
#                     Leasing_Email = ''
#                     print("Leasing_Email", e, response.url)
#
#                 item = ProprtySitesItem()
#                 item['Property_Name'] = Property_Name
#                 item['Address'] = address
#                 item['City'] = city
#                 item['State'] = state
#                 item['zip_code'] = zip_code
#                 item['Contact'] = Contact
#                 item['County'] = County
#                 item['Type'] = Type
#                 item['Total_SF'] = Total_SF
#                 item['Year_Renovated'] = Year_Renovated
#                 item['Units'] = Units
#                 item['Leasing_Phone'] = Leasing_Phone
#                 item['Leasing_Fax'] = Leasing_Fax
#                 item['Leasing_Email'] = Leasing_Email
#                 item['URL'] = response.url
#                 yield item
#             except Exception as e:
#                 print(e)
#         except Exception as e:
#             print("getdata", e, response.url)
# # from scrapy.cmdline import execute
# # execute("scrapy crawl store_304 -a list_id=304".split())
# #
