# -*- coding: utf-8 -*-
import datetime
import scrapy, json, requests, re
import html2text
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func

class Store426_Spider(scrapy.Spider):
    name = 'store_426'
    allowed_domains = []

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)
        print(self.table_name)

    def start_requests(self):
        try:
            source_url = link = f'http://www.coccadevelopment.com/properties/commercial/'
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(self.run_date) + '.html'
            yield scrapy.FormRequest(url=str(link), callback=self.firstlevel,
                                     meta={'source_url': source_url,
                                           'file_path': file_path, 'proxy_type': self.proxy_type})
        except Exception as e:
           print(e)

    def firstlevel(self, response):
        try:
            source_url = response.meta['source_url']
            file_path = response.meta['file_path']
            proxy_type = response.meta['proxy_type']
            links = response.xpath('//*[@class="btn btn-gray"]/@href').extract()
            for link in links:
                yield scrapy.FormRequest(url=link, callback=self.get_store_list,
                                         meta={'source_url': source_url, 'file_path': file_path,'proxy_type': proxy_type})

            next_page = response.xpath('//*[@class="nextpostslink"]/@href').extract_first()
            if next_page:
                yield scrapy.Request(url=next_page, callback=self.firstlevel,
                                     meta={'source_url': source_url,
                                           'file_path': file_path, 'proxy_type': self.proxy_type})
        except Exception as e:
            print("firstlevel", e, response.url)

    # Get data from the response
    def get_store_list(self, response):
        try:
            try:
                try:
                    Property_Name = response.xpath('//h1/text()').extract_first(default='')
                except Exception as e:
                    print("store_name", e, response.url)

                try:
                    addres_data = response.xpath('//*[@class="list-unstyled"]/li/text()').extract()
                    address = addres_data[0]
                    state = addres_data[-1].split(',')[-1].strip().split(' ')[0].strip()
                    zip_code = addres_data[-1].split(' ')[-1]
                    city = addres_data[1].split(',')[0].strip()
                except Exception as e:
                    print("address", e, response.url)

                try:
                    GLA = response.xpath('normalize-space(//*[@class="content"]/p/text())').extract_first(default='').replace(',', '')
                    if GLA:
                        GLA = re.findall(r'(\d+)', GLA)[0]
                except Exception as e:
                    print(e)

                try:
                    Leasing_Phone = response.xpath('normalize-space(//*[contains(@href,"tel:")]/text())').extract_first(default='')
                except Exception as e:
                    print(e)


                # URL = response.url
                # try:
                #     store_hash_id = bytes(f"{Property_Name} {address} {state} {city} {zip_code} {GLA} {Leasing_Phone} {URL}", encoding='utf-8')
                #     store_hash_id = int(hashlib.md5(store_hash_id).hexdigest(), 16) % (10 ** 16)
                # except Exception as e:
                #     print(e)
                item = ProprtySitesItem()
                item['Property_Name'] = Property_Name
                item['Address'] = address
                item['City'] = city
                item['State'] = state
                item['GLA']=GLA
                item['zip_code'] = zip_code
                # item['Submarket'] = Submarket
                # item['Building_Size'] = Building_Size
                # item['Year_Constructed'] = Year_Constructed.encode('ascii', 'ignore').decode('utf8')
                # item['Year_Acquired'] = Year_Acquired.encode('ascii', 'ignore').decode('utf8')
                # item['Access'] = Access
                # item['Leasing'] = Leasing
                item['Leasing_Phone'] = Leasing_Phone
                # item['Leasing_Email'] = Leasing_Email
                # item['Management'] = Management
                # item['Management_Phone'] = Management_Phone
                # item['Management_Email'] = Management_Email
                item['URL'] = response.url
                yield item
                # try:
                # Property_Name,Address,City,State,GLA,zip_code,Leasing_Phone,URL

                #     insert = "insert into cocca_development_data (store_hash_id, `Property Name`, `Address`, `City`, `State`, `Zip Code`, `GLA`, `Leasing Phone`, `Property URL`) values(%s, %s, %s, %s, %s, %s, %s, %s, %s)"
                #     self.cursor.execute(insert, (store_hash_id, Property_Name, address, city, state, zip_code, GLA, Leasing_Phone, URL))
                #     self.con.commit()
                #     print('Data Inserted...')
                # except Exception as e:
                #     print(e)
            except Exception as e:
                print(e)

        except Exception as e:
            print(e)

    def response_html_path(self, request):
        return request.meta['fpath']

from scrapy.cmdline import execute
# execute('''scrapy crawl store_426 -a list_id=426 -a proxy_type='''.split())
