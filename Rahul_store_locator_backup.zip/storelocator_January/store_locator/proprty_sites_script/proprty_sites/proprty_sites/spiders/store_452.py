import hashlib
import scrapy
# from storelocatore_property.items import StorelocatorePropertyItem
# from store_locators.items import StoreLocatorsItem
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func
import datetime
class Roic(scrapy.Spider):
    name = 'store_452'

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        source_url= urls = 'https://www.roireit.net/shopping-centers/search-results.php?sqFeet=0-10000'
        file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(self.run_date) + '.html'
        # for i in urls:
        yield scrapy.Request(url=urls,callback=self.parse,meta={'source_url': source_url, 'file_path': file_path})
    def parse(self, response):
        urls = response.xpath('//table[@id="search-results-table"]//td/a/@href').extract()
        for i in urls:
            yield scrapy.Request(url='https://www.roireit.net'+i,callback=self.Extract)

    def Extract(self,response):
        item = ProprtySitesItem()
        item['Property_Name'] = response.xpath('//*[@id="property-detail"]/div/h2/text()').extract_first().strip()
        item['Address'] = response.xpath('//*[@id="property-detail"]/div/h3/text()').extract_first().strip()
        item['City'] = response.xpath('//*[@id="property-detail"]/div/h3/text()').extract()[1].strip().split(',')[0].strip()
        item['State'] = response.xpath('//*[@id="property-detail"]/div/h3/text()').extract()[1].strip().split(',')[1].strip().split(' ')[0]
        try:
            item['Zip'] = response.xpath('//*[@id="property-detail"]/div/h3/text()').extract()[1].strip().split(',')[1].strip().split(' ')[1]
        except Exception as e:
            print('error in zip',e)
            # item['Address'] =' '.join(response.xpath('//*[@id="propTitle"]/div/span/text()').extract())
        item['GLA'] = response.xpath('//*[contains(text(),"Total Square Footage:")]/following-sibling::div/text()').extract_first()
        item['Description'] = ' '.join(response.xpath('//*[@id="property-detail"]/div[@id="left-col"]/p/text()').extract())

        if item['Description'] == None:
            item['Description'] =''
        if len(item['Description']) < 10:
            item['Description'] =''

        item['Leasing_Contact_Name'] = response.xpath('//*[@class="address"]/strong/text()').extract_first()
        item['Leasing_Contact_Phone'] = response.xpath('//*[@class="address"]/text()').extract()[-2].strip()
        item['Leasing_Contact_Email'] = response.xpath('//*[@class="address"]/a/text()').extract_first()
        item['Site_Plan_URL'] = 'https://www.roireit.net'+response.xpath('//*[@class="image-box col"]//img/@src').extract_first()
        item['Property_URL'] = response.url

        # hasstr = (str(item['Property_URL']) + str(item['Property_Name'])).encode('utf8')
        # Hash_id = int(hashlib.md5(hasstr).hexdigest(), 16)
        # item['hash'] = Hash_id
        yield item

# from scrapy.cmdline import execute
# execute('''scrapy crawl store_452 -a list_id=452'''.split())
