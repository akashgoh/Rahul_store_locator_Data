import re
import scrapy
import datetime
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func


class Store497Spider(scrapy.Spider):
    name = "store_497"
    allowed_domains = []
    start_urls = ['https://waterstonepg.com/category/retail/']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def parse(self, response):
        links = response.xpath('//*[@class="row container--properties__row"]//*[@class="prop--link"][1]/@href').extract()
        for link in links:
            yield scrapy.Request(url=link, callback=self.get_data)

    def get_data(self, response):
        try:
            Property_Name = response.xpath('//h1/text()').extract_first()
        except Exception as e:
            Property_Name = ''
            print("Property_Name " + str(e))
        try:
            Address = response.xpath('//*[@class="proplocation__streetAddress"]/text()').extract_first()
            if Address:
                Address = Address.strip()
        except Exception as e:
            print(e)
            Address = ''
        try:
            City = response.xpath('//*[@class="proplocation__addressLocality"]/text()').extract_first()
            if City:
                City = City.strip()
        except Exception as e:
            print(e)
            City = ''
        try:
            State = response.xpath('//*[@class="proplocation__addressRegion"]/text()').extract_first()
            if State:
                State = State.strip()
        except Exception as e:
            print(e)
            State = ''
        try:
            Zip_code = response.xpath('//*[@class="proplocation__postalCode"]/text()').extract_first()
            if Zip_code:
                Zip_code = Zip_code.strip()
        except Exception as e:
            print(e)
            Zip_code = ''
        try:
            gla = response.xpath('//p[contains(text(),"GLA")]/text()').extract_first()
            if gla:
                gla = re.sub(r'\s+', ' ', gla).strip().split(' ')
                if len(gla) == 3:
                    GLA = gla[1]
                else:
                    for index, gla_tmp in enumerate(gla):
                        if 'GLA' in gla_tmp and ',' in gla[index + 1]:
                            if re.match(r'\d+', gla_tmp):
                                GLA = gla_tmp
                                break
                        elif 'PHASE' in gla:
                            if ',' in gla_tmp and re.match(r'\d+', gla_tmp):
                                GLA = gla_tmp
                                break
                        else:
                            GLA = ' '
        except Exception as e:
            GLA = ''
            print("gla " + str(e))
        try:
            if response.xpath('//*[@class="proplist__highlight"]'):
                Description = ' '.join(response.xpath('//*[@class="proplist__highlight"]/text()').extract())
            elif response.xpath('//*[@class="property-highlights__inner"]'):
                des = ' '.join(response.xpath('//*[@class="property-highlights__inner"]//text()').extract())
                if 'Property Highlights' in des:
                    Description = re.findall(r'Property Highlights(.*?)$', des, re.DOTALL)
                    if len(Description) == 1:
                        Description = Description[0].strip()
                else:
                    Description = ' '
            else:
                Description = ' '
        except Exception as e:
            print(e)
            Description = ''
        try:
            Leasing_Contact_Phone = response.xpath('//*[@class="blue-text"]/text()').extract_first()
            if Leasing_Contact_Phone:
                Leasing_Contact_Phone = Leasing_Contact_Phone.strip()
        except Exception as e:
            print(e)
            Leasing_Contact_Phone = ''
        try:
            Leasing_Contact_Email = response.xpath('//*[@class="liame blue-text"]/text()').extract_first()
            if Leasing_Contact_Email:
                Leasing_Contact_Email = Leasing_Contact_Email.strip()
        except Exception as e:
            print(e)
            Leasing_Contact_Email = ''
        try:
            if response.xpath('//a[contains(text(),"Site Plan")]/@href'):
                Site_Plan_URL = response.xpath('//a[contains(text(),"Site Plan")]/@href').extract_first()
            else:
                Site_Plan_URL = response.xpath('//a[contains(text(),"Site Map")]/@href').extract_first()
            if Site_Plan_URL == None:
                Site_Plan_URL = ''
        except Exception as e:
            print(e)
            Site_Plan_URL = ''
        try:
            Property_URL = response.url
        except Exception as e:
            print(e)
            Property_URL = ''
        try:
            item = ProprtySitesItem()
            item['Property_Name'] = Property_Name
            item['Address'] = Address
            item['City'] = City
            item['State'] = State
            item['ZIP'] = Zip_code
            item['GLA'] = GLA
            item['Description'] = Description
            item['Leasing_Contact_Phone'] = Leasing_Contact_Phone
            item['Leasing_Contact_Email'] = Leasing_Contact_Email
            item['Site_Plan_URL'] = Site_Plan_URL
            item['Property_URL'] = Property_URL
            yield item
        except Exception as e:
            print("not insert " + str(e))


from scrapy.cmdline import execute
# execute("scrapy crawl store_497 -a list_id=497".split())