# -*- coding: utf-8 -*-
import requests
import scrapy
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func
import datetime

class store_685_Spider(scrapy.Spider):
    name = 'store_685'
    # allowed_domains = ['www.example.com']
    start_urls = ['https://www.aew.com/assets']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)


    def parse(self, response):
        blocks=response.xpath('//section/div[@class="property-preview"]')
        for block in blocks:

            try:

                store_name=block.xpath('./div[2]/h4/text()').get().strip()
            except Exception as e:
                print(e,response.url)
                store_name=''


            try:
                # Address=addresss.split(',')[0].strip()
                Address=block.xpath('./div[2]/h3/text()').get().strip()
            except Exception as e:
                print(e,response.url)
                Address=''


            try:
                # city=addresss.split(',')[-2].strip()
                city_state=block.xpath('./div[2]/h5/text()').get().strip()
                if ',' in city_state:
                    city=city_state.split(',')[0].strip()
                    State=city_state.split(',')[-1].strip()
                elif 'and' in city_state:
                    city = city_state.split('and')[0].strip()
                    State = city_state.split('and')[-1].strip()
                else:
                    city=city_state
                    State=''

            except Exception as e:
                print(e,response.url)
                city=''
                State=''





            try:
                item = ProprtySitesItem()
                item['Property_Name'] = store_name
                item['Address'] = Address
                item['City'] = city
                item['State']=State
                item['Property_URL'] = response.url



                # print (item)
                yield item
            except Exception as e:
                print("item", e)



# from scrapy.cmdline import execute
# execute('''scrapy crawl store_685 -a list_id=685'''.split())
