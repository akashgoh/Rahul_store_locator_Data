import datetime
# -*- coding: utf-8 -*-
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
import html2text
h = html2text.HTML2Text()
import datetime
import scrapy, json, requests, re
import html2text
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func

class AlexanderSpider(scrapy.Spider):
    name = 'store_466'
    allowed_domains = ['example.com']
    start_urls = ['http://alexanderbaldwin.propertycapsule.com/property/output/find/search4']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def parse(self, response):
        try:
            links = response.xpath('//*[@id="pc-property-grid"]//a/@href').getall()
            for link in links:
            # link = 'http://alexanderbaldwin.propertycapsule.com/properties/kuniashoppingcenter'
                id = link.split('/')[-2]
                yield scrapy.FormRequest(url=link, callback=self.parse_data, dont_filter=True, meta={'id':id})
        except Exception as e:
            print(e)

    def parse_data(self, response):

        id = response.meta['id']
        # try:
        #     f = open('D:/nishant/page/StoreLocator/Alexander/' + str(id) + '.html', 'wb')
        #     f.write(response.text.encode('utf-8'))
        #     print('Page Saved...', str(id))
        #     f.close()
        # except Exception as e:
        #     print(e)

        try:
            item = ProprtySitesItem()
            item['PropertyName'] = response.xpath('//*[@class="col-xs-10 col-xs-offset-1"]/h2/text()').get()
            print(item['PropertyName'])
            addr = response.xpath('//*[@class="col-xs-10 col-xs-offset-1"]/p[1]/text()').getall()
            item['Address'] = addr[0].strip()
            item['City'] = addr[1].split(',')[0].strip()
            item['State'] = addr[1].split(',')[1].strip().split()[0].strip()
            item['ZipCode'] = addr[1].split(',')[1].strip().split()[1].strip()
            item['Description'] = response.xpath('//*[@class="col-xs-10 col-xs-offset-1"]/p[3]/text()').get()
            item['GLA'] = response.xpath('//*[@class="col-xs-10 col-xs-offset-1"]/div/div[2]/text()').extract()[1].replace('SF','').strip()
            item['LeasingContact'] = response.xpath('//*[@class="leasing-contact-container"]/div[1]/p[1]/text()').get()
            if item['LeasingContact'] == None:
                item['LeasingContact'] = ''
            item['LeasingPhone'] = response.xpath('//*[@class="leasing-contact-container"]/div[1]/p[2]/text()').get()
            if item['LeasingPhone'] == None:
                item['LeasingPhone'] = ''
            item['LeasingEmail'] = response.xpath('//*[@class="leasing-contact-container"]/div[1]/p[3]/a/text()').get()
            if item['LeasingEmail'] == None:
                item['LeasingEmail'] = ''

            L2 = response.xpath('//*[@class="leasing-contact-container"]/div[2]/p[1]/text()').get()
            if L2:
                item['LeasingContact'] = item['LeasingContact'] +'|'+ str(response.xpath('//*[@class="leasing-contact-container"]/div[2]/p[1]/text()').get())
                item['LeasingPhone'] = item['LeasingPhone'] +'|'+ str(response.xpath('//*[@class="leasing-contact-container"]/div[2]/p[2]/text()').get())
                item['LeasingEmail'] = item['LeasingEmail'] +'|'+ str(response.xpath('//*[@class="leasing-contact-container"]/div[2]/p[3]/a/text()').get())
            item['PropertyManagerName'] = response.xpath('//*[contains(text(),"Property Managers")]/following-sibling::div/p[1]/text()').get()
            if item['PropertyManagerName'] == None:
                item['PropertyManagerName'] = ''
            item['PropertyManagerPhone'] = response.xpath('//*[contains(text(),"Property Managers")]/following-sibling::div/p[2]/text()').get()
            if item['PropertyManagerPhone'] == None:
                item['PropertyManagerPhone'] = ''
            item['PropertyManagerEmail'] = response.xpath('//*[contains(text(),"Property Managers")]/following-sibling::div/p[3]/a/text()').get()
            if item['PropertyManagerEmail'] == None:
                item['PropertyManagerEmail'] = ''

            sp_link = response.xpath('//*[@id="jsviewer"]/@src').get()
            r = requests.get(sp_link)
            res = HtmlResponse(url=r.url, body=r.content)
            try:
                data = re.findall(r'JSON.parse\("(.*?)"\)', res.text)[0].replace('\\','')
            except Exception as e:
                data=''
            # print(data)
            if data != '':
                try:
                    jdata = json.loads(data)
                except Exception as e:
                    jdata =''
                if response.url == 'http://alexanderbaldwin.propertycapsule.com/properties/kuniashoppingcenter':
                    item['SitePlanURL'] = ''
                else:
                    item['SitePlanURL'] = jdata['planWidgetObjects']['mapPlanImg']
            else:
                item['SitePlanURL'] = ''
            item['PropertyURL'] = response.url
            yield item
        except Exception as e:
            print(e)


from scrapy import cmdline
# cmdline.execute("scrapy crawl store_466 -a list_id=466".split())