# # -*- coding: utf-8 -*-
# import scrapy
# import json
# from proprty_sites.items import ProprtySitesItem
# from proprty_sites.spiders.common_functions import Func
# import datetime
# import re
#
# class store_309_Spider(scrapy.Spider):
#     name = 'store_309'
#     # allowed_domains = ['www.example.com']
#     start_urls = ['http://dunhillpartners.com/properties/']
#     not_export_data = True
#
#     def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
#         super().__init__(name, **kwargs)
#         self.list_id, self.proxy_type = list_id, proxy_type
#         self.f1 = Func()
#         self.run_date = str(datetime.datetime.today()).split()[0]
#         self.table_name = self.f1.set_details(self.list_id, self.run_date)
#
#
#
#     def parse(self, response):
#         links= response.xpath('//h5[@class="portfolio_title entry_title"]/a/@href').extract()
#         for link in links:
#             yield scrapy.Request(url=link,callback=self.get_data)
#
#
#     def get_data(self,response):
#         item = ProprtySitesItem()
#         address=response.xpath('//h6[contains(text(),"Location")]/following-sibling::p/text()').get().strip().split('\r')[0].strip()
#         # add1 = response.xpath('//h6[contains(text(),"Location")]/../p/text()[2]').extract_first()
#         # # state = re.findall(r'[A-Z]{2}', add1)
#         # item['state'] = re.findall('[A-Z]{2}', add1)[0]
#         # # zipcode = re.findall('(\d{5})', add1)
#         # item['zipcode'] = re.findall('(\d{5})', add1)[0]
#
#         item['Property_Name']=response.xpath('//h1/span/text()').get()
#
#         # item['Address']=response.xpath('//h6[contains(text(),"Location")]/following-sibling::p/text()').get().strip()
#
#         item['City']=response.xpath('//h6[contains(text(),"Location")]/following-sibling::p/text()').get().strip().split('\r')[-1].strip().split(',')[0].strip()
#         state = response.xpath('//h6[contains(text(),"Location")]/following-sibling::p/text()').get().strip().split('\r')[-1].strip().split(',')[-1].strip().split()[0]
#         if state == "77575":
#             state = "TX"
#         if state == "77058":
#             state = "TX"
#         item['State'] = state
#         if address == "Dallas, Texas":
#             address = ""
#         if address == "Fort Worth, Texas":
#             address = ""
#         if address == "Waxahachie, Texas":
#             address = ""
#         if address == "Dallas, TX":
#             address = ""
#         item['Address'] = address
#
#         zipcode= response.xpath('//h6[contains(text(),"Location")]/following-sibling::p/text()').get().strip().split('\r')[-1].strip().split(',')[-1].strip().split()[-1]
#         if zipcode == "TX":
#             zipcode = ""
#         if zipcode == "Texas":
#             zipcode = ""
#         item['Zip_Code']=zipcode
#
#         Category= response.xpath('//h6[contains(text(),"Category ")]/following-sibling::span/text()').get().strip()
#         item['Category']=Category
#
#         data = response.xpath('//h6[contains(text(),"Contact Information")]/following-sibling::p[1]//text()').getall()
#         data = ''.join(data)
#         data = data.replace('\r', '')
#         data_list = data.split('\n')
#         print(data_list)
#         for i in range(0, len(data_list)):
#             if "Property Manager" in data_list[i]:
#                 item['Property_Manager']=Property_Manager=data_list[i - 1].strip()
#                 item['Property_Manager_Direct_Phone']=Property_Manager_Direct_Phone=data_list[i+2].split(':')[-1].strip()
#                 item['Property_Manager_Email']=Property_Manager_Email=data_list[i+3].strip()
#                 item['Leasing_Agent'] = ''
#                 item['Leasing_Agent_Direct_Phone'] = ''
#                 item['Leasing_Agent_Email'] =''
#                 #
#             if "Leasing Agent" in data_list[i]:
#                 item['Leasing_Agent'] = Leasing_Agent = data_list[i - 1].strip()
#                 item['Leasing_Agent_Direct_Phone'] = Leasing_Agent_Direct_Phone = data_list[i + 2].split(':')[-1].strip()
#                 if ".com" in Leasing_Agent_Direct_Phone:
#                     item['Leasing_Agent_Direct_Phone'] = data_list[i + 1].split(':')[-1].strip()
#                     item['Leasing_Agent_Email'] = data_list[i + 2].strip()
#                 else:
#                     item['Leasing_Agent_Email'] = Leasing_Agent_Email = data_list[i + 3].strip()
#
#         item['Site_plan_URL']=Site_plan_URL=response.xpath('//h6[contains(text(),"Site Plan")]/following-sibling::p/a/@href').get(default='').strip()
#
#         if Site_plan_URL=='':
#
#             site_plan_url=response.xpath('//div[@class="portfolio_images"]/img/@src').getall()
#             for plan_url in site_plan_url:
#                 if 'site' in plan_url:
#                     item['Site_plan_URL']=plan_url
#
#         item['URL']=response.url
#         yield item
#         # print(item)
#
#
# from scrapy.cmdline import execute
# # execute('''scrapy crawl store_309 -a list_id=309'''.split())
