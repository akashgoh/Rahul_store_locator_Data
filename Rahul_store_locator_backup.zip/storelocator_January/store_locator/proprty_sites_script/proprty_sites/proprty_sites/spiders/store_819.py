# -*- coding: utf-8 -*-
# pip install scrapy-html-storage

# -*- coding: utf-8 -*-
import datetime
from scrapy.http import HtmlResponse
import scrapy, json, requests, re
import html2text
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func


class Store819Spider(scrapy.Spider):
    name = 'store_819'
    allowed_domains = []
    # not_export_data = True

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        try:
            self.f1.set_details(self.list_id, self.run_date)
            url = "https://albdev.com/great-places/"
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
                self.run_date) + '.html'
            yield scrapy.FormRequest(url=str(url), callback=self.parse_firstlevel, dont_filter=True)
        except Exception as e:
            print(e)

    def parse_firstlevel(self, response):
        url = response.xpath('//*[@class="property_list"]/div/a/@href').extract()
        for i in url:
            link = i
            yield scrapy.Request(str(link), callback=self.parse_data)
            print(response.text)

    def parse_data(self, response):
        try:
            try:
                Property_Name = response.xpath('//*[contains(@class,"foothills_banner")]//h1/text()').extract()[0]
                Property_Name = re.sub('[\t]|\n|\s\s+|\r', ' ', str(Property_Name))
            except Exception as e:
                print("Property_Name", e, response.url)

            try:
                City1 = re.findall("LOCATION <span>(.*)</span>",response.text)[0]
                City1 = City1.split(",")
                print(len(City1))
                if len(City1)==2:
                    City = City1[0]
                    State = City1[1]
                elif len(City1)==3:
                    City = City1[0] + City1[1]
                    State = City1[2]
            except Exception as e:
                print("Property_Name", e, response.url)

            # try:
            #     SitePlan_URLs = response.xpath('//*[@class="fancybox"]//@src').extract_first()
            #     print(SitePlan_URLs)
            # except Exception as e:
            #     SitePlan_URLs = ""

            try:
                Brochure_URL = response.xpath('//*[@class="download_leasing"]//a/@href').extract_first().strip()
            except Exception as e:
                Brochure_URL = ""
                print(e)

            # try:
            #     Property_type = response.xpath('//*[contains(text(), "Property Type")]/../td[2]/span/text()').extract_first()
            #     print(Property_type)
            #     if Property_type ==None:
            #         Property_type=response.xpath('//*[contains(text(), "Center Type")]/../td[2]/span/text()').extract_first() or response.xpath('//*[contains(text(), "Space Use")]/../div[2]/text()').extract_first()
            # except Exception as e:
            #     Property_type = ""
            #     print(e)

            try:
                description = response.xpath('//*[@class="property_content"]/p[1]/text()').extract()[0]
            except Exception as e:
                description = ""
                print(e)

            try:
                GLA = re.findall("TOTAL GLA <span>(.*)</span>",response.text) or re.findall("RETAIL GLA <span>(.*)</span>",response.text) or re.findall("SITE AREA <span>(.*)</span>",response.text)
                GLA = GLA[0]
            except:
                GLA = ""

            item = ProprtySitesItem()
            item['Property_Name'] = Property_Name
            # item['Address'] = response.meta['address']
            item['City'] = City
            item['State'] = State
            item['zip'] = ""
            item['description'] = description
            item['GLA'] = GLA
            # item['Property_type'] = Property_type
            item['Brochure_URLs'] = Brochure_URL
            # item['SitePlan_URLs'] = SitePlan_URLs
            item['Property_URLs'] = response.url
            # item['Contact'] = Contact
            # item['County'] = response.meta['country']
            yield item
        except Exception as e:
            print(e)


# from scrapy.cmdline import execute
#
# execute("scrapy crawl store_819 -a list_id=819".split())
