# -*- coding: utf-8 -*-
import datetime
import scrapy, json, requests, re
import html2text
from scrapy.http import HtmlResponse

from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func

class UrbanEdgeSpider(scrapy.Spider):
    name = 'store_495'
    allowed_domains = []
    # start_urls = ['http://urbanedge.propertycapsule.com/property/output/find/map_google/search2:1/fit:1/?property_ids=']
    start_urls = ['http://urbanedge.propertycapsule.com/properties/crossbaycommons#docs']
    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)


    def parse(self, response):
        # text = re.findall(r'var markersByFolder = (.*?);', response.text)[0]
        #
        # json_data = json.loads(text)
        #
        # length = len(json_data['folders']['1']['properties'])
        # for i in range(0, int(length)):
        #     link = json_data['folders']['1']['properties'][i]['data']['link1']
        property_urls = response.xpath('//select/option/@value').getall()
        for link in property_urls:
            yield scrapy.Request(url=link, callback=self.parse2)
            #yield scrapy.Request(url='http://urbanedge.propertycapsule.com/properties/brunswickcommons#overview', callback=self.parse2)


    def parse2(self, response):
        try:property_name = response.xpath('//h2[@class="property-metadata p-label"]/text()').get(default='').strip()
        except Exception as e:print(e)

        try:address = response.xpath('//span[@class="p-street-address"]/text()').get(default='').strip()
        except Exception as e:print(e)

        try:city = response.xpath('//span[@class="p-locality"]/text()').get(default='').strip()
        except Exception as e:print(e)

        try:state = response.xpath('//span[@class="p-region"]/text()').get(default='').strip()
        except Exception as e:print(e)

        try:zipcode = response.xpath('//span[@class="p-postal-code"]/text()').get(default='').strip()
        except Exception as e:print(e)

        try:GLA = response.xpath('//h3[contains(text(),"Highlights")]/following-sibling::p/strong/text()').getall()[2].replace(',','').strip()
        except:GLA = ''

        try:description = ''.join(response.xpath('//span[@id="propcap-overview"]/p/text()').getall()).strip()
        except:description = ''

        try:leasing_contact_name = response.xpath('//*[@class="p-name"]/text()').extract_first()
        except Exception as e:print(e)

        try:leasing_phone = response.xpath('//*[@class="p-tel p-tel-office"]/text()').extract_first()
        except Exception as e:print(e)

        text = re.findall(r'window.agents = \[(.*?)\];', response.text)[0]

        try:leasing_email = re.findall(r'"email":"(.*?)",', text)[0]
        except:leasing_email = ''

        try:
            sp_link = response.xpath('//*[@id="jsviewer"]/@src').get()
            r = requests.get(sp_link)
            res = HtmlResponse(url=r.url, body=r.content)
            data = re.findall(r'JSON.parse\("(.*?)"\)', res.text)[0].replace('\\', '')
            jdata = json.loads(data)
            site_plan_url = jdata['planWidgetObjects']['mapPlanImg']
        except:
            site_plan_url = ''

        property_url = response.url

        item = ProprtySitesItem()
        item['PropertyName'] = property_name
        item['Address'] = address
        item['City'] = city
        item['State'] = state
        item['ZipCode'] = zipcode
        item['GLA'] = GLA
        item['Description'] = description
        item['Leasing_Contact_Name'] = leasing_contact_name
        item['Leasing_Contact_Phone'] = leasing_phone
        item['Leasing_Contact_Email'] = leasing_email

        item['SitePlanURL'] = site_plan_url
        item['PropertyURL'] = property_url
        yield item


from scrapy.cmdline import execute
# execute('scrapy crawl store_495 -a list_id=495'.split())
