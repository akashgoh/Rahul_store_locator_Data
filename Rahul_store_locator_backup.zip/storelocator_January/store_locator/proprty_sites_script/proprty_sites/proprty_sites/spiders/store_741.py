# -*- coding: utf-8 -*-
import datetime
import scrapy, json, requests, re
import html2text
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func


class store_741_Spider(scrapy.Spider):
    name = 'store_741'
    allowed_domains = ['']
    start_urls = ['http://www.baprop.com/listings/']


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        url = 'http://www.baprop.com/listings/'
        yield scrapy.FormRequest(url=url, callback=self.parse1)

    def parse1(self, response):
        links = response.xpath('//div[@class="wpb_text_column wpb_content_element "]//a/@href').extract()
        for link in links:
            # link = 'http://www.baprop.com/listings/gwynedd-center/'
            yield scrapy.FormRequest(url=link, dont_filter=True, callback=self.parse2)

    def parse2(self, response):

        try:
            property_name = response.xpath('//div[@class="title_subtitle_holder_inner"]/h1/span/text()').get()
            if property_name == None:
                property_name = response.xpath('//div[@class="wpb_wrapper"]/h2/text()').get()
        except Exception as e:
            print(e)

        try:
            address = response.xpath('//div[@class="wpb_wrapper"]/p[2]/text()[2]/../text()[1]').get()
            if address == None:
                address = response.xpath('//div[@class="wpb_wrapper"]/p[2]/text()').get()
        except Exception as e:
            print(e)

        try:

            add = response.xpath('//div[@class="wpb_wrapper"]/p[2]/text()[2]').get().strip()
            if ',' not in add:
                add = response.xpath('//div[@class="wpb_wrapper"]/p[2]/text()[3]').get().strip()
        except Exception as e:
            print(e)
            add = ''

        try:
            if add  != '':
                if ',' in add:
                    city = add.split(',')[0].strip()
                else:
                    city = ''
            else:
                city = ''
        except Exception as e:
            print(e)

        try:
            if add != '':
                add2 = add.split(',')[1].strip()
                if " " in add2:
                    state = add2.split(' ')[0]
                else:
                    state = add2
            else:
                state = ''
        except Exception as e:
            print(e)

        try:
            if add != '':
                if " " in add2:
                    zip = add2.split(' ')[1]
                else:
                    zip = ''
            else:
                zip = ''
        except Exception as e:
            print(e)

        try:
            contact_name = response.xpath('//div[@class="wpb_wrapper"]/p[4]/text()[1]').get()
        except Exception as e:
            print(e)


        try:
            contact_phone = response.xpath('//div[@class="wpb_wrapper"]/p[4]/text()[3]').get()
            if contact_phone == "\n" :
                contact_phone = response.xpath('//div[@class="wpb_wrapper"]/p[4]/text()[2]').get()
        except Exception as e:
            print(e)

        try:
            contact_email = response.xpath('//div[@class="wpb_wrapper"]/p[4]/a/@href').get()
            if contact_email == None:
                contact_email = response.xpath('//div[@class="wpb_wrapper"]/p[4]/text()[4]').get()
                if contact_email == None:
                    contact_email = response.xpath('//div[@class="wpb_wrapper"]/p[5]/a/@href').get()
        except Exception as e:
            print(e)

        try:
            discription = response.xpath('//div[@class="wpb_wrapper"]/h4/text()').get()
            if discription == None:
                discription = response.xpath('//div[@class="wpb_wrapper"]/p[1]/text()').get()
            elif discription == None:
                discription = response.xpath('//div[@class="wpb_wrapper"]/p[2]/text()').get()
        except Exception as e:
            print(e)

        try:
            broucher_url = response.xpath('//div[@class="wpb_wrapper"]/a/@href').get()
            if broucher_url == None:
                broucher_url = ''
        except Exception as e:
            print(e)
        url = response.url

        item = ProprtySitesItem()
        item['property_name']  = property_name
        item['address']  = address
        item['city']  = city
        item['state']  = state
        item['zip']  = zip
        item['contact_name']  = contact_name
        item['contact_phone']  = contact_phone
        item['contact_email']  = contact_email.replace('mailto:','')
        item['discription'] = discription
        item['broucher_url'] = broucher_url
        item['property_url'] = url
        yield  item

# property_name,address,city,state,zip,contact_name,contact_phone,contact_email,discription,property_url
from scrapy.cmdline import execute
# execute("scrapy crawl store_741 -a list_id=741".split())


# ----------------------------  please check thr csv after run for gla ------------------------------