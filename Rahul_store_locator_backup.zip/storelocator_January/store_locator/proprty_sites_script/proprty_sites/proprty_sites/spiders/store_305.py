# # -*- coding: utf-8 -*-
# # pip install scrapy-html-storage
#
# # -*- coding: utf-8 -*-
# import datetime
# from scrapy.http import HtmlResponse
# import scrapy, json, requests, re
# import html2text
# from proprty_sites.items import ProprtySitesItem
# from proprty_sites.spiders.common_functions import Func
#
#
# class Store305Spider(scrapy.Spider):
#     name = 'store_305'
#     allowed_domains = []
#     # not_export_data = True
#
#     def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
#         super().__init__(name, **kwargs)
#         self.list_id, self.proxy_type = list_id, proxy_type
#         self.f1 = Func()
#         self.run_date = str(datetime.datetime.today()).split()[0]
#         self.table_name = self.f1.set_details(self.list_id, self.run_date)
#
#     def start_requests(self):
#         try:
#             source_url = link = f'http://bigvproperties.propertycapsule.com/property/output/find/search'
#             file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
#                 self.run_date) + '.html'
#             yield scrapy.FormRequest(url=str(link), callback=self.firstlevel,
#                                      meta={'source_url': source_url, 'file_path': file_path,
#                                            'proxy_type': self.proxy_type})
#         except Exception as e:
#             print(e)
#
#     def firstlevel(self, response):
#         try:
#             source_url = response.meta['source_url']
#             file_path = response.meta['file_path']
#             proxy_type = response.meta['proxy_type']
#             url = response.xpath('//td[@class="priority-1"]/a/@href').extract()
#             # print(url)
#             # Total_SF =re.findall('<td class="priority-4">(.*?)</td>', response.text, re.DOTALL)
#             # print(Total_SF)
#             Total_SF=response.xpath('//td[@class="priority-4"]/a[text() or not(text())]').extract()
#             # print(Total_SF)
#             for url,Total_SF in zip(url,Total_SF):
#                 url = url
#                 Total_SF=Total_SF
#                 yield scrapy.FormRequest(url=url, callback=self.get_store_list,dont_filter=True,
#                                          meta={'source_url': source_url, 'file_path': file_path,
#                                                'proxy_type': proxy_type,'Total_SF':Total_SF})
#         except Exception as e:
#             print("firstlevel", e, response.url)
#
#         # Get data from the response
#
#     def get_store_list(self, response):
#         # if not response.url.startswith('file://'):
#         #     self.f1.page_save(response.meta['file_path'], response.body)
#         try:
#             try:
#                 try:
#                     Property_Name = response.xpath('//h1[@id="property_name"]/text()').extract_first().strip()
#                 except Exception as e:
#                     print("Property_Name", e, response.url)
#
#                 try:
#                     Plan_URL1 = response.xpath('//*[@class="jsviewer"]/@src').extract_first(default='').strip()
#                     if Plan_URL1 != "":
#                         resp = requests.get(Plan_URL1)
#                         response1 = HtmlResponse(url=response.url, body=resp.text, encoding='utf8')
#                         Site_Plan_URL = re.findall(r'\\"mapPlanImg\\":\\"(.*?)\\",\\"mapPlanImg1\\":', response1.text,
#                                                    re.DOTALL)
#                         if len(Site_Plan_URL) == 1:
#                             Site_Plan_URL = Site_Plan_URL[0].replace('\\', '')
#                             # print(Site_Plan_URL)
#                         else:
#                             Site_Plan_URL = ""
#                 except Exception as e:
#                     Site_Plan_URL = ""
#
#                 try:
#                     address = response.xpath('//div[@id="property_address"]/text()').extract_first(default='').strip()
#                 except Exception as e:
#                     print("address", e, response.url)
#                 try:
#                     address_data = response.xpath('//div[@id="property_city_state_zip"]/text()').extract_first().strip()
#                     address_data1= address_data.split(",")
#                     city=address_data1[0]
#
#                     address_data2=address_data1[1].split(" ")
#                     state=address_data2[1]
#                     zip_code=address_data2[2]
#                 except Exception as e:
#                     print("====", e, response.url)
#                 County = ''
#
#
#                 try:
#                     Contact = re.findall('Phone:(.*?)<br>', str(response.text))[0].strip()
#                 except Exception as e:
#                     Contact = ''
#                     print("Contact", e, response.url)
#
#
#                 try:
#                     Leasing_Phone1 = response.xpath('//div[@id="div_leasing_agent"]//*[contains(text(),"Leasing Agent")]/../a[@id="leasing_agent_phone"]/text()').extract_first(default='')
#                 except Exception as e:
#                     Leasing_Phone1 = ''
#
#
#                 try:
#                     Leasing_Phone2 = response.xpath('//div[@id="div_leasing_agent"]//*[contains(text(),"Leasing Agent")]/../a[@id="leasing_agent_cell"]/text()').extract_first(default='')
#                 except Exception as e:
#                     Leasing_Phone2 = ''
#
#                 Leasing_Phone=Leasing_Phone1 +"|"+Leasing_Phone2.strip()
#                 Leasing_Phone=Leasing_Phone.strip('|')
#                 try:
#                     Leasing_Email = response.xpath('//div[@id="div_leasing_agent"]//*[contains(text(),"Leasing Agent")]/../a[@id="leasing_agent_email"]/text()').extract()
#                     Leasing_Email = "|".join(Leasing_Email).strip()
#                 except Exception as e:
#                     Leasing_Email = ''
#                     print("Leasing_Email", e, response.url)
#
#
#                 Total_SF=response.meta['Total_SF']
#                 Total_SF=re.findall('">(.*?)</a>', Total_SF)[0].strip()
#
#                 item = ProprtySitesItem()
#                 item['Property_Name'] = Property_Name
#                 item['Address'] = address
#                 item['City'] = city
#                 item['State'] = state
#                 item['zip_code'] = zip_code
#                 item['Contact'] = Contact
#                 item['County'] = County
#                 item['Total_SF'] = Total_SF
#                 item['Leasing_Phone'] = Leasing_Phone
#                 item['Leasing_Email'] = Leasing_Email
#                 item['Plan_URL'] = Site_Plan_URL
#                 item['URL'] = response.url
#                 yield item
#
#             except Exception as e:
#                 print(e)
#
#         except Exception as e:
#             print(e)
#
# # from scrapy.cmdline import execute
# # execute("scrapy crawl store_305 -a list_id=305".split())
#
#
#
#
#
#
