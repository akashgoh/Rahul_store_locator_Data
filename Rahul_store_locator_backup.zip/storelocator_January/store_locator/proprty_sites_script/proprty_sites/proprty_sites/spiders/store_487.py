# -*- coding: utf-8 -*-
import datetime
import json
import re
import scrapy
from scrapy.cmdline import execute
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func


class RivercrestSpider(scrapy.Spider):
    name = 'store_487'
    allowed_domains = ['rivercrest.propertycapsule.com']
    start_urls = ['http://rivercrest.propertycapsule.com/property/output/find/search']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def parse(self, response):
        data = re.findall(r'console.log\((.*?)\);\n', response.text)[1]
        for i in json.loads(data):
            url = re.findall(r"href='(.*?)'", i[0])[0]
            yield scrapy.Request(
                url=url,
                callback=self.process_prop
            )

    def process_prop(self, response):
        data = json.loads(re.findall(b'window.property = (.*?);\n', response.body)[0])
        agent = json.loads(re.findall(b'window.agents = (.*?);\n', response.body)[0])
        item = ProprtySitesItem()
        item["Property_Name"] = data["name"]
        item["Address"] = data["address"]
        item["City"] = data["city"]
        item["State"] = data["state"]
        item["Zip"] = data["zip"]
        item["GLA"] = data["gla"]
        item["Description"] = data["gla"]
        item["Leasing_Contact_Name"] = agent[0]["name"]
        item["Leasing_Contact_Phone"] = agent[0]["phone"]
        item["Leasing_Contact_Email"] = agent[0]["email"]
        item["Property_Manager_Name"] = response.xpath('//*[contains(text(), "Property Management")]//following-sibling::p//*[@class="p-name"]/text()').get('')
        item["Property_manager_phone"] = response.xpath('//*[contains(text(), "Property Management")]//following-sibling::p//*[contains(@class, "p-tel-office")]/text()').get('')
        try:
            coded = response.xpath('//*[contains(text(), "Property Management")]//following-sibling::div//*[contains(@id, "email_")]//a//text()').re('coded = "(.*?)"')[0]
            key = response.xpath('//*[contains(text(), "Property Management")]//following-sibling::div//*[contains(@id, "email_")]//a//text()').re('key = "(.*?)"')[0]
            item["Property_manager_email"] = self.deobfuscate_text(coded, key)
        except:
            item["Property_manager_email"] = ""
        item["Property_URL"] = response.url
        print(item)
        yield item

    def deobfuscate_text(self, coded, key):
        offset = (len(key) - len(coded)) % len(key)
        shifted_key = key[offset:] + key[:offset]
        lookup = dict(zip(key, shifted_key))
        return "".join(lookup.get(ch, ch) for ch in coded)

if __name__ == '__main__':
    name = "rivercrest_realty_investors"
    today = datetime.datetime.now().strftime("%m-%d-%Y")
    execute("scrapy crawl store_487 -a list_id=487".split())
