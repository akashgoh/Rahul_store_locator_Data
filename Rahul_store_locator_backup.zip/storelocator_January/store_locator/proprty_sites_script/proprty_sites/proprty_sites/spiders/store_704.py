# -*- coding: utf-8 -*-
import datetime
import scrapy, json, requests, re
import html2text
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func


class store_704_Spider(scrapy.Spider):
    name = 'store_704'
    allowed_domains = ['www.rappaportco.com']
    start_urls = ['https://www.rappaportco.com/properties/']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        url = 'https://www.rappaportco.com/properties/'
        yield scrapy.FormRequest(url=url , callback=self.parse1)



    def parse1(self, response):

        links = response.xpath('//div[@class="col-xs-12 col-sm-6 col-md-3"]/div/a/@href').getall()
        for link in links:


            yield scrapy.FormRequest(url=link,dont_filter=True, callback=self.parse_detail)

    def parse_detail(self,response):
        item = ProprtySitesItem()

        try:
            property_name =  response.xpath(' //div[@class="quick-summary"]/h2/text()').get()
        except Exception as e:
            property_name = ''

        add = response.xpath('//div[@class="quick-summary"]/ul/li/a/span/text()').get()
        description=  response.xpath('//div[@class="content"]/p[1]/text()').get()
        household_income =  response.xpath('//li[@class="income-icon"]/span/text()').get()
        population = response.xpath('//li[@class="population-icon"]/span/text()').get()
        daytime_population = response.xpath('//li[@class="daytime-icon"]/span/text()').get()
        vehicles_per_day = response.xpath('//li[@class="vehicles-icon"]/span/text()').get()


        contactname1 = response.xpath('//div[@class="row"]/div[1]/div/div[2]/div/h4/a/text()').get()
        contactPhonenumber1 = response.xpath('//div[@class="row"]/div[1]/div/div[2]/div[2]/div[1]/span[2]/strong/a/text()').get()
        contactEmail1 = response.xpath('//div[@class="row"]/div[1]/div/div[2]/div[2]/div[3]/span/a/@href').get()
        if contactEmail1 == None:
            contactEmail1 = response.xpath('//div[@class="row"]/div[1]/div/div[2]/div[2]/div[2]/span/a/@href').get()

        contactname2= response.xpath('//div[@class="row"]/div[2]/div/div[2]/div/h4/a/text()').get()
        contactPhonenumber2 = response.xpath('//div[@class="row"]/div[2]/div/div[2]/div[2]/div[1]/span[2]/strong/a/text()').get()

        contactEmail2 = response.xpath('//div[@class="row"]/div[2]/div/div[2]/div[2]/div[2]/span/a/@href').get()
        if contactEmail2 == None:
            contactEmail2 = response.xpath('//div[@class="row"]/div[2]/div/div[2]/div[2]/div[3]/span/a/@href').get()

        try:
            contactname3 = response.xpath('//div[@class="row"]/div[3]/div/div[2]/div/h4/a/text()').get()
        except Exception as e:
            contactname3 = ''

        try:
            contactPhonnumber3 = response.xpath('//div[@class="row"]/div[3]/div/div[2]/div[2]/div[1]/span[2]/strong/a/text()').get()
        except Exception as e:
            contactPhonnumber3 = ''

        try:
            contactEmail13 = response.xpath('//div[@class="row"]/div[3]/div/div[2]/div[2]/div[3]/span/a/@href').get()
            if contactEmail13 == None:
                contactEmail13 =   response.xpath('//div[@class="row"]/div[3]/div/div[2]/div[2]/div[2]/span/a/@href').get()
        except Exception as e:
            contactEmail13 = ''

        try:
            broucher_url = response.xpath('//div[@class="quick-summary"]/p[1]/a/@href').get()
        except Exception as e:
            broucher_url = ''





        lks = "".join(response.url)

        address = add.split(",")[0]
        try:
            city = add.split(",")[1]
        except Exception as e:
            city = ''

        try:
            state = add.split(",")[2]
        except Exception as e:
            state = ''

        try:
            zip = add.split(",")[-1]
        except Exception as e:
            zip = ''

        # property_name,address,description,household_income,population,daytime_population,vehicles_per_day,contactname1,ContactPhonenumber1,ContactEmail1,contactname2,ContactPhonenumber2,ContactEmail2,contactname3,ContactPhonnumber3,city,state,zip,contactEmail13,broucher_url,urls
        item['property_name'] = property_name
        item['address'] = address
        item['description'] = description
        item['household_income'] = household_income
        item['population'] = population
        item['daytime_population'] = daytime_population
        item['vehicles_per_day'] = vehicles_per_day
        item['contactname1'] = contactname1
        item['ContactPhonenumber1'] = contactPhonenumber1.replace("\n","")
        item['ContactEmail1'] = contactEmail1
        item['contactname2'] = contactname2
        item['ContactPhonenumber2'] = contactPhonenumber2
        item['ContactEmail2'] = contactEmail2
        item['contactname3'] = contactname3
        item['ContactPhonnumber3'] = contactPhonnumber3
        item['city'] = city
        item['state'] = state

        item['zip'] = zip
        item['contactEmail13'] = contactEmail13
        item['broucher_url'] = broucher_url
        item['urls'] = lks

        yield item


# from scrapy.cmdline import execute
# execute("scrapy crawl store_704 -a list_id=704".split())
