# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import random
import re
import pymysql as MySQLdb
import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func
import datetime

class TruGreenSpider(scrapy.Spider):
    name = 'store_160'
    allowed_domains = []

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            self.f1.set_details(self.list_id,run_date)
            if self.f1.search_by != 'link':
                search_terms = self.f1.get_search_term(self.f1.search_by)
                for search_term in (search_terms):
                    source_url = link = 'https://www.trugreen.com/local-lawn-care'
                    yield scrapy.FormRequest(url=str(link), callback=self.get_store_list)
            else:
                connection = MySQLdb.connect('localhost', 'root', 'xbyte', 'store_locator_april', charset='utf8')
                cursor = connection.cursor()
                cursor.execute("select * from 160_urls")
                results = cursor.fetchall()
                for row in results:
                    url = str(row[1]).strip()
                    bno = str(row[2]).strip()
                    yield scrapy.FormRequest(url=url, callback=self.get_store_list, meta={'branchNo': bno, 'url': url})
        except Exception as e:
            print(e)


    # Get data from the response
    def get_store_list(self, response):

        try:
            branchNo = response.meta['branchNo']
            f = open('E:/Anil/Html Pages/StoreLocator/trugreen1/' + str(branchNo) + '.html', 'wb')
            f.write(response.text.encode('utf-8'))
            print('Page Saved...',str(branchNo))
            f.close()
        except Exception as e:
            print(e)

        try:
            additional_info = {}
            item = StoreLocatorsItem()


            try:
                address = item['address'] = re.findall(r'"streetAddress": "(.*?)"', response.text)[0]
                city = re.findall(r'"addressLocality": "(.*?)"', response.text)[0]
                state = re.findall(r'"addressRegion": "(.*?)"', response.text)[0]
                zip_code = re.findall(r'"postalCode": "(.*?)"', response.text)[0]
            except Exception as e:
                print("city",e,response.url)

            try:
                store_name = 'TruGreen Lawn Care - ' + str(city)
            except Exception as e:
                print("store_name",e,response.url)

            try:
                phone_number = re.findall(r'"telephone": "(.*?)"', response.text)[0]
            except Exception as e:
                phone_number = ''


            try:
                address_split_params = ('unit ', 'suit ', 'ste ', 'suite ', 'units ', 'ste. ')
                for address_split_param in address_split_params:
                    if address_split_param in (address.lower()):
                        item['address'] = (item['address'].lower()).split(address_split_param)[0]
                        item['address_line_2'] = f"{address_split_param} {((address.lower()).split(address_split_param)[1])}"
                        break
            except Exception as e:
                print("address", e, response.url)

            try:
                latitude = re.findall(r'"latitude": "(.*?)"', response.text)[0]
                longitude = re.findall(r'"longitude": "(.*?)"', response.text)[0]
            except Exception as e:
                print("latitude and longitude", e, response.url)

            try:
                hours = []
                key = response.xpath('//*[contains(text(),"Hours of Operation")]/following-sibling::div/span[1]/text()').getall()
                val = response.xpath('//*[contains(text(),"Hours of Operation")]/following-sibling::div/span[2]/text()').getall()
                for k, v in zip(key, val):
                    hrs = k + ' - ' + v
                    hours.append(hrs)
                store_hours = '|'.join(hours)
            except Exception as e:
                store_hours = ''

            try:
                slink = 'https://api.trugreen.com/plansandproducts/V1/branchProducts'
                payload = {"branchId":""+str(branchNo)+"","stateId":""+str(state)+"","zip":""+str(zip_code)+""}
                data1 = json.dumps(payload)
                hdr ={'Accept':'application/json, text/plain, */*',
                      'Content-Type':'application/json;charset=UTF-8',
                      'Host':'api.trugreen.com',
                      'Origin':'https://www.trugreen.com',
                      'Referer':'https://www.trugreen.com/local-lawn-care/alabama/huntsville',
                      'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36'}
                r = requests.post(url=slink, data=data1, headers=hdr)
                res = HtmlResponse(url=r.url, body=r.content)
                jsonservice = json.loads(res.text)
                lengths = len(jsonservice['items'])
                service = []
                for a in range(0, lengths):
                    skey = jsonservice['items'][a]['name']
                    sval = jsonservice['items'][a]['short_description']
                    serv = skey + ':' + sval
                    service.append(serv)
                services = '|'.join(service)
            except Exception as e:
                services = ''

            try:
                additional_info = ''
            except Exception as e:
                print("additional_info",e,response.url)


            item['search_term'] = 'link'
            item['store_name']= store_name
            item['city'] = city
            item['state'] =state
            item['zip_code'] = zip_code
            item['phone_number'] =phone_number
            item['latitude'] = latitude
            item['longitude'] = longitude
            item['store_type'] = ''
            item['website_address'] = ''
            item['coming_soon'] = 0
            item['store_number'] = ''
            item['country_code'] = item['country'] = 'US'
            item['services'] = services
            item['store_hours'] = store_hours
            item['additional_info'] = additional_info
            item['source_url'] = response.url

            yield item
        except Exception as e:
            print(e)

#execute('''scrapy crawl store_160 -a list_id=160'''.split())
