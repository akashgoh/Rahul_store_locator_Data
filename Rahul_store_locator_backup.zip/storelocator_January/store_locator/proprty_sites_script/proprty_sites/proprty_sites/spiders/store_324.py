# -*- coding: utf-8 -*-
import hashlib
import os

import scrapy,re
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func
from scrapy.cmdline import execute
import datetime


class DataSpider(scrapy.Spider):
    name = 'store_324'
    allowed_domains = ['starwoodretail.com']
    start_urls = ['http://starwoodretail.com/']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)


    def start_requests(self):
        headers={
                'Host': 'starwoodretail.com',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                'Accept-Language': 'en-US,en;q=0.9',
                'Accept-Encoding': 'gzip, deflate, br'}
        yield scrapy.FormRequest(url='https://starwoodretail.com/lease-from-us/our-properties',headers=headers,callback=self.parse)

    def parse(self, response):
        property_links = response.xpath('//a[@class="search-property-grid__link"]/@href').extract()
        for link in property_links:
            yield scrapy.FormRequest(url=f"https://starwoodretail.com/{link}",callback=self.extract,dont_filter=True)

    def extract(self,response):
        try:
            title = response.xpath('//meta[@property="og:title"]/@content').extract_first(default='').strip()
            print(title)
            address = response.xpath('//meta[@property="og:street_address"]/@content').extract_first(default='').strip()
            city = response.xpath('//*[contains(@class,"section--intro__address")]/p/text()[2]').extract_first(default='').split(',')[0].strip()
            state = response.xpath('//meta[@property="og:locality"]/@content').extract_first(default='').strip()
            zipcode = response.xpath('//meta[@property="og:postal_code"]/@content').extract_first(default='').strip()
            phone = response.xpath('//meta[@property="og:phone_number"]/@content').extract_first(default='').strip()
            website = response.xpath('//a[contains(text(),"Visit Shopper Site")]/@href').extract_first(default='').strip()
            desc = response.xpath('//span[contains(text(),"Description")]/following::div[1]/text()').extract_first(default='').strip()
            sqft = response.xpath('//span[contains(text(),"Total Sq. Ft.")]/following::div[1]/text()').extract_first(default='').strip()
            sqft_stores = response.xpath('//span[contains(text(),"Number of Stores")]/following::div[1]/text()').extract_first(default='').strip()
            sqft_parking = response.xpath('//span[contains(text(),"Number of Parking")]/following::div[1]/text()').extract_first(default='').strip()
            print('sqftpark------------->',sqft_parking)
            anchors_temp = response.xpath('//span[contains(text(),"Anchors")]/following::div[1]/text()').extract_first(default='').strip()

            if anchors_temp!='':
                anchors = re.sub('\n\s+',' ',anchors_temp)
            else:anchors = ''
            tenants_temp = response.xpath('//span[contains(text(),"Key Tenants")]/following::div[1]/text()').extract_first(default='').strip()
            if tenants_temp!='':
                tenants = re.sub('\n\s+',' ',tenants_temp)
            else:tenants = ''
            trade_area = ''.join(response.xpath('//span[contains(text(),"Trade Area")]/following-sibling::div/text()').extract()) if response.xpath('//span[contains(text(),"Trade Area")]/following-sibling::div/text()').extract()!=[] else ''

            leasing = response.xpath('//h3[contains(text(),"Leasing")]/ancestor::div[1]//span[contains(@class,"contacts__name")]/span/text()').extract_first(default='').strip()
            leasing_phone = response.xpath('//h3[contains(text(),"Leasing")]/ancestor::div[1]//span[contains(@class,"contacts__tel")]/a/text()').extract_first(default='').strip()
            leasing_email = response.xpath('//h3[contains(text(),"Leasing")]/ancestor::div[1]//span[contains(@class,"contacts__email")]/a/text()').extract_first(default='').strip()

            local_leasing = response.xpath('//h3[contains(text(),"Local Leasing")]/ancestor::div[1]//span[contains(@class,"contacts__name")]/span/text()').extract_first(default='').strip()
            local_leasing_phone = response.xpath('//h3[contains(text(),"Local Leasing")]/ancestor::div[1]//span[contains(@class,"contacts__tel")]/a/text()').extract_first(default='').strip()
            local_leasing_email = response.xpath('//h3[contains(text(),"Local Leasing")]/ancestor::div[1]//span[contains(@class,"contacts__email")]/a/text()').extract_first(default='').strip()

            pro_management = response.xpath('//h3[contains(text(),"Property Management")]/ancestor::div[1]//span[contains(@class,"contacts__name")]/span/text()').extract_first(default='').strip()
            pro_management_phone = response.xpath('//h3[contains(text(),"Property Management")]/ancestor::div[1]//span[contains(@class,"contacts__tel")]/a/text()').extract_first(default='').strip()
            pro_management_email = response.xpath('//h3[contains(text(),"Property Management")]/ancestor::div[1]//span[contains(@class,"contacts__email")]/a/text()').extract_first(default='').strip()

            m_and_p = response.xpath('//h3[contains(text(),"Marketing & Partnerships")]/ancestor::div[1]//span[contains(@class,"contacts__name")]/span/text()').extract_first(default='').strip()
            m_and_p_phone = response.xpath('//h3[contains(text(),"Marketing & Partnerships")]/ancestor::div[1]//span[contains(@class,"contacts__tel")]/a/text()').extract_first(default='').strip()
            m_and_p_email = response.xpath('//h3[contains(text(),"Marketing & Partnerships")]/ancestor::div[1]//span[contains(@class,"contacts__email")]/a/text()').extract_first(default='').strip()

            bb_leasing = response.xpath('//h3[contains(text(),"Big Box Leasing")]/ancestor::div[1]//span[contains(@class,"contacts__name")]/span/text()').extract_first(default='').strip()
            bb_leasing_phone = response.xpath('//h3[contains(text(),"Big Box Leasing")]/ancestor::div[1]//span[contains(@class,"contacts__tel")]/a/text()').extract_first(default='').strip()
            bb_leasing_email = response.xpath('//h3[contains(text(),"Big Box Leasing")]/ancestor::div[1]//span[contains(@class,"contacts__email")]/a/text()').extract_first(default='').strip()

            restau_leasing = response.xpath('//h3[contains(text(),"Restaurant Leasing")]/ancestor::div[1]//span[contains(@class,"contacts__name")]/span/text()').extract_first(default='').strip()
            restau_leasing_phone = response.xpath('//h3[contains(text(),"Restaurant Leasing")]/ancestor::div[1]//span[contains(@class,"contacts__tel")]/a/text()').extract_first(default='').strip()
            restau_leasing_email = response.xpath('//h3[contains(text(),"Restaurant Leasing")]/ancestor::div[1]//span[contains(@class,"contacts__email")]/a/text()').extract_first(default='').strip()

            talent_coo = response.xpath('//h3[contains(text(),"Tenant Coordination")]/ancestor::div[1]//span[contains(@class,"contacts__name")]/span/text()').extract_first(default='').strip()
            talent_coo_phone = response.xpath('//h3[contains(text(),"Tenant Coordination")]/ancestor::div[1]//span[contains(@class,"contacts__tel")]/a/text()').extract_first(default='').strip()
            talent_coo_email = response.xpath('//h3[contains(text(),"Tenant Coordination")]/ancestor::div[1]//span[contains(@class,"contacts__email")]/a/text()').extract_first(default='').strip()

            try:
                Plan_url = response.xpath('//a[contains(text(),"Site Plan")]/@href').extract_first(default='').strip()
                print(Plan_url)
                if 'http://starwoodretail.com' in Plan_url:
                    Plan_url=Plan_url
                else:
                    if Plan_url=='':
                        Plan_url=''
                    else:
                        Plan_url='https://starwoodretail.com' + Plan_url
                print(Plan_url)
            except:
                Plan_url=''

            item = ProprtySitesItem()
            item['Property_Name'] = title
            item['Address'] = address
            item['City'] = city
            item['State'] = state
            item['Country']='US'
            item['Zip_Code'] = zipcode
            item['GLA'] = ''
            item['Mall_Phone'] = phone
            item['Website'] = website
            item['Description'] = desc
            item['SqFt'] = sqft.replace(',','')
            item['sqft_of_stores'] = sqft_stores.replace(',','')
            item['sqft_of_parking'] = sqft_parking.replace(',','')
            item['Anchors'] = anchors
            item['Key_Tenants'] = tenants
            item['Trade_Area'] = trade_area
            item['Leasing'] = leasing
            item['Leasing_Phone'] = leasing_phone
            item['Leasing_Email'] = leasing_email
            item['Local_Leasing'] = local_leasing
            item['Local_Leasing_Phone'] = local_leasing_phone
            item['Local_Leasing_Email'] = local_leasing_email
            item['Property_Management'] = pro_management
            item['Property_Management_Phone'] = pro_management_phone
            item['Property_Management_Email'] = pro_management_email
            item['Marketing_and_Partnerships'] = m_and_p
            item['Marketing_and_Partnerships_Phone'] = m_and_p_phone
            item['Marketing_and_Partnerships_Email'] = m_and_p_email
            item['Big_Box_Leasing'] = bb_leasing
            item['Big_Box_Leasing_Phone'] = bb_leasing_phone
            item['Big_Box_Leasing_Email'] = bb_leasing_email
            item['Restaurant_Leasing'] = restau_leasing
            item['Restaurant_Leasing_Phone'] = restau_leasing_phone
            item['Restaurant_Leasing_Email'] = restau_leasing_email
            item['Talent_Coordination'] = talent_coo
            item['Talent_Coordination_Phone'] = talent_coo_phone
            item['Talent_Coordination_Email'] = talent_coo_email
            item['Plan_url'] = Plan_url
            item['URL'] = response.url
            yield item

        except Exception as e:
            print(e)


# execute("scrapy crawl store_324 -a list_id=324".split())