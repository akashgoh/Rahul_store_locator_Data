# -*- coding: utf-8 -*-
import json
import re
import logging
import scrapy
from scrapy.utils.response import open_in_browser
import datetime
# from store_property.items import StorePropertyItem

from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func

class DonahueSchriberSpider(scrapy.Spider):
    name = 'store_474'
    allowed_domains = []
    # start_urls = ['https://www.donahueschriber.com/our-properties/']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        try:

            source_url = link = 'https://www.donahueschriber.com/our-properties/'
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(self.run_date) + '.html'
            yield scrapy.FormRequest(url=str(link), callback=self.parse,meta={'source_url': source_url,'file_path': file_path})

        except Exception as e:
            logging.log(logging.ERROR, e)


    def parse(self, response):
        # open_in_browser(response)
        links=response.xpath('//div[@class="prop_list"]/div/a/@href').getall()
        for link in links:
            yield scrapy.FormRequest(url=link, callback=self.get_store, dont_filter=True)



    def get_store(self,response):
        # data=json.loads(response.text)
        # open_in_browser(response)
        item=ProprtySitesItem()
        try:
            item['Property_Name'] = response.xpath('//h1[@class="prop_name"]//text()').get(default='')
            item['Address'] = response.xpath('//i[@class="fas fa-map-marker-alt"]/following-sibling::text()').get(default='').split(',')[0]
            item['City'] = response.xpath('//i[@class="fas fa-map-marker-alt"]/following-sibling::text()').get(default='').split(',')[1]
            item['State'] =response.xpath('//i[@class="fas fa-map-marker-alt"]/following-sibling::text()').get(default='').split(',')[-1].strip().split(' ')[0]
            item['Zip'] =response.xpath('//i[@class="fas fa-map-marker-alt"]/following-sibling::text()').get(default='').split(',')[-1].strip().split(' ')[-1]
            item['GLA'] = response.xpath('//b[contains(text(),"SF:")]/following-sibling::text()').get(default='').strip()
            item['Leasing_contact_name'] = response.xpath('//p[contains(text(),"Leasing Contact")]/../p[@class="contact_name"]/text()').get(default='')
            item['Leasing_contact_phone'] =response.xpath('//p[contains(text(),"Leasing Contact")]/../p[@class="contact_phone"]//text()[2]').get(default='')
            item['Leasing_contact_email'] = response.xpath('//*[@id="property-area"]/div[2]/div[2]/div[1]/a/@href').get(default='').replace("mailto:", "")
            item['Brochure_url'] = response.xpath('//a[@class="brochure_link"]//@href').get(default='')
            item['URL'] = response.url # self.f1.country_dict.get(item['country'].lower())
        except Exception as e:
            print(e)
        yield item



from scrapy.cmdline import execute
# execute('''scrapy crawl store_474 -a list_id=474'''.split())
