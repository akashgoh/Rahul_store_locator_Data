# -*- coding: utf-8 -*-
import scrapy, re, json, requests
from scrapy.http import HtmlResponse
import datetime
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func


class Store434Spider(scrapy.Spider):
    name = 'store_434'
    allowed_domains = []
    start_urls = []

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        head = {'Host': 'buildout.com',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:72.0) Gecko/20100101 Firefox/72.0',
                'Accept': 'application/json, text/javascript, */*; q=0.01',
                'Accept-Language': 'en-GB,en;q=0.5',
                'Accept-Encoding': 'gzip, deflate, br',
                'X-NewRelic-ID': 'Vg4GU1RRGwIJUVJUAwY=',
                'X-Requested-With': 'XMLHttpRequest',
                'Referer': 'https://buildout.com/plugins/7dd4d8338b99791ba9f5432a0d7994974f0e1e89/inventory?utf8=%E2%9C%93&page=0&brandingId=&searchText=&q%5Bsale_or_lease_eq%5D=lease&q%5Bs%5D%5B%5D=name_or_address+asc&viewType=map&q%5Btype_eq_any%5D%5B%5D=2&q%5Btype_eq_any%5D%5B%5D=1&q%5Bmax_space_available_gteq%5D=&q%5Bmin_space_available_lteq%5D=&q%5Bmax_lease_rate_gteq%5D=&q%5Bmin_lease_rate_lteq%5D='}
        url = 'https://buildout.com/plugins/7dd4d8338b99791ba9f5432a0d7994974f0e1e89/inventory?utf8=%E2%9C%93&page=0&brandingId=&searchText=&q%5Bsale_or_lease_eq%5D=lease&q%5Bs%5D%5B%5D=name_or_address+asc&viewType=map&q%5Btype_eq_any%5D%5B%5D=2&q%5Btype_eq_any%5D%5B%5D=1&q%5Bmax_space_available_gteq%5D=&q%5Bmin_space_available_lteq%5D=&q%5Bmax_lease_rate_gteq%5D=&q%5Bmin_lease_rate_lteq%5D='
        yield scrapy.FormRequest(url=url,callback=self.parse,headers=head,dont_filter=True)

    def parse(self, response):
        try:

            df = json.loads(response.text)
            loop = df['inventory']
            for lp in loop:
                item = ProprtySitesItem()
                item['Property_Name'] = lp['display_name']
                item['Address'] = lp['address'] if lp['address']!=None else ''
                item['City'] = lp['city'] if lp['city']!=None else ''
                item['State'] = lp['state'] if lp['state']!=None else ''
                item['Zip_Code'] = lp['zip'] if lp['zip']!=None else ''
                item['Description'] = lp['description'].replace('\r\n','') if lp['description']!=None else ''
                item['Leasing_Contact'] = lp['broker_contacts'][0]['name'] if lp['broker_contacts'][0]['name']!=None else ''
                item['Leasing_Phone'] = lp['broker_contacts'][0]['phone'] if lp['broker_contacts'][0]['phone']!=None else ''
                item['Leasing_Email'] = lp['broker_contacts'][0]['email'] if lp['broker_contacts'][0]['email']!=None else ''
                item['Site_Plan_URL'] = ""
                item['Property_URL'] = lp['show_link'] if lp['show_link']!=None else ''

                pro_id = lp['show_link'].split('propertyId=')[-1].strip()
                res = requests.get(f"https://buildout.com/plugins/7dd4d8338b99791ba9f5432a0d7994974f0e1e89/halpernent.com/inventory/{pro_id}?pluginId=0&iframe=true&embedded=true&cacheSearch=true&enableCookie=true&propertyId={pro_id}")
                response = HtmlResponse(url=res.url,body=res.content)
                ids = re.findall('data-plan-id="(.*?)" data-property-id="(.*?)" data-token="(.*?)"',response.text)[0]
                plan_url = f"https://buildout.com/properties/{str(ids[1])}/plans/{str(ids[0])}.png?style=web&token={str(ids[2])}"
                res_p = requests.get(plan_url)
                response_p = HtmlResponse(url=res_p.url, body=res_p.content)
                Site_Plan_URL = response_p.url
                gla = response.xpath('//td[contains(.//text(),"GLA")]/following::td[1]/text()').extract_first(default='').strip()
                item['GLA'] = gla.replace('SF','').strip()
                item['Site_Plan_URL'] = Site_Plan_URL
                yield item

        except Exception as e:
            print(e)

# Property_Name,Address,City,State,Zip_Code,Description,Leasing_Contact,Leasing_Phone,Leasing_Email,Site_Plan_URL,Property_URL,GLA

# from scrapy.cmdline import execute
# execute("scrapy crawl store_434 -a list_id=434".split())