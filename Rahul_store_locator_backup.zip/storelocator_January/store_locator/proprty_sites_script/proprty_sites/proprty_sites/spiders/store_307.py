# -*- coding: utf-8 -*-
import scrapy
import json
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func
import datetime


class store_307_Spider(scrapy.Spider):
    name = 'store_307'
    # allowed_domains = ['www.example.com']
    start_urls = ['https://centennialrec.com/retail-places/centennial-collection/']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)


    def parse(self, response):
        links= response.xpath('//ul[@class="grid"]/li/a/@href').extract()
        for link in links:
            url='https://centennialrec.com'+link
            yield scrapy.Request(url=url,callback=self.get_data)


    def get_data(self,response):
        item = ProprtySitesItem()
        address=response.xpath('//article/address/text()').get().split(',')[0].strip()
        item['Property_Name']=response.xpath('//header/h1/text()').get()

        item['City']=response.xpath('//article/address/text()').get().split(',')[1].strip()
        item['State']=response.xpath('//article/address/text()').get().split(',')[2].strip()
        item['Address'] = address

        zipcode= response.xpath('//article/address/text()').get().split(',')[-1].strip().split('|')[0].strip()
        item['Zip_Code']=zipcode

        mall_phone= response.xpath('//article/address/text()').get().split(',')[-1].strip().split('|')[-1].strip()
        item['Mall_Phone']=mall_phone

        per_l=response.xpath('//h3[contains(text(),"Leasing Contacts")]/following-sibling::ul/li[1]/strong/text()').getall()
        per_l = '|'.join(per_l)
        item['Permanent_Leasing']=per_l.strip('|')

        spe_l=response.xpath('//h3[contains(text(),"Leasing Contacts")]/following-sibling::ul/li[2]/strong/text()').getall()
        spe_l = '|'.join(spe_l)
        item['Specialty_Leasing']=spe_l.strip('|')

        anchor_l=response.xpath('//h3[contains(text(),"Leasing Contacts")]/following-sibling::ul/li[3]/strong/text()').getall()

        if anchor_l==None:
            anchor_l=''

        if anchor_l==[]:
            anchor_l=''

        else:
            anchor_l = '|'.join(anchor_l)

        item['Anchor_and_Pad_Leasing'] = anchor_l.strip('|')

        per_phone=response.xpath('//h3[contains(text(),"Leasing Contacts")]/following-sibling::ul/li[1]/span/a[1]/text()').getall()
        per_phone='|'.join(per_phone)

        per_email=response.xpath('//h3[contains(text(),"Leasing Contacts")]/following-sibling::ul/li[1]/span/a[2]/text()').getall()
        per_email = '|'.join(per_email)

        spe_phone=response.xpath('//h3[contains(text(),"Leasing Contacts")]/following-sibling::ul/li[2]/span/a[1]/text()').getall()
        spe_phone = '|'.join(spe_phone)

        spe_email=response.xpath('//h3[contains(text(),"Leasing Contacts")]/following-sibling::ul/li[2]/span/a[2]/text()').getall()
        spe_email = '|'.join(spe_email)

        try:
            anchor_phone=response.xpath('//h3[contains(text(),"Leasing Contacts")]/following-sibling::ul/li[3]/span/a[1]/text()').getall()
            anchor_phone = '|'.join(anchor_phone)

            anchor_email=response.xpath('//h3[contains(text(),"Leasing Contacts")]/following-sibling::ul/li[3]/span/a[2]/text()').getall()
            anchor_email = '|'.join(anchor_email)
        except:
            anchor_phone=''
            anchor_email=''
        try:
            site_plan_url=response.xpath('//h4[contains(text(),"Lease Plans")]/../../../@href').get(default='')
            if site_plan_url!='':
                site_plan_url='https://centennialrec.com'+site_plan_url
        except:
            site_plan_url=''

        try:
            broucher_url=response.xpath('//h4[contains(text(),"Leasing Brochure")]/../../../@href').get(default='')
            if broucher_url!='':
                broucher_url='https://centennialrec.com'+site_plan_url
        except:
            broucher_url=''


        item['Permanent_Phone']=per_phone.strip('|')
        item['Permanent_Email']=per_email.strip('|')
        item['Specialty_Phone'] =spe_phone.strip('|')
        item['Specialty_Email'] =spe_email.strip('|')
        item['Anchor_and_Pad_Phone'] =anchor_phone.strip('|')
        item['Anchor_and_Pad_Email'] =anchor_email.strip('|')
        item['Site_plan_URL']=site_plan_url
        item['Leasing_Brochure_URL']=broucher_url
        item['URL']=response.url
        yield item
        # print(item)


# from scrapy.cmdline import execute
# execute('''scrapy crawl store_307 -a list_id=307'''.split())
