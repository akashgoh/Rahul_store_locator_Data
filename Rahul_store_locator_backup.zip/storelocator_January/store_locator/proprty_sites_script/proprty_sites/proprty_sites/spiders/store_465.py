# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import re
from scrapy.http import HtmlResponse
import datetime
import scrapy, json, requests, re
import html2text
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func



class Store465Spider(scrapy.Spider):
    name = 'store_465'
    allowed_domains = []

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        try:
            source_url = link = f'https://albanesecormier.com/page/1/?s&post_type=listing&cities=&states=&propertytypes=&squarefootage='
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
                self.run_date) + '.html'
            yield scrapy.FormRequest(url=str(link), callback=self.firstlevel,
                                     meta={'source_url': source_url, 'file_path': file_path,
                                           'proxy_type': self.proxy_type})
        except Exception as e:
            print(e)

    def firstlevel(self, response):
        page = 1
        for i in range(0, 10):
            try:
                link = "https://albanesecormier.com/page/" + str(page) + "/?s&post_type=listing&cities=&states=&propertytypes=&squarefootage="
                print(link)
                # link="https://albanesecormier.com/page/9/?s&post_type=listing&cities&states&propertytypes&squarefootage"
                file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
                    self.run_date) + '.html'
                yield scrapy.FormRequest(url=str(link), callback=self.secondlevel, dont_filter=True,
                                         meta={'file_path': file_path, 'proxy_type': self.proxy_type, 'page': page})
                page = page + 1
                print(page)
            except Exception as e:
                print(e)

    def secondlevel(self, response):
        if not response.url.startswith('file://'):
            self.f1.page_save(response.meta['file_path'], response.body)
        try:
            file_path = response.meta['file_path']
            peoples = response.xpath('//div[@class="listing-wrap"]')
            for people in peoples:
                link = people.xpath('./a[1]/@href').extract_first(default='').strip().replace(", AIA", '')
                # link="https://albanesecormier.com/listings/athens-outparcel/"
                addresdata = people.xpath('./span[@class="listing-address"]/text()').extract_first(default='').strip()
                city_state_zip = people.xpath('./span[@class="listing-city-state-zip"]/text()').extract_first(default='')
                file_path = self.f1.html_data_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
                    self.run_date) + '.html'
                yield scrapy.Request(url=link, callback=self.get_store_list,
                                         meta={'addresdata': addresdata, 'file_path': file_path,
                                               'city_state_zip': city_state_zip})
        except Exception as e:
            print("firstlevel", e, response.url)

        # Get data from the response

    def get_store_list(self, response):
        if not response.url.startswith('file://'):
            self.f1.page_save(response.meta['file_path'], response.body)
        try:
            try:
                try:
                    Property_Name = response.xpath('//h1[@class="entry-title"]/text()').extract_first()
                except Exception as e:
                    print("Property_Name", e, response.url)

                # try:
                #     addres_data = response.xpath('//div[@class="entry-content"]/p//a[contains(text(),"Get Directions")]/@href').extract_first()
                #     if "https://www.google.com/maps/dir" in str(addres_data):
                #         addres_data=addres_data.replace("https://www.google.com/maps/dir//","https://www.google.com/maps/dir/").strip()
                #         addres_data=addres_data.split('https://www.google.com/maps/dir/')[1].split('/@')[0]
                #     else:
                #         addres_data = addres_data.split('embed&daddr=')[1].split('@@')[0]
                #         print(addres_data)
                #         Zip=''
                #         address=''
                # except Exception as e:
                #     print("Address", e, response.url)

                address = response.meta['addresdata'].strip()
                city_state_zip = response.meta['city_state_zip'].strip()
                try:
                    city = city_state_zip.split(',')[0].strip(',')
                    bunch = city_state_zip.split(',')[1].strip()
                    number = len(bunch.split(' '))
                    if number == 2:
                        state = bunch.split(' ')[0].strip(',')
                        Zip = bunch.split(' ')[-1]
                    else:
                        state1 = bunch.split(' ')[0].strip(',')
                        state2 = bunch.split(' ')[1].strip(',')
                        state = state1 + " " + state2
                        state = state.strip()
                        Zip = bunch.split(' ')[2].strip(',')
                except Exception as e:
                    print("address", e, response.url)
                    city = ''
                    state = ''
                    Zip = ''

                try:
                    GLA = response.xpath(
                        '//div[@class="first one-half"]/ul/li[contains(text(),"GLA")]/text()').extract_first(
                        default='').strip()
                except Exception as e:
                    GLA = ''
                    print("GLA", e, response.url)

                if GLA == "":
                    try:
                        Description = ' '.join(response.xpath('//div[@class="first one-half"]/ul/li/text()').extract())
                        Description = Description.strip()
                    except Exception as e:
                        Description = ''
                        print("Description", e, response.url)
                else:
                    try:
                        l1 = []
                        divs = response.xpath('//div[@class="first one-half"]/ul/li')
                        for div in divs:
                            key = div.xpath('.//text()').extract_first()
                            if "GLA" in str(key):
                                key = ''
                            else:
                                key = key
                            l1.append(key)
                            Description = '|'.join(l1)
                            while Description.startswith("|"):
                                Description = Description[1:]
                            while Description.endswith("|"):
                                Description = Description[:-1]
                    except Exception as e:
                        Description = ''
                        print("Description", e, response.url)

                try:
                    Leasing_Contact_Name1 = response.xpath(
                        '//div[@class="property-details-item leasing-agent first one-third"]/text()').extract()
                    Leasing_Contact_Name = Leasing_Contact_Name1[0].strip()
                    Leasing_Contact_Phone = Leasing_Contact_Name1[1].strip()
                except Exception as e:
                    Leasing_Contact_Phone = ''
                    Leasing_Contact_Name = ''
                    print("Leasing_Contact_Name", e, response.url)

                try:
                    Leasing_Contact_Email = response.xpath(
                        '//div[@class="property-details-item leasing-agent first one-third"]/a/text()').extract_first(
                        default='').strip()
                except Exception as e:
                    print("Leasing_Contact_Email", e, response.url)

                try:
                    Property_Manager_Name1 = response.xpath(
                        '//div[@class="property-details-item property-manager one-third"]/text()').extract()
                    Property_Manager_Name = Property_Manager_Name1[0].strip()
                    Property_Manager_phone = Property_Manager_Name1[1].strip()
                except Exception as e:
                    Property_Manager_Name = ''
                    Property_Manager_phone = ''
                    print("Property_Manager_Name", e, response.url)

                try:
                    Property_Manager_Email = response.xpath(
                        '//div[@class="property-details-item property-manager one-third"]/a/text()').extract_first(
                        default='').strip()
                except Exception as e:
                    print("Property_Manager_Email", e, response.url)

                try:
                    Site_Plan_URL = response.xpath(
                        '//div[@class="entry-content"]/p//a[contains(text(),"Siteplan")]/@href').extract_first(
                        default='').strip()
                except Exception as e:
                    print("Site_Plan_URL", e, response.url)

                item = ProprtySitesItem()
                item['Property_Name'] = Property_Name
                item['Address'] = address
                item['City'] = city
                item['State'] = state
                item['Zip_Code'] = Zip
                item['Description'] = Description
                item['GLA'] = GLA
                item['Leasing_Contact_Name'] = Leasing_Contact_Name
                item['Leasing_Contact_Phone'] = Leasing_Contact_Phone
                item['Leasing_Contact_Email'] = Leasing_Contact_Email
                item['Property_Manager_Name'] = Property_Manager_Name
                item['Property_Manager_Phone'] = Property_Manager_phone
                item['Property_manager_email'] = Property_Manager_Email
                item['Site_Plan_URL'] = Site_Plan_URL
                item['Property_URL'] = response.url
            except Exception as e:
                print(e)

        except Exception as e:
            print(e)

# from scrapy.cmdline import execute
# execute('''scrapy crawl store_465 -a list_id=465 -a proxy_type='''.split())


