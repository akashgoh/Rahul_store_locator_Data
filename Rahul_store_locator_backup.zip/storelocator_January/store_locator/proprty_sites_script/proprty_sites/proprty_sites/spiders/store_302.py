# -*- coding: utf-8 -*-
import datetime
import re

import scrapy

from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func


class Store302Spider(scrapy.Spider):
    name = 'store_302'
    allowed_domains = []
    start_urls = ['https://example.com/']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)


    def parse(self, response):
        for i in range(0, 300, 20):
            link = 'https://www.acadiarealty.com/properties/search?ipquicksearch=1&start=' + str(i)
            yield scrapy.Request(url=link, callback=self.get_store_list)


    def get_store_list(self, response):
        links = response.xpath('//div[@class="span7 ip-overview-desc"]//a/@href').getall()
        for link in links:
            yield scrapy.Request(url='https://www.acadiarealty.com'+link, callback=self.parse_data)


    def parse_data(self, response):
        try:Property_Name = response.xpath('//meta[@property="og:title"]/@content').get(default='').strip()
        except Exception as e:print(e)

        address = response.xpath('//div[@class="pull-left"]/address/text()').getall()
        Address = address[0].strip()

        try:zip_code = re.findall(r'\d{5}', address[-1])[0].strip()
        except:zip_code = ''

        try:city = address[-1].split(',')[0].strip()
        except:city = ''

        state = address[-1].split(',')[-1].replace(zip_code,'').strip()
        state = state_name(state)

        try:Contact = response.xpath('//div[@class="ip-agent-details uk-margin-bottom"]/strong/text()').get(default='').strip()
        except Exception as e:print(e)

        try:
            phone = response.xpath('//div[@class="ip-agent-details uk-margin-bottom"]/text()').getall()
            Phone = re.findall(r'phone: (.*?) \S+', phone[-2])[0].strip()
        except:
            Phone = ''

        try:Email = response.xpath('//div[@class="ip-agent-details uk-margin-bottom"]/a/text()').get(default='').strip()
        except Exception as e:print(e)

        try:Metro_Area = response.xpath('//li[contains(text(),"Metro Area:")]/strong/text()').get(default='').strip()
        except Exception as e:print(e)

        try:Property_Type = response.xpath('//li[contains(text(),"Property Type: ")]/strong/text()').get(default='').strip()
        except Exception as e:print(e)

        try:Parking_Space = response.xpath('//li[contains(text(),"Parking Spaces:")]/strong/text()').get(default='').strip()
        except Exception as e:print(e)

        try:SF = response.xpath('//div[@class="ip-availablesqft pull-right"]/p/text()').get(default='').strip()
        except Exception as e:print(e)

        try:Available_Space = response.xpath('//li[contains(text(),"Available Space:")]/strong/text()').get(default='').strip()
        except Exception as e:print(e)

        try:
            site_plan_url = response.xpath('//div[@class="ip-siteplan"]//img/@src').get(default='').strip()
            if site_plan_url:
                site_plan_url = 'https://www.acadiarealty.com' + site_plan_url
            else:
                site_plan_url = ''
        except Exception as e:
            print(e)


        item = ProprtySitesItem()
        item['Property_Name'] = Property_Name
        item['Address'] = Address
        item['City'] = city
        item['State'] = state
        item['zip_code'] = zip_code
        item['Contact'] = Contact
        item['Phone'] = Phone
        item['Email'] = Email
        item['Metro_Area'] = Metro_Area
        item['Property_Type'] = Property_Type
        item['Parking_Space'] = Parking_Space
        item['SF'] = SF
        item['Available_Space'] = Available_Space
        item['Site_Plan_URL'] = site_plan_url
        item['URl'] = response.url
        yield item


def state_name(xyz):

    us_states_dict = {'alabama': 'AL', 'alaska': 'AK', 'arizona': 'AZ', 'arkansas': 'AR', 'california': 'CA',
                      'colorado': 'CO', 'connecticut': 'CT', 'delaware': 'DE', 'district of columbia': 'DC',
                      'florida': 'FL', 'georgia': 'GA', 'hawaii': 'HI', 'idaho': 'ID', 'illinois': 'IL',
                      'indiana': 'IN', 'iowa': 'IA', 'kansas': 'KS', 'kentucky': 'KY', 'louisiana': 'LA',
                      'maine': 'ME', 'maryland': 'MD', 'massachusetts': 'MA', 'michigan': 'MI', 'minnesota': 'MN',
                      'mississippi': 'MS', 'missouri': 'MO', 'montana': 'MT', 'nebraska': 'NE', 'nevada': 'NV',
                      'new hampshire': 'NH', 'new jersey': 'NJ', 'new mexico': 'NM', 'new york': 'NY',
                      'north carolina': 'NC', 'north dakota': 'ND', 'ohio': 'OH', 'oklahoma': 'OK', 'oregon': 'OR',
                      'pennsylvania': 'PA', 'rhode island': 'RI', 'south carolina': 'SC', 'south dakota': 'SD',
                      'tennessee': 'TN', 'texas': 'TX', 'utah': 'UT', 'vermont': 'VT', 'virginia': 'VA',
                      'washington': 'WA', 'west virginia': 'WV', 'wisconsin': 'WI', 'wyoming': 'WY', 'guam': 'GU',
                      'marshall islands': 'MH', 'micronesia': 'FM', 'northern marianas': 'MP', 'palau': 'PW',
                      'puerto rico': 'PR', 'virgin islands': 'VI'}
    temp = xyz
    Nomalise_text = temp.replace('US,','').replace('US','').replace('United States','').strip().strip(',').replace('-',',')
    Loc1 = Nomalise_text.split(',')
    all_state_list = list(us_states_dict.values())
    for each in Loc1:
        find_state = each.strip().lower()
        try:
            state = us_states_dict.get(find_state)    #                 # state = Utility.state_name(find_state)
            if find_state.upper() in all_state_list:
                Loc = xyz.strip(',').strip()
                return Loc

            elif state != None:
                Loc = Nomalise_text.replace(each, '').strip(',') + ', ' + state
                Loc = Loc.strip().strip(',')
                if Loc == ' NY' or Loc == 'City, NY':
                    Loc = Loc.replace('City, NY','NY')
                    Loc = Loc1[-1] + ', ' + Loc.strip()
                if 'NY' in Loc.split(',')[0]:
                    Loc = 'NY'
                if Loc == 'DC, WA' or Loc == 'WA, DC':
                    Loc = 'Washington, DC'
                return Loc.strip(',').strip()
        except Exception as e:
            print()

# from scrapy.cmdline import execute
# execute('''scrapy crawl store_302 -a list_id=302'''.split())
