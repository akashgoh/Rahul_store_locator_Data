#
# # -*- coding: utf-8 -*-
# import datetime
# from scrapy.http import HtmlResponse
# import scrapy, json, requests, re
# import html2text
# from proprty_sites.items import ProprtySitesItem
# from proprty_sites.spiders.common_functions import Func
#
# class Store306Spider(scrapy.Spider):
#     name = 'store_306'
#     allowed_domains = []
#
#     def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
#         super().__init__(name, **kwargs)
#         self.list_id, self.proxy_type = list_id, proxy_type
#         self.f1 = Func()
#         self.run_date = str(datetime.datetime.today()).split()[0]
#         self.table_name = self.f1.set_details(self.list_id, self.run_date)
#
#
#     def start_requests(self):
#         try:
#             source_url = link = f'https://properties.brixmor.com/cre/commercial-real-estate-listings-portfolio/'
#             file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
#                 self.run_date) + '.html'
#             yield scrapy.FormRequest(url=str(link), callback=self.firstlevel,
#                                      meta={'source_url': source_url, 'file_path': file_path,
#                                            'proxy_type': self.proxy_type})
#         except Exception as e:
#             print(e)
#
#     def firstlevel(self, response):
#         try:
#             source_url = response.meta['source_url']
#             file_path = response.meta['file_path']
#             proxy_type = response.meta['proxy_type']
#             divs = response.xpath('//a[@class="hoverBox"]/@href').extract()
#             for i in divs:
#                 url = i
#                 yield scrapy.FormRequest(url=url, callback=self.get_store_list,
#                                          meta={'source_url': source_url, 'file_path': file_path,
#                                                'proxy_type': proxy_type}, dont_filter=True)
#         except Exception as e:
#             print("firstlevel", e, response.url)
#
#     # Get data from the response
#     def get_store_list(self, response):
#         if not response.url.startswith('file://'):
#             self.f1.page_save(response.meta['file_path'], response.body)
#         try:
#             try:
#                 try:
#                     Property_Name = response.xpath('//div[@class="caption col-md-6"]/h1/text()').extract_first().strip()
#                 except Exception as e:
#                     print("Property_Name", e, response.url)
#
#                 try:
#                     Plan_URL1=response.xpath('//*[@class="jsviewer"]/@src').extract_first(default='').strip()
#                     if Plan_URL1!="":
#                         resp = requests.get(Plan_URL1)
#                         response1 = HtmlResponse(url=response.url, body=resp.text,encoding='utf8')
#                         Site_Plan_URL = re.findall(r'\\"mapPlanImg\\":\\"(.*?)\\",\\"mapPlanImg1\\":', response1.text, re.DOTALL)
#                         if len(Site_Plan_URL) == 1:
#                             Site_Plan_URL = Site_Plan_URL[0].replace('\\', '')
#                             # print(Site_Plan_URL)
#                         else:
#                             Site_Plan_URL=""
#                 except Exception as e:
#                     Site_Plan_URL=""
#
#
#                 try:
#                     address1 = response.xpath('//div[@class="caption col-md-6"]/p[1]/text()').extract()
#                     address = address1[0].strip(',')
#                     bunch = address1[1].strip()
#
#                     try:
#                         city = bunch.split(',')[0].strip()
#                     except Exception as e:
#                         city = ''
#
#                     bunch2 = bunch.split(',')[1].strip()
#                     try:
#                         state = bunch2.split(' ')[0].strip()
#                     except Exception as e:
#                         state = ''
#
#                     try:
#                         zip_code = bunch2.split(' ')[1].strip()
#                     except Exception as e:
#                         zip_code = ''
#
#                 except Exception as e:
#                     address1 = ''
#                     print("address1", e, response.url)
#
#                 try:
#                     Leasing = response.xpath(
#                         '//*[contains(text(),"Leasing Representative")]/../following-sibling::p/text()').extract_first(
#                         default='').strip()
#                 except Exception as e:
#                     print("Leasing", e, response.url)
#
#                 try:
#                     Leasing_Email = response.xpath(
#                         '//*[contains(text(),"Leasing Representative")]/../following-sibling::a[@class="email open-agent"]/@href').extract_first(
#                         default='').strip()
#                     Leasing_Email = Leasing_Email.replace('mailto:', '').replace('javascript:;', '')
#                     Leasing_Email = Leasing_Email.split('?subject=')[0].strip()
#                 except Exception as e:
#                     print("Leasing_Email", e, response.url)
#
#                 try:
#                     Leasing_Phone = response.xpath(
#                         '//*[contains(text(),"Leasing Representative")]/../following-sibling::a[@class="phone open-phone"]/text()').extract_first(
#                         default='').strip()
#                 except Exception as e:
#                     print("Leasing_Phone", e, response.url)
#
#                 try:
#                     Management = response.xpath(
#                         '//*[contains(text(),"Property Manager")]/../following-sibling::p/text()').extract_first(
#                         default='').strip()
#                 except Exception as e:
#                     print("Management", e, response.url)
#
#                 try:
#                     Management_Email = response.xpath(
#                         '//*[contains(text(),"Property Manager")]/../following-sibling::a[@class="email open-manager"]/@href').extract_first(
#                         default='').strip()
#                     Management_Email = Management_Email.replace('mailto:', '').replace('javascript:;', '')
#                     Management_Email = Management_Email.split('?subject=')[0].strip()
#                 except Exception as e:
#                     print("Management_Email", e, response.url)
#
#                 try:
#                     Management_Phone = response.xpath(
#                         '//*[contains(text(),"Property Manager")]/../following-sibling::a[@class="phone open-phone"]/text()').extract_first(
#                         default='').strip()
#                 except Exception as e:
#                     print("Management_Phone", e, response.url)
#
#                 try:
#                     Specialty_Leasing = response.xpath(
#                         '//*[contains(text(),"Specialty Leasing")]/../following-sibling::p/text()').extract_first(
#                         default='').strip()
#                 except Exception as e:
#                     print("Specialty_Leasing", e, response.url)
#
#                 try:
#                     Specialty_Leasing_Email = response.xpath(
#                         '//*[contains(text(),"Specialty Leasing")]/../following-sibling::a[@class="email open-agent"]/@href').extract_first(
#                         default='').strip()
#                     Specialty_Leasing_Email = Specialty_Leasing_Email.replace('mailto:', '').replace('javascript:;', '')
#                 except Exception as e:
#                     print("Specialty_Leasing_Email", e, response.url)
#
#                 try:
#                     Specialty_Leasing_Phone = response.xpath(
#                         '//*[contains(text(),"Specialty Leasing")]/../following-sibling::a[@class="phone open-phone"]/text()').extract_first(
#                         default='').strip()
#                 except Exception as e:
#                     print("Specialty_Leasing_Phone", e, response.url)
#
#                 try:
#                     County = response.xpath('//*[contains(text(),"County:")]/../text()').extract_first(
#                         default='').strip()
#                 except Exception as e:
#                     print("County", e, response.url)
#
#                 try:
#                     Total_SF = response.xpath('//*[contains(text(),"Total SF:")]/../text()').extract_first(
#                         default='').strip()
#                 except Exception as e:
#                     print("Total_SF", e, response.url)
#
#                 try:
#                     Metro_Area = response.xpath('//*[contains(text(),"Metro Area:")]/../text()').extract_first(
#                         default='').strip()
#                 except Exception as e:
#                     print("Metro_Area", e, response.url)
#
#                 item = ProprtySitesItem()
#                 item['Property_Name'] = Property_Name
#                 item['Address'] = address
#                 item['City'] = city
#                 item['State'] = state
#                 item['zip_code'] = zip_code
#                 item['Leasing'] = Leasing
#                 item['Leasing_Email'] = Leasing_Email
#                 item['Leasing_Phone'] = Leasing_Phone
#                 item['Management'] = Management
#                 item['Management_Email'] = Management_Email
#                 item['Management_Phone'] = Management_Phone
#                 item['Specialty_Leasing'] = Specialty_Leasing
#                 item['Specialty_Leasing_Email'] = Specialty_Leasing_Email
#                 item['Specialty_Leasing_Phone'] = Specialty_Leasing_Phone
#                 item['County'] = County
#                 item['Total_SF'] = Total_SF
#                 item['Metro_Area'] = Metro_Area
#                 item['Plan_URL'] = Site_Plan_URL
#                 item['URL'] = response.url
#                 yield item
#             except Exception as e:
#                 print(e)
#
#         except Exception as e:
#             print(e)
#
# # from scrapy.cmdline import execute
# # execute("scrapy crawl store_306 -a list_id=306".split())
#
#
#
#
#
#
#
#
