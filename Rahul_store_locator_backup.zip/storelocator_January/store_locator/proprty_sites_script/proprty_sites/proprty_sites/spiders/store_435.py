# -*- coding: utf-8 -*-
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
import html2text
h = html2text.HTML2Text()
import datetime
import scrapy, json, requests, re
import html2text
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func

class HawkinscompaniesSpider(scrapy.Spider):
    # name = 'hawkinscompanies'
    name = 'store_435'
    allowed_domains = []
    start_urls = ['https://www.hawkinscompanies.com/properties/page/2/']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def parse(self, response):
        links = response.xpath('//*[@class="listing-item"]//a/@href').extract()
        for link in links:
            yield scrapy.FormRequest(url=link,callback=self.extract,dont_filter=True)

    def extract(self,response):
        try:
            name = response.xpath('//h2/text()').extract_first(default='').strip()
            add_temp = response.xpath('//*[@class="address"]/text()').extract_first(default='').strip().split(',')
            temp = h.handle(response.xpath('//*[@class="description"]').get()).split('Property Description')[-1]
            try:desc =temp.split('Available')[0].strip().replace('###','')
            except:desc = ''
            l_name = response.xpath('//*[@class="person"][1]/*[@class="name"]/text()').extract_first(default='').strip()
            pm_name = response.xpath('//*[@class="person"][2]/*[@class="name"]/text()').extract_first(default='').strip()
            l_phone = response.xpath('//*[@class="person"][1]/*[@class="info"]/text()').extract_first(default='').split('|')[0].strip()
            pm_phone = response.xpath('//*[@class="person"][2]/*[@class="info"]/text()').extract_first(default='').split('|')[0].strip()
            l_email = response.xpath('//*[@class="person"][1]/*[@class="info"]/a/text()').extract_first(default='').strip()
            pm_email = response.xpath('//*[@class="person"][2]/*[@class="info"]/a/text()').extract_first(default='').strip()
            # site_plan_temp = response.xpath('//a[@class="photobox"]/@href').extract()
            # site_plan = [f"https://www.hawkinscompanies.com{i}" for i in site_plan_temp]

            site_plan_temp = response.xpath('//a[@class="photobox"]/@href').extract_first()
            site_plan = f"https://www.hawkinscompanies.com{site_plan_temp}"
            print(site_plan)


            item = ProprtySitesItem()

            item['Property_Name'] = name
            print(item['Property_Name'])
            try:item['Address'] = add_temp[0]
            except:item['Address'] = ''
            try:
                item['City'] = add_temp[1].strip()
                print(item['City'])
            except:item['City'] = ''
            try:item['State'] = add_temp[2]
            except:item['State'] = ''
            item['Description'] = desc
            item['Leasing_Contact'] = l_name
            item['Leasing_Phone'] = l_phone
            item['Leasing_Email'] = l_email
            item['Property_Manager_Name'] = pm_name
            item['Property_Manager_Phone'] = pm_phone
            item['Property_Managers'] = pm_email
            item['GLA'] = ''
            # item['Site_Plan_URL'] = ' | '.join(site_plan) if site_plan!=[] else ''
            item['Site_Plan_URL'] =  site_plan
            item['Property_URL'] = response.url
            yield item

        except Exception as e:
            print(e)

# execute("scrapy crawl store_435 -a list_id=435".split())
