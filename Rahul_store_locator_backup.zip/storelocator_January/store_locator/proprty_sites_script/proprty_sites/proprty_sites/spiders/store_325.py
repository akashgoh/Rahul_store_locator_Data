# -*- coding: utf-8 -*-
import datetime
import scrapy, json, requests, re
import html2text
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func

class store_325_Spider(scrapy.Spider):
    name = 'store_325'
    allowed_domains = ['www.example.com']
    start_urls = ['https://trademarkproperty.com/portfolio/']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def parse(self, response):
        try:
            links = response.xpath('//div[@class="col-sm-6"]/a/@href').extract()
            for link in links:
                yield scrapy.FormRequest(url=link, callback=self.firstlevel, dont_filter=True)
        except Exception as e:
            print("parse:------> ", e, response.url)

    def firstlevel(self, response):
            item = ProprtySitesItem()
            try:
                Property_Name = response.xpath('//h1[@class="headline"]/text()').extract_first().strip()
                item['property_name'] = Property_Name
            except Exception as e:
                print("Property_Name", e, response.url)

            try:
                fullAddress = response.xpath('//div[@class="row"]/div/h3/text()').getall()
                if len(fullAddress) == 3:
                    Address = fullAddress[1]
                    City = fullAddress[-1].split(',')[0]
                    State = fullAddress[-1].split()[-2]
                    zip_code = fullAddress[-1].split()[-1]
                    item['address'] = Address
                    item['city'] = City
                    item['state'] = State
                    item['zip_code'] = zip_code
            except Exception as e:
                print("Address: ",e)
            try:
                Leasing_Names = "|".join(response.xpath('//*[contains(text(),"Leasing")]/../div/h5/text()').extract())
                Leasing_Phones = "|".join(response.xpath('//*[contains(text(),"Leasing")]/../div/p[2]/a/text()').extract())
                item['Leasing_Name'] = Leasing_Names
                item['Leasing_Phone'] = Leasing_Phones
            except Exception as e:
                print("leasing",e)
            try:
                Manager_Names = "|".join(response.xpath('//*[contains(text(),"Management")]/../div/h5/text()').extract())
                Manager_Phones = "|".join(response.xpath('//*[contains(text(),"Management")]/../div/p[2]/a/text()').extract())
                item['Manager_Name'] = Manager_Names
                item['Manager_Phone'] = Manager_Phones
            except Exception as e:
                print("Manager: ",e)
            try:
                site_plan = response.xpath('//div[@class="downloads"]/a/@href').get()
                print(site_plan)
                if '#contact-form' not in site_plan:
                    item['site_plan'] = site_plan
            except Exception as e:
                print("site plan: ",e)
            try:
                website = response.xpath('//*[@class="row"]/div//a/@href').get()
                if '.pdf' not in website:
                    item['website'] = website
            except Exception as e:
                print("website: ",e)

            item['propertyURL'] = response.url
            print(item)
            yield item


if __name__ == '__main__':
    from scrapy.cmdline import execute
    execute('''scrapy crawl store_325 -a list_id=325'''.split())