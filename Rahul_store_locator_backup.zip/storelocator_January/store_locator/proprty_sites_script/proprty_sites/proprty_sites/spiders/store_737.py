# -*- coding: utf-8 -*-
import datetime
import scrapy, json, requests, re
import html2text
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func


class store_737_Spider(scrapy.Spider):
    name = 'store_737'
    allowed_domains = ['']
    start_urls = ['https://www.lbxinvestments.com/portfolio']


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        url = 'https://www.lbxinvestments.com/portfolio'
        yield scrapy.FormRequest(url=url, callback=self.parse1)

    def parse1(self, response):
        links = response.xpath('//*[@class="col sqs-col-4 span-4"]/div/div/div//a/@href').extract()
        for link in links:
            link = 'https://www.lbxinvestments.com' + link
            yield scrapy.FormRequest(url=link, dont_filter=True, callback=self.parse2)

    def parse2(self, response):
        try:
            # property_name = response.xpath('//div[@class="sqs-block-content"]//strong/text()').get()
            property_name = str(re.findall(r'<b data-preserve-html-node="true">(.*?)</b>',response.text,re.DOTALL))
        except Exception as e:
            print(e)
            property_name = ''

        try:
            address = str(re.findall(r'style="font-size: 16pt;">(.*?)</span>',response.text,re.DOTALL))
            property_address = address.split(',')[0]
        except Exception as e:
            print(e)
            property_address = ''

        try:
            city = address.split(',')[-2]
        except Exception as e:
            print(e)
            city = ''

        try:
            add1 = address.split(',')[-1]
        except Exception as e:
            print(e)
            add1 = ''

        try:
            state = add1.split(' ')[-2].strip()
        except Exception as e:
            print(e)
            state = ''

        try:
            zip = add1.split(' ')[-1]
        except Exception as e:
            print(e)
            zip = ''

        # n = str(re.findall(r'<h2 data-preserve-html-node="true">(.*?)</h2>(.*?)<br data-preserve-html-node="true">',
        #                    response.text, re.DOTALL))
        # n = "".join(n)
        # n = n.split(" in")[1].replace("\n", "").strip()
        # try:
        #     city = n.split(",")[0]
        # except Exception as e:
        #     print(e)
        #     city = ''
        # try:
        #     state = n.split(",")[1].replace("')]", "").replace("\\n", "").strip()
        # except Exception as e:
        #     print(e)
        #     state = ''

        try:
            description = str(re.findall(r': </strong>(.*?)</p>',response.text,re.DOTALL))
            if description == '':
                description = ','.join(response.xpath('//div[@class="col sqs-col-2 span-2"]/../div[2]/div[2]/div/div//text()').extract())
            elif description == '' :
                description = ','.join(response.xpath('//div[@class="sqs-block markdown-block sqs-block-markdown"]/div/div//text()').extract())
        except Exception as e:
            print(e)
            description = ''

        try:
            gla = re.findall(r'<tbody data-preserve-html-node="true">(.*?)</tbody>',response.text,re.DOTALL)[0].replace(',','')
            # gla = "".join(gla)
            gla = "".join(re.findall(r'(\d+) SF',gla))

            # gla = re.findall(r'(\d+)',gla,re.DOTALL)
            gla = "".join(gla)
            print(gla)

        except Exception as e:
            print(e)
            gla = ''

        try:
            site_plan = response.xpath('//img[contains(@src,"Site")]/@src').extract_first()
        except Exception as e:
            print(e)
            site_plan = ''

        lks = ''.join(response.url)

        item = ProprtySitesItem()
        item['property_name'] = property_name
        item['property_address'] = property_address
        item['city'] = city
        item['state'] = state
        item['zip'] = zip
        item['description'] = description
        item['site_plan'] = site_plan
        item['gla'] = gla

        item['lks'] = lks
        yield item

# property_name,property_address,city,state,zip,description,site_plan,gla,lks


from scrapy.cmdline import execute
# execute("scrapy crawl store_737 -a list_id=737".split())