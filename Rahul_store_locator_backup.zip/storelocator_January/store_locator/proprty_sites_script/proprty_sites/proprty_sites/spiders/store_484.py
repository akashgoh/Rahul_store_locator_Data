# -*- coding: utf-8 -*-
# -*- coding: utf-8 -*-
import datetime
import scrapy, json, requests, re
import html2text
from scrapy.utils.response import open_in_browser

from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func

class RcgventuresSpider(scrapy.Spider):
    name = 'store_484'
    # name = 'rcgventures'
    allowed_domains = []
    start_urls = ['http://rcgventures.com/properties/']
    # custom_settings = {
    #     "FEED_EXPORT_FIELDS": ["Property Name", "Address", "City", "State", "Zip", "GLA", "Description", "Leasing Contact Name", "Leasing Contact Phone", "Leasing Contact Email", "Site Plan URL", "Property URL"]
    # }
    not_export_data = False

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    # def parse(self, response):
    #     # for url in response.xpath('//*[@class="mix mix_all"]//@href').getall():
    #
    #     for url in response.xpath('//h4[@itemprop="name"]/../@href').getall():
    #         yield scrapy.Request(
    #             url=url,
    #             callback=self.process_property
    #         )
    #
    # def process_property(self, response):
    #
    #     address = response.xpath('//*[@class="property-title"]/h4/text()').get('').split(',')
    #     print(address)
    #     email = response.xpath('//*[@data-enc-email]//text()').getall()
    #     email = "".join([email[k] for k in range(len(email)) if not k % 2])
    #     agent_details = response.xpath('//*[text()="Contact:"]/parent::li//text()').getall()
    #
    #     item = ProprtySitesItem()
    #     item["Property_Name"] = response.xpath('//*[@class="property-title"]/h1/text()').get('')
    #     print(item["Property_Name"])
    #     item["Address"] = address[0].strip()
    #     item["City"] = address[1].strip()
    #
    #     try:
    #         item["State"] = address[2].strip().split()[0].strip()
    #         item["Zip"] = address[2].strip().split()[1].strip()
    #     except:
    #         try:
    #             item["State"] = address[3].strip()
    #             item["Zip"] = address[4].strip()
    #         except:
    #             item["Address"] = ""
    #             item["City"] = address[0].strip()
    #             item["State"] = address[1].strip().split()[0].strip()
    #             item["Zip"] = address[1].strip().split()[1].strip()
    #
    #     item["GLA"] = response.xpath('//*[text()="Total SF:"]/following-sibling::text()').get('')
    #     item["Description"] = "".join(response.xpath('//article//p[@style="text-align: justify;"]//text()').getall())
    #     item["Leasing_Contact_Name"] = agent_details[1].strip()
    #     item["Leasing_Contact_Phone"] = agent_details[-1].strip()
    #     # item["Leasing Contact Email"] = ''.join(reversed(email))
    #     item["Site_Plan_URL"] = response.xpath('//*[contains(@href, "SitePlan")]/@href').get('')
    #     item["Property_URL"] = response.url
    #     # print(item)
    #     yield item


#------------------------------------- NEw CODE 18-11-2020 ---------------------------------------------------------------------------#


    def start_requests(self):
        # yield scrapy.Request(url='file:///D:/nishant/properties.html', callback=self.parse)
        yield scrapy.Request(url='http://rcgventures.com/properties/', callback=self.parse)

    def parse(self, response):
            urls = re.findall(r"'url':'(.*?)'",response.text)
            for url in urls:
                url = url
                if url != '':
                    url = 'http://rcgventures.com/' + str(url)
                    url = url.replace("/../","/")
                    print(url)
                    yield scrapy.Request(url=url,callback=self.parse2,dont_filter=True)

    def parse2(self,response):
        links =  response.xpath('//h4[@itemprop="name"]/../@href').getall()
        for link in links:
            link = link
            yield  scrapy.FormRequest(url=link,callback=self.process_property,dont_filter=True)


        #-------------manual checkimng --------------------#

        # link = 'http://rcgventures.com/properties/240-penn-park/'
        # yield scrapy.FormRequest(url=link, callback=self.process_property, dont_filter=True)


    def process_property(self, response):
        address = response.xpath("//*[contains(text(),'Address')]/../text()").get('').split(',')
        # print(address)

        if len(address) == 2:
            Address = address[0].strip()
            city = ''
            state = address[1].strip().split()[0].strip()
            zip = address[1].strip().split()[1].strip()
        else:
            Address = address[0].strip()
            city = address[1].strip()
            state = address[2].strip().split()[0].strip()
            try:
                zip = address[2].strip().split()[1].strip()
            except Exception as e:
                print(e)
                zip = address[3].strip()


        email = response.xpath("//*[contains(@href,'mail')]/text()").get()
        # print(email)

        GLA = response.xpath('//*[text()="Total Square Feet"]/following-sibling::text()').get('')
        Description = response.xpath('//div[@class="et_pb_module_inner"]/p/text()').extract_first()
        Leasing_Contact_Name = response.xpath("//*[contains(text(),'CONTACT')]/../text()[1]").get()
        Leasing_Contact_Phone = response.xpath("//*[contains(@href,'tel')]/text()").get()
        Leasing_Contact_Email = email
        site_plan_url = response.xpath("//*[contains(text(),'Site Plan')]/@href").get('')

        item = ProprtySitesItem()
        # item["Property_Name"] = response.xpath('//*[@class="property-title"]/h1/text()').get('')
        item["Property_Name"] = response.xpath('//div[@class="et_pb_module_inner"]/h1/text()').get('')
        item["Address"] = Address
        item["City"] = city
        item["State"] = state
        item["Zip"] = zip


        item["GLA"] = GLA
        item["Description"] = Description
        item["Leasing_Contact_Name"] = Leasing_Contact_Name
        item["Leasing_Contact_Phone"] = Leasing_Contact_Phone
        item["Leasing_Contact_Email"] = Leasing_Contact_Email
        item["Site_Plan_URL"] = site_plan_url
        item["Property_URL"] = response.url
        # print(item)
        yield item
#

from scrapy.cmdline import execute
# execute("scrapy crawl store_484 -a list_id=484".split())
