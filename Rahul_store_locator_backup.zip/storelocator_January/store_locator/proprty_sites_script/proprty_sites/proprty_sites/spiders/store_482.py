# -*- coding: utf-8 -*-
# import datetime
#
# import scrapy
# from scrapy.cmdline import execute
import logging
import os
import re

import datetime
import scrapy, json, requests, re
import html2text
from scrapy.cmdline import execute

from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func




class Store482Spider(scrapy.Spider):
    name = 'store_482'
    allowed_domains = []

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)
    # start_urls = ['https://www.preppg.com/properties/']
    # custom_settings = {
    #     'FEED_EXPORT_FIELDS': ["Property_Name", "Address", "City", "State", "Zip", "Description",
    #                            "Leasing_Contact_Name", "Leasing_Contact_Phone", "Property_Manager_Name",
    #                            "Property_manager_phone", "Property_URL"],
    # }
    def start_requests(self):
        try:
            # if self.f1.search_by != 'link':
            #     search_terms = self.f1.get_search_term(self.f1.search_by)
            #     print(search_terms)
            #     for search_term in (search_terms):
            #         source_url = link = 'https://www.risepartners.net/portfolio'
            #         file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(search_term) + '_' + str(self.run_date) + '.html'
            #         if os.path.exists(file_path):
            #             link = 'file://' + file_path.replace('\\','/')
            #
            #         header = {
            #                 "Upgrade-Insecure-Requests": "1",
            #                 "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36",
            #                 "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
            #                 "Sec-Fetch-Site": "none",
            #                 "Sec-Fetch-Mode": "navigate",
            #                 "Sec-Fetch-User": "?1",
            #                 "Sec-Fetch-Dest": "document"}
            #         yield scrapy.FormRequest(url=str(link), callback=self.property_links, meta={'source_url': source_url,'search_term': search_term,'file_path':file_path}, headers=header)
            # else:
            source_url = link = 'https://www.preppg.com/properties/'
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(self.run_date) + '.html'
            yield scrapy.FormRequest(url=str(link), callback=self.parse,meta={'source_url': source_url,'file_path': file_path})

        except Exception as e:
            logging.log(logging.ERROR, e)

    def parse(self, response):
        for property_link in response.xpath('//*[contains(@href, "/property/")]/@href').getall():
            yield scrapy.Request(url=property_link,callback=self.process_property)

    def process_property(self, response):
        item = ProprtySitesItem()
        item['Property_Name'] = response.xpath('//*[@class="hr"]/text()').get()
        try:
            address = response.xpath('//*[contains(@class, "address")]//text()').get().split(",")
            item['Address'] = address[0].strip()
            item['City'] = address[1].strip()
            State = address[-1].strip()
            if len(State) > 2:
                item['State'] = address[-1].split(' ')[1].strip()
                item['Zip'] = address[-1].split(' ')[-1].strip()
            else:
                item['State'] = address[-1].split(' ')[1].strip()
                item['Zip'] = ""
        except:
            address = ""
            item['Address'] = ""
            item['City'] = ""
            item['State'] = ""
            item['Zip'] = ""
        # try:
        #     address = response.xpath('//*[contains(@class, "address")]//text()').get().split(",")
        #     item['Address'] = address[0].strip()
        #     item['City'] = address[1].strip()
        #     item['State'] = address[2].strip()
        # except:
        #     address = []
        #     item['Address'] = ""
        #     item['City'] = ""
        #     item['State'] = ""
        # item['Property_Name'] = response.xpath('//*[@class="hr"]/text()').get()
        # item['Zip'] = ""
        # state = item['State'].split(" ", 2)
        # if len(state) > 1:
        #     item['Zip'] = state[-1]
        #     item['State'] = item['State'].replace(item['Zip'], "").strip()

        item['Description'] = "".join(
            [i.strip() for i in response.xpath('//*[@class="large-12 medium-12 columns"]//p//text()').getall() if
             i.strip() != ""])
        item['Leasing_Contact_Name'] = response.xpath('//*[@class="property-contacts"]/div/div[1]/p[1]/text()').get()
        item['Leasing_Contact_Phone'] = response.xpath(
            '//*[@class="property-contacts"]/div/div[1]/p[3]/text()').get().replace("Office", "").strip()
        item['Property_Manager_Name'] = response.xpath('//*[@class="property-contacts"]/div/div[2]/p[1]/text()').get()
        item['Property_manager_phone'] = response.xpath('//*[@class="property-contacts"]/div/div[2]/p[3]/text()').get().replace("Office", "").strip()
        item['Property_URL'] = response.url
        yield item


# name = "prep_property_group"
today = datetime.datetime.now().strftime("%m-%d-%Y")
# execute('''scrapy crawl store_482 -a list_id=482'''.split())


# class PreppgPropertyItem(scrapy.Item):
#     Property_Name = scrapy.Field()
#     Address = scrapy.Field()
#     City = scrapy.Field()
#     State = scrapy.Field()
#     Zip = scrapy.Field()
#     Description = scrapy.Field()
#     Leasing_Contact_Name = scrapy.Field()
#     Leasing_Contact_Phone = scrapy.Field()
#     Property_Manager_Name = scrapy.Field()
#     Property_manager_phone = scrapy.Field()
#     Property_URL = scrapy.Field()