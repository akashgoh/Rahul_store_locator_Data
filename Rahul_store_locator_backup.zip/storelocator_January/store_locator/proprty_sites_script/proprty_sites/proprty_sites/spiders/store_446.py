# -*- coding: utf-8 -*-
import datetime
import json

import html2text
import requests
import scrapy
from scrapy.http import HtmlResponse
from scrapy.utils.response import open_in_browser

from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func


class Store446Spider(scrapy.Spider):
    name = 'store_446'
    allowed_domains = []
    start_urls = ['https://www.olshanproperties.com/wp-content/themes/olshan/json/properties.1608136660.json']
    not_export_data = True

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def parse(self, response):
        json_data = json.loads(response.text)
        for i in range(0, 50):
            try:
                try:property_name = json_data[i]['name']
                except:property_name = ''

                try:address = json_data[i]['location']['address']
                except:address = ''

                try:city = json_data[i]['location']['city']
                except:city = ''

                try:state = json_data[i]['property-state'][0]['slug'].upper()
                except:state = ''

                try:zipcode = json_data[i]['location']['zip']
                except:zipcode = ''
                property_url = 'https://' + json_data[i]['sharplaunch']['url']
                # property_url='https://www.olshanproperties.com/properties/offices-at-the-greene-town-center/'https://1443035thavenue.sharplaunch.com/
                res = requests.get(property_url)
                # response = HtmlResponse(url='xyz.com', body=res.content)
                print(res)
                if '200' in str(res):
                    response1 = HtmlResponse(url=res.url, body=res.content)
                    # open_in_browser(response1)
                    try:
                        description = ','.join(response1.xpath('//*[@class="building"]//div[@class="text-center"]/div[1]//text()').extract()).strip()
                        print(description)
                        # description = text.handle(description)
                    except Exception as e:
                        print(e)

                    try:
                        leasing_contact = '|'.join(response1.xpath('//*[@class="team-member__name px-sub-head-3"]//text()').getall())
                        print(leasing_contact)
                    except Exception as e:print(e)

                    try:
                        Leasing_phone = []
                        leasing_phone = response1.xpath('//*[@class="team-member__phone px-body-1"]//text()').getall()
                        if leasing_phone != []:
                            for phone in leasing_phone:
                                phone = phone.strip()
                                if phone != '':
                                    Leasing_phone.append(phone)
                                else:
                                    Leasing_phone=''
                        else:
                            Leasing_phone=''
                            print(Leasing_phone)
                    except Exception as e:
                        print(e)

                    try:
                        leasing_email = ''.join(response1.xpath('//*[@class="team-member__email px-body-1"]//text()').getall())
                        print(leasing_email)
                    except Exception as e:print(e)

                    try:
                        site_plan_url = response1.xpath('//*[contains(text(),"Site Plan")]/..//@href').get(default='').strip()
                        print(site_plan_url)
                    except Exception as e:print(e)

                    try:
                        brochure_url = response1.xpath('//*[contains(text(),"Brochure")]/../a/@href').get(default='').strip()
                        print(brochure_url)
                    except Exception as e:print(e)
                    try:
                        Amenities = ','.join(response1.xpath('//*[contains(text(),"Amenities")]/../div[2]/div/div/div/text()').extract()).replace("• ","").strip()
                    except Exception as e:
                        print(e)
                    # a = response1.xpath('//*[@class="hero-container"]/h1/text()').extract_first()

                else:
                    description = ''
                    leasing_contact = ''
                    Leasing_phone = ''
                    leasing_email = ''
                    site_plan_url = ''
                    brochure_url = ''


                item = ProprtySitesItem()
                item['Property_Name'] = property_name
                item['Address'] = address
                item['City'] = city
                item['State'] = state
                item['ZipCode'] = zipcode
                item['Description'] = description
                item['Leasing_Contact_Name'] = leasing_contact
                item['Leasing_Contact_Phone'] = '|'.join(Leasing_phone)
                item['Leasing_Contact_Email'] = leasing_email
                item['Site_Plan_URL'] = site_plan_url
                item['Property_URL'] = json_data[i]['url']
                item['Brochure_URL'] = brochure_url
                item['url'] = json_data[i]['url']
                item['Amenities'] = Amenities
                if property_name != '':
                    yield item
                        # print(item)
            except Exception as e:
                print(e)

# Property_Name,Address,City,State,ZipCode,Description,Leasing_Contact_Name,Leasing_Contact_Phone,Leasing_Contact_Email,Site_Plan_URL,Property_URL,Brochure_URL,url
from scrapy.cmdline import execute
execute('scrapy crawl store_446 -a list_id=446'.split())
