# -*- coding: utf-8 -*-
import datetime
import logging

import scrapy, re, json, requests
from scrapy.http import HtmlResponse
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func


class Store433Spider(scrapy.Spider):
    name = 'store_433'
    allowed_domains = []
    # start_urls = ['https://www.gk-re.com/projects']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        try:
            # if self.f1.search_by != 'link':
            #     search_terms = self.f1.get_search_term(self.f1.search_by)
            #     print(search_terms)
            #     for search_term in (search_terms):
            #         source_url = link = 'https://www.risepartners.net/portfolio'
            #         file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(search_term) + '_' + str(self.run_date) + '.html'
            #         if os.path.exists(file_path):
            #             link = 'file://' + file_path.replace('\\','/')
            #
            #         header = {
            #                 "Upgrade-Insecure-Requests": "1",
            #                 "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36",
            #                 "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
            #                 "Sec-Fetch-Site": "none",
            #                 "Sec-Fetch-Mode": "navigate",
            #                 "Sec-Fetch-User": "?1",
            #                 "Sec-Fetch-Dest": "document"}
            #         yield scrapy.FormRequest(url=str(link), callback=self.property_links, meta={'source_url': source_url,'search_term': search_term,'file_path':file_path}, headers=header)
            # else:
            source_url = link = 'https://www.gk-re.com/properties'
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(self.run_date) + '.html'
            yield scrapy.FormRequest(url=str(link), callback=self.parse,meta={'source_url': source_url,'file_path': file_path})
        #
        except Exception as e:
            logging.log(logging.ERROR, e)


    def parse(self, response):
        try:
            data = response.xpath('//a[@class="img-card__link"]/@href').extract()
            for lp in data:
                res = requests.get(lp)
                response = HtmlResponse(url=res.url, body=res.content)

                name = response.xpath('//h1/text()').extract_first(default='').strip()
                address = response.xpath('//p[@class="lead"]/text()').extract_first(default='').strip().split(',')
                desc = response.xpath('//p[@class="lead"]/following::p[1]/text()').extract_first(default='').strip()
                gla = response.xpath('//*[contains(text(),"GLA")]/following::*[1]/text()').extract_first(default='').strip()
                l_name = response.xpath('//h3[contains(text(),"Leasing Contact")]/following::p[1]/text()').extract_first(default='').strip()
                l_phone = response.xpath('//h3[contains(text(),"Leasing Contact")]//following::a[contains(@href,"tel")][1]/text()').extract_first(default='').strip()
                l_mail = response.xpath('//h3[contains(text(),"Leasing Contact")]//following::a[contains(@href,"mailto")][1]/text()').extract_first(default='').strip()

                item = ProprtySitesItem()
                item['Property_Name'] = name
                try:item['Address'] = address[0].strip()
                except:item['Address'] = ''
                try:item['City'] = address[1].strip()
                except:item['Address'] = ''
                try:item['State'] = address[2].strip()
                except:item['Address'] = ''
                item['Description'] = desc
                item['GLA'] = gla
                item['Leasing_Contact'] = l_name
                item['Leasing_Phone'] = l_phone
                item['Leasing_Email'] = l_mail
                item['Property_URL'] = response.url
                yield item

        except Exception as e:
            print(e)


from scrapy.cmdline import execute
# execute("scrapy crawl store_433 -a list_id=433".split())

