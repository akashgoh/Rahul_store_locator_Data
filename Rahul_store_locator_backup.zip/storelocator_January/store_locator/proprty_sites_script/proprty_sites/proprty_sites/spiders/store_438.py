# -*- coding: utf-8 -*-
# -*- coding: utf-8 -*-
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
import html2text
h = html2text.HTML2Text()
import datetime
import scrapy, json, requests, re
import html2text
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func

class JbgsmithSpider(scrapy.Spider):
    # name = 'kprcenters'
    name = 'store_438'
    allowed_domains = []
    start_urls = ['http://kprcenters.propertycapsule.com/property/output/find/search']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)
        print(self.table_name)

    def parse(self, response):
        try:
           links = response.xpath('//a[@class="property-detail"]/@href').extract()
           for link in links:
               yield scrapy.FormRequest(url=link,callback=self.extract,dont_filter=True)
        except Exception as e:
            print(e)

    def extract(self,response):
        try:
            try:
                js1 = re.findall('window.property =(.*);',response.text)[0]
                df1 = json.loads(js1)
                try:
                    name = df1['name']
                    print(name)
                except Exception as e:
                    name=''
                try:
                    address = df1['address']
                    print(address)
                except Exception as e:
                    address=''
                try:
                    city = df1['city']
                except Exception as e:
                    city=''
                try:
                    state = df1['state']
                    print(state)
                except Exception as e:
                    state=''
                try:
                    zipcode = df1['zip']
                    print(zipcode)
                except Exception as e:
                    zipcode=''

                try:
                    desc = h.handle(df1['overview']).strip()
                    print(desc)
                except Exception as e:
                    desc=''
                try:
                    parking = df1['parking']
                except Exception as e:
                    parking=''
                try:
                    gla = df1['gla']
                    print(gla)
                except Exception as e:
                    gla=''
            except Exception as e:
                print(e)
            try:
                js2 = re.findall('window.agents =(.*?);',response.text)[0]
                df2 = json.loads(js2)
                try:
                    l_name = df2[1]['name']
                    print(l_name)
                except Exception as e:
                    l_name=''
                try:
                    l_phone = df2[1]['phone']
                    print(l_phone)
                except Exception as e:
                    l_phone=''
                try:
                    l_email = df2[1]['email']
                    print(l_email)
                except Exception as e:
                    l_email=''
            except Exception as e:
                print(e)

            try:
                site_plan = '|'.join(re.findall('src\="(http://kprcenters.propertycapsule.com/property/capsule_data/.*?)"',response.text)) if re.findall('src\="(http://kprcenters.propertycapsule.com/property/capsule_data/.*?)"',response.text) != [] else ''
                print(site_plan)
            except:
                site_plan=''

            item = ProprtySitesItem()
            item['Property_Name'] = name
            item['Address'] = address
            item['City'] = city
            item['State'] = state
            item['Zip_code'] = zipcode
            item['Description'] = desc
            item['Parking_Spaces'] = parking
            item['GLA'] = gla
            item['Leasing_Contact'] = l_name
            item['Leasing_Phone'] = l_phone
            item['Leasing_Email'] = l_email
            item['Site_Plan_URL'] = site_plan
            item['Property_URL'] = response.url
            yield item
        except Exception as e:
            print(e)
# Property Name,Address,City,State,Zip Code,Description,Parking Spaces,GLA,Leasing Contact,Leasing Phone,Leasing Email,Site Plan URL,Property URL

# execute("scrapy crawl store_438  -a list_id=438".split())
