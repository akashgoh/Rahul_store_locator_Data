# -*- coding: utf-8 -*-
import scrapy
import os
from scrapy.cmdline import execute
import  hashlib
import datetime
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func


class DataSpider(scrapy.Spider):
    name = 'store_322'
    allowed_domains = []
    start_urls = []

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)


    def start_requests(self):
        headers = {
                    'Host': 'www.seritage.com',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:72.0) Gecko/20100101 Firefox/72.0',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                    'Accept-Language': 'en-GB,en;q=0.5',
                    'Accept-Encoding': 'gzip, deflate, br'}

        yield scrapy.FormRequest(url='https://www.seritage.com/properties', callback=self.parse, headers=headers)

    def parse(self, response):
        pro_links = response.xpath('//*[@class="row searchable-location"]//a/@href').extract()
        for link in pro_links:
            yield scrapy.FormRequest(url=f"https://www.seritage.com{link}", callback=self.extract,dont_filter=True)

    def extract(self,response):
        try:
            title = response.xpath('//h1/text()').extract_first(default='').strip()
            add = response.xpath('//*[@id="map"]/@data-address').extract_first(default='').strip()
            city = response.xpath('//*[@id="map"]/@data-city').extract_first(default='').strip()
            try:
                temp = response.xpath('//h2/text()[2]').extract_first(default='').split(',')[-1].strip()
                state = temp.split(' ')[0].strip()
                zip = temp.split(' ')[-1].strip()
            except:
                state = zip =''
            total_sf = response.xpath('//*[@class="sqft"]/text()').extract_first(default='').strip().replace(',','')
            loop = response.xpath('//h4[contains(text(),"Anchors at Mall")]/following::ul//li/text()').extract()
            if loop!=[]:
                try:Anchor_1=loop[0].strip()
                except:Anchor_1=''
                try:Anchor_2=loop[1].strip()
                except:Anchor_2=''
                try:Anchor_3=loop[2].strip()
                except:Anchor_3=''
            else:
                Anchor_1 = Anchor_2 = Anchor_3 =''

            Plan_url = response.xpath('//div[@id="siteplan-modal"]//img/@src').extract_first(default='').strip()

            item = ProprtySitesItem()
            item['Property_Name'] = title
            item['Address'] = add
            item['City'] = city
            item['State'] = state
            item['zip_code'] = zip
            item['Total_SF'] = total_sf
            item['Anchor_1'] = Anchor_1
            item['Anchor_2'] = Anchor_2
            item['Anchor_3'] = Anchor_3
            item['GLA'] = total_sf
            item['Plan_url'] = Plan_url
            item['URL'] = response.url

            yield item
        except Exception as e:
            print(e)


# execute("scrapy crawl store_322 -a list_id=322".split())