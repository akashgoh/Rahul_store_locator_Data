# -*- coding: utf-8 -*-
import datetime
import scrapy, json, requests, re
import html2text
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func

h = html2text.HTML2Text()


class SandordevCrawlerSpider(scrapy.Spider):
    name = 'store_455'
    allowed_domains = ['www.example.com']
    start_urls = ['https://www.sandordev.com/properties/results?showall=1/']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)
    def parse(self, response):
        divs= response.xpath('//table[@id="PropertySearchResults"]/tbody/tr')
        for div in divs:
            url = div.xpath('./@onclick').extract_first().replace('location.href=','').replace("'",'')

            st = div.xpath('.//*[@class="state"]/text()').extract_first().strip()
            # del st[0]
            city = div.xpath('.//*[@class="city"]/text()').extract_first().strip()
            # del city[0]
            yield scrapy.Request(url='https://www.sandordev.com' + str(url), callback=self.parseData2,
                                 dont_filter=True, meta={'st': st, 'city': city})

    def parseData2(self, response):
        item = ProprtySitesItem()

        text = html2text.HTML2Text()
        text.ignore_images = True
        text.ignore_links = True
        text.ignore_emphasis = True
        text.body_width = 0
        text.ignore_tables = True

        a = response.text.split('var properties = ')[1].split('}],')[0]
        data = a + '}]'
        lst = json.loads(str(data))

        # a =
        item['Property_Name'] = lst[0]['name']

        #     state = ''
        #     zipc = ''

        item['Address'] = lst[0]['street_address']
        item['City'] = response.meta['city'].strip()
        item['State'] = response.meta['st'].strip()
        item['Zip'] = lst[0]['zip']
        item['GLA'] = ''

        # dscr = response.xpath("//*[contains(text(),'key features')]/../parent::div/ul").get()
        # description = text.handle(dscr)
        # description = Utility.Beautifier(description).strip()

        item['Description'] = re.sub(r'\s+', ' ', ''.join(
            response.xpath("//*[contains(text(),'key features')]/../parent::div/ul//text()").getall()).strip())
        item['Site_Plan_URL'] = ''.join(response.xpath('//*[@id="SitePlan"]/img/@src').extract())
        item['Property_URL'] = response.url

        item['Leasing_Contact_Name'] = ''.join(
            re.findall(r'p class="name"><em>(.*?)</p', response.text)[0]).strip()
        item['Leasing_Contact_Phone'] = ''.join(
            re.findall(r'<p class="phone">(.*?)</p>', response.text)[0]).strip()
        item['Leasing_Contact_Email'] = ''.join(
            re.findall(r'"><a href="mailto:(.*?)">', response.text)[0]).strip()

        yield item



# from scrapy.cmdline import execute
# execute("scrapy crawl store_455 -a list_id=455".split())