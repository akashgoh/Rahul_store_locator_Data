# -*- coding: utf-8 -*-
import datetime
import scrapy, json, requests, re
import html2text
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func


class store_706_Spider(scrapy.Spider):
    name = 'store_706'
    allowed_domains = ['http://greenwayinvestment.com']
    start_urls = ['http://greenwayinvestment.com/Properties/PropertyList.php?D=All']


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        url = 'http://greenwayinvestment.com/Properties/PropertyList.php?D=All'
        # headers ={"Upgrade-Insecure-Requests": "1",
        #           "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36"}


        yield scrapy.FormRequest(url=url, callback=self.parse1)



    def parse1(self, response):

        links = response.xpath('//div[@class="PropertyListing-Thumb"]/p[2]/a/@href').getall()

        name = response.xpath('//div[@class="PropertyListing-Thumb"]/p[1]/a/text()').getall()
        address = response.xpath('//div[@class="PropertyListing-Thumb"]/p[2]/text()').getall()

        for link, name, address in zip(links, name , address):
            link = 'http://greenwayinvestment.com/Properties/' + str(link)
            name = name
            print(name)
            address = address
            print(address)
            yield scrapy.FormRequest(url=link, dont_filter=True, callback=self.parse_detail, meta={'name': name,'address':address})

        # for link in links:
        #     link = 'http://greenwayinvestment.com/Properties/' + str(link)
        #     yield scrapy.FormRequest(url=link, callback=self.parse_detail)

    def parse_detail(self, response):

        item = ProprtySitesItem()
        name = response.meta['name']
        address = response.meta['address']
        # property_name = response.xpath('//div[@class="PropertyListing-Thumb"]/p[1]/a/@href').getall()

        # address = response.xpath('//div[@class="PropertyListing-Thumb"]/p[2]/text()').get()

        description = response.xpath('//div[@class="ArticleColumn"]/div/p[1]/text()').get()
        info_url = 'http://greenwayinvestment.com' + str(response.xpath('//div[@class="ArticleColumn"]/div/p[2]/a/@href').get())
        lks = "".join(response.url)
        item['description'] = description
        item['name'] = name
        item['address'] = address
        # item['name'] = feet
        item['city'] = ""
        item['state'] = ""
        item['zipcode'] = ""
        item['info_url'] = info_url

        item['urls'] = lks

        yield item



from scrapy.cmdline import execute
# execute("scrapy crawl store_706 -a list_id=706".split())



# ----------------- set download delay = 10--------------------------
# ----------------- set concorant request = 32 ----------------------
# --------------------- use ip vanish(us ip)-------------------------
# --------------------- see old file and keep change for add in city state zip and gla. -------------------------