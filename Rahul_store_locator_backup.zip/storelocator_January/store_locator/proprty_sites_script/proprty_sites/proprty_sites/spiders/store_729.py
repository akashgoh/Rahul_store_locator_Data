import datetime
import scrapy, json, requests, re
import html2text
from scrapy.http import HtmlResponse

from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func



class Store729Spider(scrapy.Spider):
    name = 'store_729'
    # allowed_domains = ['www.hudsonpacificproperties.com/office/list']
    # start_urls = ['https://www.hudsonpacificproperties.com/office/list']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        source_url = 'https://hpp-corp-api-prod.herokuapp.com/api/v1/property'
        yield scrapy.Request(url=source_url, callback=self.parse)


    def parse(self, response):


        data = json.loads(response.text)
        for i in range(0,len(data)):

            property_name = data[i]['name']
            address = data[i]['street_address']
            city = data[i]['city']
            state = data[i]['state']
            zip_code = data[i]['zip_code']
            try:
                SQ = data[i]['features'][0]['feature']['feature_name']

                if 'SF' in SQ:
                    GLA = SQ.replace('SF','').replace(',','')
                elif ','  in SQ:
                    GLA = SQ.replace('SF','').replace(',','')
                else:
                    GLA = ''
            except:
                GLA = ''
            Description = data[i]['web_description']
            Brochure_URL  = data[i]['custom_flyer']
            Property_URL = 'https://www.hudsonpacificproperties.com/office/' +str(data[i]['slug'])
            agent = data[i]['users']['primary']['agents']
            a = agent.keys()
            agent_name = []
            agent_email = []
            agent_phone = []
            for j in a:
                email = agent[j]['email']
                name = agent[j]['first_name'] + ' ' + agent[j]['last_name']
                phone = agent[j]['phone']

                if name != None:
                    if name != '':
                        agent_name.append(name)
                if email != None:
                    if email != '':
                        agent_email.append(email)
                if phone != None:
                    if phone != '':
                        agent_phone.append(phone)

            item = ProprtySitesItem()
            item['Property_name'] = property_name
            item['Address'] = address
            item['City'] = city
            item['State'] = state
            item['ZIP'] = zip_code
            item['GLA'] = GLA
            item['Description'] = Description
            if agent_name != []:
                item['agent_name'] = '|'.join(agent_name)
                print(item['agent_name'])
            else:
                item['agent_name'] = ''
            if agent_email != []:
                item['agent_email'] = '|'.join(agent_email)
            else:
                item['agent_email'] = ''
            if agent_phone != []:
                item['agent_phone'] = '|'.join(agent_phone)
            else:
                item['agent_phone'] = ''


            item['Brochure_URL'] = Brochure_URL
            item['PropertyURL'] = Property_URL
            yield item

from scrapy.cmdline import execute
# execute('scrapy crawl store_729 -a list_id=729'.split())
