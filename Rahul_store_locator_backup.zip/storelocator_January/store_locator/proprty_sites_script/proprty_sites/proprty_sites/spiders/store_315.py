# -*- coding: utf-8 -*-
import datetime
import scrapy, json, requests, re
import html2text
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func


class KimcoSpider(scrapy.Spider):
    name = 'store_315'
    allowed_domains = []
    start_urls = ['http://properties.kimcorealty.com/property/output/find/search4']


    def parse(self, response):
        urls = set(response.xpath('//div[@class="property_list_box_title_content"]//@href').extract())
        for url in urls:
            yield scrapy.Request(url=url,callback=self.parse_data,dont_filter=True)


    def parse_data(self,response):

        item = ProprtySitesItem()

        item['Property_Name'] = response.xpath('//div[@id="property_overview_row_1"]//text()').get(default='')
        item['Address'] = response.xpath('//div[@id="property_overview_row_2_box_1"]//li[1]//text()').get(default='')
        item['City'] = response.xpath('//div[@id="property_overview_row_2_box_1"]//li[2]//text()').get(default='').split(',')[0]
        item['State'] = response.xpath('//div[@id="property_overview_row_2_box_1"]//li[2]//text()').get(default='').split(',')[-1].strip().split(' ')[0]
        item['Zip_Code'] = response.xpath('//div[@id="property_overview_row_2_box_1"]//li[2]//text()').get(default='').split(',')[-1].strip().split(' ')[-1]
        item['GLA'] = response.xpath('//span[contains(text(),"GLA")]/following-sibling::text()').get(default='').split(':')[-1].strip()
        item['Parking_Spaces'] = response.xpath('//span[contains(text(),"Parking Spaces")]/following-sibling::text()').get(default='').split(':')[-1].strip()
        item['Metro_Area'] = response.xpath('//span[contains(text(),"Metro Area")]/following-sibling::text()').get(default='').split(':')[-1].strip()
        item['Leasing_Rep'] = response.xpath('//p[contains(text(),"Leasing Representative")]/following-sibling::p/text()').get(default='').strip()
        item['Leasing_Rep_Phone'] =response.xpath('//p[contains(text(),"Leasing Representative")]/following-sibling::p[2]//text()').get(default='').replace('Office:','').replace('|','').strip()
        item['Leasing_Rep_Cell'] =response.xpath('//p[contains(text(),"Leasing Representative")]/following-sibling::p[2]//text()[2]').get(default='').replace('Cell:','').replace('|','').strip()
        item['Leasing_Rep_Email'] =response.xpath('//p[contains(text(),"Leasing Representative")]/following-sibling::p//a[2]//@href').get(default='')
        item['Lease_Analyst'] =response.xpath('//p[contains(text(),"Lease Analyst")]/following-sibling::p/text()').get(default='').strip()
        item['Lease_Analyst_Phone'] =response.xpath('//p[contains(text(),"Lease Analyst")]/following-sibling::p[2]//text()').get(default='').replace('Office:','').strip()
        item['Lease_Analyst_Cell'] =response.xpath('//p[contains(text(),"Lease Analyst")]/following-sibling::p[2]//text()[2]').get(default='').replace('Cell:','').strip()
        item['Lease_Analyst_Email'] =response.xpath('//p[contains(text(),"Lease Analyst")]/following-sibling::p//a[2]//@href').get(default='')
        item['Property_Manager'] =response.xpath('//p[contains(text(),"Property Manager")]/following-sibling::p/text()').get(default='').strip()
        item['Property_Manager_Phone'] =response.xpath('//p[contains(text(),"Property Manager")]/following-sibling::p[2]//text()').get(default='').replace('Office:','').replace('|','').strip()
        item['Property_Manager_Cell'] =response.xpath('//p[contains(text(),"Property Manager")]/following-sibling::p[2]//text()[2]').get(default='').replace('Cell:','').replace('|','').strip()
        item['Property_Manager_Email'] =response.xpath('//p[contains(text(),"Property Manager")]/following-sibling::p//a[2]//@href').get(default='')
        item['URL'] =response.url
        yield item




from scrapy.cmdline import execute
# execute("scrapy crawl Kimco".split())