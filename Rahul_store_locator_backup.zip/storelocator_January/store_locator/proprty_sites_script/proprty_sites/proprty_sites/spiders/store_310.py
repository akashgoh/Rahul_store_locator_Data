# -*- coding: utf-8 -*-
import datetime
import hashlib

import scrapy, json, requests, re
import html2text
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func



class store_310_Spider(scrapy.Spider):
    name = 'store_310'

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        yield scrapy.Request(url='http://firstwash.propertycapsule.com/property/output/find/search4',
                             callback=self.parse)

    def parse(self, response):
        urls = response.xpath('//div[@class="listing"]/a[1]/@href').extract()
        for url in urls:
            yield scrapy.Request(url=url, callback=self.Extractdata)

    def Extractdata(self, response):

        item = ProprtySitesItem()
        try:
            item['Property_Name'] = response.xpath('//*[@class="property-title"]/text()').extract_first().strip()
        except Exception as e:
            item['Property_Name'] = ''
            print('error in Property_Name : ', e)

        try:
            item['Address'] = response.xpath('//*[@class="property-address"]/span[1]/text()').extract_first().strip()
        except Exception as e:
            item['Address'] = ''
            print('error in Address : ', e)
        try:
            item['City'] = \
            response.xpath('//*[@class="property-address"]/span[2]/text()').extract_first().strip().split(',')[0]
        except Exception as e:
            item['City'] = ''
            print('error in City : ', e)

        try:
            item['State'] = \
            response.xpath('//*[@class="property-address"]/span[2]/text()').extract_first().strip().split(',')[
                1].strip().split(' ')[0]
        except Exception as e:
            item['State'] = ''
            print('error in State : ', e)

        try:
            item['zip_code'] = \
            response.xpath('//*[@class="property-address"]/span[2]/text()').extract_first().strip().split(',')[
                1].strip().split(' ')[1]
        except Exception as e:
            item['zip_code'] = ''
            print('error in zip_code : ', e)

        try:
            item['Contact'] = response.xpath('//*[@class="contact-name"]/text()').extract_first()
        except Exception as e:
            item['Contact'] = ''
            print('error in Contact : ', e)

        try:
            item['Phone'] = response.xpath('//*[@class="contact-phone inline"]/text()').extract_first()
        except Exception as e:
            item['Phone'] = ''
            print('error in Phone : ', e)

        try:
            item['Email'] = response.xpath('//*[@class="contact-email inline"]/text()').extract_first()
        except Exception as e:
            item['Email'] = ''
            print('error in Email : ', e)

        try:
            item['Avail_SQFT'] = response.xpath('//*[@class="available-square-feet"]/text()').extract_first()
            if item['Avail_SQFT'] == None:
                item['Avail_SQFT'] = response.xpath(
                    '//div[@class="detail-holder"]/span[@class="square-feet"]/text()').extract_first()
        except Exception as e:
            item['Avail_SQFT'] = ''
            print('error in Avail_SQFT : ', e)

        try:
            item['Anchors'] = response.xpath('//*[@class="anchors"]/text()').extract_first().replace('  ', '').replace(
                '\n', '').replace('\t', '')
        except Exception as e:
            item['Anchors'] = ''
            print('error in Anchors : ', e)

        try:
            item['MSA'] = response.xpath('//*[@class="msa_value"]/text()').extract_first().strip()
        except Exception as e:
            item['MSA'] = ''
            print('error in MSA : ', e)
        try:
            item['SQFT'] = response.xpath(
                "//*[contains(text(),'Square Footage:')]/../span/text()").extract_first().strip()
        except Exception as e:
            item['SQFT'] = ''
            print('error in SQFT : ', e)

        try:
            id = str(response.text).split('var siteMapId =')[1].split(';')[0].strip().strip()
            plan = f"https://firstwash.propertycapsule.com/property/capsule_data/785/property/sitemap_image/{id}.png"
            item['Site_Plan_URL'] = plan
        except:
            item['Site_Plan_URL'] = ''

        item['URL'] = response.url
        hasstr = (str(response.url) + str(item['Property_Name'])).encode('utf8')
        Hash_id = int(hashlib.md5(hasstr).hexdigest(), 16)
        item['hash'] = Hash_id
        yield item

# Property_Name,Address,City,State,zip_code,Contact,Phone,Email,Avail_SQFT,Anchors,MSA,SQFT,Site_Plan_URL,URL,hash


from scrapy.cmdline import execute
# execute("scrapy crawl store_310 -a list_id=310".split())