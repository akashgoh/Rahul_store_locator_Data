# # -*- coding: utf-8 -*-
# import scrapy
# import json
# from proprty_sites.items import ProprtySitesItem
# from proprty_sites.spiders.common_functions import Func
# import datetime
#
#
# class store_463_Spider(scrapy.Spider):
#     name = 'store_463'
#     # allowed_domains = ['www.example.com']
#     start_urls = ['https://teiretail.com/properties/?cpage=1',
#                   'https://teiretail.com/properties/?cpage=2']
#
#     def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
#         super().__init__(name, **kwargs)
#         self.list_id, self.proxy_type = list_id, proxy_type
#         self.f1 = Func()
#         self.run_date = str(datetime.datetime.today()).split()[0]
#         self.table_name = self.f1.set_details(self.list_id, self.run_date)
#
#
#     def parse(self, response):
#         links= response.xpath('//ul[@id="national-listing"]/li/div/div/a/@href').extract()
#         for link in links:
#             url='https://teiretail.com/properties/'+link
#             yield scrapy.Request(url=url,callback=self.get_data)
#
#
#     def get_data(self,response):
#         try:
#             store_name = response.xpath('//div[@itemprop="name"]/text()').get().strip()
#         except Exception as e:
#             print(e, response.url)
#             store_name = ''
#
#         try:
#             address = response.xpath('//*[contains(text(),"ADDRESS")]/following-sibling::div/text()').get().strip()
#         except Exception as e:
#             print(e, response.url)
#             address = ''
#
#         try:
#             city = response.xpath('//*[contains(text(),"CITY/STATE")]/following-sibling::div/text()').get().strip().split(',')[0].strip()
#         except Exception as e:
#             print(e, response.url)
#             city = ''
#
#         try:
#             state = response.xpath('//*[contains(text(),"CITY/STATE")]/following-sibling::div/text()').get().strip().split(',')[-1].strip()
#         except Exception as e:
#             print(e, response.url)
#             state = ''
#
#
#         try:
#             GLA = response.xpath(
#                 '//*[contains(text(),"AVAILABLE SPACE")]/following-sibling::div/text()').get().strip().replace(',', '').strip()
#         except Exception as e:
#             print(e, response.url)
#             GLA = ''
#
#         try:
#             Property_Manager_Name = response.xpath('//*[contains(text(),"PROPERTY MANAGER")]/following-sibling::div/text()').get().strip()
#         except Exception as e:
#             print(e, response.url)
#             Property_Manager_Name = ''
#
#         try:
#             Property_Manager_Email = response.xpath('//*[contains(text(),"PROPERTY MANAGER")]/following-sibling::p/a/text()').get().strip()
#         except Exception as e:
#             print(e, response.url)
#             Property_Manager_Email = ''
#
#
#         try:
#             Leasing_contact_Name = response.xpath('//*[contains(text(),"LEASING ANALYST")]/following-sibling::div/text()').get().strip()
#         except Exception as e:
#             print(e, response.url)
#             Leasing_contact_Name = ''
#
#         try:
#             Leasing_contact_Email = response.xpath('//*[contains(text(),"LEASING ANALYST")]/following-sibling::p/a/text()').get().strip()
#         except Exception as e:
#             print(e, response.url)
#             Leasing_contact_Email = ''
#
#
#         if Property_Manager_Name=='Steve Tiritilli':
#             Property_Manager_Email='stevet@jstrealestate.com'
#         elif Property_Manager_Name=='Laurie Dunlop':
#             Property_Manager_Email='ldunlop@woodmont.com'
#         elif Property_Manager_Name == 'Adam Levitt':
#             Property_Manager_Email = 'alevitt@timeequities.com'
#         elif Property_Manager_Name=='Amy DiTripani':
#             Property_Manager_Email='amyd@hybridgecre.com'
#         elif Property_Manager_Name=='Azar Meszaros':
#             Property_Manager_Email='azar.meszaros@mebcommercial.com'
#         elif Property_Manager_Name=='Bill Klauseger':
#             Property_Manager_Email='bklauseger@aol.com'
#         elif Property_Manager_Name=='Bob Worgan':
#             Property_Manager_Email='bworganrealtec@aol.com'
#         elif Property_Manager_Name=='Boo Moca':
#             Property_Manager_Email='boo@wilsonkibler.com'
#         elif Property_Manager_Name=='Chris Keena':
#             Property_Manager_Email='ckeena@adrealestate.us'
#         elif Property_Manager_Name=='Christiane Fischer':
#             Property_Manager_Email='c.fischer@midamericagrp.com'
#         elif Property_Manager_Name=='Eric Zimmerman':
#             Property_Manager_Email='eric.zimmerman@colliers.com'
#         elif Property_Manager_Name=='Erin McTear':
#             Property_Manager_Email='emctear@midamericagrp.com'
#         elif Property_Manager_Name=='Evan Kupferberg':
#             Property_Manager_Email='ekupferberg@timeequities.com'
#         elif Property_Manager_Name=='Heather Meyer':
#             Property_Manager_Email='heather.meyer@cushwake.com'
#         elif Property_Manager_Name=='Jerry Griffo':
#             Property_Manager_Email='jgriffo@flaummgt.com'
#         elif Property_Manager_Name=='John Bouck':
#             Property_Manager_Email='j.bouck@verizon.net'
#         elif Property_Manager_Name=='June Hurt':
#             Property_Manager_Email='june.hurt@ngkf.com'
#         elif Property_Manager_Name=='Karen Colucci':
#             Property_Manager_Email='kcolucci@ngkf.com'
#         elif Property_Manager_Name=='Karen Satterwhite':
#             Property_Manager_Email='ksatterwhite@fickling.com'
#         elif Property_Manager_Name=='Kevin Dexter':
#             Property_Manager_Email='kdexter@midamericagrp.com'
#         elif Property_Manager_Name=='Kevin Perkins':
#             Property_Manager_Email='kperkins@engelrealty.com'
#         elif Property_Manager_Name=='Kim Guerrero':
#             Property_Manager_Email='kim.guerrero@am.jll.com'
#         elif Property_Manager_Name=='Laurie Dunlop':
#             Property_Manager_Email='ldunlop@woodmont.com'
#         elif Property_Manager_Name=='Marianne Meyers':
#             Property_Manager_Email='mmeyers@shopmacombmall.com'
#         elif Property_Manager_Name=='Mark Canvasser':
#             Property_Manager_Email='mcanvasser@aol.com'
#         elif Property_Manager_Name=='Michael Kaufman':
#             Property_Manager_Email='mkaufman@urbanretail.com'
#         elif Property_Manager_Name=='Muffy Schladensky':
#             Property_Manager_Email='muffy.schladensky@woodruffre.com'
#         elif Property_Manager_Name=='Perry Radic':
#             Property_Manager_Email='perry@drakeam.com'
#         elif Property_Manager_Name=='Steve Tiritilli':
#             Property_Manager_Email='stevet@jstrealestate.com'
#         elif Property_Manager_Name=='Steven Bell':
#             Property_Manager_Email='steven.bell@cbre.com'
#         elif Property_Manager_Name=='Tera Greenland':
#             Property_Manager_Email='tgreenland@midamericagrp.com'
#         elif Property_Manager_Name=='Teri Schaller':
#             Property_Manager_Email='tschaller@urbanretail.com'
#         elif Property_Manager_Name=='Tim Wadley':
#             Property_Manager_Email='tim.wadley@am.jll.com'
#         elif Property_Manager_Name=='Vince Dellavalle':
#             Property_Manager_Email='vdellavalle@merioncommercial.com'
#
#
#
#
#
#
#         try:
#             item = ProprtySitesItem()
#             item['Property_Name'] = store_name
#             item['Address'] = address
#             item['City'] = city
#             item['State'] = state
#             item['GLA'] = GLA
#             item['Leasing_contact_Name'] = Leasing_contact_Name
#             item['Leasing_contact_Email'] = 'ekupferberg@timeequities.com'
#             item['Property_Manager_Name'] = Property_Manager_Name
#             item['Property_Manager_Email'] = Property_Manager_Email
#
#             item['Property_URL'] = response.url
#
#             # print (item)
#             yield item
#         except Exception as e:
#             print("item", e)
#
#
# # from scrapy.cmdline import execute
# # execute('''scrapy crawl store_463 -a list_id=463'''.split())
