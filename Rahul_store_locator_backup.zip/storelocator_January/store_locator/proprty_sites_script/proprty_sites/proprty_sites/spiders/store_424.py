# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
# -*- coding: utf-8 -*-

import datetime
import scrapy, json, requests, re
import html2text
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func
from scrapy.cmdline import execute

class Store424Spider(scrapy.Spider):
    name = 'store_424'
    allowed_domains = []
    not_export_data = True

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        try:
            page = 1
            source_url = link = f'https://www.castoinfo.com/retail/portfolio/'
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
                self.run_date) + '.html'
            yield scrapy.FormRequest(url=str(link), callback=self.firstlevel,
                                     meta={'source_url': source_url, 'file_path': file_path,
                                           'proxy_type': self.proxy_type, 'page': page})
        except Exception as e:
            print(e)

    def firstlevel(self, response):
        if not response.url.startswith('file://'):
            self.f1.page_save(response.meta['file_path'], response.body)
        try:
            source_url = response.meta['source_url']
            file_path = response.meta['file_path']
            proxy_type = response.meta['proxy_type']
            links = response.xpath('//div[@class="portfoliogrid"]/a/@href').extract()
            for link in (links):
                link = "https://www.castoinfo.com" + link.strip()
                page = link.replace('https://www.castoinfo.com/retail/portfolio/', '').replace('/', '_').strip()
                file_path = self.f1.html_data_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
                    self.run_date) + '_' + str(page) + '.html'
                yield scrapy.FormRequest(url=link, callback=self.get_store_list,
                                         meta={'source_url': source_url, 'file_path': file_path,
                                               'proxy_type': proxy_type})
        except Exception as e:
            print("firstlevel", e, response.url)

    # Get data from the response
    def get_store_list(self, response):
        if not response.url.startswith('file://'):
            self.f1.page_save(response.meta['file_path'], response.body)
        try:
            try:
                try:
                    Property_Name = response.xpath('//h2[@id="property-title"]/text()').extract_first().strip()
                except Exception as e:
                    print("Property_Name", e, response.url)

                try:
                    city_state = response.xpath('//h3[@id="property-address"]/text()').extract_first(default='').strip()
                    city = city_state.split(',')[0].strip()
                    state = city_state.split(',')[1].strip()
                    if "|" in str(state):
                        state = state.split('|')[0].strip()
                except Exception as e:
                    print("city_state", e, response.url)

                try:
                    Description = response.xpath('normalize-space(//div[@id="property-description"]/p/text())').extract_first(default='')
                except Exception as e:
                    Description = ''
                    print("Description", e, response.url)

                try:
                    GLA = response.xpath(
                        '//div[@id="property-tenants"]//*[contains(text(),"Size")]/../ul/li/text()').extract_first(
                        default='').strip()
                    GLA=GLA.replace("square feet","").strip()
                except Exception as e:
                    print("GLA", e, response.url)

                try:
                    Leasing_Contact = response.xpath('//div[@class="name-badge"]/b/text()').extract_first(
                        default='').strip()
                except Exception as e:
                    print("Leasing_Contact", e, response.url)

                try:
                    Leasing_Email = response.xpath(
                        '//div[@class="property-agent-badge col-md-12"]/@data-email').extract_first(default='').strip()
                except Exception as e:
                    print("Leasing_Email", e, response.url)

                try:
                    Leasing_Phone = response.xpath(
                        '//div[@class="name-badge"]/p/a[@class="keyjobphone"]/text()').extract_first(default='').strip()
                except Exception as e:
                    print("Leasing_Phone", e, response.url)

                try:
                    Brochure_URL = response.xpath('//a[@id="property-flyer-button"]/@href').extract_first(
                        default='').strip()
                except Exception as e:
                    print("Brochure_URL", e, response.url)


                item = ProprtySitesItem()
                item['Property_Name'] = Property_Name
                item['City'] = city
                item['State'] = state
                item['Description'] = Description
                item['GLA'] = GLA
                item['Leasing_Contact'] = Leasing_Contact
                item['Leasing_Phone'] = Leasing_Phone
                item['Leasing_Email'] = Leasing_Email
                item['Property_URL'] = response.url
                item['Brochure_URL'] = Brochure_URL
                yield item
            except Exception as e:
                print(e)

        except Exception as e:
            print(e)


# execute("scrapy crawl store_424 -a list_id=424".split())


