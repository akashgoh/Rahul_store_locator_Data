# -*- coding: utf-8 -*-
import scrapy
import json
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func
import datetime


class store_480_Spider(scrapy.Spider):
    name = 'store_480'
    # allowed_domains = ['www.example.com']
    start_urls = ['https://www.macerich.com/Leasing/Find']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)


    def parse(self, response):
        links=response.xpath('//div[@class="uk-grid uk-grid-preserve uk-grid-match"]/div//a/@href').getall()

        for link in links:
            link='https://www.macerich.com'+link
            yield scrapy.Request(url=link, callback=self.finaldata,dont_filter=True)

    def finaldata(self, response):

        try:
            store_name=response.xpath('//div[@class="content-container"]/h2/text()').get().strip()
        except Exception as e:
            print('problem ',e, response.url)



        try:
            address= response.xpath('//p[@class="address"]//text()').getall()[0].strip()
        except Exception as e:
            print(e, response.url)
            address = ''

        try:
            city=response.xpath('//p[@class="address"]//text()').getall()[-1].strip().split(',')[0].strip()
        except Exception as e:
            print(e,response.url)
            city=''

        try:
            state=response.xpath('//p[@class="address"]//text()').getall()[-1].strip().split(',')[1].strip().split()[0].strip()
        except Exception as e:
            print(e,response.url)
            state=''


        try:
            zip_code =response.xpath('//p[@class="address"]//text()').getall()[-1].strip().split(',')[1].strip().split()[1].strip()
        except Exception as e:
            print(e,response.url)
            zip_code=''

        try:
            GLA=response.xpath('//p[contains(text(),"Total square feet")]/preceding-sibling::h3/text()').get().strip()
        except Exception as e:
            print(e,response.url)
            GLA=''


        try:
            Leasing_Contact_Name=response.xpath('//div[@class="mobile-padding-bottom"][1]/span[@class="contact-name"]/text()').getall()[0].strip()
        except Exception as e:
            print(e, response.url)
            Leasing_Contact_Name=''

        try:
            Leasing_Contact_Phone=response.xpath('//div[@class="mobile-padding-bottom"][1]/span[@class="contact-phone"]/text()').getall()[0].strip()
        except Exception as e:
            print(e, response.url)
            Leasing_Contact_Phone = ''


        try:
            Leasing_Contact_Email= response.xpath('//div[@class="mobile-padding-bottom"][1]/span[@class="contact-email"]//text()').getall()[0].strip()
        except Exception as e:
            print(e,response.url)
            Leasing_Contact_Email=''


        try:
            Property_Manager_Name=response.xpath('//div[@class="mobile-padding-bottom"][1]/span[@class="contact-name"]/text()').getall()[1].strip()
        except Exception as e:
            print(e, response.url)
            Property_Manager_Name=''

        try:
            Property_Manager_Phone=response.xpath('//div[@class="mobile-padding-bottom"][1]/span[@class="contact-phone"]/text()').getall()[1].strip()
        except Exception as e:
            print(e, response.url)
            Property_Manager_Phone = ''


        try:
            Property_Manager_Email= response.xpath('//div[@class="mobile-padding-bottom"][1]/span[@class="contact-email"]//text()').getall()[1].strip()
        except Exception as e:
            print(e,response.url)
            Property_Manager_Email=''

        try:
            Site_Plan_URL= response.xpath('//*[contains(text(),"Market Profile")]/../@href').get()
        except Exception as e:
            print(e,response.url)
            Site_Plan_URL=''


        try:
            item = ProprtySitesItem()
            item['Property_Name'] = store_name
            item['Address']=address
            item['City'] = city
            item['State'] = state
            item['Zip']=zip_code
            item['GLA'] = GLA

            item['Leasing_Contact_Name']=Leasing_Contact_Name
            item['Leasing_Contact_Phone'] =Leasing_Contact_Phone
            item['Leasing_Contact_Email'] =Leasing_Contact_Email
            item['Property_Manager_Name']=Property_Manager_Name
            item['Property_Manager_Phone'] =Property_Manager_Phone
            item['Property_Manager_Email'] =Property_Manager_Email
            item['Site_Plan_URL'] = Site_Plan_URL

            item['Property_URL'] = response.url


            # print (item)
            yield item
        except Exception as e:
            print("item", e)


# from scrapy.cmdline import execute
# execute('''scrapy crawl store_480 -a list_id=480'''.split())
