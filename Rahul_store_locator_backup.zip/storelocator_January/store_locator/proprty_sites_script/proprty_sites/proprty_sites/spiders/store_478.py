# -*- coding: utf-8 -*-
import scrapy
import json
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func
import datetime
from scrapy.http import HtmlResponse
import re
import requests


class store_478_Spider(scrapy.Spider):
    name = 'store_478'
    # allowed_domains = ['www.example.com']
    start_urls = ['https://inventrust.propertycapsule.com/property/output/find/browse2/?utm_source=IVTWebsite&utm_medium=web&utm_campaign=IVT']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)


    def parse(self, response):
        links=response.xpath('//div[@class="properties-3"]/ul/li/a/@href').getall()
        for link in links:
            link=link.replace('search2','search2datajson')
            yield scrapy.Request(url=link, callback=self.json)
            # state= re.findall('state:(.*?)/', link)[0]
            # url='https://inventrust.propertycapsule.com/property/output/find/map_google/search2:1/fit:1/allowableFolders:1/state:'+str(state)+'/active:1/offset:0/limit:150/?property_ids='
            # yield scrapy.Request(url=url, callback=self.json)


    def json(self, response):
        data=response.text
        machine_data = json.loads(data)
        #
        # total_store=len(machine_data['tableData'])
        # for i in total_store:
        #
        #
        # links=response.xpath('//table[@class="dataTable"]/tbody/tr/td[1]/div/a/@href').getall()
        # for link in links:
        #     yield scrapy.Request(url=link, callback=self.finaldata)
        # try:
        #     data = re.findall('var markersByFolder = (.*?);', response.text)[0]
        #     machine_data = json.loads(data)
        #     total_property = machine_data['folders']['6']['properties']
        #     # total_property = machine_data['folders']['1']['properties']
        # except:
        #     print('in this',response.url)
        #     total_property=machine_data['folders']['6']['properties']
        hipsdata=machine_data['hipsterData']
        for i in range(0, int(len(hipsdata))):
            # storename=machine_data['folders']['1']['properties'][i]['data']['name']
            # loaction=machine_data['folders']['1']['properties'][i]['data']['location']
            # link = machine_data['folders']['1']['properties'][i]['data']['link1']
            link=machine_data['hipsterData'][i]['property_data']['url']
            yield scrapy.Request(url=link, callback=self.finaldata)

    def finaldata(self, response):

        # addresss = response.meta['loaction']

        try:
            # store_name=response.meta['storename'].strip()
            store_name=response.xpath('//h2[@class="property-metadata p-label"]/text()').get().strip()
        except Exception as e:
            print(e,response.url)
            store_name=''


        try:
            # Address=addresss.split(',')[0].strip()
            Address=response.xpath('//span[@class="p-street-address"]/text()').get().strip()
        except Exception as e:
            print(e,response.url)
            Address=''


        try:
            # city=addresss.split(',')[-2].strip()
            city=response.xpath('//span[@class="p-locality"]/text()').get().strip()
        except Exception as e:
            print(e,response.url)
            city=''

        try:
            # State = addresss.split(',')[-1].strip()
            State=response.xpath('//span[@class="p-region"]/text()').get().strip()
        except Exception as e:
            print(e, response.url)
            State = ''

        try:
            zip_code = response.xpath('//span[@class="p-postal-code"]/text()').get().strip()
        except Exception as e:
            print(e,response.url)
            zip_code=''

        try:
            GLA=response.xpath('//dt[contains(text(),"Total SF:")]/following-sibling::dd/text()').get().strip()
        except Exception as e:
            print(e,response.url)
            GLA=''

        try:
            Description=' '.join(response.xpath('//div[@class="overview_data-propcap"]/ul/li/text()').getall()).strip()
        except Exception as e:
            print(e, response.url)
            Description=''

        try:
            l_c_n=response.xpath('//dt[contains(text(),"Director of Leasing")]/..//dd/div[@class="p-name"]/text()').get(default='').strip()
        except Exception as e:
            print(e, response.url)
            l_c_n=''

        try:
            l_c_p=response.xpath('//dt[contains(text(),"Director of Leasing")]/..//dd/div[@class="p-tel"]/text()').get(default='').strip()
        except Exception as e:
            print(e, response.url)
            l_c_p = ''

        try:
            l_c_e = re.findall('"email":"(.*?)",',response.text)[0]
        except Exception as e:
            print(e, response.url)
            l_c_e = ''


        try:
            Property_Manager_Name=response.xpath('//dt[contains(text(),"Property Management")]/../following-sibling::dl/dd/div[@class="p-name"]/text()').get(default='').strip()
        except Exception as e:
            print(e, response.url)
            Property_Manager_Name=''

        try:
            Property_Manager_Phone=response.xpath('//dt[contains(text(),"Property Management")]/../following-sibling::dl/dd/div[@class="p-tel"]/text()').get(default='').strip()
        except Exception as e:
            print(e, response.url)
            Property_Manager_Phone = ''


        try:
            Property_Manager_Email= response.xpath('//dt[contains(text(),"Property Management")]/../following-sibling::dl/dd//a[@class="u-email"]/text()').get(default='').strip()
        except Exception as e:
            print(e,response.url)
            Property_Manager_Email=''


        try:
            Site_Plan_URL= response.url+'#plans'

            c = requests.get(url=Site_Plan_URL)
            response_1 = HtmlResponse(url=Site_Plan_URL, body=c.content)

            try:
                s_url=re.findall('<iframe id="jsviewer" src="(.*?)" scrolling',response_1.text)[0]
            except:
                Site_Plan_URL=''

            if s_url!='':
                d = requests.get(url=s_url)
                response_2 = HtmlResponse(url=s_url, body=d.content)

                id=re.findall('png\?(.*?)\\"',response_2.text)[0]


                Site_Plan_URL=re.findall('https://inventrust.propertycapsule.com/property/capsule_data(.*?)png',response_1.text)[0]
                Site_Plan_URL='https://inventrust.propertycapsule.com/property/capsule_data'+Site_Plan_URL+'png?'+str(id).strip('\\')
            else:
                Site_Plan_URL=''
        except Exception as e:
            print(e,response.url)
            Site_Plan_URL=''

        if Property_Manager_Name=='Brooke Benton':
            Property_Manager_Email='brooke.benton@inventrustpm.com'
        elif Property_Manager_Name=='Debbie Gillies':
            Property_Manager_Email='debra.gillies@inventrustpm.com'
        elif Property_Manager_Name == 'Hanna Moser':
            Property_Manager_Email = 'hanna.moser@inventrustpm.com'
        elif Property_Manager_Name=='Jessi Richards':
            Property_Manager_Email='jessi.richards@inventrustpm.com'
        elif Property_Manager_Name=='Janet Coleman':
            Property_Manager_Email='janet.coleman@inventrustpm.com'
        elif Property_Manager_Name=='Jennifer Roeser':
            Property_Manager_Email='jennifer.roeser@inventrustpm.com'
        elif Property_Manager_Name=='Karen Egbert':
            Property_Manager_Email='karen.egbert@inventrustpm.com'
        elif Property_Manager_Name=='Madonna McAdam':
            Property_Manager_Email='madonna.mcadam@inventrustpm.com'
        elif Property_Manager_Name=='Rhonda  Allen':
            Property_Manager_Email='rhonda.allen@inventrustpm.com'
        elif Property_Manager_Name=='Samantha Sebesta':
            Property_Manager_Email='samantha.sebesta@inventrustpm.com'
        elif Property_Manager_Name=='Warren Armstrong':
            Property_Manager_Email='warren.armstrong@inventrustpm.com'

        try:
            item = ProprtySitesItem()
            item['Property_Name'] = store_name
            item['Address'] = Address
            item['City'] = city
            item['State']=State
            item['Zip']=zip_code
            item['GLA'] = GLA
            item['Description']=Description
            item['Leasing_Contact_Name'] = l_c_n
            item['Leasing_Contact_Phone']=l_c_p
            item['Leasing_Contact_Email'] =l_c_e
            item['Property_Manager_Name'] = Property_Manager_Name
            item['Property_Manager_Phone'] = Property_Manager_Phone
            item['Property_Manager_Email'] = Property_Manager_Email

            item['Site_Plan_URL'] = Site_Plan_URL

            item['Property_URL'] = response.url


            # print (item)
            yield item
        except Exception as e:
            print("item", e)



# from scrapy.cmdline import execute
# execute('''scrapy crawl store_478 -a list_id=478'''.split())
