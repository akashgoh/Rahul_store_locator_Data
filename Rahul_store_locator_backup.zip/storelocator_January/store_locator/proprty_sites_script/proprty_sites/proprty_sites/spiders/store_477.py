# # -*- coding: utf-8 -*-
# import scrapy
# import json
# from proprty_sites.items import ProprtySitesItem
# from proprty_sites.spiders.common_functions import Func
# import datetime
#
#
# class store_477_Spider(scrapy.Spider):
#     name = 'store_477'
#     # allowed_domains = ['www.example.com']
#     start_urls = ['https://hackneyrealestate.com/properties/']
#
#     def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
#         super().__init__(name, **kwargs)
#         self.list_id, self.proxy_type = list_id, proxy_type
#         self.f1 = Func()
#         self.run_date = str(datetime.datetime.today()).split()[0]
#         self.table_name = self.f1.set_details(self.list_id, self.run_date)
#
#
#
#     def parse(self, response):
#         links=response.xpath('//table[@class="table properties-table"]/tbody/tr/td[1]/a/@href').getall()
#         for link in links:
#             yield scrapy.Request(url=link, callback=self.finaldata)
#
#     def finaldata(self, response):
#
#         try:
#             store_name=response.xpath('//div[@class="col-md-6"]/h1/text()').get().strip()
#         except Exception as e:
#             print(e,response.url)
#             store_name=''
#
#         try:
#             address=response.xpath('//div[@class="col-md-6"]/p[1]/text()').getall()[0].strip()
#         except Exception as e:
#             print(e, response.url)
#             address = ''
#
#         try:
#             city= response.xpath('//div[@class="col-md-6"]/p[1]/text()').getall()[-1].strip().split(',')[0].strip()
#         except Exception as e:
#             print(e,response.url)
#             city=''
#
#         try:
#             state= response.xpath('//div[@class="col-md-6"]/p[1]/text()').getall()[-1].strip().split(',')[-1].strip().split()[0].strip()
#         except Exception as e:
#             print(e,response.url)
#             state=''
#
#
#         try:
#             zip_code = response.xpath('//div[@class="col-md-6"]/p[1]/text()').getall()[-1].strip().split(',')[-1].strip().split()[-1].strip()
#         except Exception as e:
#             print(e,response.url)
#             zip_code=''
#
#         try:
#             GLA=response.xpath('//*[contains(text(),"Square Feet:")]/following-sibling::text()').get().strip().replace(',','').strip()
#         except Exception as e:
#             print(e,response.url)
#             GLA=''
#
#         try:
#             Parking_Spaces=response.xpath('//*[contains(text(),"Parking Spaces:")]/following-sibling::text()').get().strip().replace(',','').strip()
#         except Exception as e:
#             print(e, response.url)
#             Parking_Spaces=''
#
#         try:
#             Leasing_contact_1=response.xpath('//div[@class="col-md-6"]/p[3]/a/text()').getall()[0].strip()
#         except Exception as e:
#             print(e, response.url)
#             Leasing_contact_1=''
#
#         try:
#             Leasing_contact_2=response.xpath('//div[@class="col-md-6"]/p[3]/a/text()').getall()[1].strip()
#         except Exception as e:
#             print(e, response.url)
#             Leasing_contact_2 = ''
#
#
#         try:
#             Brochure_URL= response.xpath('//div[@class="col-md-6"]//p/a[@class="btn btn-primary btn-brochure"]/@href').get()
#         except Exception as e:
#             print(e,response.url)
#             Brochure_URL=''
#
#         try:
#             item = ProprtySitesItem()
#             item['Property_Name'] = store_name
#             item['Address']=address
#             item['City'] = city
#             item['State'] = state
#             item['Zip']=zip_code
#             item['GLA'] = GLA
#             item['Parking_Spaces']=Parking_Spaces
#             item['Leasing_contact_1']=Leasing_contact_1
#             item['Leasing_contact_2'] =Leasing_contact_2
#             item['Brochure_URL'] =Brochure_URL
#
#             item['Property_URL'] = response.url
#
#
#             # print (item)
#             yield item
#         except Exception as e:
#             print("item", e)
#
#
# # from scrapy.cmdline import execute
# # execute('''scrapy crawl store_477 -a list_id=477'''.split())
