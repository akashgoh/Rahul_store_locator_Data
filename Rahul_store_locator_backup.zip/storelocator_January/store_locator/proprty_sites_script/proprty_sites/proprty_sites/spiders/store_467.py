# -*- coding: utf-8 -*-
import datetime
import scrapy, json, requests, re
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func
import html2text
h = html2text.HTML2Text()

class JbgsmithSpider(scrapy.Spider):
    name = 'store_467'
    allowed_domains = []
    # start_urls = ['https://www.americanassetstrust.com/portfolio/properties?filter_locstate=&filter_city=&filter_cat=11&filter_keyword=&51ef751b260ace73986e61c68906c5cd=1']
    start_urls = ['https://www.americanassetstrust.com/portfolio/properties']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def parse(self, response):
        try:
           links = response.xpath('//a[@class="title"]/@href').extract()
           for link in links:
               yield scrapy.FormRequest(url=f"https://www.americanassetstrust.com{link}",callback=self.extract,dont_filter=True)
        except Exception as e:
            print(e)

    def extract(self,response):
        try:
            name = response.xpath('//h1/text()').extract_first(default='').strip()
            add_temp = response.xpath('//*[@class="full-address"]/address/text()').extract_first(default='').strip().split(',')
            desc = response.xpath('//*[@class="description"]/p/text()').extract_first(default='').strip()
            gla = response.xpath('//div[contains(text(),"Square Feet")]/following-sibling::div[1]/text()').extract_first(default='').strip()
            l_name = response.xpath('//div[contains(text(),"Leasing Office")]/following-sibling::div[1]/text()').extract_first(default='').strip()
            l_phone = response.xpath('//div[contains(text(),"Leasing Office")]/following-sibling::a[1]/text()').extract_first(default='').strip()
            pm_name = response.xpath('//div[contains(@class,"agents")]//*[@class="name"]/text()').extract_first(default='').strip()
            pm_phone = response.xpath('//div[contains(@class,"agents")]//a[@class="phone"]/text()').extract_first(default='').strip()
            temp = response.xpath('//a[contains(text(),"Print Site Plan")]/@href').extract_first(default='').strip()
            site_plan = re.findall("open\(\\'(.*?)\\'\);",temp) if temp!='' else ''


            try:
                item = ProprtySitesItem()
                item['Property_Name'] = name
                try:item['Address'] = add_temp[0].strip()
                except:item['Address'] = ''
                try:item['City'] = add_temp[1].strip()
                except:item['City'] = ''

                try:
                    item['zip_code'] = add_temp[2].split('')[-1].strip()
                except:
                    item['zip_code']= ''
                print(item['zip_code'])

                try:item['State'] = add_temp[2].strip()
                except:item['State'] = ''
                item['Description'] = desc
                item['GLA'] = gla.replace(',','').strip()
                item['Leasing_Contact'] = l_name
                item['Leasing_Phone'] = l_phone
                item['Property_Manager_Name'] = pm_name
                item['Property_Manager_Phone'] = pm_phone
                item['Site_Plan_URL'] = '|'.join(site_plan) if site_plan != [] else ''
                item['Property_URL'] = response.url
                yield item
            except Exception as e:
                print(e)

        except Exception as e:
            print(e)

# execute("scrapy crawl store_467 -a list_id=467".split())