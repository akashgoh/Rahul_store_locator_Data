import datetime
import scrapy, json, requests, re
import html2text
from scrapy.cmdline import execute
from scrapy.http import HtmlResponse

from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func

h = html2text.HTML2Text()

class highwoodsSpider(scrapy.Spider):
    name = 'store_730'
    allowed_domains = ['www.highwoods.com']
    start_urls = ['https://www.highwoods.com/find-your-space/search']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def parse(self, response):
            l = response.xpath('//div[@class="SearchResult-details"]').extract()
            m = len(l)
            for i in range(0,m):
                try:
                    name = response.xpath('//h2[@class="SearchResult-title h30"]/a/text()').extract()
                    # print(name)
                    name = name[i].strip()
                    # print(name)

                except Exception as e:
                    # print(e)
                    name = ''
                # try:
                #     # sqft = response.xpath('//div[@class="SearchResult-main"]/span/text()').extract()
                #     sqft = response.xpath('//div/div[2]/div[3]/text()[3]').extract()
                #     # print(sqft)
                #     sqft = sqft[i].strip()
                #     print(sqft)
                # except Exception as e:
                #     print(e)

                try:
                    street = response.xpath('//div[@class="Grid u-mediumGray"]/div/a/text()[1]').extract()
                    # print(street)
                    street = street[i].strip()
                    # print(street)
                except Exception as e:
                    # print(e)
                    street = ''

                try:
                    temp_add = response.xpath('//div[@class="Grid u-mediumGray"]/div/a/text()[2]').extract()
                    temp_add = temp_add[i].strip().replace("\n","").strip()
                    # print(temp_add)
                    # temp_add = temp_add[1].strip().replace("\n","").strip()
                    # print(temp_add)
                except Exception as e:
                    # print(e)
                    temp_add=''

                try:
                    city = temp_add.split(",")[0].strip()
                    # print(city)
                except Exception as e:
                    # print(e)
                    city=''

                try:
                    state = temp_add.split(",")[1].strip()
                    # print(state)
                    state = state.split(" ")[0].strip()
                    # print(state)
                except Exception as e:
                    # print(e)
                    state=''

                try:
                    zip_c = temp_add.split(",")[1].strip()
                    # print(zip_c)
                    zip_c = zip_c.split(" ")[-1]
                    # print(zip_c)
                except Exception as e:
                    # print(e)
                    zip_c=''

                # try:
                #     leasing_agent_name = response.xpath('//div[@class="Grid u-mediumGray"]/div[2]/text()[2]').extract()
                #     # print(leasing_agent_name)
                #     leasing_agent_name = leasing_agent_name[i].strip()
                #     # print(leasing_agent_name)
                # except Exception as e:
                #      # print(e)
                #     leasing_agent_name=''

                # try:
                #     leasing_phone = response.xpath('//div[@class="Grid u-mediumGray"]/div[2]/text()[3]').extract()
                #     # print(leasing_phone)
                #     leasing_phone = leasing_phone[i].strip()
                #     # print(leasing_phone)
                #
                # except Exception as e:
                #     # print(e)
                #     leasing_phone=''

                try:
                    # link = response.xpath('//*[contains(text(),"available suite")]/@href').extract()
                    link = response.xpath('//h2[@class="SearchResult-title h30"]/a/@href').extract()
                    print(link)
                    link = link[i]
                except Exception as e:
                    print(e)

                yield scrapy.FormRequest(url=link,dont_filter=True,callback=self.parse2,meta={'name':name,
                                            'zip_c':zip_c,'state':state,'city':city,'temp_add':temp_add,'street':street})

    def parse2(self,response):
        print(response.url)

        name = response.meta['name']
        # leasing_phone = response.meta['leasing_phone']
        zip_c = response.meta['zip_c']
        state = response.meta['state']
        city = response.meta['city']
        street = response.meta['street']
        # leasing_agent_name = response.meta['leasing_agent_name']

        try:
            desc = "".join(response.xpath('//div[@class="Grid-cell  u-lg-size2of5"]/p[1]/text()').extract()).strip()
            if desc == '':
                desc = "".join(response.xpath('//div[@class="Grid-cell  u-lg-size2of5"]/p/span/text()').extract()).strip()
        except Exception as e:
            # print(e)
            desc=''
        # print(desc)

        try:
            sqft = "".join(response.xpath('//*[contains(text(),"Building SF")]/../p/text()').extract()).strip()
            # print(sqft)
        except Exception as e:
            # print(e)
            sqft=''

        try:
            leasing_agent_name = response.xpath('//div[@class="Media-body"]/h3/text()').extract_first()
            print(leasing_agent_name)
        except Exception as e:
            # print(e)
            leasing_agent_name=''

        try:
            leasing_phone = response.xpath('//div[@class="Media-body"]/div/p/text()').extract_first()
            print(leasing_phone)
        except Exception as e:
            # print(e)
            leasing_phone=''

        try:
            leasing_email = response.xpath('//div[@class="Media-body"]/div/p/a/text()').extract_first()
            print(leasing_email)
        except Exception as e:
            # print(e)
            leasing_email=''


        item = ProprtySitesItem()
        item['Property_Name'] = name
        item['Address'] = street
        item['City'] = city
        item['State'] = state
        item['Zip'] = zip_c
        item['GLA'] = sqft
        item['Description'] = desc
        item['Leasing_Contact_Name'] = leasing_agent_name
        item['Leasing_Contact_Phone'] = leasing_phone
        item['Leasing_Contact_Email'] = leasing_email
        # item['Property_Manager_Name'] = Property_Manager_Name
        # item['Site_Plan_URL'] = Site_Plan_URL
        item['Property_URL'] = response.url
        yield item


# execute("scrapy crawl store_730 -a list_id=730".split())