# -*- coding: utf-8 -*-

import datetime
import scrapy, json, requests, re
import html2text
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func
from scrapy.cmdline import execute

class Store423Spider(scrapy.Spider):
    name = 'store_423'
    allowed_domains = []
    not_export_data = True

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        try:
            page = 1
            header = {
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
                "Accept-Encoding": "gzip, deflate",
                "Upgrade-Insecure-Requests": "1",
                "Accept-Language": "en-GB,en-US;q=0.9,en;q=0.8",
                "User-Agent": "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Mobile Safari/537.36",
                "Connection": "keep-alive"}
            source_url = link = f'http://www.brixtoncapital.com/portfolio/'
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
                self.run_date) + '.html'
            yield scrapy.FormRequest(url=str(link), callback=self.get_store_list, headers=header,
                                     meta={'source_url': source_url,
                                           'file_path': file_path, 'proxy_type': self.proxy_type, 'page': page})
        except Exception as e:
            print(e)

    # Get data from the response
    def get_store_list(self, response):
        if not response.url.startswith('file://'):
            self.f1.page_save(response.meta['file_path'], response.body)

        try:
            try:
                divs = response.xpath(
                    '//div[@class="col-12-m col-8-sm col-6-md bottom"] | //div[@class="col-12-m col-8-sm col-6-md "]')
                for div in divs:

                    try:
                        Property_Name = div.xpath('.//div[@class="title"]/text()').extract_first()
                    except Exception as e:
                        print("Property_Name", e, response.url)

                    try:
                        addres_data = div.xpath('.//div[@class="details"]').extract_first().split('<br>')
                        length = (len(addres_data))
                        lastindex = (addres_data[-1])
                        if lastindex == "\r\n</div>":
                            length = 4
                        if length == 4:
                            address = addres_data[2].strip()
                            bunch = addres_data[3]
                            city = bunch.split(',')[0].strip()
                            state = bunch.split(',')[1]
                        if length == 3:
                            address = ''
                            bunch = addres_data[2]
                            city = bunch.split(',')[0].strip()
                            state = bunch.split(',')[1].strip()
                        if length == 5:
                            address1 = addres_data[2].strip()
                            address2 = addres_data[3].strip()
                            address = address1 + " " + address2.strip()
                            bunch = addres_data[4]
                            city = bunch.split(',')[0].strip()
                            state = bunch.split(',')[1].strip()
                        address = address.replace('&amp;', '&').strip()
                        address = address.strip(',')
                        state = state.replace('</div>', '').strip()
                    except Exception as e:
                        address = ''
                        city = ''
                        state = ''
                        print("Address", e, response.url)

                    try:
                        Description = ' '.join(div.xpath('.//div[@class="info"]//text()').extract()).strip()
                    except Exception as e:
                        Description = ''
                        print("Description", e, response.url)

                    try:
                        GLA = div.xpath('.//div[@class="details"]').extract_first().split('<br>')
                        print(GLA)
                        GLA = GLA[1].strip()
                        # if "SQ FT" in str(GLA):
                        #     GLA=GLA
                        # elif "SF" in str(GLA):
                        #     GLA = GLA
                        # else:
                        #     GLA=''
                    except Exception as e:
                        print("GLA", e, response.url)

                    try:
                        Leasing_Contact = response.xpath(
                            '//div[@class="col-12-m col-6-sm"][1]//div[@class="desc"]/text()').extract_first(
                            default='').strip()
                    except Exception as e:
                        print("Leasing_Contact", e, response.url)

                    try:
                        Leasing_Phone = response.xpath(
                            '//div[@class="col-12-m col-6-sm"][2]//div[@class="desc"]/text()').extract_first(
                            default='').strip()
                    except Exception as e:
                        print("Leasing_Phone", e, response.url)

                    try:
                        Leasing_Email = response.xpath(
                            '//div[@class="col-12-m col-6-sm"][2]//div[@class="desc"]/a[1]/text()').extract_first(
                            default='').strip()
                    except Exception as e:
                        print("Leasing_Email", e, response.url)


                    item = ProprtySitesItem()
                    item['Property_Name'] = Property_Name
                    item['Address'] = address
                    item['City'] = city
                    item['State'] = state
                    item['Description'] = Description
                    item['GLA'] = GLA
                    item['Leasing_Contact'] = Leasing_Contact
                    item['Leasing_Phone'] = Leasing_Phone
                    item['Leasing_Email'] = Leasing_Email
                    item['Property_URL'] = response.url
                    yield item
            except Exception as e:
                print(e)

        except Exception as e:
            print(e)

# execute('''scrapy crawl store_423 -a list_id=423 -a proxy_type='''.split())


