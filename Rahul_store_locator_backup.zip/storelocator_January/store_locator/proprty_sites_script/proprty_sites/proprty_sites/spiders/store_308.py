# -*- coding: utf-8 -*-
import scrapy
import json
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func
import datetime


class store_308_Spider(scrapy.Spider):
    name = 'store_308'
    # allowed_domains = ['www.example.com']
    start_urls = ['https://www.chaseprop.com/our-properties/']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)


    def parse(self, response):
        links= response.xpath('//div[@class="map-dropdown-results-area"]/ul/li/a/@href').extract()
        for link in links:
            yield scrapy.Request(url=link,callback=self.get_data)


    def get_data(self,response):
        item = ProprtySitesItem()
        address=response.xpath('//div[@class="property-title-area"]/ul/li[1]/h2/text()').get().split(',')[0].strip()
        item['Property_Name']=response.xpath('//h1/text()').get()

        item['City']=response.xpath('//div[@class="property-title-area"]/ul/li[2]/h2//text()').get().strip()
        item['State']=response.xpath('//div[@class="property-title-area"]/ul/li[2]/h2//text()').getall()[-1].strip()
        item['Address'] = address


        contact=response.xpath('//div[@id="availability"]//div[@class="relator-calling-cards"]/div//div[@class="realtor-info"]/h4/text()').getall()
        contact = '|'.join(contact)
        item['Contact'] = contact.strip('|')

        Phone= response.xpath('//div[@id="availability"]//div[@class="relator-calling-cards"]/div//div[@class="realtor-phone"]/a/@href').getall()
        Phone = '|'.join(Phone)
        item['Phone'] = Phone.strip('|').replace('tel:','')

        Email=response.xpath('//div[@id="availability"]//div[@class="relator-calling-cards"]/div//div[@class="realtor-email"]/a/@href').getall()
        Email = '|'.join(Email)
        item['Email'] = Email.strip('|')

        Avail_SQFT=[]
        Avail_SQFTS=response.xpath('//div[@class="property-availability-content-area"]/p/strong/text()').getall()
        if Avail_SQFTS!=[]:
            for avail_sq in Avail_SQFTS:
                if 'Please contact' in avail_sq:
                    continue
                else:
                    avail_sq=avail_sq.split('–')[-1].strip()
                    Avail_SQFT.append(avail_sq)
            item['Avail_SQFT'] = '|'.join(Avail_SQFT).strip('|')
        else:
            Avail_SQFTS = response.xpath('//div[@class="property-availability-content-area"]/h4/strong/text()').getall()
            if Avail_SQFTS != []:
                for avail_sq in Avail_SQFTS:
                    if 'Please contact'  in avail_sq:
                        continue
                    else:
                        avail_sq = avail_sq.split('–')[-1].strip()
                        Avail_SQFT.append(avail_sq)
                item['Avail_SQFT'] = '|'.join(Avail_SQFT).strip('|')
            else:
                Avail_SQFTS = response.xpath(
                    '//div[@class="property-availability-content-area"]/p/text()').getall()
                if Avail_SQFTS != []:
                    for avail_sq in Avail_SQFTS:
                        if 'Please contact' in avail_sq:
                            continue
                        else:
                            avail_sq = avail_sq.split('–')[-1].strip()
                            Avail_SQFT.append(avail_sq)
                    item['Avail_SQFT'] = '|'.join(Avail_SQFT).strip('|')

        SQFT=response.xpath('//li[@class="square-feet"]//text()').get().strip()
        item['SQFT']=SQFT

        site_plan_url=response.xpath('//p[contains(text(),"Site Plan")]/../@href').get(default='')
        if site_plan_url=='':
            item['Site_plan_URL'] =''
        else:
            item['Site_plan_URL'] =site_plan_url




        item['URL']=response.url
        yield item
        # print(item)

# from scrapy.cmdline import execute
# execute('''scrapy crawl store_308 -a list_id=308'''.split())