import json
import re
import scrapy
import requests
from scrapy.http import HtmlResponse
import datetime
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func


class Store496Spider(scrapy.Spider):
    name = "store_496"
    allowed_domains = []
    start_urls = ['http://ubproperties.propertycapsule.com/property/output/find/search']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def parse(self, response):
        text = re.findall(r'window.uniqueSpaces = (.*?);\nwindow.cid = 0;', response.text, re.DOTALL)[0]
        data_json = json.loads(text)
        for data in data_json:
            property_name = data['name']
            rename = re.sub(r'[\s\-]', '', property_name)
            link = f"http://ubproperties.propertycapsule.com/properties/{rename}"
            yield scrapy.Request(url=link, callback=self.get_data, meta={'data': data})

    def get_data(self, response):
        try:
            Property_URL = response.url
        except Exception as e:
            print("Property URL" + str(e))
        try:
            Property_Name = response.meta['data']['name']
        except Exception as e:
            Property_Name = ''
            print("Property_Name " + str(e))
        try:
            Address = response.meta['data']['address']
        except Exception as e:
            print(e)
            Address = ''
        try:
            City = response.meta['data']['city']
        except Exception as e:
            print(e)
            City = ''
        try:
            State = response.meta['data']['state']
        except Exception as e:
            print(e)
            State = ''
        try:
            Zip_code = response.meta['data']['zip']
        except Exception as e:
            print(e)
            Zip_code = ''
        try:
            gla = response.meta['data']['gla']
            if ',' in gla:
                GLA = gla.replace(',', '')
            else:
                GLA = gla
        except Exception as e:
            GLA = ' '
            print("gla " + str(e))
        try:
            Leasing_Contact = response.meta['data']['agentName']
        except Exception as e:
            Leasing_Contact = ''
            print("Leasing Contact " + str(e))
        try:
            Leasing_Contact_Phone = response.meta['data']['agentPhone']
        except Exception as e:
            Leasing_Contact_Phone = ''
            print("Leasing Contact Phone " + str(e))
        try:
            Leasing_Contact_Email = response.meta['data']['agentEmail']
        except Exception as e:
            Leasing_Contact_Email = ''
            print("Leasing Contact Email " + str(e))
        try:
            Site_Plan_URL = re.findall(r'</h4><img src="(.*?)" width="', response.text, re.DOTALL)
            if len(Site_Plan_URL) == 1:
                Site_Plan_URL = Site_Plan_URL[0]
                res = requests.get(Site_Plan_URL)
                response1 = HtmlResponse(url=res.url, body=res.content)
                if 'Not found.' == response1.text:
                    Site_Plan_URL = ' '
                else:
                    Site_Plan_URL = Site_Plan_URL
            else:
                Site_Plan_URL = ' '
        except Exception as e:
            Site_Plan_URL = ''
            print("Site Plan URL" + str(e))
        try:
            item = ProprtySitesItem()
            item['Property_Name'] = Property_Name
            item['Address'] = Address
            item['City'] = City
            item['State'] = State
            item['ZIP'] = Zip_code
            item['GLA'] = GLA
            item['Leasing_Contact'] = Leasing_Contact
            item['Leasing_Contact_Phone'] = Leasing_Contact_Phone
            item['Leasing_Contact_Email'] = Leasing_Contact_Email
            item['Site_Plan_URL'] = Site_Plan_URL
            item['Property_URL'] = Property_URL
            yield item
        except Exception as e:
            print("not insert " + str(e))


from scrapy.cmdline import execute
# execute("scrapy crawl store_496 -a list_id=496".split())