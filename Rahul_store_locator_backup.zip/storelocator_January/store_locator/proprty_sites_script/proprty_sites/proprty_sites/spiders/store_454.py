
import datetime
import re
import html2text
import scrapy
from scrapy.http import HtmlResponse
import string
from scrapy.cmdline import execute
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func


class rkcentersSpider(scrapy.Spider):
    name = 'store_454'
    allowed_domains = ['www.example.com']
    start_urls = ['https://www.rkcenters.com/']
    not_export_data = True

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def parse(self, response):

        urls = response.xpath('//*[@data-ubermenu-trigger="mouseover"]/a/@href').extract()
        del urls[-1]
        for url in urls:
            yield scrapy.Request(url=url,callback=self.parsedata,dont_filter=True)
            # break

    def parsedata(self,response):
        block = response.xpath('//*[@style="background-color:#CCC"]/../following-sibling::tbody/tr')
        for b in block:
            url = ''.join(b.xpath('./td[1]//a/@href').extract()).strip()
            if 'http' not in url:
                url = 'https://www.rkcenters.com' + url
            # print(url)
            info = ''.join(b.xpath('./td[3]//text()').extract()).strip()
            price = ''.join(b.xpath('./td[4]//text()').extract()).strip()
            yield scrapy.Request(url=url, callback=self.parseData2, dont_filter=True,meta={'info':info,'price':price})

    def parseData2(self,response):
        item = ProprtySitesItem()

        item['Property_Name'] = ''.join(re.findall(r'h1 class="title entry-title">(.*?)</h1>', response.text))
        try:
            infoq = len(str(response.meta['info']).split(','))
            info = str(response.meta['info']).split(',')
            print(infoq)
        except Exception as e:
            infoq = ''
            info = ''

        if infoq == 3:
            try:
                address = info[0]
            except:
                address = ''
            try:
                city = info[1].strip()
            except:
                city = ''
            try:
                state = info[2].split()[0].strip()
            except:
                state = ''
            try:
                zipc = info[2].split()[1].strip()
            except:
                zipc = ''

        elif infoq ==2:
            try:
                address = info[0]
            except:
                address = ''
            try:
                city = info[1].strip()
            except:
                city = ''
            try:
                state = info[2].split()[0].strip()
            except:
                state = ''
            try:
                zipc = info[2].split()[1].strip()
            except:
                zipc = ''

        else:
            print("error")
            address = ''
            city = ''
            state = ''
            zipc = ''

        item['Address'] = address
        item['City'] = city
        item['State'] = state
        item['Zip'] = zipc
        item['GLA'] = ''.join(response.xpath("//*[contains(text(),'TOTAL SQUARE')]/parent::div/h2/text()").extract()).strip()
        item['Description'] = ''.join(response.xpath('//*[@class="wpb_wrapper"]/ul/li//text()').extract()).strip()
        item['Brochure_URL'] = response.xpath('//*[@class="ubtn-link ult-adjust-bottom-margin ubtn-left ubtn-block "]/@href').extract_first(default="")
        item['Property_URL'] = response.url

        try:
            item['Leasing_Contact_Name_1'] = "New England Office"
        except:
            item['Leasing_Contact_Name_1'] = ''
        try:
            item['Leasing_Contact_Phone_1'] = "(781) 320-0001"
        except:
            item['Leasing_Contact_Phone_1'] = ''
        try:
            item['Leasing_Contact_Email_1'] = "leasingne@rkcenters.com"
        except:
            item['Leasing_Contact_Email_1'] = ''
        try:
            item['Leasing_Contact_Name_2'] = "Florida Office"
        except:
            item['Leasing_Contact_Name_2'] = ''
        try:
            item['Leasing_Contact_Phone_2'] = "(305) 949-4110"
        except:
            item['Leasing_Contact_Phone_2'] = ''
        try:
            item['Leasing_Contact_Email_2'] = "leasingfl@rkcenters.com"
        except:
            item['Leasing_Contact_Email_2'] = ''

        yield item


# execute(f'scrapy crawl store_454 -a list_id=454'.split())
