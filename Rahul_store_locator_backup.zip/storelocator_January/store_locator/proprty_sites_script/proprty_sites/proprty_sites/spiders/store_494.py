import datetime
import scrapy, json, requests, re
import html2text
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func

class TolsonentErprisesSpider(scrapy.Spider):
    name = 'store_494'
    allowed_domains = ['example.com']
    start_urls = ['http://unisonrealtypartners.com/projects/']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def parse(self, response):
        try:
            links = response.xpath('//*[@class="projects_holder_outer v3"]//article//*[@class="preview"]/@href').getall()
            for link in links:
                yield scrapy.FormRequest(url=link, callback=self.parse_data, dont_filter=True)
        except Exception as e:
            print(e)

    def parse_data(self, response):

        # id = response.meta['id']
        # try:
        #     f = open('E:/Anil/Html Pages/StoreLocator/tolsonenterprises/' + str(id) + '.html', 'wb')
        #     f.write(response.text.encode('utf-8'))
        #     print('Page Saved...', str(id))
        #     f.close()
        # except Exception as e:
        #     print(e)

        try:
            item = ProprtySitesItem()
            item['PropertyName'] = response.xpath('//*[@class="portfolio_single_text_holder"]/h2[1]/text()').get()
            if item['PropertyName'] == "Downloads":
                item['PropertyName'] = "HIGH POINTE COMMONS"

            try:
                addr = response.xpath('//*[contains(text(),"Address")]/following-sibling::p/a/text()').getall()
                if not addr:
                    addr = response.xpath('//*[contains(text(),"Address")]/following-sibling::p/text()').getall()

                if len(addr)>1:
                    addr[1].replace("North Carolina","NorthCarolina")
                    item['Address'] = addr[0].replace('\u2028','')
                    item['City'] = addr[1].split(',')[0].strip()
                    state_zip = addr[1].split(',')[1].strip()
                    item['State'] = re.findall(r'(\D+)',state_zip)[0].strip()
                    item['Zip'] = re.findall(r'(\d+)',state_zip)[0].strip()
                else :
                    if len(addr[0].split(','))>2:
                        item['Address'] = addr[0].split(',')[0].replace('\u2028','')
                        item['City'] = addr[0].split(',')[1].strip()
                        state_zip = addr[0].split(',')[2].strip()
                        item['State'] = re.findall(r'(\D+)',state_zip)[0].strip()
                        item['Zip'] = re.findall(r'(\d+)',state_zip)[0].strip()
                    else :
                        item['Address'] = addr[0].replace('\u2028','')
                        item['City'] = addr[0].split(',')[0].strip()
                        state_zip = addr[0].split(',')[1].strip()
                        item['State'] = re.findall(r'(\D+)', state_zip)[0].strip()
                        item['Zip'] = re.findall(r'(\d+)', state_zip)[0].strip()

            except Exception as e:
                print(e)

            try:
                gla = response.xpath('//*[contains(text(),"Total GLA")]/following-sibling::p/text()').get().replace(',','')
                item['GLA'] = re.findall(r'(\d+)',gla)[0]
            except:
                item['GLA'] = ''

            try:
                item['Description'] = response.xpath('//*[@class="portfolio_single_text_holder"]/p[1]/text()').get()
            except:
                item['Description'] = ''

            try:
                SitePlanURL = response.xpath('//*[contains(text(),"Downloads")]/following-sibling::a/@href').get()
                if not SitePlanURL:
                    SitePlanURL = response.xpath('//*[contains(text(),"DOWNLOADS")]/following-sibling::a/@href').get()
                item['SitePlanURL'] = SitePlanURL
            except:
                item['SitePlanURL'] = ''
            item['PropertyURL'] = response.url
            yield item
        except Exception as e:
            print(e)

# from scrapy import cmdline
# cmdline.execute("scrapy crawl store_494 -a list_id=494".split())