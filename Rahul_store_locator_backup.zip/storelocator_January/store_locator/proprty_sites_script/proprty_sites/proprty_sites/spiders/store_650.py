# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import re
from scrapy.http import HtmlResponse
import datetime
import scrapy, json, requests, re
import html2text
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func


class Store650Spider(scrapy.Spider):
    name = 'store_650'
    allowed_domains = []
    start_urls = []

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)
    def start_requests(self):
        try:
            page = 1
            source_url = link = f'https://pacificretail.com/properties/'

            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
                self.run_date) + '.html'
            yield scrapy.FormRequest(url=str(link), callback=self.firstlevel,
                                     meta={'source_url': source_url,
                                           'file_path': file_path, 'proxy_type': self.proxy_type, 'page': page})
        except Exception as e:
            print(e)

    def firstlevel(self, response):
        if not response.url.startswith('file://'):
            self.f1.page_save(response.meta['file_path'], response.body)
        try:
            source_url = response.meta['source_url']
            file_path = response.meta['file_path']
            proxy_type = response.meta['proxy_type']
            url = response.xpath('//*[@class="gt-overlay"]/a/@href').extract()
            for ul in url:
                yield scrapy.Request(url=ul, callback=self.get_store_list, dont_filter=True,meta={'source_url': source_url, 'file_path': file_path,
                                               'proxy_type': proxy_type})

        except Exception as e:
            print("firstlevel", e, response.url)

    # Get data from the response
    def get_store_list(self, response):
        if not response.url.startswith('file://'):
            self.f1.page_save(response.meta['file_path'], response.body)
        try:
            try:
                try:
                    Property_Name = re.findall(r'<title>(.*?)&#8211;', response.text)[0]
                except Exception as e:
                    Property_Name = ""
                    print("Property_Name", e, response.url)
                try:
                    addressbunch = response.xpath('//*[contains(text(),"MAP IT")]/../text()').extract()
                    if addressbunch == ['\n']:
                        addressbunch = response.xpath('//*[contains(text(),"MAP IT")]/../../h5[1]/text()').extract()
                    lenaddressbunch = len(addressbunch)
                    print(lenaddressbunch)
                    if lenaddressbunch == 5:
                        street = addressbunch[0]
                        street1 = addressbunch[1]
                        address = street + ' ' + street1
                        address = re.sub('[\t]|\n|\s\s+|\r', ' ', str(address)).strip()
                        bunch = addressbunch[2].strip()
                        if "," in str(bunch):
                            city = bunch.split(',')[0]
                            bunch1 = bunch.split(',')[1].strip()
                            state = bunch1.split(' ')[0]
                            zip = bunch1.split(' ')[1]
                        else:
                            city = bunch.split(' ')[0]
                            state = bunch.split(' ')[1]
                            zip = bunch.split(' ')[2]
                    if lenaddressbunch == 3:
                        street = addressbunch[0]
                        street1 = addressbunch[1]
                        address = street + ' ' + street1
                        address = re.sub('[\t]|\n|\s\s+|\r', ' ', str(address)).strip()
                        bunch = addressbunch[2].strip()
                        if "," in str(bunch):
                            city = bunch.split(',')[0]
                            bunch1 = bunch.split(',')[1].strip()
                            state = bunch1.split(' ')[0]
                            zip = bunch1.split(' ')[1]
                        else:
                            city = bunch.split(' ')[0]
                            state = bunch.split(' ')[1]
                            zip = bunch.split(' ')[2]
                    else:
                        if addressbunch != "" and lenaddressbunch != 5 and lenaddressbunch != 3:
                            address = addressbunch[0]
                            bunch = addressbunch[1].strip()
                            if "," in str(bunch):
                                city = bunch.split(',')[0]
                                bunch1 = bunch.split(',')[1].strip()
                                state = bunch1.split(' ')[0]
                                zip = bunch1.split(' ')[1]
                            else:
                                city = bunch.split(' ')[0]
                                state = bunch.split(' ')[1]
                                zip = bunch.split(' ')[2]
                except Exception as e:
                    addressbunch = ""

                if addressbunch == "":
                    try:
                        addressbunch = response.xpath(
                            '//*[contains(text(),"MAP IT")]/../preceding-sibling::span[2]/text()').extract()
                        lenaddressbunch = len(addressbunch)
                        print(lenaddressbunch)
                        if lenaddressbunch == 5:
                            street = addressbunch[0]
                            street1 = addressbunch[1]
                            address = street + ' ' + street1
                            address = re.sub('[\t]|\n|\s\s+|\r', ' ', str(address)).strip()
                            bunch = addressbunch[2].strip()
                            if "," in str(bunch):
                                city = bunch.split(',')[0]
                                bunch1 = bunch.split(',')[1].strip()
                                state = bunch1.split(' ')[0]
                                zip = bunch1.split(' ')[1]
                            else:
                                city = bunch.split(' ')[0]
                                state = bunch.split(' ')[1]
                                zip = bunch.split(' ')[2]
                        if lenaddressbunch == 3:
                            street = addressbunch[0]
                            street1 = addressbunch[1]
                            address = street + ' ' + street1
                            address = re.sub('[\t]|\n|\s\s+|\r', ' ', str(address)).strip()
                            bunch = addressbunch[2].strip()
                            if "," in str(bunch):
                                city = bunch.split(',')[0]
                                bunch1 = bunch.split(',')[1].strip()
                                state = bunch1.split(' ')[0]
                                zip = bunch1.split(' ')[1]
                            else:
                                city = bunch.split(' ')[0]
                                state = bunch.split(' ')[1]
                                zip = bunch.split(' ')[2]
                        else:
                            if addressbunch != "" and lenaddressbunch != 5 and lenaddressbunch != 3:
                                address = addressbunch[0]
                                bunch = response.xpath(
                                    '//*[contains(text(),"MAP IT")]/../preceding-sibling::span[1]/text()').extract_first()
                                if "," in str(bunch):
                                    city = bunch.split(',')[0]
                                    bunch1 = bunch.split(',')[1].strip()
                                    state = bunch1.split(' ')[0]
                                    zip = bunch1.split(' ')[1]
                                else:
                                    city = bunch.split(' ')[0]
                                    state = bunch.split(' ')[1]
                                    zip = bunch.split(' ')[2]
                    except Exception as e:
                        city = ""
                        state = ""
                        zip = ""
                        address = ""

                try:
                    GLA = response.xpath("//*[contains(text(),'TOTAL GLA')]/following-sibling::div/text()").get('')
                except Exception as e:
                    print("GLA", e, response.url)
                try:
                    Brochure_URL = response.xpath(
                        '//*[contains(text(),"LEASING BROCHURE")]/@href').extract_first().strip()
                except Exception as e:
                    Brochure_URL = ""

                try:
                    SitePlan_URL = response.xpath('//*[contains(text()," SITE PLAN")]/@href').extract_first().strip()
                except Exception as e:
                    SitePlan_URL = ""

                Leasing_Contact_name = response.xpath(
                    "//*[contains(text(),'SPECIALTY LEASING')]/../following-sibling::h5[1]//text()").get('')
                if Leasing_Contact_name == "":
                    Leasing_Contact_name = response.xpath(
                        "//*[contains(text(),'SPECIALTY LEASING')]/../h5//text()").get('')

                Leasing_Contact_Email = response.xpath(
                    "//*[contains(text(),'SPECIALTY LEASING')]/../following-sibling::p/span//text()").get('')
                if Leasing_Contact_Email == "":
                    Leasing_Contact_Email = response.xpath(
                        "//*[contains(text(),'SPECIALTY LEASING')]/../p/a[2]/text()").get('')
                if Leasing_Contact_Email == "":
                    Leasing_Contact_Email = response.xpath(
                        "//*[contains(text(),'SPECIALTY LEASING')]/../following-sibling::p/a[2]/text()").get('')

                Leasing_Contact_Phone = response.xpath(
                    "//*[contains(text(),'SPECIALTY LEASING')]/../following-sibling::p//text()").get('')
                if Leasing_Contact_Phone == "":
                    Leasing_Contact_Phone = response.xpath(
                        "//*[contains(text(),'SPECIALTY LEASING')]/./following-sibling::p/a/text()").get('')

                item = ProprtySitesItem()
                item['Property_Name'] = Property_Name
                item['Address'] = address
                item['City'] = city
                item['State'] = state
                item['Zip_Code'] = zip
                item['GLA'] = GLA
                item['Leasing_Contact_Name'] = Leasing_Contact_name
                item['Leasing_Contact_Phone'] = Leasing_Contact_Phone
                item['Leasing_Contact_Email'] = Leasing_Contact_Email
                item['Brochure_URL']=Brochure_URL
                item['SitePlan_URL'] = SitePlan_URL
                item['Property_URL'] = response.url
            except Exception as e:
                print(e)

        except Exception as e:
            print(e)

#from scrapy.cmdline import execute
#execute("scrapy crawl store_650 -a list_id=650".split())



