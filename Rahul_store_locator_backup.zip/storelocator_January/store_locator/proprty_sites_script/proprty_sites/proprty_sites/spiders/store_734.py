import datetime
import scrapy, json, requests, re
import html2text
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func

class store_325_Spider(scrapy.Spider):
    name = 'store_734'
    allowed_domains = ['www.example.com']
    start_urls = ['https://www.nrdc.com/properties/search/-/-/-/0;200000']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def parse(self, response):
        property_links = response.xpath('//tr//td//a/@href').extract()
        print(len(property_links))
        links = list(dict.fromkeys(property_links))
        print(len(links))
        print(links)
        for link in links:
            url = "https://www.nrdc.com" + str(link)
            print(url)
            yield scrapy.FormRequest(url=url,callback=self.Detail,dont_filter=True)

    def Detail(self,response):
        try:
            Property_Name = response.xpath('//*[@class="property-details-title"]/text()').extract_first().strip()
            Address = response.xpath('//div[@class="property-details-address"]/text()[1]').extract_first().strip()
            Address2 = response.xpath('//div[@class="property-details-address"]/text()[2]').extract_first().strip()
            City = Address2.split(',')[0]
            State = Address2.split(',')[-1].split(' ')[-2]
            Zip_Code = Address2.split(',')[-1].split(' ')[-1]
            try:
                GL = response.xpath('//*[contains(text(),"Gross Leasable Area")]/../div[2]/text()').extract_first()
                GL = GL.replace(',','').strip()
                GLA = re.findall(r"(\d+)",GL)[0]
            except: GLA = ''
            try:dscr = " ".join(response.xpath('//*[contains(text(),"Detail")]/../div[3]/div//li/text()').getall())
            except: dscr = ''
            try:Leasing_contact_name = response.xpath('//div[@class="name"]/text()').extract_first()
            except: Leasing_contact_name = ''
            try:Leasing_contact_phone =response.xpath('//div[@class="info"]/div/text()[1]').extract_first()
            except:Leasing_contact_phone = ''
            try:Leasing_contact_email= response.xpath('//div[@class="info"]/div//a/text()').extract_first()
            except: Leasing_contact_email = ''
            # # try:
            # #     i2 = response.xpath('//div[@class="property-plan-image-wrapper"]/img/@src').extract()
            # #     for i in i2:
            # #         PlanImage = 'https://www.nrdc.com/'+str(i)
            # #         print(PlanImage)
            # # except Exception as e:
            # #     PlanImage = ''
            # #     print("PlanImage ------>> ",e)
            # PlanImage ='https://www.nrdc.com/'
            # try:
            #     i1 = response.xpath('//*[@class="property-slideshow-item "]/img/@src').extract()
            #     for j in i1:
            #         propertyImage = 'https://www.nrdc.com/'+str(j)
            #         print(propertyImage)
            # except Exception as e:
            #     propertyImage = ''
            #     print('propertyImage ----->> ',e)
            siteplanURL = response.xpath('//*[@class="property-plan-image-wrapper"]/img/@src').extract_first()
            if siteplanURL == '' or siteplanURL == None:
                siteplanURL = ''
            else:
                siteplanURL = 'https://www.nrdc.com/'+ siteplanURL


            item=ProprtySitesItem()
            item['Property_Name'] = Property_Name
            item['Address'] = str(Address)
            item['City'] = City
            item['State'] = State
            item['Zip_Code'] = Zip_Code
            item['GLA'] = GLA
            item['Description'] = dscr
            item['Leasing_contact_name'] = Leasing_contact_name
            item['Leasing_contact_phone'] = Leasing_contact_phone
            item['Leasing_contact_email'] = Leasing_contact_email
            item['siteplanURL'] =siteplanURL
            item['URL'] = response.url  # self.f1.country_dict.get(item['country'].lower())
            print(item)
            yield item
        except Exception as e:
            print('Problem insertion ---------->>  ',e)



if __name__ == '__main__':
    from scrapy.cmdline import execute
    execute('''scrapy crawl store_734 -a list_id=734'''.split())