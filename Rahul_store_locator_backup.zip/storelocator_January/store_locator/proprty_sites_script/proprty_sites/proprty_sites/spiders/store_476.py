# -*- coding: utf-8 -*-
import scrapy
import json
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func
import datetime


class store_476_Spider(scrapy.Spider):
    name = 'store_476'
    # allowed_domains = ['www.example.com']
    start_urls = ['https://haagenco.com/properties/']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)


    def parse(self, response):
        links=response.xpath('//ul[@class="properties"]/li/a/@href').getall()
        for link in links:
            yield scrapy.Request(url=link, callback=self.finaldata)

    def finaldata(self, response):

        try:
            store_name=response.xpath('//div[@class="property-header"]/h1/text()').get().strip()
        except Exception as e:
            print(e,response.url)
            store_name=''


        # try:
        #     Address=response.xpath('//*[contains(text(),"City")]/following-sibling::span/text()').get().strip()
        # except Exception as e:
        #     print(e,response.url)
        #     Address=''


        try:
            city=response.xpath('//*[contains(text(),"City")]/following-sibling::span/text()').get().strip()
        except Exception as e:
            print(e,response.url)
            city=''

        try:
            zip_code = response.xpath('//*[contains(text(),"Zip Code")]/following-sibling::span/text()').get().strip()
        except Exception as e:
            print(e,response.url)
            zip_code=''

        try:
            GLA=response.xpath('//*[contains(text(),"Building Size")]/following-sibling::span/text()').get().strip().split()[0].strip().replace(',','').strip()
        except Exception as e:
            print(e,response.url)
            GLA=''

        try:
            l_c_n_1=response.xpath('//div[@class="broker-details"]/h4//text()').getall()[0].strip()
        except Exception as e:
            print(e, response.url)
            l_c_n_1=''

        try:
            l_c_n_2=response.xpath('//div[@class="broker-details"]/h4//text()').getall()[1].strip()
        except Exception as e:
            print(e, response.url)
            l_c_n_2=''

        try:
            l_c_p_1=response.xpath('//p[@itemprop="telephone"]/text()').getall()[0].strip()
        except Exception as e:
            print(e, response.url)
            l_c_p_1 = ''

        try:
            l_c_p_2 = response.xpath('//p[@itemprop="telephone"]/text()').getall()[1].strip()
        except Exception as e:
            print(e, response.url)
            l_c_p_2 = ''

        try:
            Site_Plan_URL= 'https://haagencompany.commercialcafe.com'+response.xpath('//ul[@class="multi-columns"]/li[2]/a/@href').get()
        except Exception as e:
            print(e,response.url)
            Site_Plan_URL=''

        try:
            item = ProprtySitesItem()
            item['Property_Name'] = store_name
            # item['Address'] = Address
            item['City'] = city
            item['Zip']=zip_code
            item['GLA'] = GLA
            item['Leasing_Contact_Name_1']=l_c_n_1
            item['Leasing_Contact_Phone_1']=l_c_p_1
            item['Leasing_Contact_Name_2'] =l_c_n_2
            item['Leasing_Contact_Phone_2'] =l_c_p_2

            item['Site_Plan_URL'] = Site_Plan_URL

            item['Property_URL'] = response.url


            # print (item)
            yield item
        except Exception as e:
            print("item", e)


# from scrapy.cmdline import execute
# execute('''scrapy crawl store_476 -a list_id=476'''.split())
