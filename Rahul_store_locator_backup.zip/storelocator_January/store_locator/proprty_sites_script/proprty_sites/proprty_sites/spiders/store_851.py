# -*- coding: utf-8 -*-
import re
import datetime
import scrapy,os,logging,hashlib
import requests,json
from lxml.html import open_in_browser
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func
import datetime
import html2text


class Store851Spider(scrapy.Spider):
    name = 'store_851'
    allowed_domains = []
    start_urls = []
    # not_export_data = True

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        self.f1.set_details(self.list_id, run_date)
        try:

            source_url = "https://schwaberholdings.com/wp-admin/admin-ajax.php?action=store_search&lat=40.75369&lng=-73.99916&max_results=100&search_radius=500"


            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(run_date) + '.html'
            yield scrapy.FormRequest(url=str(source_url), callback=self.secondlevel,
                                     # headers=headers,
                                     meta={'source_url': source_url,
                                           # 'search_term': search_term,
                                           'file_path': file_path, 'proxy_type': self.proxy_type})
        except Exception as e:
            print(e)

    def secondlevel(self, response):
        # if not response.url.startswith('file://'):
        #     self.f1.page_save(response.meta['file_path'], response.body)
        try:
            source_url = response.meta.get('source_url', '')
            body = json.loads(response.body)
            if body != '':
                le = len(body)
                for i in range(0, le):
                    try:
                        Property_Name = body[i]['store']
                    except Exception as e:
                        print(e)

                    try:
                        address = body[i]['address']
                    except Exception as e:
                        print(e)

                    try:
                        City = body[i]['city']
                    except Exception as e:
                        print(e)

                    try:
                        state = body[i]['state']
                    except Exception as e:
                        print(e)

                    try:
                        zip_code = body[i]['zip']
                    except Exception as e:
                        print(e)

                    try:
                        Country = body[i]['country']
                    except Exception as e:
                        print(e)

                    try:
                        latitude = body[i]['lat']
                    except Exception as e:
                        print(e)

                    try:
                        longitude = body[i]['lng']
                    except Exception as e:
                        print(e)

                    try:
                        url = body[i]['permalink']
                        if "http" in url:
                            url = url
                        else:
                            url = "https://schwaberholdings.com" + url

                    except Exception as e:
                        print(e)
                    res = requests.get(url)
                    response = HtmlResponse(url='example.@xyz', body=res.content)
                    a = response.text

                    try:
                        Description = ''.join(response.xpath('//*[@class="highlights-list"]/li//text()').extract()).strip()
                    except Exception as e:
                        Description = ""
                        print(e)

                    try:
                        Brochure_URL = "https://schwaberholdings.com" + response.xpath('//*[@class="et_pb_button et_pb_button_0 module-inline-block et_pb_bg_layout_dark"]/@href').extract_first().strip()
                    except Exception as e:
                        Brochure_URL = ""
                        print(e)



                    item = ProprtySitesItem()
                    item['Property_Name'] = Property_Name
                    item['Address'] = address
                    item['City'] = City
                    item['State'] = state
                    item['zip_code'] = zip_code
                    item['Country'] = Country
                    item['latitude'] = latitude
                    item['longitude'] = longitude
                    item['country_code'] = "US"
                    item['coming_soon'] = "1"
                    item['Description'] = Description
                    item['Brochure_URL'] = Brochure_URL
                    item['url'] = url
                    yield item

                    # yield scrapy.FormRequest(url=url, callback=self.get_store_list,
                    #                             meta={'Property_Name':Property_Name,'address':address,'City':City,'state':state,'zip_code':zip_code,'Country':Country,'latitude':latitude,'longitude':longitude,'url':url})
        except Exception as e:
            print(e)

# execute('''scrapy crawl store_851 -a list_id=851'''.split())

    # def get_store_list(self, response):
    #     try:
    #         Property_Name = response.meta['Property_Name']
    #         address = response.meta['address']
    #         City = response.meta['City']
    #         state = response.meta['state']
    #         zip_code = response.meta['zip_code']
    #         Country = response.meta['Country']
    #         latitude = response.meta['latitude']
    #         longitude = response.meta['longitude']
    #         url = response.meta['url']
            # try:
            #     Description = ''.join(response.xpath('//*[@class="highlights-list"]/li//text()').extract()).strip()
            # except Exception as e:
            #     Description = ""
            #     print(e)
            #
            # try:
            #     Brochure_URL = "https://schwaberholdings.com" + response.xpath('//*[@class="et_pb_button et_pb_button_0 module-inline-block et_pb_bg_layout_dark"]/@href').extract_first().strip()
            # except Exception as e:
            #     Brochure_URL = ""
            #     print(e)




        #
        #     item = ProprtySitesItem()
        #     item['Property_Name'] = Property_Name
        #     item['Address'] = address
        #     item['City'] = City
        #     item['State'] = state
        #     item['zip_code'] = zip_code
        #     item['Country'] = Country
        #     item['latitude'] = latitude
        #     item['longitude'] = longitude
        #     item['country_code'] = "US"
        #     item['coming_soon'] = "1"
        #     # item['Description'] = Description
        #     # item['Brochure_URL'] = Brochure_URL
        #     item['url'] = url
        #     yield item
        #
        # except Exception as e:
        #     print(e)

# execute('''scrapy crawl store_851 -a list_id=851'''.split())