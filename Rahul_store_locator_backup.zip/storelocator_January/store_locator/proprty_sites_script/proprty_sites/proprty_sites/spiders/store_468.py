import datetime
import hashlib

import scrapy, json, requests, re
import html2text
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func

class BrookfieldpropertiesretailSpider(scrapy.Spider):
    name = 'store_468'
    allowed_domains = []
    start_urls = ['https://www.brookfieldpropertiesretail.com/properties.html']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def parse(self, response):
        name=response.xpath('//div[@class="card hoverable property-search-result"]//div//span[1]//text()').getall()
        city=response.xpath('//div[@class="card hoverable property-search-result"]//div//span[2]//text()').getall()
        links=response.xpath('//div[@class="card hoverable property-search-result"]//a//@href').getall()
        # print(len(links))
        # print(len(city))
        # print(len(name))
        for link,name,cit in zip(links,name,city):
            link='https://www.brookfieldpropertiesretail.com'+link
        # header={"Accept":"application/json, text/javascript, */*; q=0.01",
        #         "Accept-Encoding":"gzip, deflate, br",
        #         "Accept-Language":"en-US,en;q=0.9",
        #         "Connection":"keep-alive",
        #         "Host":"www.regencycenters.com",
        #         "Sec-Fetch-Mode":"cors",
        #         "Sec-Fetch-Site":"same-origin",
        #         "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36",
        #         "X-Requested-With":"XMLHttpRequest"}
            yield scrapy.FormRequest(url=link, callback=self.get_store,meta={'name':name,'cit':cit})


    def get_store(self,response):
        item=ProprtySitesItem()

        item['Property_Name'] = response.meta['name']
        Address = response.xpath('//div[@class="address"]/span[1]/text()').get(default='')
        item['Address'] = str(Address)
        item['City'] = response.meta['cit'].split(',')[0]
        item['State'] =response.meta['cit'].split(',')[1]
        item['Zip_Code'] = response.xpath('//div[@class="address"]/span[5]/text()').get(default='')

        item['GLA'] = response.xpath('//div[contains(text(),"Total Retail Space")]/following-sibling::div/text()').get(default='')
        item['Description'] = response.xpath('//div[@class="title-and-text"]//div[2]//p/text()').get(default='')
        item['Leasing_contact_name'] = response.xpath('//h3[contains(text(),"Retail Leasing")]/../../../..//div[@class="contact-card"]/div[1]/text()').get(default='').replace('\n','').replace('\t','').strip()
        item['Leasing_contact_phone'] =response.xpath('//h3[contains(text(),"Retail Leasing")]/../../../..//div[@class="contact-card"]/div[3]//a//text()').get(default='').replace('\n','').replace('\t','').strip()
        if '@' in item['Leasing_contact_phone']:
            item['Leasing_contact_phone'] = response.xpath('//h3[contains(text(),"Retail Leasing")]/../../../..//div[@class="contact-card"]/div[2]//a//text()').get(default='').replace('\n', '').replace('\t', '').strip()
            item['Leasing_contact_email'] = response.xpath('//h3[contains(text(),"Retail Leasing")]/../../../..//div[@class="contact-card"]/div[3]//a//text()').get(default='').replace('\n', '').replace('\t', '').strip()
        else:
            item['Leasing_contact_email'] = response.xpath('//h3[contains(text(),"Retail Leasing")]/../../../..//div[@class="contact-card"]/div[4]//a//text()').get(default='').replace('\n','').replace('\t','').strip().replace("\xa0","")
        item['URL'] = response.url # self.f1.country_dict.get(item['country'].lower())
        print(item)
        yield item

        # "Property_Name,Address, City,State,Zip_Code,GLA,Description,Leasing_contact_name,Leasing_contact_phone,Leasing_contact_email,URL"


if __name__ == '__main__':
    from scrapy.cmdline import execute
    execute('''scrapy crawl store_468 -a list_id=468'''.split())
