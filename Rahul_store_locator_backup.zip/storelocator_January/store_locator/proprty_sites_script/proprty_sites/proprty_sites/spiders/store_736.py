# -*- coding: utf-8 -*-
import datetime
import scrapy, json, requests, re
import html2text
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func

h = html2text.HTML2Text()


class hadlerSpider(scrapy.Spider):
    name = 'store_736'
    allowed_domains = ['hadler.com']
    start_urls = ['http://hadler.com/retail-centers/']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def parse(self, response):

        links = response.xpath('//*[@class="av_textblock_section "]//h3/a/@href').getall()
        divs = response.xpath('//*[@class="av_textblock_section "]//ul')

        for link,div in zip(links,divs):
            GLA = div.xpath(".//*[contains(text(),'square feet')]//text()").get()
            GLA = ''.join(re.findall('\d+',GLA))
            if 'http' not in link:
                link = 'http://hadler.com'+link
            yield scrapy.Request(url=link,callback=self.parseData2,dont_filter=True,meta={'GLA':GLA})

    def parseData2(self, response):

        text = html2text.HTML2Text()
        text.ignore_images = True
        text.ignore_links = True
        text.ignore_emphasis = True
        text.body_width = 0
        text.ignore_tables = True
        try:
            a = response.xpath('//*[@class="avia_textblock redbox-text "]/div[1]//text()').get()
            if a =='' or a==None or a=='\n':
                a = response.xpath('//*[@class="avia_textblock redbox-text "]/p//text()').get()
                if 'AVAILABLE FOR LEASE' in a or a=='\n' or a=='' or a==None:
                    a = response.xpath('//*[@class="avia_textblock redbox-text "]/p[2]//text()').get()
                    if a=='' or a==None or a=='\n':
                        a = response.xpath('//*[@class="avia_textblock redbox-text "]/p/span/text()').get()
                        # if a=='' or a==None or a=='\n':
        except Exception as e:
            a = response.xpath('//*[@class="avia_textblock redbox-text "]/div[1]//text()').getall()[1]

        try:
            GLA = response.meta['GLA']
        except Exception as e:
            GLA =''

        try:
            address = a.split(',')[0]
        except Exception as e:
            address = ''

        try:
            city = a.split(',')[1]
        except Exception as e:
            city =''

        try:
            state = a.split(',')[2].strip().split()[0].strip()
        except Exception as e:
            state = ''

        try:
            zipcode = a.split(',')[2].strip().split()[1].strip()
        except Exception as e:
            zipcode = ''
        try:
            site_plan_img = re.findall(" avia_image\\' src=\\'(.*?)\\'",response.text)[1]
            if site_plan_img == '' or site_plan_img == None:
                site_plan_img = response.xpath("//*[contains(text(),'VIEW SITE PLAN PDF')]/parent::a/@href").get()
        except Exception as e:
            site_plan_img = ''
            site_plan_img = response.xpath("//*[contains(text(),'VIEW SITE PLAN PDF')]/parent::a/@href").get()

        try:
            description = ''.join(response.xpath('//*[@class="avia_textblock  "]/ul/li//text()').getall())
            if description =='' or description ==None:
                description = response.xpath('//*[@class="avia_textblock  "]/p[1]/text()').get()

        except Exception as e:
            description = ''

        try:
            Property_Name = re.findall('<title>(.*?)</title>',response.text)[0].split('-')[0]
        except Exception as e:
            Property_Name = ''

        item = ProprtySitesItem()

        item['Property_Name'] = Property_Name
        item['Address'] = address
        item['City'] = city
        item['State'] = state
        item['Zip'] = zipcode
        item['Description'] = description
        item['Site_Plan_URL'] = site_plan_img
        item['Property_URL'] = response.url
        item['GLA'] = GLA
        yield item

from scrapy.cmdline import execute
# execute("scrapy crawl store_736 -a list_id=736".split())