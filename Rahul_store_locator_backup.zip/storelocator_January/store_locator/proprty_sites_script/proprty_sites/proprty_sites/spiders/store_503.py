# -*- coding: utf-8 -*-
import scrapy
import json
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func
import datetime


class store_503_Spider(scrapy.Spider):
    name = 'store_503'
    # allowed_domains = ['www.example.com']
    start_urls = ['https://www.wsdevelopment.com/property-archive/']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)



    def parse(self, response):


        links=response.xpath('//div[@class="property-blocks"]/div/a/@href').getall()
        for link in links:
            yield scrapy.Request(url=link, callback=self.finaldata)

    def finaldata(self, response):

        try:
            store_name=response.xpath('//h2[@class="title"]/text()').get().strip()
        except Exception as e:
            print(e,response.url)
            store_name=''


        try:
            Address=response.xpath('//li[@class="address"]/text()').get().strip()
        except Exception as e:
            print(e,response.url)
            Address=''


        try:
            city=response.xpath('//li[@class="address"]/p/text()').get().strip().split(',')[0].strip()

        except Exception as e:
            print(e,response.url)
            city=''

        try:
            State = response.xpath('//li[@class="address"]/p/text()').get().strip().split(',')[-1].strip().split()[0]
        except Exception as e:
            print(e, response.url)
            State = ''

        try:
            zip_code = response.xpath('//li[@class="address"]/p/text()').get().strip().split(',')[-1].strip().split()[-1]
        except Exception as e:
            print(e,response.url)
            zip_code=''

        try:
            GLA=response.xpath('//span[contains(text(),"GLA")]//following-sibling::p/text()').get().strip().replace('Square Feet','').replace(',','').strip()
        except Exception as e:
            print(e,response.url)
            GLA=''

        try:
            Description=' '.join(response.xpath('//h2[@class="title"]/following-sibling::p[2]/text()').getall()).strip()
        except Exception as e:
            print(e, response.url)
            Description=''

        try:
            l_c_n=response.xpath('//span[contains(text(),"Lease Inquiry")]//following-sibling::p//text()[normalize-space()]').getall()[0].strip()
        except Exception as e:
            print(e, response.url)
            l_c_n=''

        try:
            l_c_p=response.xpath('//span[contains(text(),"Lease Inquiry")]//following-sibling::p//text()[normalize-space()]').getall()[1].strip()
        except Exception as e:
            print(e, response.url)
            l_c_p = ''

        try:
            l_c_e =response.xpath('//span[contains(text(),"Lease Inquiry")]//following-sibling::p//text()[normalize-space()]').getall()[-1].strip()
        except Exception as e:
            print(e, response.url)
            l_c_e = ''

        try:
            item = ProprtySitesItem()
            item['Property_Name'] = store_name
            item['Address'] = Address
            item['City'] = city
            item['State']=State
            item['Zip']=zip_code
            item['GLA'] = GLA
            item['Description']=Description
            item['Leasing_Contact_Name'] = l_c_n
            item['Leasing_Contact_Phone']=l_c_p
            item['Leasing_Contact_Email'] =l_c_e

            item['Property_URL'] = response.url


            # print (item)
            yield item
        except Exception as e:
            print("item", e)


# from scrapy.cmdline import execute
# execute('''scrapy crawl store_503 -a list_id=503'''.split())
