import re
import pgeocode
import scrapy, os, logging, hashlib
import requests, json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from selenium import webdriver
from selenium.webdriver.firefox.options import Options
# from store_locators.items import StoreLocatorsItem
# from store_locators.spiders.common_functions import Func
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func

from scrapy.cmdline import execute

import datetime


class Store427Spider(scrapy.Spider):
    name = 'store_427'
    allowed_domains = []


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)


    def start_requests(self):
        try:
            source_url = link = f'https://www.combined.biz/portfolio/properties/'
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(self.run_date) + '.html'
            yield scrapy.FormRequest(url=str(link), callback=self.firstlevel,
                                     meta={'source_url': source_url,
                                           'file_path': file_path, 'proxy_type': self.proxy_type})
        except Exception as e:
            logging.log(logging.ERROR, e)

    def firstlevel(self, response):

        try:
            source_url = response.meta['source_url']
            file_path = response.meta['file_path']
            proxy_type = response.meta['proxy_type']
            links = response.xpath('//*[@class="properties-list"]/div/a/@href').extract()

            for link in links:
                yield scrapy.FormRequest(url=link, callback=self.get_store_list,
                                         meta={'source_url': source_url, 'file_path': file_path,'proxy_type': proxy_type})

        except Exception as e:
            print("firstlevel", e, response.url)

    # Get data from the response
    def get_store_list(self, response):
        try:
            try:
                Property_Name = response.xpath('//h2/text()').extract_first(default='').strip()
            except Exception as e:
                print("store_name", e, response.url)

            try:
                address_link = response.xpath('//iframe/@src').extract_first()
                address_data = requests.get(address_link)
                data = re.findall(r' initEmbed\((.*?)\);', address_data.text)[0]
                ll_json = json.loads(data)
                d = ll_json[21][3][13]
                if d:
                    d = d.split(',')
                    address = d[0]
                    city = d[1].strip()
                    state = d[-2].strip().split(' ')[0].strip()
                    zip_code = d[-2].strip().split(' ')[-1].strip()
            except Exception as e:
                address = Property_Name
                city_data = response.xpath('//h2/span/text()').extract_first().split(',')
                city = city_data[0].strip()
                state = city_data[-1].strip().split(' ')[0].strip()
                zip_code = city_data[-1].strip().split(' ')[-1].strip()

            try:
                Description = ' '.join(response.xpath('//*[@class="content-full"]//li/text()').extract())
            except Exception as e:
                print(e)

            try:
                GLA = response.xpath('normalize-space(//*[contains(text(),"GLA")]/../span/text())').extract_first(default='').replace(',', '')
                if GLA:
                    GLA = re.findall(r'(\d+)', GLA)[0]
            except Exception as e:
                print(e)

            try:
                Plan_URL = response.xpath('//*[@class="leasing-plan"]/img/@src').extract_first(default='')
            except Exception as e:
                print(e)


            URL = response.url
            try:
                store_hash_id = bytes(f"{Property_Name} {address} {state} {city} {zip_code} {GLA} {Description} {Plan_URL} {URL}", encoding='utf-8')
                store_hash_id = int(hashlib.md5(store_hash_id).hexdigest(), 16) % (10 ** 16)
            except Exception as e:
                print(e)


            item = ProprtySitesItem()
            item['Property_Name'] = Property_Name
            item['Address'] = address
            item['City'] = city
            item['State'] = state
            item['zip_code'] = zip_code
            item['Description'] = Description
            item['GLA'] = GLA
            item['Site_Plan_URL'] = Plan_URL
            item['Property_URL'] = URL
            yield item

        except Exception as e:
            logging.log(logging.ERROR, e)

    def response_html_path(self, request):
        return request.meta['fpath']


# execute('''scrapy crawl store_427 -a list_id=427 -a proxy_type='''.split())