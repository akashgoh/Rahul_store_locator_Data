# -*- coding: utf-8 -*-
import html2text
import scrapy,os,hashlib
import requests,json
import re
import calendar
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func
import datetime
from pprint import pprint as pp


class Store517Spider(scrapy.Spider):
    name = 'store_517'
    allowed_domains = []
    start_urls = ['http://www.alicepizza.it/en/puntivendita/']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()

    def parse(self, response):
        run_date = str(datetime.datetime.today()).split()[0]
        self.f1.set_details(self.list_id, run_date)
        header = {
            'Accept': 'application/json, text/javascript, */*; q=0.01',
            'Accept-Encoding': 'gzip, deflate, br',
            'Accept-Language': 'en-US,en;q=0.9',
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'Host': 'www.alicepizza.it',
            'Origin': 'http://www.alicepizza.it',
            'Referer': 'http://www.alicepizza.it/en/puntivendita/',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36',
            'X-Requested-With': 'XMLHttpRequest'
        }
        data = {
            'action': 'get_puntivendita'
        }
        url = 'http://www.alicepizza.it/wp-admin/admin-ajax.php'
        yield scrapy.FormRequest(url=url, callback=self.get_store_list, method="POST", headers=header, formdata=data)

    def get_store_list(self, response):
        data_json = json.loads(response.text)
        text = html2text.HTML2Text()
        text.ignore_images = True
        text.ignore_links = True
        text.ignore_emphasis = True
        text.body_width = 0
        text.ignore_tables = True

        for data in data_json:
            if data['name'] == 'Italia':
                print(len(data['cities']))
                for cc in range(len(data['cities'])):
                    store_count = len(data['cities'][cc]['stores'])
                    for sc in range(store_count):
                        store_name = data['cities'][cc]['stores'][sc]['name']
                        if store_name:
                            city = data['cities'][cc]['stores'][sc]['city'][0]['name']
                            longitude = data['cities'][cc]['stores'][sc]['lng']
                            latitude = data['cities'][cc]['stores'][sc]['lat']
                            store_number = data['cities'][cc]['stores'][sc]['id']
                            source_url = data['cities'][cc]['stores'][sc]['permalink']
                            try:
                                address_detail = address = data['cities'][cc]['stores'][sc]['indirizzo']
                                address_line_2 = ''
                                for i in ['Unit', 'STE', 'Ste', 'SUITE', 'Suite', 'suite', 'Suit', 'SUIT', 'suit', 'UNIT', 'unit', 'ste']:
                                    for aw in address_detail.split(' '):
                                        if i == aw:
                                            if address_detail.split(' ').index(aw) != 0:
                                                address = address_detail.split(i)[0].strip()
                                                address_line_2 = i + ' ' + address_detail.split(i)[-1].strip()
                                                break
                            except Exception as e:
                                address = ''
                                print("address " + str(e))
                            try:
                                phone_number = data['cities'][cc]['stores'][sc]['telefono']
                                if re.match(r'[a-z]|[A-Z]', phone_number):
                                    phone_number = re.findall(r'\+(.*?)$', phone_number, re.DOTALL)
                                    if len(phone_number) == 1:
                                        phone_number = f"+{phone_number[0].strip()}"
                                else:
                                    phone_number = phone_number
                            except Exception as e:
                                phone_number = ''
                                print("phone_number " + str(e))

                            item = ProprtySitesItem()
                            item['store_name'] = store_name
                            item['address'] = address
                            item['address_line_2'] = address_line_2
                            item['city'] = city
                            item['state'] = ''
                            item['phone_number'] = phone_number
                            item['email_address'] = ''
                            item['latitude'] = latitude
                            item['longitude'] = longitude
                            item['store_number'] = store_number
                            item['zip_code'] = ''
                            item['coming_soon'] = 0
                            item['source_url'] = source_url
                            item['country'] = item['country_code'] = 'IT'
                            yield scrapy.Request(url=source_url, callback=self.get_store_details, meta={'item': item})
            else:
                print("differ country")

    def get_store_details(self, response):
        hour = response.xpath('//*[@class="col-lg-6 descriptionSinglePunto"]//p[last()]/text()').extract_first()
        if hour:
            hour = hour.strip()
        response.meta['item']['store_hours'] = hour
        yield response.meta['item']


# execute('''scrapy crawl store_517 -a list_id=517'''.split())
