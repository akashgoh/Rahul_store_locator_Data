# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import re

import scrapy, os, logging, hashlib
import requests, json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func
# from store_locators.items import StoreLocatorsItem
# from store_locators.spiders.common_functions import Func
import datetime


class Store184Spider(scrapy.Spider):
    name = 'store_184'
    allowed_domains = []


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        try:
            # self.f1.set_details(self.list_id, run_date)
            # if self.f1.search_by != 'link':
            #     search_terms = self.f1.get_search_term(self.f1.search_by)
            #     print(search_terms)
            #     # Page save code (File path should be combination of list id , country_code , date of running and serach term if exists)
            #     search_terms = ''
            #     for search_term in (search_terms):
            #         source_url = link = 'https://16handles.com/locations/'
            #         file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(search_term) + '_' + str(run_date) + '.html'
            #         if os.path.exists(file_path):
            #             link = 'file://' + file_path.replace('\\', '/')
            #         yield scrapy.FormRequest(url=str(link), callback=self.get_store_list,
            #                                  meta={'source_url': source_url, 'search_term': search_term,
            #                                        'file_path': file_path, 'proxy_type': self.proxy_type})
            # else:
            source_url = link = 'https://www.theedgefitnessclubs.com/locations/'
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(run_date) + '.html'
            yield scrapy.FormRequest(url=str(link), callback=self.firstlevel,
                                     meta={'source_url': source_url,
                                           'file_path': file_path, 'proxy_type': self.proxy_type})
        except Exception as e:
            logging.log(logging.ERROR, e)

    def firstlevel(self, response):
        try:
            source_url = response.meta['source_url']
            file_path = response.meta['file_path']
            proxy_type = response.meta['proxy_type']
            links = response.xpath('//*[@class="hs-menu-item hs-menu-depth-3"]/a/@href').extract()
            # count = 0
            # for link in links[:42]:
            #     count = count+1
            #     print(count)
            #     print(link)
            for link in links[:42]:
                header = {
                    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
                    "accept-language": "en-US,en;q=0.9",
                    "cache-control": "max-age=0",
                    "referer": "https://www.theedgefitnessclubs.com/locations/",
                    "sec-fetch-dest": "document",
                    "sec-fetch-mode": "navigate",
                    "sec-fetch-site": "same-origin",
                    "sec-fetch-user": "?1",
                    "upgrade-insecure-requests": "1",
                    "user-agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36"
                }
                yield scrapy.FormRequest(url=link, callback=self.get_store_list, headers=header,
                                         meta={'source_url': source_url, 'file_path': file_path,
                                               'proxy_type': proxy_type})

        except Exception as e:
            print("firstlevel", e, response.url)

    # Get data from the response
    def get_store_list(self, response):
        # print(response.url)
        try:
            if not response.url.startswith('file://'):
                self.f1.page_save(response.meta['file_path'], response.body)
            search_term = response.meta.get('search_term', '')
            filt = response.xpath('//*[@id="hs_cos_wrapper_module_1549288077122400_"]/h3/text()').extract_first(default='')
            if 'Opening' in filt:
                item = ProprtySitesItem()
                try:
                    if response.url.endswith('/'):
                        store_name = 'The Edge Fitness Clubs - ' + response.url.split('/')[-2].replace('-',' ').title()
                    else:
                        store_name = 'The Edge Fitness Clubs - ' + response.url.split('/')[-1].replace('-', ' ').title()
                except Exception as e:
                    print("store_name", e, response.url)

                try:
                    phone_number = response.xpath('//*[@id="hs_cos_wrapper_module_1549288077122400_"]/p/strong/span/text()').get()
                    if not phone_number:
                        phone_number = response.xpath('//*[contains(@href,"tel:")]/text()').get().replace('%20','').replace('=', '')
                        if phone_number == '877-The-Edge':
                            phone_number = ''
                    else:
                        if phone_number == '877-The-Edge':
                            phone_number = ''
                        else:
                            phone_number = phone_number.replace('%20', '').replace('=', '')
                    if not phone_number:
                        phone_number = response.xpath('//*[contains(text(),"Phone:")]/text()|//*[@id="hs_cos_wrapper_module_1549288077122400_"]/p[2]/span/text()').extract_first()
                        if phone_number:
                            if ':' in phone_number:
                                phone_number = phone_number.split(':')[-1].strip().replace('&nbsp;','')
                        else:
                            phone_number = ''

                except Exception as e:
                    print("phone_number", e, response.url)

                try:
                    address = ''.join(response.xpath('//*[@id="hs_cos_wrapper_module_1549288077122400_"]/p/text()|//*[@id="hs_cos_wrapper_module_1549288077122400_"]/p[2]/span/text()').get())
                    if '989 Northwest Plaza Drive St. Ann' in address:
                        address = response.xpath('//*[@id="hs_cos_wrapper_module_1549288077122400_"]/p/text()').getall()[1]
                    if 'Phone:' in address:
                        address = address.replace('Phone:', '').strip()
                    if not address:
                        address = response.xpath('//*[contains(@href,"mailto")]/../span/text()').get().strip()
                    else:
                        address = address.strip()
                        try:
                            address = re.findall(r'^(.*\d{5})',address)[0]
                        except:
                            address = response.xpath('//*[@id="hs_cos_wrapper_module_1549288077122400_"]/p[2]/span/text()').get() + ' ' + response.xpath('//*[@id="hs_cos_wrapper_module_1549288077122400_"]/p[2]/text()').get()

                    address_detail = add = address.split(',')[0]
                    address_line_2 = ''
                    for i in ['unit', 'suite', 'suit', 'michigan/farmington-hills/']:
                        for aw in address_detail.split(' '):
                            if i.title() == aw:
                                add = address_detail.split(i.title())[0].strip()
                                address_line_2 = i.title() + ' ' + address_detail.split(i.title())[-1].strip()
                                break
                except Exception as e:
                    print("address", e, response.url)

                if address == phone_number:
                    phone_number = ''

                try:
                    city = store_name.split('-')[-1].strip()
                except Exception as e:
                    print("city", e, response.url)

                try:
                    state = address.split(',')[-1].strip().split(' ')
                    if len(state) == 3:
                        state = state[1].strip()
                    else:
                        state = state[0].strip()
                except Exception as e:
                    print("state", e, response.url)

                try:
                    zip_code = re.findall('\d{5}',address.split(',')[-1].strip().split(' ')[-1].strip())[0]
                except Exception as e:
                    print("zip_code", e, response.url)

                try:
                    email_address = response.xpath('//*[contains(@href,"mailto")]/text()').get()
                    if not email_address:
                        email_address = response.xpath('//*[@id="hs_cos_wrapper_module_1549288077122400_"]//a/text()').get()
                    else:
                        email_address = email_address.split(':')[-1]

                    if email_address:
                        email_address = email_address.strip()
                    else:
                        email_address = ''

                except Exception as e:
                    print("Email", e, response.url)

                # item['search_term'] = search_term
                item['store_name'] = store_name
                item['address'] = add
                item['address_line_2'] = address_line_2
                item['city'] = city
                item['state'] = state
                item['zip_code'] = zip_code
                item['phone_number'] = phone_number
                item['email_address'] = email_address
                item['coming_soon'] = 1
                item['source_url'] = response.url
                item['country_code'] = item['country'] = 'US'  # self.f1.country_dict.get(item['country'].lower())
                if item['country_code'] == 'US' and len(item['state']) > 2:
                    item['state'] = self.f1.state_dict.get(state, '')
                yield item

            else:
                try:
                    item = ProprtySitesItem()
                    try:
                        store_name = 'The Edge Fitness Clubs - ' + response.url.split('/')[-2].replace('-', ' ').title()
                    except Exception as e:
                        print("store_name", e, response.url)

                    try:
                        phone_number = response.xpath('//*[contains(@href,"tel:")]/@href').get()#//*[@class="contact-links__link contact-links__link--phone"]/@href|//*[@id="hs_cos_wrapper_module_1549288077122400_"]//strong[2]/text()
                        if not phone_number:
                            phone_number = response.xpath('//*[contains(text(),"Phone:")]/text()').extract_first()
                            if ':' in phone_number:
                                phone_number = phone_number.split(':')[-1].strip().replace('&nbsp;', '')
                        else:
                            phone_number = phone_number.split(':')[-1].strip().replace('%20','').replace('=','')
                    except Exception as e:
                        print("phone_number", e, response.url)

                    try:
                        address = ''
                        address1 = response.xpath('//*[@class="location-info__address"]/text()').extract()
                        for a in address1:
                            address = address + ' ' + a.strip().replace('\n','')
                        address = address.strip()
                        if not address:
                            address1 = address = response.xpath('//*[@id="hs_cos_wrapper_module_1549288077122400_"]/p[2]/text()').extract_first(default='').strip()
                        if not address:
                            address1 = address = response.xpath('//*[@id="hs_cos_wrapper_module_1549288077122400_"]/p/span/text()').extract_first(default='').strip()
                        if not address:
                            address1 = address = response.xpath('//*[@id="hs_cos_wrapper_module_1549288077122400_"]//strong/text()').extract_first().split('-')[-1].strip()
                        if ("4025 Veteran's Memorial" in address) or ("36577 Warren Rd" in address):
                            address_detail = add = address.split('.')[0]
                        else:
                            address_detail = add = address.split(',')[0]
                        address_line_2 = ''
                        for i in ['unit', 'suite', 'suit', 'ste']:
                            for aw in address_detail.split(' '):
                                if i.title() == aw:
                                    add = address_detail.split(i.title())[0].strip()
                                    address_line_2 = i.title() + ' ' + address_detail.split(i.title())[-1].strip()
                                    break
                    except Exception as e:
                        print("address", e, response.url)

                    try:
                        if ("4025 Veteran's Memorial" in address) or ("36577 Warren Rd" in address):
                            city = ''.join(address.split(',')[0].strip().split('.')[1:])
                        else:
                            comma = address1.count(',')
                            if comma == 2:
                                city = address1.split(',')[1].strip()
                            else:
                                city = address1[-1].strip().split(',')[0].strip()

                    except Exception as e:
                        print("city", e, response.url)

                    try:
                        if ("4025 Veteran's Memorial" in address) or ("36577 Warren Rd" in address):
                            state = address.split(',')[-1].strip().split(' ')[0]
                        else:
                            comma = address1.count(',')
                            if comma == 2:
                                state = address1.split(',')[-1].strip().split(' ')[0].strip()
                            else:
                                state = address1[-1].strip().split(',')[-1].strip().split(' ')[0]

                    except Exception as e:
                        print("state", e, response.url)
                    try:
                        if ("4025 Veteran's Memorial" in address) or ("36577 Warren Rd" in address):
                            zip = address.split(',')[-1].strip().split(' ')[-1]
                        else:
                            comma = address1.count(',')
                            if comma == 2:
                                zip = address1.split(',')[-1].strip().split(' ')[-1].strip()
                            else:
                                zip = address1[-1].strip().split(',')[-1].strip().split(' ')[-1]
                        zip_code = re.findall('\d{5}', zip)[0]
                    except Exception as e:
                        print("zip_code", e, response.url)

                    try:
                        email_address = response.xpath('//*[@class="contact-links__link contact-links__link--email"]/@href').get()
                        if not email_address:
                            email_address = response.xpath('//*[contains(@href,"mailto")]/text()').extract_first(default='')
                        if email_address:
                            email_address = email_address.split(':')[-1]
                        else:
                            email_address = ''
                    except Exception as e:
                        print("Email", e, response.url)

                    try:
                        store_hours = {}
                        figure = response.xpath('//figure')
                        for f in figure:
                            key = f.xpath('.//h3/text()').extract_first().replace(':','')
                            hours = '|'.join(f.xpath('.//ul/li//text()').extract()).strip().replace('\n','')
                            store_hours[key] = hours.strip('|')


                    except Exception as e:
                        print("store_hours", e, response.url)

                    # item['search_term'] = search_term
                    item['store_name'] = store_name
                    item['address'] = add
                    item['address_line_2'] = address_line_2
                    item['city'] = city
                    item['state'] = state
                    item['zip_code'] = zip_code
                    item['phone_number'] = phone_number
                    item['email_address'] = email_address
                    item['store_type'] = ''
                    item['coming_soon'] = 0
                    item['source_url'] = response.url
                    item['country_code'] = item['country'] = 'US'  # self.f1.country_dict.get(item['country'].lower())
                    item['store_hours'] = store_hours
                    if item['country_code'] == 'US' and len(item['state']) > 2:
                        item['state'] = self.f1.state_dict.get(state, '')
                    yield item
                except Exception as e:
                    print(e)

        except Exception as e:
            logging.log(logging.ERROR, e)

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_184 -a list_id=184'''.split())