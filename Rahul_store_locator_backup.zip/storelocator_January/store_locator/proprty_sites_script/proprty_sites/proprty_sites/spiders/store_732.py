# -*- coding: utf-8 -*-
import datetime
import scrapy, json, requests, re
import html2text
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func


class store_732_Spider(scrapy.Spider):
    name = 'store_732'
    allowed_domains = ['']
    start_urls = ['http://fairwayinvestments.com/our-properties/?']


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        url = 'http://fairwayinvestments.com/our-properties/?'
        yield scrapy.FormRequest(url=url, callback=self.parse1)

    def parse1(self, response):
        link = response.xpath('//div[@id="propertyResults"]//a/@href').extract()
        for links in link:
        # links = 'http://fairwayinvestments.com/property-detail/?propid=85&prop=Harbor_Plaza'
            yield scrapy.FormRequest(url=links,dont_filter=True, callback=self.parse2)

    def parse2(self, response):

        try:
            property_name = response.xpath('//div[@class="large-10 align-center cell text-center property-details"]/h1/em/text()').get()
        except Exception as e:
            print(e)
            property_name = ''

        try:
            description = response.xpath('//div[@class="large-10 align-center cell text-center property-details"]/p/em/text()').get()
        except Exception as e:
            print(e)
            description = ''

        try:
            address = response.xpath('//div[@class="large-10 align-center cell text-center property-details"]/h5/strong/text()').get()
        except Exception as e:
            print(e)
            address = ''

        try:
            property_address = address.split('|')[0]
        except Exception as  e:
            print(e)
            property_address = ''

        try:
            add1 = address.split('|')[1]
        except Exception as e:
            print(e)
            add1 = ''
        try:
            city = add1.split(',')[0]
        except Exception as e:
            print(e)
            city = ''
        try:
            add2 = add1.split(',')[1]
        except Exception as e:
            print(e)
            add2 = ''
        try:
            state = add2.split(' ')[-2]
        except Exception as e:
            print(e)
            state = ''
        try:
            zip = add2.split(' ')[-1]
        except Exception as e:
            print(e)
            zip = ''


        try:
            property_manager_name = response.xpath('//div[@class="grid-x grid-padding-x"]/div[2]/div[1]/div[2]/text()[2]').get()
        except Exception as e:
            print(e)
            property_manager_name = ''

        try:
            property_manager_phone = response.xpath('//div[@class="grid-x grid-padding-x"]/div[2]/div[1]/div[2]/text()[4]').get()
            if '-' not in property_manager_phone:
                property_manager_phone = response.xpath('//div[@class="grid-x grid-padding-x"]/div[2]/div[1]/div[2]/text()[6]').get()
        except Exception as e:
            print(e)
            property_manager_phone = ''

        try:
            property_manager_email = response.xpath('//div[@class="grid-x grid-padding-x"]/div[2]/div[1]/div[2]/text()[5]').get()
            if '@' not in property_manager_email:
                property_manager_email = response.xpath('//div[@class="grid-x grid-padding-x"]/div[2]/div[1]/div[2]/text()[6]').get()
                print(property_manager_email)
                if '@' not in property_manager_email:
                    property_manager_email = response.xpath('//div[@class="grid-x grid-padding-x"]/div[2]/div[1]/div[2]/text()[7]').get()
                # else:
                #     property_manager_email = 'ok'
            print(property_manager_email)
        except Exception as e:
            print(e)
            property_manager_email = 'ok'

        try:
            leasing_name = response.xpath('//div[@class="grid-x grid-padding-x"]/div[2]/div[2]/div[2]/text()[2]').get()
        except Exception as e:
            print(e)
            leasing_name = ''

        try:
            # leasing_phone = re.findall(r'Cell: (.*?)<br />',response.text())[1]
            leasing_phone = response.xpath('//div[@class="grid-x grid-padding-x"]/div[2]/div[2]/div[2]/text()[6]').get()
            print(leasing_phone)
            if '-' not in leasing_phone:
                leasing_phone = response.xpath('//div[@class="grid-x grid-padding-x"]/div[2]/div[2]/div[2]/text()[4]').get()
                if '-' not in leasing_phone:
                    leasing_phone = response.xpath('//div[@class="grid-x grid-padding-x"]/div[2]/div[2]/div[2]/text()[7]').get()
                    if '-' not in leasing_phone:
                        leasing_phone = response.xpath('//div[@class="grid-x grid-padding-x"]/div[2]/div[2]/div[2]/text()[5]').get()
                        if '-' not in leasing_phone:
                            leasing_phone = response.xpath('//div[@class="grid-x grid-padding-x"]/div[2]/div[2]/div[2]/text()[6]').get()
        except Exception as e:
            print(e)
            leasing_phone = ''

        try:
            leasing_email = response.xpath('//div[@class="grid-x grid-padding-x"]/div[2]/div[2]/div[2]/a[1]/text()').get()
            if leasing_email == None or '@' not in leasing_email:
                leasing_email = response.xpath('//div[@class="grid-x grid-padding-x"]/div[2]/div[2]/div[2]/text()[6]').get()
                if '@' not in leasing_email:
                    leasing_email = response.xpath('//div[@class="grid-x grid-padding-x"]/div[2]/div[2]/div[2]/text()[7]').get()
                    if '@' not in leasing_email:
                        leasing_email = response.xpath('//div[@class="grid-x grid-padding-x"]/div[2]/div[2]/div[2]/text()[8]').get()
                        if '@' not in leasing_email:
                            leasing_email = response.xpath('//div[@class="grid-x grid-padding-x"]/div[2]/div[2]/div[2]/text()[9]').get()
            leasing_email = re.sub('\n|\r|\t','',leasing_email)

        except Exception as e:
            print(e)
            leasing_email = ''
            # if leasing_email == '' or leasing_email == None or '@' not in leasing_email:
            #     try:
            #         leasing_email = response.xpath('//div[@class="grid-x grid-padding-x"]/div[2]/div[2]/div[2]/text()[7]').get()
            #     except Exception as e:
            #         try:
            #             leasing_email = response.xpath('//div[@class="grid-x grid-padding-x"]/div[2]/div[2]/div[2]/text()[9]').get()
            #         except Exception as e:
            #             try:
            #                 leasing_email = response.xpath('//div[@class="grid-x grid-padding-x"]/div[2]/div[2]/div[2]/text()[8]').get()
            #             except Exception as e:
            #                 leasing_email =''

        try:
            site_plan = response.xpath('//div[@class="grid-x grid-padding-x"]/div[3]/div[1]//a/@href').get()
        except Exception as e:
            print(e)
            site_plan = ''

        try:
            broucher_url = response.xpath('//div[@class="grid-x grid-padding-x"]/div[3]/div[2]//a/@href').get()
            if broucher_url == '' or broucher_url == None:
                broucher_url = response.xpath('//div[@class="grid-x grid-padding-x"]/div[3]/div[1]//a/@href').get()
        except Exception as e:
            print(e)
            broucher_url = ''

        lks = "".join(response.url)

        item = ProprtySitesItem()
        item['property_name'] = property_name
        item['description'] = description
        item['property_address'] = property_address
        item['city'] = city
        item['state'] = state
        item['zip'] = zip
        item['property_manager_name'] = property_manager_name
        item['property_manager_phone'] = property_manager_phone
        item['property_manager_email'] = property_manager_email
        item['leasing_name'] = leasing_name
        item['leasing_phone'] = leasing_phone
        item['leasing_email'] = leasing_email
        item['site_plan'] =  site_plan
        item['broucher_url'] = broucher_url
        item['lks'] = lks

        yield item
# property_name,description,property_address,city,state,zip,property_manager_name,property_manager_phone,property_manager_email,leasing_name,leasing_phone,leasing_email,site_plan,broucher_url,lks
from scrapy.cmdline import execute
# execute("scrapy crawl store_732 -a list_id=732".split())