# -*- coding: utf-8 -*-
import hashlib
import scrapy
import datetime
import scrapy, json, requests, re
import html2text
from scrapy.cmdline import execute

from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func

class PreitSpider(scrapy.Spider):
    name = 'store_320'
    allowed_domains = ['example.com']
    start_urls = ['https://www.preit.com/properties/mall-portfolio/']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)


    def parse(self, response):
        try:
            data = re.findall(r'var propertydata =(.*?)/\* ]]> \*/', response.text, re.DOTALL)[0].replace('\\','')
            urls = re.findall(r'"link":"(.*?)"', data)
            for url in urls:
                url = url.replace('https://www.preit.com/news/','')
                url = 'https://www.preit.com/properties/mall-portfolio/' + url
                yield scrapy.FormRequest(url=url, callback=self.parse_data, dont_filter=True)
        except Exception as e:
            print(e)

    def parse_data(self, response):

        # uniqueid = int(hashlib.md5(bytes(str(response.url) + str(datetime.date.today()), "utf8")).hexdigest(), 16) % (10 ** 30)
        # try:
        #     f = open('E:/Anil/Html Pages/StoreLocator/preit/' + str(uniqueid) + '.html', 'wb')
        #     f.write(response.text.encode('utf-8'))
        #     print('Page Saved...', str(uniqueid))
        #     f.close()
        # except Exception as e:
        #     print(e)

        try:
            item = ProprtySitesItem()
            item['Property_Name'] = response.xpath('//*[@class="entry-title"]/text()').get()
            addr = response.xpath('//*[@class="property-info__contact-address"]/text()').getall()
            item['Address'] = addr[0].strip()
            item['City'] = addr[1].split(',')[0].strip()
            if '19090' in addr[1]:
                item['State'] = addr[1].split(',')[1].strip()
                item['zip_code'] = addr[1].split(',')[2].strip()
            else:
                statezip = addr[1].split(',')[1].strip()
                item['State'] = statezip.split()[0]
                item['zip_code'] = statezip.split()[1]

            try:item['GLA'] = response.xpath('//*[@class="property-info__details-stat"]/text()').get().replace(',','')
            except:item['GLA'] = ''

            try:item['Inline_Leasing_1'] = response.xpath('//*[@class="property-info__contact"]/div[2]/div/span[2]/text()').get()
            except:item['Inline_Leasing_1'] = ''

            try:item['Leasing_1_Phone'] = response.xpath('//*[@class="property-info__contact"]/div[2]/div/span[3]/a/text()').get()
            except:item['Leasing_1_Phone'] = ''

            try:item['Inline_Leasing_2'] = response.xpath('//*[@class="property-info__contact"]/div[3]/div/span[2]/text()').get()
            except:item['Inline_Leasing_2'] = ''

            try:item['Leasing_2_Phone'] = response.xpath('//*[@class="property-info__contact"]/div[3]/div/span[3]/a/text()').get()
            except:item['Leasing_2_Phone'] = ''

            try:item['Box_n_Outparcel_Leasing'] = response.xpath('//*[@class="property-info__contact"]/div[4]/div/span[2]/text()').get()
            except:item['Box_n_Outparcel_Leasing'] = ''

            try:item['Box_n_Outparcel_Leasing_Phone'] = response.xpath('//*[@class="property-info__contact"]/div[4]/div/span[3]/a/text()').get()
            except:item['Box_n_Outparcel_Leasing_Phone'] = ''

            try:item['Partnership_Marketing'] = response.xpath('//*[@class="property-info__contact"]/div[5]/div/span[2]/text()').get()
            except:item['Partnership_Marketing'] = ''

            try:item['Partnership_Marketing_Phone'] = response.xpath('//*[@class="property-info__contact"]/div[5]/div/span[3]/a/text()').get()
            except:item['Partnership_Marketing_Phone'] = ''

            try:item['Leasing_1_Email'] = response.xpath('//*[@class="property-info__contact"]/div[2]/a/@href').get().replace('mailto:','')
            except:item['Leasing_1_Email'] = ''

            try:item['Leasing_2_Email'] = response.xpath('//*[@class="property-info__contact"]/div[3]/a/@href').get().replace('mailto:','')
            except:item['Leasing_2_Email'] = ''

            try:item['Box_n_Outparcel_Leasing_Email'] = response.xpath('//*[@class="property-info__contact"]/div[4]/a/@href').get().replace('mailto:','')
            except:item['Box_n_Outparcel_Leasing_Email'] = ''

            try:item['Partnership_Marketing_Email'] = response.xpath('//*[@class="property-info__contact"]/div[5]/a/@href').get().replace('mailto:','')
            except:item['Partnership_Marketing_Email'] = ''

            try:item['Mall_Website'] = response.xpath('//*[@class="property-info__site btn"]/@href').get()
            except:item['Mall_Website'] = ''

            try:item['Plan_Url'] = response.xpath('//*[@id="site-plan"]//img/@src').get()
            except:item['Plan_Url'] = ''

            item['URL'] = response.url
            yield item
        except Exception as e:
            print(e)

#ID,Property_Name,Address,City,State,zip_code,GLA,Inline_Leasing_1,Leasing_1_Phone,Inline_Leasing_2,Leasing_2_Phone,
# Box_n_Outparcel_Leasing,Box_n_Outparcel_Leasing_Phone,Partnership_Marketing,Partnership_Marketing_Phone,Leasing_1_Email,
# Leasing_2_Email,Box_n_Outparcel_Leasing_Email,Partnership_Marketing_Email,Mall_Website,Plan_Url,URL


# execute("scrapy crawl store_320 -a list_id=320".split())