import logging
import os
import re

import datetime
import scrapy, json, requests, re
import html2text
from scrapy.cmdline import execute

from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func

class Store709Spider(scrapy.Spider):
    name = 'store_709'
    allowed_domains = []

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        try:
            # if self.f1.search_by != 'link':
            #     search_terms = self.f1.get_search_term(self.f1.search_by)
            #     print(search_terms)
            #     for search_term in (search_terms):
            #         source_url = link = 'https://www.risepartners.net/portfolio'
            #         file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(search_term) + '_' + str(self.run_date) + '.html'
            #         if os.path.exists(file_path):
            #             link = 'file://' + file_path.replace('\\','/')
            #
            #         header = {
            #                 "Upgrade-Insecure-Requests": "1",
            #                 "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36",
            #                 "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
            #                 "Sec-Fetch-Site": "none",
            #                 "Sec-Fetch-Mode": "navigate",
            #                 "Sec-Fetch-User": "?1",
            #                 "Sec-Fetch-Dest": "document"}
            #         yield scrapy.FormRequest(url=str(link), callback=self.property_links, meta={'source_url': source_url,'search_term': search_term,'file_path':file_path}, headers=header)
            # else:
            source_url = link = 'https://www.risepartners.net/portfolio'
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(self.run_date) + '.html'
            yield scrapy.FormRequest(url=str(link), callback=self.property_links,meta={'source_url': source_url,'file_path': file_path})

        except Exception as e:
            logging.log(logging.ERROR, e)


    # Get data from the response
    def property_links(self, response):
        all_links = response.xpath('//div[@class="sqs-block-content"]/div//figure/a/@href').getall()
        for links in all_links:
            link = 'https://www.risepartners.net' + str(links)
            yield scrapy.FormRequest(url=link, dont_filter=True, callback=self.parse)
            # print(link)

    def parse(self,response):
        item = ProprtySitesItem()
        property_name = response.xpath('//div[@class="col sqs-col-12 span-12"]/div[@class="row sqs-row"]/div/div/div/h1/text()').get()
        print(property_name)
        add = response.xpath('//div[@class="sqs-block map-block sqs-block-map"]/@data-block-json').get()
        address = add.split('"addressLine1":')[1].split(',"addressLine2"')[0]
        city = add.split(',"addressLine2":')[1].split(',"addressCountry"')[0].split(',')[0]
        state = add.split(',"addressLine2":')[1].split(',"addressCountry"')[0].split(',')[1]
        zip_code = add.split(',"addressLine2":')[1].split(',"addressCountry"')[0].split(',')[-1]

        description  = response.xpath('//div[@class="sqs-block-content"]/p/text()').get()
        if "PAYTON PARK" in property_name:
            BrochureURL = 'https://static1.squarespace.com/static/5a57891b90bade59dedd4dc1/t/5e1e2129b53e9b48f49f45de/1579032875432/payton-park-brochure.pdf'
            item['Type'] = "Retail"
            item['Anchor'] = "  "
            item['BrochureURL'] = BrochureURL
            item['GLA'] = "231,820"
            item['SitePlanURL'] = 'https://images.squarespace-cdn.com/content/v1/5a57891b90bade59dedd4dc1/1583355148206-8B1GSJW7BNNEL1CE6BA2/ke17ZwdGBToddI8pDm48kNjaqyhA9PIfO0A8uSK8F2MUqsxRUqqbr1mOJYKfIPR7LoDQ9mXPOjoJoqy81S2I8N_N4V1vUb5AoIIIbLZhVYxCRW4BPu10St3TBAUQYVKcVwiMXy0_LgceVXG1CKh67s4NpXkC1wtBCPvtLnmLRI7jl66nGcb0b9zIzKbSRBV8/payton-park-siteplan-new-march-2020.jpg?format=1000w'
        elif "Clarksville Commons " in property_name:
            BrochureURL = 'https://static1.squarespace.com/static/5a57891b90bade59dedd4dc1/t/5e1dfe7e6d383e527aeac06e/1579024001830/rise-partners-clarksville-commons-brochure.pdf'
            item['Type'] = ""
            item['BrochureURL'] = BrochureURL
            item['GLA'] = ""
            item['Anchor'] = str(response.xpath('//*[@id="block-f256476cac145f0219df"]/div/ul/li[2]/p/text()').getall())
            item['SitePlanURL'] = 'https://images.squarespace-cdn.com/content/v1/5a57891b90bade59dedd4dc1/1579025381572-SZAAAM25PH7BX2RRHPMM/ke17ZwdGBToddI8pDm48kGtYifcxn3m5EUb4Y0ND36d7gQa3H78H3Y0txjaiv_0fDoOvxcdMmMKkDsyUqMSsMWxHk725yiiHCCLfrh8O1z5QHyNOqBUUEtDDsRWrJLTmEczKEiHaQrO44vfJ0kKvIO0YDMQgbGeSEu8PTQQTGkwcZ8jmYL4GzXWqwzwBMQGy/clarksville-commons-siteplan.jpg?format=1000w'
        elif "EASLEY/TOWN AND COUNTRY SHOPPING CENTER" in property_name:
            BrochureURL = 'https://static1.squarespace.com/static/5a57891b90bade59dedd4dc1/t/5e611cf64ae5d240e8e97698/1583422720531/rise-partners-easley-town-and-country-brochure.pdf'
            item['Type'] = " "
            item['Anchor'] = " "
            item['BrochureURL'] = BrochureURL
            item['GLA'] = " "
            item['SitePlanURL'] = 'https://images.squarespace-cdn.com/content/v1/5a57891b90bade59dedd4dc1/1583422935738-3CDLVD9S8G95LFJI64S8/ke17ZwdGBToddI8pDm48kPoM1oP6zbnQm5TY8F1FdJYUqsxRUqqbr1mOJYKfIPR7LoDQ9mXPOjoJoqy81S2I8N_N4V1vUb5AoIIIbLZhVYxCRW4BPu10St3TBAUQYVKcBL9-sfhFC9vgUkOX3g4cBicSYHgJxQr8MipZ6jlmT0waMQWSITlQb30A0vsNUSkL/easley-siteplan-march-2020.jpg?format=1000w'
        elif "JACKSON PLAZA " in property_name:
            BrochureURL = 'https://static1.squarespace.com/static/5a57891b90bade59dedd4dc1/t/5e1e2a2a6bf4cf739d045ca9/1579035189165/jackson-plaza-brochure.pdf'
            item['Type'] = "Retail"
            item['BrochureURL'] = BrochureURL
            item['GLA'] = "340,000"
            item['Anchor'] = response.xpath('//*[@id="yui_3_17_2_1_1597306908834_608"]/li[3]/p//text()').get()
            item['SitePlanURL'] = 'https://images.squarespace-cdn.com/content/v1/5a57891b90bade59dedd4dc1/1583355488275-M6EXUN7SFLE5S62H2AMZ/ke17ZwdGBToddI8pDm48kA_Ln3LpYUafszzuF63ZQVkUqsxRUqqbr1mOJYKfIPR7LoDQ9mXPOjoJoqy81S2I8N_N4V1vUb5AoIIIbLZhVYxCRW4BPu10St3TBAUQYVKcFtCDtOWAjczIeQpN_E-PefeZG_inenu1pR6nSm_BH0GPJlCNwL5TnGAN8Zc5gvWZ/jackson-plaza-siteplan-march-2020.jpg?format=1000w'
        elif 'EASTON Marketplace' in property_name:
            BrochureURL = 'https://static1.squarespace.com/static/5a57891b90bade59dedd4dc1/t/5e601807ab8c5a3a1182e57c/1583355914425/rise-partners-easton-marketplace-brochure.pdf'
            item['Type'] = "Retail"
            item['BrochureURL'] = BrochureURL
            item['GLA'] = "320,000"
            item['Anchor'] = response.xpath('//*[@id="yui_3_17_2_1_1597311179061_487"]/p[3]/text()').get()
            item['SitePlanURL'] = 'https://images.squarespace-cdn.com/content/v1/5a57891b90bade59dedd4dc1/1583934135911-KA3AR9UNKZMWEI5WITHZ/ke17ZwdGBToddI8pDm48kF-jP3IXUy0T8dAXNyecp3EUqsxRUqqbr1mOJYKfIPR7LoDQ9mXPOjoJoqy81S2I8N_N4V1vUb5AoIIIbLZhVYxCRW4BPu10St3TBAUQYVKc8Kr-J0ZBj-la88Q1cbTrHE9cH266w_7UqgSGb6ZQOaLOGiyxe_EuBahT6Q1Tabb0/easton-marketplace-plan-rise-partners.jpg?format=1500w'


        item['Property_name'] = property_name
        item['Address'] = address
        item['City'] = city
        item['State'] = state
        item['ZIP'] = zip_code
        item['LeasingContact'] = "Jeff Howell"
        item['LeasingContactPhone'] = '4236371541'
        item['LeasingContactEmail'] = 'jhowell@risepartners.net'
        item['PropertyURL'] = response.url
        item['Description'] = description
        # item['country'] = "United States"
        # item['country_code'] = 'US'

        yield item

# execute('''scrapy crawl store_709 -a list_id=709'''.split())