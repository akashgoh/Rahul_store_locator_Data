import logging
import os
import re

import datetime
import scrapy, json, requests, re
import html2text
from scrapy.cmdline import execute

from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func

class Store721Spider(scrapy.Spider):
    name = 'store_735'
    allowed_domains = []


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        try:
            source_url = link = 'https://www.masonam.com/properties/'
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(self.run_date) + '.html'
            yield scrapy.FormRequest(url=str(link), callback=self.prop_link,meta={'source_url': source_url,'file_path': file_path})

        except Exception as e:
            logging.log(logging.ERROR, e)

    def prop_link(self,response):
        count = 0
        links = response.xpath('//table[@id="propertiesList"]/tbody/tr/td[2]/a/@href').getall()
        for link in links:
            url = link
            # count = count+1
            # print(count,url)
            yield scrapy.FormRequest(url=url, callback=self.prop_detail)

    def prop_detail(self,response):

        # print('final url........',response.url)
        try:
            property_name = str(response.xpath('//div[@class="wpb_wrapper"]/h3/text()').get()).strip()
            print(property_name)
        except Exception as e:
            print('prob in property_name..',e,response.url)
        try:
            address = str(response.xpath('//div[@class="wpb_wrapper"]/p/text()[1]').get()).strip()
        except:
            print('prob in address..',response.url)
        try:
            cs = str(response.xpath('//div[@class="wpb_wrapper"]/p/text()[2]').get()).strip()
            city = cs.split(',')[0]
            state = cs.split(',')[-1].split('\xa0')[0].strip()
            zip = cs.split(',')[-1].split('\xa0')[-1].strip()
        except:
            print('prob in CS....',response.url)
        try:
            GLA = str(response.xpath('//div[@class="wpb_wrapper"]/p/text()[3]').get()).replace('GLA:','').replace('SF','').replace(',','').strip()
        except:
            print('prob in GLA.....')
        try:
            desc = ' | '.join(response.xpath('//ul[@class="uavc-list"]/li//span/text()').getall()[1:])
        except:
            print('prob in Desc....')
        try:
            type = response.xpath('//ul[@class="uavc-list"]/li[1]//span/text()').get()
        except:
            print('prob in type....')
        try:
            Flyer = response.xpath('//*[contains(text(),"Flyer")]/../../../..//a/@href').get()
        except:
            print('prob in stories')
        try:
            siteplan = response.xpath('//*[contains(text(),"Site Plan")]/../../../..//a/@href').get()
        except:
            print('prob in stories')
        #
        item = ProprtySitesItem()
        item['Property_name'] = property_name
        item['Address'] = address
        item['City'] = city
        item['State'] = state
        item['Zip'] = zip
        item['GLA'] = GLA
        item['Description'] = desc
        item['Type'] = type
        item['Flyer'] = Flyer
        item['SitePlanURL'] = siteplan
        item['PropertyURL'] = response.url
        yield item

# execute('''scrapy crawl store_735 -a list_id=735'''.split())



