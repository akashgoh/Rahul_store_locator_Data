import hashlib
import scrapy
import datetime
import scrapy, json, requests, re
import html2text
from scrapy.http import HtmlResponse

from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func

class RptrealtySpider(scrapy.Spider):
    name = 'store_321'
    allowed_domains = ['example.com']
    start_urls = ['http://rptrealty.propertycapsule.com/property/output/find/search/format:json']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def parse(self, response):
        try:
            data = response.text
            rptjson = json.loads(data)
            length = len(rptjson['results'])
            for i in range(0, length):
                slug = rptjson['results'][i]['slug']
                id = rptjson['results'][i]['id']
                url = 'http://rptrealty.propertycapsule.com/properties/'+str(slug)+'/format:json'
                print(url)
                yield scrapy.FormRequest(url=url, callback=self.parse_data, dont_filter=True, meta={'id':id, 'slug':slug})
        except Exception as e:
            print(e)

    def parse_data(self, response):

        id = response.meta['id']
        print(id)
        # try:
        #     f = open('E:/Anil/Html Pages/StoreLocator/rptrealty/' + str(id) + '.json', 'wb')
        #     f.write(response.text.encode('utf-8'))
        #     print('Page Saved...', str(id))
        #     f.close()
        # except Exception as e:
        #     print(e)

        # try:
        pdata = response.text
        rptpjson = json.loads(pdata)
        item = ProprtySitesItem()
        item['Property_Name'] = rptpjson['property']['name']
        # print(item['Property_Name'])

        item['Address'] = rptpjson['property']['address']
        # print(item['Address'])

        item['City'] = rptpjson['property']['city']
        # print(item['City'])

        item['State'] = rptpjson['property']['state']
        # print(item['State'])

        item['zip_code'] = rptpjson['property']['zip']
        # print(item['zip_code'])

        item['Leasing_Agent'] = rptpjson['agents'][0]['name']
        # print(item['Leasing_Agent'])

        item['Leasing_Phone'] = rptpjson['agents'][0]['phone']
        # print(item['Leasing_Phone'])

        item['Leasing_Email'] = rptpjson['agents'][0]['email']
        # print(item['Leasing_Email'])

        item['County'] = rptpjson['property']['county']
        # print(item['County'])

        item['Type'] = rptpjson['property']['type']
        # print(item['Type'])

        item['SQFT'] = rptpjson['property']['gla']
        # print(item['SQFT'])


        try:
            item['Year_Built'] = rptpjson['property']['year_built']
        except:
            item['Year_Built'] = ''
        print(item['Year_Built'])

        item['Parking_Spaces'] = rptpjson['property']['parking']
        print(item['Parking_Spaces'])

        item['Metro_Area'] = rptpjson['property']['metroArea']
        print(item['Metro_Area'])

        item['URL'] = 'http://rptrealty.com/properties/' + str(response.meta['slug'])
        print(item['URL'])

        try:
            sid = rptpjson['spaces'][0]['sID']
            pid = rptpjson['property']['id']
            sp_link = 'http://rptrealty.propertycapsule.com/property/output/center/jsviewer/id:'+str(pid)+'/sitemap_ID:'+str(sid)
            r = requests.get(sp_link)
            res = HtmlResponse(url=r.url, body=r.content)
            data = re.findall(r'JSON.parse\("(.*?)"\)', res.text)[0].replace('\\', '')
            jdata = json.loads(data)
            item['SitePlanURL'] = jdata['planWidgetObjects']['mapPlanImg']
            print(item['SitePlanURL'])
        except:
            item['SitePlanURL'] = ''

        yield item
        # except Exception as e:
            # print(e)

# Property_Name,Address,City,State,zip_code,Leasing_Agent,Leasing_Phone,Leasing_Email,County,Type,SQFT,Year_Built,Parking_Spaces,Metro_Area,URL,SitePlanURL
# ID,Property_Name,Address,City,State,zip_code,Leasing_Agent,Leasing_Phone,Leasing_Email,County,Type,SQFT,Year_Built,Parking_Spaces,Metro_Area,URL
#
from scrapy import cmdline
# cmdline.execute("scrapy crawl store_321 -a list_id=321".split())