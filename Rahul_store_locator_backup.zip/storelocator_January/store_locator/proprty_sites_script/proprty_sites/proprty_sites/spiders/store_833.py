# import re
# import datetime
# import scrapy,os,logging,hashlib
# import requests,json
# from lxml.html import open_in_browser
# from scrapy.http import HtmlResponse
# from scrapy.cmdline import execute
# from proprty_sites.items import ProprtySitesItem
# from proprty_sites.spiders.common_functions import Func
# import datetime
# import html2text
#
#
# # from selenium import webdriver
# # from selenium.webdriver.chrome.options import Options
# # chrome_options = Options()
# # # chrome_options.add_argument("--headless")
# # chrome_driver ="D:\chromedriver.exe"
#
#
#
# class Store833Spider(scrapy.Spider):
#     name = 'store_833'
#     # allowed_domains = []
#     start_urls = ['https://www.example.com/']
#     not_export_data = True
#
#     def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
#         super().__init__(name, **kwargs)
#         self.list_id, self.proxy_type = list_id, proxy_type
#         self.f1 = Func()
#         self.run_date = str(datetime.datetime.today()).split()[0]
#         self.table_name = self.f1.set_details(self.list_id, self.run_date)
#
#     def parse(self, response):
#         try:
#             for i in range(1, 29):
#                 link = f'D:\\property_save\\{i}.html'
#                 with open(link, "rb") as f:
#                     text = f.read()
#                 response = HtmlResponse(url='a.com', body=text)
#                 try:
#                     Property_Name = ''.join(response.xpath('//*[@class="propertyDescription"]//h3/text()').extract()).strip()
#                 except Exception as e:
#                     print(e)
#
#                 try:
#                     Property_type = response.xpath('//*[contains(text(),"Property Type:")]/../div[2]//text()').extract_first().strip()
#                 except Exception as e:
#                     Property_type = ""
#                     print(e)
#
#                 try:
#                     Address = response.xpath('//*[@class="propertyDescription"]//p[4]/text()[3]|//*[@class="propertyDescription"]//p[2]//text()[3]').extract_first().strip()
#                 except Exception as e:
#                     Address = ""
#                     print(e)
#                 try:
#                     data = response.xpath('//*[@class="propertyDescription"]//p[4]/text()[4]').extract_first().strip()
#                     City = data.split(",")[0]
#                     State = data.split(",")[1].split(" ")[1]
#                     zip_code = data.split(",")[1].split(" ")[2]
#                 except Exception as e:
#                     print(e)
#
#                 try:
#                     Description = ''.join(response.xpath('//*[@class="propertyDescription"]//p[2]//text()').extract()).strip()
#                 except Exception as e:
#                     print(e)
#
#                 try:
#                     Leasing_Contact_Name = '|'.join(response.xpath('//*[@class="w-col w-col-8 w-col-small-8 w-clearfix"]/strong//text()').extract()).strip()
#                 except Exception as e:
#                     print(e)
#
#                 try:
#                     Leasing_Contact_Phone = '|'.join(response.xpath('//*[@class="w-col w-col-8 w-col-small-8 w-clearfix"]/text()[4]').extract()).strip()
#                 except Exception as e:
#                     print(e)
#
#                 try:
#                     Leasing_Contact_Email = '|'.join(response.xpath('//*[@class="w-col w-col-8 w-col-small-8 w-clearfix"]//a//text()').extract()).strip()
#                 except Exception as e:
#                     print(e)
#
#                 try:
#                     Site_Plan_URL = response.xpath('//*[@class="propertyDocs"]//li[2]//a[1]/@href').extract_first()
#                 except Exception as e:
#                     print(e)
#
#                 try:
#                     Brochure_URL = response.xpath('//*[@class="propertyDocs"]//li[3]//a[1]/@href').extract_first().strip()
#                 except Exception as e:
#                     print(e)
#
#
#                 try:
#                     SqFt = response.xpath('//*[contains(text(),"Availability:")]/../div[2]//text()').extract_first().strip()
#                 except Exception as e:
#                     SqFt = ""
#                     print(e)
#
#                 try:
#                     GLA1 = ''.join(response.xpath('//*[@class="propertyListing"]//li//strong//text()').extract()).strip()
#                     GLA = GLA.split("SQUARE")[0]
#                 except Exception as e:
#                     print(e)
#
#
#                 item = ProprtySitesItem()
#                 item['Property_Name'] = Property_Name
#                 item['Property_type'] = Property_type
#                 item['Address'] = Address
#                 item['City'] = City
#                 item['State'] = State
#                 item['zip_code'] = zip_code
#                 item['Description'] = Description
#                 item['Leasing_Contact_Name'] = Leasing_Contact_Name
#                 item['Leasing_Contact_Phone'] = Leasing_Contact_Phone
#                 item['Leasing_Contact_Email'] = Leasing_Contact_Email
#                 item['Site_Plan_URL'] = Site_Plan_URL
#                 item['Brochure_URL'] = Brochure_URL
#                 item['url'] = "http://www.kourycorp.com/Retail/RetailPortfolio.aspx"
#                 item['Sq_Ft'] = SqFt
#                 item['GLA'] = GLA
#                 yield item
#
#
#         except Exception as e:
#             print(e)
# # GLA manually
# # execute('''scrapy crawl store_833 -a list_id=833'''.split())
#
#
#
#
#     # def get_link(self, response):
#     #     try:
#     #         Property_Name  = ''.join(response.xpath('//*[@class="propertyDescription"]//h3//text()').extract()).strip()
#     #     except Exception as e:
#     #         print(e)
#     #
#     #     item = ProprtySitesItem()
#     #     item['Property_Name'] = Property_Name
#     #     yield item
#
# # execute('''scrapy crawl store_833 -a list_id=833'''.split())
#
#
# #
# #
# #
# #     def start_requests(self):
# #         try:
# #             source_url = link = 'http://www.kourycorp.com/Retail/RetailPortfolio.aspx'
# #             print(source_url)
# #             file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
# #                 self.run_date) + '.html'
# #             yield scrapy.FormRequest(url=str(link), callback=self.firstlevel,
# #                                      meta={'source_url': source_url, 'file_path': file_path,
# #                                            'proxy_type': self.proxy_type})
# #         except Exception as e:
# #             print(e)
# #
# #     def firstlevel(self, response):
# #         try:driver = webdriver.Chrome(chrome_options=chrome_options, executable_path=chrome_driver)
# #         except Exception as e: print(e)
# #         # driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
# #         url = driver.get(response.url)
# #         response = HtmlResponse(url=driver.current_url, body=driver.page_source.encode('utf8'))
# #         # driver.quit()
# #         driver.get(response.url)
# #         divs = response.xpath('//*[@class="propertyListing"]//li')
# #         for div in divs:
# #             links = driver.find_element_by_xpath('.//div[@class="propertyInfo"]//a/@href').click()
# #             # links = div.find_element_by_xpath('.//*[contains(text(),"View Property Details")]').click()
# #             print(links)
# #             driver.back()
# #         try:
# #             # data = response.xpath('//*[@class="propertyDetailsBtn"]/@href').extract()
# #
# #             # for div in data:
# #             #     url = re.findall('javascript:__doPostBack(\(.*?),',div)[0].strip().replace("'(\'","").replace("\''","").replace("('","").replace("'","")
# #             #     print(url)
# #
# #                 # yield scrapy.FormRequest(url=url, callback=self.start_requests, dont_filter=True)
# #             # next_page = response.xpath('//*[@id="dnn_ctr558_XModPro_ctl00_Primary_PrimarypgrBottom_lnkNext"]/@href').extract_first()
# #             # link = next_page
# #             # yield scrapy.FormRequest(url=link, callback=self.firstlevel, dont_filter=True)
# #
# #             source_url = response.meta['link']
# #             # file_path = response.meta['file_path']
# #             proxy_type = response.meta['proxy_type']
# #             ViewState = response.xpath('//*[@id="__VIEWSTATE"]/@value').extract_first().strip()
# #             # ViewState = ViewState.replace("/", "%2F")
# #             # ViewState = ViewState.replace("=", "%3D")
# #             # ViewState = ViewState.replace("+", "%2B")
# #             view_gen = response.xpath('//input[@id="__VIEWSTATEGENERATOR"]/@value').extract_first()
# #             view_EVEN = response.xpath('//input[@id="__EVENTVALIDATION"]/@value').extract_first()
# #             # view_EVEN = view_EVEN.replace("/", "%2F")
# #             # view_EVEN = view_EVEN.replace("=", "%3D")
# #             # view_EVEN = view_EVEN.replace("+", "%2B")
# #             view_EventTarget = response.xpath('//input[@id="__EVENTTARGET"]/@value').extract_first()
# #             Even_argumnet = response.xpath('//input[@id="__EVENTARGUMENT"]/@value').extract_first()
# #             Viewcrypted = response.xpath('//input[@id="__VIEWSTATEENCRYPTED"]/@value').extract_first()
# #             KB_JSTester_JSEnabled = "1"
# #             KB_JSTester_JQueryVsn = " 3.5.1"
# #             __EVENTTARGET = "dnn$ctr558$XModPro$ctl00$Primary$PrimaryrptrListView$ctl01$ctl02$_lnk"
# #
# #             headers = {
# #                 'accept': "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
# #                 'accept-encoding': "gzip, deflate",
# #                 'accept-language': "en-US,en;q=0.9",
# #                 'cache-control': "no-cache",
# #                 'connection': "keep-alive",
# #                 'content-type': "multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW",
# #                 'cookie': ".ASPXANONYMOUS=mrwxYIt6q7RPNtBFbaknanyvOGj4ymnmryANrIBx7ukPOUXH64P8XsdxqR_Cim1F8aq3jFzlkGht6t4VBpzB88k0DqSlFz0rXBqUF7o4OY64Xzsl0; __utmz=222913665.1608359974.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none); ASP.NET_SessionId=kgeigka2zmtq0udlemiwvu5l; language=en-US; __utmc=222913665; __utma=222913665.1991245360.1608359974.1608696454.1609128722.7; __utmt=1; __utmb=222913665.8.10.1609128722",
# #                 'host': "www.kourycorp.com",
# #                 'origin': "http://www.kourycorp.com",
# #                 'referer': "http://www.kourycorp.com/Retail/RetailPortfolio.aspx",
# #                 'upgrade-insecure-requests': "1",
# #                 'user-agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36",
# #                 # 'postman-token': "7179c1e9-9b37-be1a-ee1a-e9ab110dc24e"
# #             }
# #             payload = "WebKitFormBoundaryovB0SgxbHk2nGQC2Content-Disposition: form-data; name='KB_JSTester_JSEnabled'"+str(KB_JSTester_JSEnabled)+"------WebKitFormBoundaryovB0SgxbHk2nGQC2Content-Disposition: form-data; name='KB_JSTester_JQueryVsn'"+str(KB_JSTester_JQueryVsn)+ "------WebKitFormBoundaryovB0SgxbHk2nGQC2Content-Disposition: form-data; name='__EVENTTARGET'"+str(view_EventTarget) + "dnn$ctr558$XModPro$ctl00$Primary$PrimaryrptrListView$ctl03$ctl02$_lnk------WebKitFormBoundaryovB0SgxbHk2nGQC2Content-Disposition: form-data; name='__EVENTARGUMENT'" + str(Even_argumnet) + "------WebKitFormBoundaryovB0SgxbHk2nGQC2Content-Disposition: form-data; name='__VIEWSTATE"+str(ViewState) + "------WebKitFormBoundaryovB0SgxbHk2nGQC2Content-Disposition: form-data; name='__VIEWSTATEGENERATOR'"+str(view_gen)+"------WebKitFormBoundaryovB0SgxbHk2nGQC2Content-Disposition: form-data; name='__VIEWSTATEENCRYPTED'"+str(Viewcrypted)+ "------WebKitFormBoundaryovB0SgxbHk2nGQC2Content-Disposition: form-data; name='__EVENTVALIDATION'"+ str(view_EVEN) + "------WebKitFormBoundaryovB0SgxbHk2nGQC2Content-Disposition: form-data; name='SearchAvailableProperties'" + "------WebKitFormBoundaryovB0SgxbHk2nGQC2Content-Disposition: form-data; name='ScrollTop'" + "------WebKitFormBoundaryovB0SgxbHk2nGQC2Content-Disposition: form-data; name='__dnnVariable'" + "------WebKitFormBoundaryovB0SgxbHk2nGQC2--"
# #
# #             # file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
# #             #     self.run_date) + '.html'
# #             yield scrapy.FormRequest(url=source_url, method="POST", body=payload, callback=self.secondlevel,
# #                                      headers=headers,
# #                                      meta={'source_url': source_url, 'proxy_type': proxy_type})
# #                                            # 'file_path':file_path})
# #         except Exception as e:
# #             print(e)
# #
# # #
# # #
# #
# #     def secondlevel(self, response):
# #         print(response.text)
# #     #     try:
#     #         source_url = response.meta['source_url']
#     #         # file_path = response.meta['file_path']
#     #         proxy_type = response.meta['proxy_type']
#     #
#     #         divs = response.xpath('//*[@class="propertyDetailsBtn"]/@href').extract()
#     #         for div in divs:
#     #             url = div
#     #             yield scrapy.FormRequest(url=url, callback=self.get_store_list, dont_filter=True)
#     #         next_page = response.xpath('//*[@id="dnn_ctr558_XModPro_ctl00_Primary_PrimarypgrBottom_lnkNext"]/@href').extract()
#     #         link = next_page
#     #         yield scrapy.FormRequest(url=link, callback=self.firstlevel, dont_filter=True)
#     #
#     #
#     #
#     #     except Exception as e:
#     #         print(e)
#     #
#     # def get_store_list(self, response):
#     #     pass
#
#
#
#
#
#
#
# execute('''scrapy crawl store_833 -a list_id=833'''.split())
#
#
#
# # import datetime
# # import json
# # import re
# # import html2text
# # import requests
# # import scrapy
# # from scrapy.http import HtmlResponse
# # from scrapy.utils.response import open_in_browser
# # from scrapy.cmdline import execute
# # from proprty_sites.items import ProprtySitesItem
# # from proprty_sites.spiders.common_functions import Func
# #
# #
# # from selenium import webdriver
# # from selenium.webdriver.chrome.options import Options
# # chrome_options = Options()
# # # chrome_options.add_argument("--headless")
# # chrome_driver ="D:\chromedriver.exe"
# #
# #
# #
# # class Store833Spider(scrapy.Spider):
# #     name = 'store_833'
# #     # handle_httpstatus_list = [500,400,401,402,403]
# #     allowed_domains = []
# #     not_export_data = True
# #
# #     def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
# #         super().__init__(name, **kwargs)
# #         self.list_id, self.proxy_type = list_id, proxy_type
# #         self.f1 = Func()
# #
# #     def start_requests(self):
# #         # run_date = str(datetime.datetime.today()).split()[0]
# #         try:
# #             link = "http://www.kourycorp.com/Retail/RetailPortfolio.aspx"
# #             # file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(self.run_date) + '.html'
# #             yield scrapy.FormRequest(url=str(link), callback=self.firstlevel,
# #                                  meta={'link': link, 'proxy_type': self.proxy_type,})
# #                                        # 'file_path':file_path})
# #         except Exception as e:
# #             print(e)
# #
# #     def firstlevel(self, response):
# #         open_in_browser(response.url)
# #         driver = webdriver.Chrome(chrome_options=chrome_options, executable_path=chrome_driver)
# #         # driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
# #         url = driver.get(response.url)
# #         response = HtmlResponse(url=driver.current_url, body=driver.page_source.encode('utf8'))
# #         driver.quit()
# #         driver.get(response.url)
# #         try:
# #             # data = response.xpath('//*[@class="propertyDetailsBtn"]/@href').extract()
# #
# #             # for div in data:
# #             #     url = re.findall('javascript:__doPostBack(\(.*?),',div)[0].strip().replace("'(\'","").replace("\''","").replace("('","").replace("'","")
# #             #     print(url)
# #
# #                 # yield scrapy.FormRequest(url=url, callback=self.start_requests, dont_filter=True)
# #             # next_page = response.xpath('//*[@id="dnn_ctr558_XModPro_ctl00_Primary_PrimarypgrBottom_lnkNext"]/@href').extract_first()
# #             # link = next_page
# #             # yield scrapy.FormRequest(url=link, callback=self.firstlevel, dont_filter=True)
# #
# #             source_url = response.meta['link']
# #             # file_path = response.meta['file_path']
# #             proxy_type = response.meta['proxy_type']
# #             ViewState = response.xpath('//*[@id="__VIEWSTATE"]/@value').extract_first().strip()
# #             # ViewState = ViewState.replace("/", "%2F")
# #             # ViewState = ViewState.replace("=", "%3D")
# #             # ViewState = ViewState.replace("+", "%2B")
# #             view_gen = response.xpath('//input[@id="__VIEWSTATEGENERATOR"]/@value').extract_first()
# #             view_EVEN = response.xpath('//input[@id="__EVENTVALIDATION"]/@value').extract_first()
# #             # view_EVEN = view_EVEN.replace("/", "%2F")
# #             # view_EVEN = view_EVEN.replace("=", "%3D")
# #             # view_EVEN = view_EVEN.replace("+", "%2B")
# #             view_EventTarget = response.xpath('//input[@id="__EVENTTARGET"]/@value').extract_first()
# #             Even_argumnet = response.xpath('//input[@id="__EVENTARGUMENT"]/@value').extract_first()
# #             Viewcrypted = response.xpath('//input[@id="__VIEWSTATEENCRYPTED"]/@value').extract_first()
# #             KB_JSTester_JSEnabled = "1"
# #             KB_JSTester_JQueryVsn = " 3.5.1"
# #             __EVENTTARGET = "dnn$ctr558$XModPro$ctl00$Primary$PrimaryrptrListView$ctl01$ctl02$_lnk"
# #
# #             headers = {
# #                 'accept': "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
# #                 'accept-encoding': "gzip, deflate",
# #                 'accept-language': "en-US,en;q=0.9",
# #                 'cache-control': "no-cache",
# #                 'connection': "keep-alive",
# #                 'content-type': "multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW",
# #                 'cookie': ".ASPXANONYMOUS=mrwxYIt6q7RPNtBFbaknanyvOGj4ymnmryANrIBx7ukPOUXH64P8XsdxqR_Cim1F8aq3jFzlkGht6t4VBpzB88k0DqSlFz0rXBqUF7o4OY64Xzsl0; __utmz=222913665.1608359974.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none); ASP.NET_SessionId=kgeigka2zmtq0udlemiwvu5l; language=en-US; __utmc=222913665; __utma=222913665.1991245360.1608359974.1608696454.1609128722.7; __utmt=1; __utmb=222913665.8.10.1609128722",
# #                 'host': "www.kourycorp.com",
# #                 'origin': "http://www.kourycorp.com",
# #                 'referer': "http://www.kourycorp.com/Retail/RetailPortfolio.aspx",
# #                 'upgrade-insecure-requests': "1",
# #                 'user-agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36",
# #                 # 'postman-token': "7179c1e9-9b37-be1a-ee1a-e9ab110dc24e"
# #             }
# #             payload = "WebKitFormBoundaryovB0SgxbHk2nGQC2Content-Disposition: form-data; name='KB_JSTester_JSEnabled'"+str(KB_JSTester_JSEnabled)+"------WebKitFormBoundaryovB0SgxbHk2nGQC2Content-Disposition: form-data; name='KB_JSTester_JQueryVsn'"+str(KB_JSTester_JQueryVsn)+ "------WebKitFormBoundaryovB0SgxbHk2nGQC2Content-Disposition: form-data; name='__EVENTTARGET'"+str(view_EventTarget) + "dnn$ctr558$XModPro$ctl00$Primary$PrimaryrptrListView$ctl03$ctl02$_lnk------WebKitFormBoundaryovB0SgxbHk2nGQC2Content-Disposition: form-data; name='__EVENTARGUMENT'" + str(Even_argumnet) + "------WebKitFormBoundaryovB0SgxbHk2nGQC2Content-Disposition: form-data; name='__VIEWSTATE"+str(ViewState) + "------WebKitFormBoundaryovB0SgxbHk2nGQC2Content-Disposition: form-data; name='__VIEWSTATEGENERATOR'"+str(view_gen)+"------WebKitFormBoundaryovB0SgxbHk2nGQC2Content-Disposition: form-data; name='__VIEWSTATEENCRYPTED'"+str(Viewcrypted)+ "------WebKitFormBoundaryovB0SgxbHk2nGQC2Content-Disposition: form-data; name='__EVENTVALIDATION'"+ str(view_EVEN) + "------WebKitFormBoundaryovB0SgxbHk2nGQC2Content-Disposition: form-data; name='SearchAvailableProperties'" + "------WebKitFormBoundaryovB0SgxbHk2nGQC2Content-Disposition: form-data; name='ScrollTop'" + "------WebKitFormBoundaryovB0SgxbHk2nGQC2Content-Disposition: form-data; name='__dnnVariable'" + "------WebKitFormBoundaryovB0SgxbHk2nGQC2--"
# #
# #             # file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
# #             #     self.run_date) + '.html'
# #             yield scrapy.FormRequest(url=source_url, method="POST", body=payload, callback=self.secondlevel,
# #                                      headers=headers,
# #                                      meta={'source_url': source_url, 'proxy_type': proxy_type})
# #                                            # 'file_path':file_path})
# #         except Exception as e:
# #             print(e)
# #
# #
# #
# #
# #     def secondlevel(self, response):
# #         print(response.text)
# #     #     try:
# #     #         source_url = response.meta['source_url']
# #     #         # file_path = response.meta['file_path']
# #     #         proxy_type = response.meta['proxy_type']
# #     #
# #     #         divs = response.xpath('//*[@class="propertyDetailsBtn"]/@href').extract()
# #     #         for div in divs:
# #     #             url = div
# #     #             yield scrapy.FormRequest(url=url, callback=self.get_store_list, dont_filter=True)
# #     #         next_page = response.xpath('//*[@id="dnn_ctr558_XModPro_ctl00_Primary_PrimarypgrBottom_lnkNext"]/@href').extract()
# #     #         link = next_page
# #     #         yield scrapy.FormRequest(url=link, callback=self.firstlevel, dont_filter=True)
# #     #
# #     #
# #     #
# #     #     except Exception as e:
# #     #         print(e)
# #
# #     def get_store_list(self, response):
# #         pass
# #
# #
# #
