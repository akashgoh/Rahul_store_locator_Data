# -*- coding: utf-8 -*-
import scrapy
import json
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func
import datetime


class store_475_Spider(scrapy.Spider):
    name = 'store_475'
    # allowed_domains = ['www.example.com']
    start_urls = ['https://staging-api-federalrealty.reol.com/api/search-properties?query=']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def parse(self, response):

        data = response.text
        machine_data = json.loads(data)
        total_property = machine_data['data']

        for i in range(0, int(len(total_property))):

            link = 'https://staging-api-federalrealty.reol.com'+machine_data['data'][i]['property']['url']

            yield scrapy.Request(url=link, callback=self.finaldata)

    def finaldata(self, response):
        data = response.text
        machine_data = json.loads(data)



        try:
            store_name=machine_data['property']['name'].strip()
        except Exception as e:
            print(e,response.url)
            store_name=''


        try:
            Address= machine_data['property']['full_address']
        except Exception as e:
            print(e,response.url)
            Address=''


        try:
            city=machine_data['property']['city']
        except Exception as e:
            print(e,response.url)
            city=''

        try:
            State = machine_data['property']['state_code']
        except Exception as e:
            print(e, response.url)
            State = ''

        try:
            zip_code = machine_data['property']['zip']
        except Exception as e:
            print(e,response.url)
            zip_code=''

        try:
            GLA=machine_data['data']['gla']
        except Exception as e:
            print(e,response.url)
            GLA=''

        try:
            Description=machine_data['data']['description'].replace('<p>','').replace('</p>','').strip()
        except Exception as e:
            print(e, response.url)
            Description=''

        try:
            l_c_n_all=[]
            l_c_p_all = []
            l_c_e_all = []
            l=machine_data['data']['leasing_agents']

            for k in range(0,int(len(l))):
                l_c_n=machine_data['data']['leasing_agents'][k]['name']
                l_c_p=machine_data['data']['leasing_agents'][k]['phone']
                l_c_e=machine_data['data']['leasing_agents'][k]['email']
                l_c_n_all.append(l_c_n)
                l_c_p_all.append(l_c_p)
                l_c_e_all.append(l_c_e)
        except Exception as e:
            print(e, response.url)
            l_c_n=''
            l_c_p=''
            l_c_e=''

        # try:
        #     l_c_n=response.xpath('//h3[contains(text(),"Leasing Agent")]//following-sibling::span//span[@class="p-name"]/text()').get().strip()
        # except Exception as e:
        #     print(e, response.url)
        #     l_c_n=''
        #
        # try:
        #     l_c_p=response.xpath('//h3[contains(text(),"Leasing Agent")]//following-sibling::span//strong[@class="p-tel p-tel-office"]/text()').get().strip()
        # except Exception as e:
        #     print(e, response.url)
        #     l_c_p = ''
        #
        # try:
        #     l_c_e = re.findall('"email":"(.*?)",',response.text)[0]
        # except Exception as e:
        #     print(e, response.url)
        #     l_c_e = ''

        try:
            Site_Plan_URL= 'https://api-federalrealty.reol.com'+machine_data['data']['pdf_site_plan']
        except Exception as e:
            print(e,response.url)
            Site_Plan_URL=''

        try:
            item = ProprtySitesItem()
            item['Property_Name'] = store_name
            item['Address'] = Address
            item['City'] = city
            item['State']=State
            item['Zip']=zip_code
            item['GLA'] = GLA
            item['Description']=Description
            item['Leasing_Contact_Name'] ='|'.join(l_c_n_all)
            item['Leasing_Contact_Phone']='|'.join(l_c_p_all)
            item['Leasing_Contact_Email'] ='|'.join(l_c_e_all)

            item['Site_Plan_URL'] = Site_Plan_URL

            id=machine_data['property']['id']
            slug=store_name.replace(' ','-')

            item['Property_URL'] = 'https://staging.federalrealty.reol.com/property/'+str(slug)+'/'+str(id)




            # print (item)
            yield item
        except Exception as e:
            print("item", e)


# from scrapy.cmdline import execute
# execute('''scrapy crawl store_475 -a list_id=475'''.split())
