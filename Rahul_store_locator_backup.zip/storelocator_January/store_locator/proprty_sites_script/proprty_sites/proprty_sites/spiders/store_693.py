import re
import scrapy
import datetime
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func
import logging

class Store693Spider(scrapy.Spider):
    name = "store_693"
    allowed_domains = []
    # start_urls = ['https://www.heidenbergproperties.com/property-portfolio-3/']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        try:
            # if self.f1.search_by != 'link':
            #     search_terms = self.f1.get_search_term(self.f1.search_by)
            #     print(search_terms)
            #     for search_term in (search_terms):
            #         source_url = link = 'https://www.risepartners.net/portfolio'
            #         file_path = self.f1.html_link_directory + str(self.list_id)+'_'+ str(search_term) + '_' + str(self.run_date) + '.html'
            #         if os.path.exists(file_path):
            #             link = 'file://' + file_path.replace('\\','/')
            #
            #         header = {
            #                 "Upgrade-Insecure-Requests": "1",
            #                 "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36",
            #                 "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
            #                 "Sec-Fetch-Site": "none",
            #                 "Sec-Fetch-Mode": "navigate",
            #                 "Sec-Fetch-User": "?1",
            #                 "Sec-Fetch-Dest": "document"}
            #         yield scrapy.FormRequest(url=str(link), callback=self.property_links, meta={'source_url': source_url,'search_term': search_term,'file_path':file_path}, headers=header)
            # else:
            source_url = link = 'https://www.heidenbergproperties.com/property-portfolio-3/'
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(self.run_date) + '.html'
            yield scrapy.FormRequest(url=str(link), callback=self.parse,meta={'source_url': source_url,'file_path': file_path})
        #
        except Exception as e:
            logging.log(logging.ERROR, e)

    def parse(self, response):
        links = response.xpath('//div[@id="tab1"]//a[contains(text(),"View full details")]/@href').extract()
        GLA_list = response.xpath('//div[@id="tab1"]//a[contains(text(),"View full details")]/../../td[3]/text()').extract()
        for link,GLA1 in zip(links,GLA_list):
            print(type(link), "link")
            if GLA1 == None:
                GLA = ''
            else:
                GLA = GLA1
            # if '"' in link:
            link=('https://www.heidenbergproperties.com'+str(link)).replace(' ','')
            print(type(link),"link")
            print(type(GLA1),"GLA1")
            yield scrapy.Request(url=link, callback=self.get_data, meta={'GLA':GLA})

    def get_data(self, response):
        # print(response.url)
        try:
            Property_URL = response.url
            print(type(Property_URL),Property_URL)
        except Exception as e:
            print(e)
        try:
            Property_Name = response.xpath('//h1/text()').extract_first()
            # Property_Name = re.sub(r'[\n\t]','',Property_Name)
            print(type(Property_Name),"Property_Name")
        except Exception as e:
            Property_Name = ''
            print(e)
        try:
            if response.xpath('//h3/strong/text()'):
                full_address = response.xpath('//h3/strong/text()').extract_first()
                print(type(full_address),"full_address")
            else:
                full_address = response.xpath('//h3/b/text()').extract_first()
                print(type(full_address),"full_address")
            if full_address != None:
                Address = full_address.split(',')[0].strip()
                print(type(Address),"Address")
                City = full_address.split(',')[1].strip()
                print(type(City),"City")
                State = full_address.split(',')[2].strip().split()[0]
                print(type(State),"State")
                Zip_code = full_address.split(',')[2].strip().split()[1]
                print(type(Zip_code),"Zip_code")
            else:
                Address = ''
                City = ''
                State = ''
                Zip_code= ''
        except Exception as e:
            Address = ''
            City = ''
            State = ''
            print(e)

        try:
            Description = response.xpath('//*[@class="portfolio_single"]/p/text()').extract_first()
            print(type(Description),"Description")
        except Exception as e:
            Description = ''
            print(e)

        try:
            Leasing_Contact = ''.join(response.xpath('//p[@style="margin: 24px 0;"]/text()[1]').getall())
            Leasing_Contact_Phone = ''.join(response.xpath('//p[@style="margin: 24px 0;"]/text()[3]').getall())
            print(type(Leasing_Contact),"Leasing_Contact")
            print(type(Leasing_Contact_Phone),"Leasing_Contact_Phone")
            # Leasing_Contact = ''.join(response.xpath('//strong[contains(text(),"Leasing Opportunities")]/../text()').extract()).strip()
            # Leasing_Contact = Leasing_Contact.replace('\n','|')
            # Leasing_Contact = re.sub('[\r\s+]','',Leasing_Contact).replace('||','|')
            # Leasing_Contact_list = Leasing_Contact.split('|')
            # if len(Leasing_Contact_list) == 3:
            #     Leasing_Contact = Leasing_Contact_list[1].strip()
            # else:
            #     Leasing_Contact = Leasing_Contact_list[0].strip()
            # Leasing_Contact_Phone = Leasing_Contact_list[-1]
        except Exception as e:
            Leasing_Contact = ''
            Leasing_Contact_Phone = ''
            print(e)

        try:
            Leasing_Contact_Email = response.xpath('//strong[contains(text(),"Leasing Opportunities")]/../a/text()').extract_first()
            print(type(Leasing_Contact_Email),"Leasing_Contact_Email")
            if Leasing_Contact_Email == None:
                Leasing_Contact_Email = ''
        except Exception as e:
            Leasing_Contact_Email = ''
            print(e)

        try:
            Site_Plan_URL = response.xpath('//*[@id="tab2"]/a/@href').extract_first()
            print(type(Site_Plan_URL),"Site_Plan_URL")
            if Site_Plan_URL == None:
                Site_Plan_URL = ''
        except Exception as e:
            Site_Plan_URL = ''
            print(e)

        try:
            item = ProprtySitesItem()
            item['Property_Name'] = str(Property_Name).strip()
            item['Address'] = str(Address)
            item['City'] = str(City)
            item['State'] = str(State)
            item['ZIP'] = str(Zip_code)
            item['GLA'] = str(response.meta['GLA'])
            item['Description'] = str(Description)
            item['Leasing_Contact'] = str(Leasing_Contact.replace("\r\n",""))
            item['Leasing_Contact_Phone'] = str(Leasing_Contact_Phone.replace(" x21","").replace("-","").replace("\r\n",""))
            item['Leasing_Contact_Email'] = str(Leasing_Contact_Email)
            item['Site_Plan_URL'] = str(Site_Plan_URL)
            item['Property_URL'] = str(Property_URL)
            yield item
        except Exception as e:
            print(e)


# from scrapy.cmdline import execute
# execute('''scrapy crawl store_693 -a list_id=693'''.split())