import datetime
import scrapy, json, requests, re
from scrapy.http import HtmlResponse
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func


class Store327Spider(scrapy.Spider):
    name = "store_327"
    allowed_domains = []
    start_urls = ['http://vestar.propertycapsule.com/property/output/find/search4']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def parse(self, response):
        links = response.xpath('//*[@class="liting-item-title"]/a/@href').extract()
        for link in links:
            yield scrapy.Request(url=link, callback=self.get_data)

    def get_data(self, response):
        try:
            source_url = response.url
        except Exception as e:
            print("source url" + str(e))
        try:
            Property_Name = response.xpath('//h1/text()').extract_first()
            if Property_Name:
                Property_Name = Property_Name.strip()
            else:
                Property_Name = ''
        except Exception as e:
            Property_Name = ''
            print("Property_Name " + str(e))
        try:
            full_address = response.xpath('//*[@class="contact-address"]/p/text()').extract_first()
            if full_address:
                Address = full_address.split(',')[0].strip()
                City = full_address.split(',')[1].strip()
                State = full_address.split(',')[2].strip()[0:2]
            else:
                Address = ''
                City = ''
                State = ''
        except Exception as e:
            Address = ''
            City = ''
            State = ''
            print("full_address " + str(e))
        try:
            Mall_Phone = ''
        except Exception as e:
            Mall_Phone = ''
            print("Mall_Phone " + str(e))
        try:
            if response.xpath('//*[@class="contact-address"]/p/a'):
                Property_Website = response.xpath('//a[contains(text(),"Property Website")]/@href').extract_first()
            else:
                Property_Website = ''
        except Exception as e:
            Property_Website = ''
            print("Property_Website " + str(e))
        try:
            Contact = response.xpath('//*[@class="name"]/text()').extract_first()
            if Contact:
                Contact = Contact.strip()
            else:
                Contact = ''
        except Exception as e:
            Contact = ''
            print("Contact " + str(e))
        try:
            Phone = response.xpath('//a[@class="phone"]/text()').extract_first()
            if Phone:
                Phone = Phone.strip()
            else:
                Phone = ''
        except Exception as e:
            Phone = ''
            print("Phone " + str(e))
        try:
            Email = response.xpath('//a[@class="email"]/text()').extract_first()
            if Email:
                Email = Email.strip()
            else:
                Email = ''
        except Exception as e:
            Email = ''
            print("Email " + str(e))
        try:
            GLA = response.xpath('//*[@class="gla"]/text()').extract_first()
            if GLA:
                GLA = GLA.strip().replace('GLA: ','')
            else:
                GLA = ''
        except Exception as e:
            GLA = ''
            print("GLA " + str(e))
        try:
            iframe_link = response.xpath('//iframe[@class="jsviewer"]/@src').extract_first()
            res_s = requests.get(iframe_link)
            response_s = HtmlResponse(url=res_s.url, body=res_s.content)
            Site_Plan_URL = re.findall(r'\\"mapPlanImg\\":\\"(.*?)\\",\\"mapPlanImg1\\":', response_s.text, re.DOTALL)
            if len(Site_Plan_URL) == 1:
                Site_Plan_URL = Site_Plan_URL[0].replace('\\','')
                if source_url == 'http://vestar.propertycapsule.com/properties/64colorado':
                    Site_Plan_URL = 'http://vestar.propertycapsule.com/property/capsule_data/669/property/sitemap_image/230.png?1583934888'
            else:
                Site_Plan_URL = ''
        except Exception as e:
            Site_Plan_URL = ''
            print("Site_Plan_URL " + str(e))
        try:
            item = ProprtySitesItem()
            item['Property_Name'] = Property_Name
            item['Address'] = Address
            item['City'] = City
            item['State'] = State
            item['Mall_Phone'] = Mall_Phone
            item['Property_Website'] = Property_Website
            item['Contact'] = Contact
            item['Phone'] = Phone
            item['Email'] = Email
            item['GLA'] = GLA
            item['Site_Plan_URL'] = Site_Plan_URL
            item['URL'] = source_url
            yield item
        except Exception as e:
            print("not insert " + str(e))

from scrapy.cmdline import execute
# execute("scrapy crawl store_327 -a list_id=327".split())