# -*- coding: utf-8 -*-
import datetime

import scrapy

from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func


class Store440Spider(scrapy.Spider):
    name = 'store_440'
    allowed_domains = []
    start_urls = ['https://kiterealty.com/properties/operating-portfolio']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)


    def parse(self, response):
        links = response.xpath('//div[@class="property-archive__property__title"]/a/@href').getall()
        for link in links:
            yield scrapy.Request(url=link, callback=self.parse2)


    def parse2(self, response):
        try:property_name = address = response.xpath('//div[@class="property__header__info "]/div/h1/text()').get(default='').strip()
        except Exception as e:print(e)

        try:city = response.xpath('//div[@class="property__header__info "]/div/h2/text()').get(default='').split(',')[0].strip()
        except Exception as e:print(e)

        try:state = response.xpath('//div[@class="property__header__info "]/div/h2/text()').get(default='').split(',')[-1].strip()
        except Exception as e:print(e)

        try:GLA = response.xpath('//h4[contains(text(),"GLA")]/following-sibling::h3/text()').get(default='').strip()
        except Exception as e:print(e)

        try:leasing_contact = response.xpath('//div[@class="property__contact__text"]/h2/text()').get(default='').strip()
        except Exception as e:print(e)

        try:leasing_phone = response.xpath('//div[@class="property__contact__text"]/a[1]/text()').get(default='').strip()
        except Exception as e:print(e)

        try:leasing_email = response.xpath('//div[@class="property__contact__text"]/a[2]/text()').get(default='').strip()
        except Exception as e:print(e)

        try:site_plan_url = response.xpath('//div[@class="property__site-plan__image"]/a/@href').get(default='').strip()
        except Exception as e:print(e)

        property_url = response.url

        try:brochure_url = response.xpath('//div[@class="property__resource"]/a/@href').get(default='').strip()
        except Exception as e:print(e)

        item = ProprtySitesItem()
        item['Property_Name'] = property_name
        item['Address'] = address
        item['City'] = city
        item['State'] = state
        item['GLA'] = GLA
        item['Leasing_Contact_Name'] = leasing_contact
        item['Leasing_Contact_Phone'] = leasing_phone
        item['Leasing_Contact_Email'] = leasing_email
        item['Site_Plan_URL'] = site_plan_url
        item['Property_URL'] = property_url
        item['Brochure_URL'] = brochure_url
        yield item

# from scrapy.cmdline import execute
# execute('scrapy crawl store_440 -a list_id=440'.split())
