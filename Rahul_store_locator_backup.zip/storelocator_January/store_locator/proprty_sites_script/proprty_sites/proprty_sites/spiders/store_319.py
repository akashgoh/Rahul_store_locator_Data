# -*- coding: utf-8 -*-
import hashlib
import scrapy
import datetime
import scrapy, json, requests, re
import html2text
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func

class PoagllcSpider(scrapy.Spider):
    name = 'store_319'
    allowed_domains = ['example.com']
    # not_export_data = True
    #start_urls = []

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        try:
            url = 'https://www.poagllc.com/lifestyle-centers/'#'https://www.poagllc.com/lifestyle-centers/page/2/']
            #for url in urls:
            yield scrapy.FormRequest(url=url, callback=self.parse, dont_filter=True)
        except Exception as e:
            print(e)

    def parse(self, response):
        try:
            links = response.xpath('//*[@id="prop-list"]/div/a/@href').getall()
            for link in links:
            # link = 'https://www.poagllc.com/lifestyle-center/the-promenade-shops-at-evergreen-walk/'
                yield scrapy.FormRequest(url=link, callback=self.parse_data, dont_filter=True)
        except Exception as e:
            print(e)

    def parse_data(self, response):

        # uniqueid = int(hashlib.md5(bytes(str(response.url) + str(datetime.date.today()), "utf8")).hexdigest(), 16) % (10 ** 30)
        # try:
        #     f = open('E:/Anil/Html Pages/StoreLocator/poagllc/' + str(uniqueid) + '.html', 'wb')
        #     f.write(response.text.encode('utf-8'))
        #     print('Page Saved...', str(uniqueid))
        #     f.close()
        # except Exception as e:
        #     print(e)

        try:
            item = ProprtySitesItem()

            addr = response.xpath('//*[contains(text(),"LOCATION")]/../following-sibling::ul[1]/li[1]/text()').getall()
            # if addr == None:
            if addr == []:
                addr = response.xpath('//*[contains(text(),"Location")]/following-sibling::p/text()').getall()
                if addr == []:
                    addr = response.xpath('//*[contains(text(),"LOCATION")]/../p/text()').getall()


            print(addr)

            if len(addr) > 2:
                try:
                    item['Property_Name'] = response.xpath('//h1/text()').get().split('-')[0]
                    print(item['Property_Name'])
                except:item['Property_Name'] = ''

                try:
                    item['Address'] = addr[1].strip()
                    print(item['Address'])
                except:item['Address'] = ''

                try:
                    item['City'] = addr[2].split(',')[0].strip()
                    print(item['City'])
                    if item['City'] == '':
                        item['City'] = addr[1].split(',')[1].strip()
                        print(item['City'])
                        item['City'] = item['City'].split(' ')[0].strip()
                        print(item['City'])
                except:
                    item['City'] = ''

                try:
                    statezip = addr[2].split(',')[1].strip()
                    print(statezip)
                    if statezip == '':
                        statezip = addr[1].split(',')[1].strip()
                        statezip = statezip.split(' ')[1].strip()
                        print(statezip)
                except:
                    # statezip = addr[1].split(',')[1].strip()
                    # statezip = statezip.split(' ')[1].strip()
                    # print(statezip)
                    statezip = ''


                try:
                    item['State'] = statezip.split()[0].strip()
                    print(item['State'])
                except:item['State'] = ''

                try:
                    item['zip_code'] = statezip.split()[1].strip()
                    print(item['zip_code'])
                except:item['zip_code'] = ''

            else:

                try:
                    item['Property_Name'] = response.xpath('//h1/text()').get().split('-')[0]
                    print(item['Property_Name'])
                except:item['Property_Name'] = ''

                try:
                    item['Address'] = addr[1].split(',')[0]
                    print(item['Address'])
                except:item['Address'] = ''

                try:
                    item['City'] = addr[1].split(',')[1].strip().split()[0]
                    print(item['City'])
                except:item['City'] = ''

                try:
                    item['State'] = addr[1].split(',')[1].strip().split()[1]
                    print(item['State'])
                except:item['State'] = ''

            try:
                Mall_Phone = response.xpath('//h5[contains(text(),"LOCATION")]/following-sibling::ul[1]/li[2]/text()').extract_first()
                print(Mall_Phone)
                if Mall_Phone == None:
                    Mall_Phone = response.xpath('//h3[contains(text(),"Location")]/../p/text()[4]').extract_first()
                    if Mall_Phone == None:
                        Mall_Phone = response.xpath('//h1[contains(text(),"Location")]/../p/text()[4]').extract_first()
                        if Mall_Phone == None:
                            Mall_Phone = response.xpath('//h2[contains(text(),"Location")]/../p/text()[4]').extract_first()
                            if Mall_Phone == None:
                                Mall_Phone = response.xpath('//strong[contains(text(),"LOCATION")]/../following-sibling::ul/li[2]/text()').extract_first()
                                if Mall_Phone == None:
                                    Mall_Phone = response.xpath('//h2[contains(text(),"Location")]/../p/text()[5]').extract_first()
                                    if Mall_Phone == None:
                                        Mall_Phone = response.xpath('//h2[contains(text(),"LOCATION")]/../p/text()[4]').extract_first()

                print(Mall_Phone)
                item['Mall_Phone'] = Mall_Phone
            except:
                item['Mall_Phone'] = ''

            try:
                Website = response.xpath('//h5[contains(text(),"WEBSITE")]/following-sibling::ul[1]/li[1]//text()').extract_first()
                if Website == None :
                    Website = response.xpath('//h3[contains(text(),"Website")]/../p/a/text()').get()
                    if Website == None:
                        Website = response.xpath('//h2[contains(text(),"Website")]/../p/a/text()').get()
                        if Website == None:
                            Website = response.xpath('//h2[contains(text(),"WEBSITE")]/../p/a/text()').get()
                            if Website == None:
                                Website = response.xpath('//strong[contains(text(),"WEBSITE")]/../following-sibling::ul/li/a/text()').extract_first()

                print(Website)
                item['Website'] = Website
            except:
                item['Website'] = ''

            try:
                # gla = ''.join(response.xpath('//h5[contains(text(),"FACTS")]/following-sibling::ul[1]/li[2]//text()').getall()).split(':')[1].replace(',','').strip()
                gla = ''.join(response.xpath('//h3[contains(text(),"Facts")]//following-sibling::p/text()[2]').getall()).replace(',','').strip()
                print(gla)
                if gla == '':
                    gla = "".join(response.xpath('//h2[contains(text(),"FACTS")]//following-sibling::p/text()').extract()).replace(',','').strip()
                    if gla == '':
                        gla = "".join(response.xpath('//h2[contains(text(),"Facts")]//following-sibling::p/text()').extract()).replace(',','').strip()
                        if gla == '':
                            gla = "".join(response.xpath('//h3[contains(text(),"Facts")]//following-sibling::p/text()').extract()).replace(',','').strip()
                            if gla == '':
                                gla = "".join(response.xpath('//strong[contains(text(),"FACTS")]/../following-sibling::ul[1]/li[2]/text()').extract()).replace(',','').strip()

                print(gla)

                GLA = re.findall(r'(\d+)',gla)[0]
                print(GLA)
                item['GLA'] = GLA
            except Exception as e:
                print(e)

                item['GLA'] = ''

            try:
                # lease1 = response.xpath('//h5[contains(text(),"LEASING")]/following-sibling::ul[1]/li[1]/text()').getall()
                lease1 = response.xpath('//h2[contains(text(),"LEASING")]/following-sibling::p/text()').getall()
                if lease1 == []:
                    lease1 = response.xpath('//strong[contains(text(),"LEASING")]/../following-sibling::ul[1]/li[1]/text()').getall()
                    if lease1 == []:
                        lease1 = response.xpath('//h2[contains(text(),"Leasing")]/../p/text()').getall()
                        if lease1 == []:
                            lease1 = response.xpath('//h3[contains(text(),"Leasing")]/../p/text()').getall()

                item['Leasing1'] = lease1[0].strip()
                print(item['Leasing1'])
                item['Leasing1_Phone'] = lease1[1].strip()
                print(item['Leasing1_Phone'])

                # item['Leasing1_Email'] = response.xpath('//h5[contains(text(),"LEASING")]/following-sibling::ul[1]/li[1]/a/text()').get()
                item['Leasing1_Email'] = response.xpath('//h2[contains(text(),"LEASING")]/following-sibling::p/a/text()').get()
                if item['Leasing1_Email'] == None:
                        item['Leasing1_Email'] = response.xpath('//h2[contains(text(),"Leasing")]/../p/a/text()').extract_first()
                        if item['Leasing1_Email'] == None:
                            item['Leasing1_Email'] = response.xpath('//h3[contains(text(),"Leasing")]/../p/a/text()').extract_first()
                            if item['Leasing1_Email'] == None:
                                item['Leasing1_Email'] = response.xpath('//strong[contains(text(),"LEASING")]/../following-sibling::ul/li[1]/a/text()').extract_first()
                print(item['Leasing1_Email'])

            except:
                item['Leasing1'] = ''
                item['Leasing1_Phone'] = ''
                item['Leasing1_Email'] = ''

            try:
                lease2 = response.xpath('//h5[contains(text(),"LEASING")]/following-sibling::ul[1]/li[2]/text()').getall()
                item['Leasing2'] = lease2[0].strip()
                print(item['Leasing2'])
                item['Leasing2_Phone'] = lease2[1].strip()
                print(item['Leasing2_Phone'])
                item['Leasing2_Email'] = response.xpath('//h5[contains(text(),"LEASING")]/following-sibling::ul[1]/li[2]/a/text()').get()
                print(item['Leasing2_Email'])
            except:
                item['Leasing2'] = ''
                item['Leasing2_Phone'] = ''
                item['Leasing2_Email'] = ''

            try:
                Brochure_URL = response.xpath('//*[contains(text(),"Leasing Brochure")]/@href').extract_first()
                print(Brochure_URL)
            except Exception as e:
                Brochure_URL = ''

            try:
                Plan_URL = response.xpath('//*[contains(text(),"Site Plan")]/@href').extract_first()
                print(Plan_URL)
            except Exception as e:
                Plan_URL = ''

            item['Brochure_URL'] = Brochure_URL
            item['Plan_URL'] = Plan_URL
            item['URL'] = response.url
            print(item['URL'])


            yield item

        except Exception as e:
            print(e)

# 'ID,Property_Name,Address,City,State,zip_code,Mall_Phone,Website,GLA,Leasing1,Leasing1_Phone,Leasing1_Email,Leasing2,Leasing2_Phone,Leasing2_Email,URL'

from scrapy import cmdline
# cmdline.execute("scrapy crawl store_319 -a list_id=319".split())