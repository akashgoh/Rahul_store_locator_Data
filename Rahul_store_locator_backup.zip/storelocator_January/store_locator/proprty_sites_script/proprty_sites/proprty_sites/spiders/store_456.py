# -*- coding: utf-8 -*-
import datetime
import json
import re
import hashlib
import html2text
import scrapy
from scrapy.http import HtmlResponse
from w3lib.html import remove_tags
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func
import datetime
import re


class store_456_Spider(scrapy.Spider):
    name = 'store_456'
    allowed_domains = []
    start_urls = ['http://www.saulcenters.com/porfolio-properties-map.htm']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)
    # custom_settings = {
    #     "FEED_EXPORT_FIELDS": ["Property Name", "Address", "City", "State", "Zip", "GLA", "Description",
    #                            "Leasing Contact Name",
    #                            "Leasing Contact Phone", "Brochure URL",
    #                            "Property URL"]
    # }
    def parse(self,response):
       url = response.xpath('//*[@align="left"]//font/a/@href').extract()
       for ul in url:
           ul = 'http://www.saulcenters.com/' + ul
           yield scrapy.Request(url=str(ul), callback=self.parseData2, dont_filter=True)

    def parseData2(self,response):
        item = dict()

        try:
            info = response.xpath("//*[contains(text(),'Location')]/following-sibling::text()").extract()
            info = [info.strip() for info in info]
            info = list(filter(lambda v: v is not '', info))
            if len(info) == 2:
                address = info[0].strip()
                city = info[1].split(',')[0].strip()
                state = info[1].split(',')[1].split()[0].strip()
                try:zipc = info[1].split(',')[1].split()[1].strip()
                except:zipc=''
            elif len(info) == 3:
                print(info)
                del info[0]
                print(info)
                address = info[0].strip()
                city = info[1].split(',')[0].strip()
                state = info[1].split(',')[1].split()[0].strip()
                try:
                    zipc = info[1].split(',')[1].split()[1].strip()
                except:
                    try:
                        zipc = info[1].split(',')[1].split(',')[1].strip()
                    except:
                        zipc=''

            else:
                try:address = info[0].strip()
                except:address=''
                try:city = info[1].split(',')[0].strip()
                except:city=''
                try:state = info[1].split(',')[1].split()[0].strip()
                except:state=''
                try:zipc = info[1].split(',')[1].split()[1].strip()
                except:zipc=''
        except Exception as e:
            print(e)
        print()
        Address = address
        City = city
        State = state
        Zip = zipc


        try:
            Property_Name = re.sub(r'\s+', ' ',response.xpath('//b[@class="content"]/text()').get().strip())
            if not Property_Name:
                Property_Name = re.sub(r'\s+', ' ',''.join(response.xpath('//*[@href="index.htm"]//text()').extract()).strip())
        except Exception as e:
            Property_Name = ''

        try:
            gla = response.xpath("//*[contains(text(),'SF:')]/ancestor::tr[1]/td[2]//text()").extract()
            gla = [gla.strip() for gla in gla][0]
            GLA = re.findall(r'(\d+,\d+)',gla)[0].strip()
        except Exception as e:
            GLA = ''

        try:
            try:condition = remove_tags(response.text.split('"><span class="content"><span class="contentBold">')[1])
            except:
                try:condition = remove_tags(response.text.split('align="left" class="content"><span class="contentBold"')[1])
                except:condition = remove_tags(response.text.split('p align="left"><span class="contentBold"')[1])
            a = condition.split('Location:')[0].strip()
            Description = re.sub(r'\s+', ' ',a).replace('&nbsp;','').replace('<','').replace('>','').strip()
        except Exception as e:
            Description = ''

        try:
            Brochure_URL = ''.join(response.xpath('//*[@src="../../../images/download2.gif"]/parent::a/@href').extract()).replace('../../../Marketing Brochures/','http://www.saulcenters.com/Marketing%20Brochures/')
        except Exception as e:
            Brochure_URL = ''


        try:
            Lease_Plan_URL = ''.join(response.xpath('//*[@src="../../../images/download2.gif"]/parent::a/@href').extract()).replace('../../../Marketing Brochures/','http://www.saulcenters.com/Marketing%20Brochures/')
        except Exception as e:
            Lease_Plan_URL = ''


        try:
            Leasing_Contact_Name = re.sub(r'\s+', ' ',response.xpath("//*[contains(text(),'Contact')]/following-sibling::a/text()").extract_first(default="")).strip()
            if not Leasing_Contact_Name:
                Leasing_Contact_Name = re.sub(r'\s+', ' ', response.xpath('''//*[contains(text(),'Contact')]/..//a[@class="content"]/text()''').extract_first(default="")).strip()
        except Exception as e:
            Leasing_Contact_Name = ''

        try:
            Leasing_Contact_Phone = re.sub(r'\s+', ' ',re.findall(r'P: (\d+.\d+.\d+)', response.text)[0])
        except Exception as e:
            Leasing_Contact_Phone = ''


        try:
            item = ProprtySitesItem()
            item['Property_Name'] = Property_Name
            item['Address']=Address
            item['City'] = City
            item['State'] = State
            item['Zip']=Zip
            item['GLA'] = GLA
            item['Description']=Description

            item['Leasing_Contact_Name']=Leasing_Contact_Name
            item['Leasing_Contact_Phone'] =Leasing_Contact_Phone
            item['Brochure_URL']=Brochure_URL

            item['Property_URL'] = response.url
            item['Lease_Plan_URL']=Lease_Plan_URL
            # hasstr = (str(item['Property_URL'])+str(item['Property_Name'])).encode('utf8')
            # Hash_id = int(hashlib.md5(hasstr).hexdigest(), 16)
            # item['hash'] = Hash_id


            # print (item)
            yield item
        except Exception as e:
            print("item", e)


# from scrapy.cmdline import execute
# execute('''scrapy crawl store_456 -a list_id=456'''.split())
