import re
import scrapy, logging, hashlib
import requests, json
from lxml import html
from scrapy.cmdline import execute
from scrapy.http import HtmlResponse
import datetime
import scrapy, json, requests, re
import html2text
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func

class Store432Spider(scrapy.Spider):
    name = 'store_432'
    allowed_domains = []

    # def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
    #     super().__init__(name, **kwargs)
    #     self.list_id, self.proxy_type = list_id, proxy_type
    #     self.f1 = Func()
    #     self.run_date = str(datetime.datetime.today()).split()[0]
    #     self.con = self.f1.con
    #     self.cursor = self.f1.cursor
    #     self.cursor.execute('SET GLOBAL local_infile = "ON";')
    #     self.cursor.execute('''create table if not exists garden_commercial_properties_data (store_hash_id varchar(32) NOT NULL,
    #                                                                 `Property Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
    #                                                                 `Address` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
    #                                                                 `City` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
    #                                                                 `State` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
    #                                                                 `zip code` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
    #                                                                 `Description` longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
    #                                                                 `GLA` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
    #                                                                 `Leasing Contact` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
    #                                                                 `Leasing Phone` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
    #                                                                 `Leasing Email` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
    #                                                                 `Site Plan URL` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
    #                                                                 `Property URL` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
    #                                                                  PRIMARY KEY (store_hash_id))''')

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        try:
            source_url = link = f'https://gardencommercial.com/retail/'
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(self.run_date) + '.html'
            yield scrapy.FormRequest(url=str(link), callback=self.firstlevel,
                                     meta={'source_url': source_url,
                                           'file_path': file_path, 'proxy_type': self.proxy_type})
        except Exception as e:
            logging.log(logging.ERROR, e)

    def firstlevel(self, response):
        try:
            source_url = response.meta['source_url']
            file_path = response.meta['file_path']
            proxy_type = response.meta['proxy_type']
            links_data = re.findall(r'et_link_options_data = (.*?);', response.text)[0]
            links = json.loads(links_data)
            for i in range(len(links)):
                link = links[i]["url"]+'location/'
                yield scrapy.FormRequest(url=link, callback=self.get_store_list,
                                         meta={'source_url': source_url, 'file_path': file_path,'proxy_type': proxy_type})

        except Exception as e:
            print("firstlevel", e, response.url)

    # Get data from the response
    def get_store_list(self, response):
        try:
            try:
                Property_Name = response.xpath('//h2/text()').extract_first(default='').strip()
            except Exception as e:
                print("store_name", e, response.url)

            try:
                address_link = response.xpath('//iframe/@src').extract_first()
                if address_link:
                    address_r = requests.get(address_link)
                    address_d = re.findall(r'initEmbed\((.*?)\);', address_r.text)[0]
                    address_data = json.loads(address_d)
                    addr = address_data[21][3][0][1]
                    if not addr:
                        addr = address_data[5][0][0][7][1][1]

                    if addr:
                        addr = addr.split(',')
                        address = addr[0].strip()
                        city = addr[1].strip()
                        state = addr[-1].strip().split(' ')[0].strip()
                        zip_code = addr[-1].strip().split(' ')[-1].strip()
            except Exception as e:
                print(e)

            try:
                description_link = response.xpath('//a[contains(text(),"Overview")]/@href').extract_first()
                description_r = requests.get(description_link)
                des_res = html.fromstring(description_r.text)
                Description = ''.join(des_res.xpath('//*[@class="et_pb_row et_pb_row_2"]//text()')).strip()
                print(Description)


                GLA_text = des_res.xpath('//*[contains(text(),"Total GLA")]/../text()')
                if GLA_text:
                    GLA = re.findall(r'(\d+)', GLA_text[0].replace(',', ''))
                    if GLA:
                        GLA = GLA[0]
                    else:
                        GLA = ''
                else:
                    GLA = ''
            except Exception as e:
                print(e)

            try:
                leasing_link = response.xpath('//a[contains(text(),"Contact")]/@href').extract()[1]
                header = {
                    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
                    "accept-encoding": "gzip, deflate, br",
                    "accept-language": "en-US,en;q=0.9",
                    "cache-control": "max-age=0",
                    "referer": description_link,
                    "sec-fetch-dest": "document",
                    "sec-fetch-mode": "navigate",
                    "sec-fetch-site": "same-origin",
                    "sec-fetch-user": "?1",
                    "upgrade-insecure-requests": "1",
                    "user-agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.100 Safari/537.36"
                }
                leasing_r = requests.get(leasing_link, headers=header)

                leasing_response = html.fromstring(leasing_r.text)

                Leasing_Contact = leasing_response.xpath('//*[@class="et_pb_module et_pb_text et_pb_text_2  et_pb_text_align_left et_pb_bg_layout_light"]/div/strong/text()')
                if Leasing_Contact:
                    Leasing_Contact = Leasing_Contact[0]
                else:
                    Leasing_Contact = ''
                Leasing_Phone = ''.join(leasing_response.xpath('//*[@class="et_pb_module et_pb_text et_pb_text_2  et_pb_text_align_left et_pb_bg_layout_light"]/div/text()')).strip()
                Leasing_Email = leasing_response.xpath('//*[@class="et_pb_module et_pb_text et_pb_text_2  et_pb_text_align_left et_pb_bg_layout_light"]/div/a/text()')
                if Leasing_Email:
                    Leasing_Email = Leasing_Email[0]
                else:
                    Leasing_Email = ''
            except Exception as e:
                print(e)

            try:
                plan_link = response.xpath('//a[contains(text(),"Site Plan")]/@href').extract_first(default='')
                if plan_link:
                    plan_r = requests.get(plan_link)
                    plan_res = html.fromstring(plan_r.text)

                    Site_Plan_URL = plan_res.xpath('//*[@class="et_pb_image_wrap "]/img/@src')
                    if Site_Plan_URL:
                        Site_Plan_URL = Site_Plan_URL[1]
                        print(Site_Plan_URL)
                    else:
                        Site_Plan_URL = ''
                else:
                    Site_Plan_URL = ''
            except Exception as e:
                print(e)

            URL = description_link
            try:
                store_hash_id = bytes(f"{Property_Name} {address} {state} {city} {zip_code} {GLA} {Description} {Leasing_Contact} {Leasing_Phone} {Leasing_Email} {Site_Plan_URL} {URL}", encoding='utf-8')
                store_hash_id = int(hashlib.md5(store_hash_id).hexdigest(), 16) % (10 ** 16)
            except Exception as e:
                print(e)
            #
            # try:
            #     insert = "insert into garden_commercial_properties_data (store_hash_id, `Property Name`, `Address`, `City`, `State`, `Zip Code`, `Description`, `GLA`, `Leasing Contact`, `Leasing Phone`, `Leasing Email`, `Site Plan URL`, `Property URL`) values(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
            #     self.cursor.execute(insert, (store_hash_id, Property_Name, address, city, state, zip_code, Description, GLA, Leasing_Contact, Leasing_Phone, Leasing_Email, Site_Plan_URL, URL))
            #     self.con.commit()
            #     print('Data Inserted...')
            # except Exception as e:
            #     print(e)


            item = ProprtySitesItem()
            item['Property_Name'] = Property_Name
            item['Address'] = address
            item['City'] = city
            item['State'] = state
            item['Description'] = Description
            item['zip_code'] = zip_code
            item['Leasing_Contact'] = Leasing_Contact
            item['Leasing_Phone'] = Leasing_Phone
            item['Leasing_Email'] = Leasing_Email
            item['Site_Plan_URL'] = Site_Plan_URL
            item['Property_URL'] = response.url

            yield item
        except Exception as e:
            logging.log(logging.ERROR, e)

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_432 -a list_id=432 -a proxy_type='''.split())