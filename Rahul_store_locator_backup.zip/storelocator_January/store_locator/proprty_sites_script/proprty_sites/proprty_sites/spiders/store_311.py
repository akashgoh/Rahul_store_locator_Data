import hashlib
import scrapy
# from storelocatore_property.items import StorelocatorePropertyItem
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func
import datetime
class GBT(scrapy.Spider):
    name = 'store_311'

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        source_url = 'http://www.gbtrealty.com/stores#current-devs'
        file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(self.run_date) + '.html'
        yield scrapy.Request(url=source_url,callback=self.parse,meta={'source_url': source_url, 'file_path': file_path})

    def parse(self, response):
        urls = response.xpath('//*[contains(text(),"More Information")]/@href').extract()
        for url in urls:
            yield scrapy.Request(url='http://www.gbtrealty.com'+url,callback=self.Extractdata)

    def Extractdata(self,response):
        item = ProprtySitesItem()
        try:
            item['Property_Name'] = response.xpath('//*[@class="title"]/a/text()').extract_first().strip()
        except Exception as e:
            item['Property_Name'] = ''
            print('error in Property_Name : ', e)

        try:
            item['Address'] = response.xpath('//*[@class="store-title"]/p/text()').extract_first().split(',')[0].strip()
        except Exception as e:
            item['Address'] = ''
            print('error in Address : ', e)
        try:
            item['City'] = response.xpath('//*[@class="store-title"]/p/text()').extract_first().split(',')[1].strip()
        except Exception as e:
            item['City'] = ''
            print('error in City : ', e)

        try:
            item['State'] = response.xpath('//*[@class="store-title"]/p/text()').extract_first().split(',')[2].strip().split(' ')[0]
        except Exception as e:
            item['State'] = ''
            print('error in State : ', e)

        try:
            item['zip_code'] = response.xpath('//*[@class="store-title"]/p/text()').extract_first().split(',')[2].strip().split(' ')[1]
        except Exception as e:
            item['zip_code'] = ''
            print('error in zip_code : ', e)

        try:
            item['Description'] = ''.join(response.xpath('//*[@id="main"]/div[3]/div/p/text()').getall())
        except Exception as e:
            item['Description'] = ''
            print(e)

        try:
            item['Leasing_Contact_Name'] = response.xpath("//*[contains(text(),'LEASING INFORMATION')]/../../div//a/text()").extract_first()
        except Exception as e:
            item['Leasing_Contact_Name'] = ''
            print('error in Contact : ',e)

        try:
            item['Leasing_Contact_Phone'] = ''
        except Exception as e:
            item['Leasing_Contact_Phone'] = ''
            print('error in Phone : ',e)

        # try:
        #     item['Leasing_Contact_Email'] = response.xpath("//*[contains(text(),'LEASING INFORMATION')]/../../div//a/@href").extract_first().replace("mailto:","")
        # except Exception as e:
        #     item['Leasing_Contact_Email'] = ''
        #     print('error in Email : ',e)

        # try:
        #     item['GLA'] = ''
        #     # if item['Avail_SQFT'] == None:
        #     #     item['Avail_SQFT'] = ''
        # except Exception as e:
        #     item['GLA'] = ''
        #     print('error in Avail_SQFT : ', e)

        # try:
        #     item['Anchors'] = ''
        # except Exception as e:
        #     item['Anchors'] = ''
        #     print('error in Anchors : ', e)
        #
        # try:
        #     item['MSA'] = ''
        # except Exception as e:
        #     item['MSA'] = ''
        #     print('error in MSA : ', e)
        # try:
        #     item['SQFT'] = ''
        # except Exception as e:
        #     item['SQFT'] = ''
        #     print('error in SQFT : ', e)

        try:
            item['Site_Plan_URL'] = 'https://www.gbtrealty.com'+response.xpath('//*[@class="single__propmap"]/@src').extract_first()
        except Exception as e:
            item['Site_Plan_URL'] = ''
            print(e)

        try:
            item['Brochure_URL'] = 'http://www.gbtrealty.com' + response.xpath('//div[@class="download"]/a/@href').get()
        except Exception as e:
            item['Brochure_URL'] = ''
            print(e)

        item['Property_URL'] = response.url
        # hasstr = (str(response.url) + str(item['Property_Name'])).encode('utf8')
        # Hash_id = int(hashlib.md5(hasstr).hexdigest(), 16)
        # item['Hasid'] = Hash_id
        yield item

# from scrapy.cmdline import execute
# execute('''scrapy crawl store_311 -a list_id=311'''.split())