# -*- coding: utf-8 -*-
import datetime
import scrapy, json, requests, re
import html2text
from scrapy.http import HtmlResponse

from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func

h = html2text.HTML2Text()

class InlandgroupCrawlerSpider(scrapy.Spider):
    name = 'store_461'
    allowed_domains = ['www.example.com']
    start_urls = ['https://inlandgroup.com/irea/property-portfolio']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)
    def parse(self, response):
        try:
            links = [
                "http://iires.propertycapsule.com/properties/10075056#overview",
                "http://iires.propertycapsule.com/properties/10075051#overview",
                "http://iires.propertycapsule.com/properties/10075055#overview",
                "http://iires.propertycapsule.com/properties/10075052#overview",
                "http://iires.propertycapsule.com/properties/circaatfishhawkranch#overview",
                "http://iires.propertycapsule.com/properties/enclaveatcharlespond#overview",
                "http://iires.propertycapsule.com/properties/emerushospital#overview",
                "http://iires.propertycapsule.com/properties/10051307#overview",
                "http://iires.propertycapsule.com/properties/10075036#overview",
                "http://iires.propertycapsule.com/properties/10075014#overview",
                "http://iires.propertycapsule.com/properties/penncircleapartments#overview",
                "http://iires.propertycapsule.com/properties/steeplechaseatparkview#overview",
                "http://iires.propertycapsule.com/properties/10075019#overview",
                "http://iires.propertycapsule.com/properties/foxpointeapartmenthomes#overview"
            ]

            # url = "http://iires.propertycapsule.com/property/output/find/search/overview"
            rr = requests.get('http://iires.propertycapsule.com/property/output/find/search/overview')
            response1 = HtmlResponse(body=bytes(rr.text.encode("utf-8")), url='')
            data1 = re.findall('window.uniqueSpaces =(.*?]);', response1.text)[0]
            data = json.loads(data1)
            le = len(data)
            for i in range(0, le):
                url = "http://iires.propertycapsule.com/properties/" + data[i]['propertyId']
                yield scrapy.FormRequest(url=url, callback=self.firstlevel, dont_filter=True)

            for link in links:

                yield scrapy.FormRequest(url=link,callback=self.firstlevel,dont_filter=True)


        except Exception as e:
            print("parse",e,response.url)

    def firstlevel(self,response):
        try:


            try:
                Property_Name = response.xpath(
                    '//h2[@class="property-metadata p-label"]/text()').extract_first()
                if Property_Name == None:
                    Property_Name = ''
                else:
                    Property_Name = Property_Name.strip()
            except Exception as e:
                print("Property_Name", e, response.url)

            try:
                Address = response.xpath(
                    '//span[@class="p-street-address"]/text()').extract_first()
                if Address == None:
                    Address = ''
                else:
                    Address = Address.strip()
            except Exception as e:
                print("Address", e, response.url)

            try:
                City = response.xpath(
                    '//span[@class="p-locality"]/text()').extract_first()
                if City == None:
                    City = ''
                else:
                    City = City.strip()
            except Exception as e:
                print("City", e, response.url)

            try:
                State = response.xpath('//span[@class="p-region"]/text()').extract_first()
                if State == None:
                    State = ''
                else:
                    State = State.strip()
            except Exception as e:
                print("State", e, response.url)

            try:
                Zip = response.xpath(
                    '//span[@class="p-postal-code"]/text()').extract_first()
                if Zip == None:
                    Zip = ''
                else:
                    Zip = Zip.strip()
            except Exception as e:
                print("Zip", e, response.url)

            datafr = re.findall('window.property =(.*?});', response.text)[0]
            data = json.loads(datafr)

            try:
                GLA = data['gla'] + " SF"
            except Exception as e:
                print("GLA", e, response.url)

            try:
                Description = ' '.join(response.xpath(
                    '//span[@id="propcap-overview"]//text()').extract())

                Description = re.sub('\s+', ' ', re.sub('\r|\n|\t', ' ', Description)).strip()
            except Exception as e:
                print("Description", e, response.url)

            try:
                Leasing_Contact_Name = response.xpath(
                    '//h3[contains(text(),"Leasing Manager")]/following-sibling::span[1]//span[@class="p-name"]/text()|//h3[contains(text(),"Leasing Manager")]/following-sibling::span[2]//span[@class="p-name"]/text()').extract_first()
                if Leasing_Contact_Name == None:
                    Leasing_Contact_Name = ''
                else:
                    Leasing_Contact_Name = Leasing_Contact_Name.strip()
            except Exception as e:
                print("Leasing_Contact_Name", e, response.url)

            try:
                Leasing_Contact_Phone = response.xpath(
                    '//h3[contains(text(),"Leasing Manager")]/following-sibling::span[1]//strong[@class="p-tel p-tel-office"]/text()|//h3[contains(text(),"Leasing Manager")]/following-sibling::span[2]//strong[@class="p-tel p-tel-office"]/text()').extract_first()
                if Leasing_Contact_Phone == None:
                    Leasing_Contact_Phone = ''
                else:
                    Leasing_Contact_Phone = Leasing_Contact_Phone.strip()
            except Exception as e:
                print("Leasing_Contact_Phone", e, response.url)

            try:
                if Leasing_Contact_Name!='':
                    Leasing_Contact_Email = re.findall('"email":"(.*?)",',response.text)[0]
                else:
                    Leasing_Contact_Email = ''
                # Leasing_Contact_Email = response.xpath(
                #     '//h3[contains(text(),"Leasing Manager")]/following-sibling::span[1]/div//a[@class="u-email"]/text()').extract_first()
                # if Leasing_Contact_Email == None:
                #     Leasing_Contact_Email = ''
                # else:
                #     Leasing_Contact_Email = Leasing_Contact_Email.strip()
            except Exception as e:
                print("Leasing_Contact_Email", e, response.url)

            try:
                Property_Manager_Name = ''.join(response.xpath(
                    '//h3[contains(text(),"Property Management")]/following-sibling::p//text()').extract()).strip()

                Property_Manager_Name = Property_Manager_Name.strip()
            except Exception as e:
                print("Property_Manager_Name", e, response.url)



            try:
                images = re.findall('</h4><img src="(.*?)"',response.text)
                if len(images)>=1:
                    images = images[0]
                else:
                    images
                Site_Plan_URL =images
            except Exception as e:
                print("Site_Plan_URL", e, response.url)

            item = ProprtySitesItem()
            item['Property_Name'] = Property_Name
            item['Address'] = Address
            item['City'] = City
            item['State'] = State
            item['Zip'] = Zip
            item['GLA'] = GLA
            item['Description'] = Description
            item['Leasing_Contact_Name'] = Leasing_Contact_Name
            item['Leasing_Contact_Phone'] = Leasing_Contact_Phone
            item['Leasing_Contact_Email'] = Leasing_Contact_Email
            item['Property_Manager_Name'] = Property_Manager_Name
            item['Site_Plan_URL'] = Site_Plan_URL
            item['Property_URL'] = response.url
            yield item

        except Exception as e:
            print("firstlevel",e,response.url)
#
# from scrapy.cmdline import execute
# execute("scrapy crawl store_461 -a list_id=461".split())
