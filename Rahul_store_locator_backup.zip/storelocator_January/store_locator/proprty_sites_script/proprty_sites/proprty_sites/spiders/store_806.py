# -*- coding: utf-8 -*-
import datetime
import scrapy, json, requests, re
import html2text
from scrapy.http import HtmlResponse

from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func


class store_806_Spider(scrapy.Spider):
    name = 'store_806'
    allowed_domains = ['']
    start_urls = ['https://ethanconradprop.com/listings/']


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        # urls = ['https://ethanconradprop.com/listings/?wplpage=1','https://ethanconradprop.com/listings/?wplpage=2']
        url = "https://ethanconradprop.com/properties/?sf_tmin_googlemap_lt=38.40677850940411&sf_tmax_googlemap_lt=38.858034995047284&sf_tmin_googlemap_ln=-121.51834493681639&sf_tmax_googlemap_ln=-121.15510946318358&sf_locationtextsearch=%20&sf_multiplelocationtextsearch=&sf_advancedlocationtextsearch=%20&widget_id=3&kind=1&sf_min_field_3047=0&sf_max_field_3047_max=10000&sf_select_property_type=6&sf_mmunit_field_3047=1&sf_select_listing=-1&wplview=property_listing&sf_unit_price=260&limit=100&wplorderby=ltype_adv%3AA10&wplorder=DESC&wplcolumns=3&wplpcc=map_box&wplpagination=normal&wplpage=1"
        # for url in urls:
        yield scrapy.FormRequest(url=url, callback=self.parse1)

    def parse1(self, response):
        links = response.xpath('//div[@class="wpl_prp_bot"]/a/@href').extract()
        for link in links:
            # link = 'https://ethanconradprop.com/listings/252-Retail-7837-Stockton-Blvd-Sacramento-California-95823/'
            yield scrapy.FormRequest(url=link, dont_filter=True, callback=self.parse2)

    def parse2(self, response):
        try:
            property_name = response.xpath('//div[@class="wpl_prp_show_title"]/h1/text()').get()
        except Exception as e:
            print(e)
            property_name = ''

        try:
            add = response.xpath('//div[@class="wpl_prp_show_title"]/h2/span/text()').get()
        except Exception as e:
            print(e)
            add = ''

        try:
            address = add.split(',')[0]
        except Exception as e:
            print(e)
            address = ''

        try:
            city = add.split(',')[1]
        except Exception as e:
            print(e)
            city = ''

        try:
            state = add.split(',')[2]
        except Exception as e:
            print(e)
            state = ''

        try:
            zip_code = add.split(',')[3]
        except Exception as e:
            print(e)
            zip_code = ''

        try:
            # gla = response.xpath('//div[contains(text(),"Space Available:")]//text()').get()
            # if gla == None:
            gla = response.xpath('//div[contains(text(),"Building Size : ")]/span/text()').get()
            if gla == None:
                gla = 00
        except Exception as e:
            print(e)
            gla = ''

        # try:
        #     pid = re.findall('"pid":"(.*?)"',response.text)[0]
        #     if pid :
        #         url = f'https://ethanconradprop.com/?wpl_format=f%3Aproperty_listing%3Aajax&wpl_function=load_suites&_wpnonce=&pid={pid}'
        #
        #         req = requests.request("GET", url)
        #         response1 = HtmlResponse(url=url, body=req.content)
        #         gla1 = re.findall('"maxSpaces":"(.*?)"',response1.text)[0]
        #     else:
        #         gla1 = ''

        # except Exception as e:
        #     print(e)
        #     gla1= ''



        try:
            property_description = ''.join(response.xpath('//div[@class="wpl_prp_show_detail_boxes_cont"]//text()').getall()).replace('[','').replace(']','').strip()
        except Exception as e:
            print(e)
            property_description = ''

        try:
            leasing_name1 = response.xpath('//*[@class="wpl_agent_info_activity"]/div[1]//li[@class="name"]/a/text()').get()
        except Exception as e :
            print(e)
            leasing_name1 = ''
        try:
            leasing_contact1 = response.xpath('//*[@class="wpl_agent_info_activity"]/div[1]//li[@class="tel"]/a/text()').get()
        except Exception as e:
            print(e)
            leasing_contact1 = ''
        try:
            leasing_email1 = response.xpath('//*[@class="wpl_agent_info_activity"]/div[1]//li[@class="email"]/p/text()').get()
        except Exception as e:
            print(e)
            leasing_email1 = ''

        try:
            leasing_name2 = response.xpath('//*[@class="wpl_agent_info_activity"]/div[2]//li[@class="name"]/a/text()').get()
        except Exception as e :
            print(e)
            leasing_name2 = ''
        try:
            leasing_contact2 = response.xpath('//*[@class="wpl_agent_info_activity"]/div[2]//li[@class="tel"]/a/text()').get()
        except Exception as e:
            print(e)
            leasing_contact2 = ''
        try:
            leasing_email2 = response.xpath('//*[@class="wpl_agent_info_activity"]/div[2]//li[@class="email"]/p/text()').get()
        except Exception as e:
            print(e)
            leasing_email2 = ''

        try:
            broucher_url = response.xpath('//a[contains(text(),"Property Brochure")]/@href').get()
        except Exception as e:
            print(e)
            broucher_url = ''

        source_url = ''.join(response.url)

        item = ProprtySitesItem()

        item['property_name'] = property_name
        item['address'] = address
        item['city'] = city
        item['state'] = state
        item['zip_code'] = zip_code
        item['gla'] = gla
        # item['gla1'] = gla1
        item['property_description'] = property_description
        item['leasing_name1'] = leasing_name1
        item['leasing_contact1'] = leasing_contact1
        item['leasing_email1'] = leasing_email1
        item['leasing_name2'] = leasing_name2
        item['leasing_contact2'] = leasing_contact2
        item['leasing_email2'] = leasing_email2
        item['broucher_url'] = broucher_url
        item['source_url'] = source_url


        yield item
# property_name,address,city,state,zip_code,gla,property_description,leasing_name1,leasing_contact1,leasing_email1,leasing_name2,leasing_contact2,leasing_email2,broucher_url,source_url


from scrapy.cmdline import execute
# execute("scrapy crawl store_806 -a list_id=806".split())


# ============================= set gla manually =============================#
