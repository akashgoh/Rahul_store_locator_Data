import json

import scrapy
import datetime
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func
import pandas as pd


class Store502Spider(scrapy.Spider):
    name = "store_502"
    allowed_domains = []
    start_urls = ['http://washingtonprime.com/map/#propertyList']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        df = pd.read_excel(r'E:\proprty_sites_script\washington_link.xlsx')
        for i in list(df['links']):
        # i = 'https://washingtonprime.com/properties/portfolio/mall-of-georgia-crossing/default.aspx'
            yield scrapy.Request(url=i,dont_filter=True, callback=self.get_data)

    def get_data(self, response):
        try:
            Property_Name1 = response.xpath('//*[@class="module_container module_container--outer"]//h2/span/text()').extract_first()
            if Property_Name1:
                Property_Name = Property_Name1.upper().strip()
        except Exception as e:
            print("Property Name" + str(e))

        try:
            full_address = response.xpath('//div[@class="address"]//a/text()').extract_first()
            if full_address:
                full_address = full_address.strip().split(',')
                Address = full_address[0]
                if Address:
                    Address = Address.upper().strip()
                City = full_address[-2]
                if City:
                    City = City.upper().strip()
                state_zip = full_address[-1]
                State = state_zip.strip().split(' ')[0].upper()
                Zip = state_zip.strip().split(' ')[1]
        except Exception as e:
            print("Address" + str(e))

        try:
            Description = response.xpath('//div[@class="address"]/following-sibling::p/text()').extract_first().strip()
        except Exception as e:
            print("Description" + str(e))

        try:
            path = response.xpath('//div[@class="grid"]/div[1]/h4[1]/text()').get()
            if  path == 'Leasing':
                Leasing_Contact_Name = response.xpath('//div[@class="grid"]/div[1]/h4[2]/text()').get()
                Leasing_Contact_Phone = response.xpath('//div[@class="grid"]/div[1]/p/text()').get()
                Leasing_Contact_Email = response.xpath('//div[@class="grid"]/div[1]//a/@href').get()

            elif  response.xpath('//div[@class="grid"]/div[2]/h4[1]/text()').get() == 'Leasing':
                Leasing_Contact_Name = response.xpath('//div[@class="grid"]/div[2]/h4[2]/text()').get()
                Leasing_Contact_Phone = response.xpath('//div[@class="grid"]/div[2]/p/text()').get()
                Leasing_Contact_Email = response.xpath('//div[@class="grid"]/div[2]//a/@href').get()

            elif response.xpath('//div[@class="grid"]/div[3]/h4[1]/text()').get() == 'Leasing':
                Leasing_Contact_Name = response.xpath('//div[@class="grid"]/div[3]/h4[2]/text()').get()
                Leasing_Contact_Phone = response.xpath('//div[@class="grid"]/div[3]/p/text()').get()
                Leasing_Contact_Email = response.xpath('//div[@class="grid"]/div[3]//a/@href').get()

            elif  response.xpath('//div[@class="grid"]/div[4]/h4[1]/text()').get() == 'Leasing':
                Leasing_Contact_Name = response.xpath('//div[@class="grid"]/div[4]/h4[2]/text()').get()
                Leasing_Contact_Phone = response.xpath('//div[@class="grid"]/div[4]/p/text()').get()
                Leasing_Contact_Email = response.xpath('//div[@class="grid"]/div[4]//a/@href').get()

            else:
                Leasing_Contact_Name = ''
                Leasing_Contact_Phone = ''
                Leasing_Contact_Email = ''
        except Exception as e:
            print("leasing" + str(e))

        try:
            path = response.xpath('//div[@class="grid"]/div[1]/h4[1]/text()').get()
            if path == 'Development' :
                Property_Manager_Name = response.xpath('//div[@class="grid"]/div[1]/h4[2]/text()').get()
                Property_manager_phone = response.xpath('//div[@class="grid"]/div[1]/p/text()').get()
                Property_manager_Email = response.xpath('//div[@class="grid"]/div[1]//a/@href').get()

            elif  response.xpath('//div[@class="grid"]/div[2]/h4[1]/text()').get() == 'Development':
                Property_Manager_Name = response.xpath('//div[@class="grid"]/div[2]/h4[2]/text()').get()
                Property_manager_phone = response.xpath('//div[@class="grid"]/div[2]/p/text()').get()
                Property_manager_Email = response.xpath('//div[@class="grid"]/div[2]//a/@href').get()

            elif response.xpath('//div[@class="grid"]/div[3]/h4[1]/text()').get() == 'Development':
                Property_Manager_Name = response.xpath('//div[@class="grid"]/div[3]/h4[2]/text()').get()
                Property_manager_phone = response.xpath('//div[@class="grid"]/div[3]/p/text()').get()
                Property_manager_Email = response.xpath('//div[@class="grid"]/div[3]//a/@href').get()

            elif response.xpath('//div[@class="grid"]/div[4]/h4[1]/text()').get() == 'Development':
                Property_Manager_Name = response.xpath('//div[@class="grid"]/div[4]/h4[2]/text()').get()
                Property_manager_phone = response.xpath('//div[@class="grid"]/div[4]/p/text()').get()
                Property_manager_Email = response.xpath('//div[@class="grid"]/div[4]//a/@href').get()

            else:
                Property_Manager_Name = ''
                Property_manager_phone = ''
                Property_manager_Email = ''
        except Exception as e:
            print("leasing" + str(e))

        p = response.url
        print(p)

        try:
            a = Property_Name1
            a = a.replace('St.','').strip()
            if 'Town Center Plaza | Town Center Crossing' in a:
                a = 'Town Center Plaza'
            elif 'North Ridge Shopping Center' in a:
                a = 'North Ridge'
            elif 'The Mall at Fairfield Commons' in a:
                a = 'Fairfield Commons'
            elif 'Classen Curve/Nichols Hills Plaza/The Triangle at Classen Curve' in a:
                a = 'Classen Curve'
            elif '®' in a:
                a = a.replace('®','').strip()
            elif 'Oak Court Mall and Office' in a:
                a = 'Oak Court Mall'
            elif 'The Mall at Johnson City' in a:
                a = 'Mall at Johnson City'
            elif 'Gateway Shopping Centers' in a:
                a = 'Gateway'
            elif 'The Shops at Arbor Walk' in a:
                a = 'Arbor Walk'
            elif 'The Shops at North East Mall' in a:
                a = 'North East Mall'
            elif 'Wolf Ranch Town Center' in a:
                a = 'Wolf Ranch'
            elif 'Charlottesville Fashion Square' in a:
                a = 'Charlottesville'
            elif 'The Outlet Collection | Seattle' in a:
                a = 'Outlet Collection'
            elif '™'in a :
                a = a.replace('™','').strip()
            b = a.replace(' ','%20')
            c = 'RC%20' + b
            # c = c.encode('utf-8').decode('utf-8').replace('™','')
            print(c)
            link = f'https://washingtonprime.com/feed/ContentAsset.svc/GetContentAssetList?apiKey=&LanguageId=1&assetType={c}&pageSize=-1&pageNumber=0&tagList=&includeTags=true&year=2020&excludeSelection=1'
            print(link)
            yield scrapy.Request(url=link, dont_filter=True, callback=self.next_parse,meta={'p':p,'Property_Name':Property_Name,'Address':Address,'City':City,'State':State,'Zip':Zip,'Description':Description,'Leasing_Contact_Name':Leasing_Contact_Name,'Leasing_Contact_Phone':Leasing_Contact_Phone,'Leasing_Contact_Email':Leasing_Contact_Email,'Property_Manager_Name':Property_Manager_Name,'Property_manager_phone':Property_manager_phone,'Property_manager_Email':Property_manager_Email})
        except Exception as e:
            print(e)

    def next_parse(self, response):
        # global Brochure_URL, Site_Plan_URL
        global Brochure_URL, Site_Plan_URL
        if response.text != '':
            # global I, I1
            Property_Name = response.meta['Property_Name']
            Address = response.meta['Address']
            City = response.meta['City']
            State = response.meta['State']
            Zip = response.meta['Zip']
            Description = response.meta['Description']
            Leasing_Contact_Name = response.meta['Leasing_Contact_Name']
            Leasing_Contact_Phone = response.meta['Leasing_Contact_Phone']
            Leasing_Contact_Email = response.meta['Leasing_Contact_Email']
            Property_Manager_Name = response.meta['Property_Manager_Name']
            Property_manager_phone = response.meta['Property_manager_phone']
            Property_manager_Email = response.meta['Property_manager_Email']
            p = response.meta['p']

            data = json.loads(response.text)
            n = len(data['GetContentAssetListResult'])
            print(n)
            for i in range(0,n):
                try:
                    Title = data['GetContentAssetListResult'][i]['Title']
                    if Title == 'Leasing Brochure':
                        Brochure_URL = data['GetContentAssetListResult'][i]['FilePath']

                        # ['GetContentAssetListResult'][i]['FilePath']
                        print(Brochure_URL)
                    # else:
                    #     Brochure_URL = ''
                except Exception as e:
                    Brochure_URL = ''

                try:
                    Title = data['GetContentAssetListResult'][i]['Title']
                    if Title == 'Leasing Sheet':
                        Site_Plan_URL = data['GetContentAssetListResult'][i]['FilePath']
                    # else:
                    #     Site_Plan_URL = ''

                except Exception as e:
                    # print("Site_Plan_URL" + str(e))
                    Site_Plan_URL = ''
            # Brochure_URL = Brochure_URL
            # Site_Plan_URL = Site_Plan_URL

            item = ProprtySitesItem()
            item['Property_Name'] = Property_Name
            item['Address'] = Address
            item['City'] = City
            item['State'] = State
            item['Zip'] = Zip
            item['Description'] = Description
            item['Leasing_Contact_Name'] = Leasing_Contact_Name
            item['Leasing_Contact_Phone'] = Leasing_Contact_Phone
            item['Leasing_Contact_Email'] = Leasing_Contact_Email
            item['Property_Manager_Name'] = Property_Manager_Name
            item['Property_manager_phone'] = Property_manager_phone
            item['Property_manager_Email'] = Property_manager_Email
            try:
                item['Brochure_URL'] = Brochure_URL
            except:
                item['Brochure_URL'] = ''
            try:
                item['Site_Plan_URL'] = Site_Plan_URL
            except:
                item['Site_Plan_URL'] = ''
            item['Property_URL'] = p

        # except Exception as e:
        #     print("not insert " + str(e))
            yield item
        else:
            print(response.url,'ljkjk')
# # Property_Name,Address,City,State,Zip,Description,Leasing_Contact_Name,Leasing_Contact_Phone,Leasing_Contact_Email,Property_Manager_Name,Property_manager_phone,Property_manager_Email,Brochure_URL,Site_Plan_URL,Property_URL

from scrapy.cmdline import execute
# execute("scrapy crawl store_502 -a list_id=502".split())


# ------------------------------------link take manually----------------------------------------------
# ------------------- set vlookup(manual) for broucher url , siteplan --------------------------------