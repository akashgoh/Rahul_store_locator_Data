import datetime
import scrapy, json, requests, re
import html2text
from scrapy.cmdline import execute
from scrapy.http import HtmlResponse

from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func

h = html2text.HTML2Text()

class highwoodsSpider(scrapy.Spider):
    name = 'store_733'
    allowed_domains = ['www.highwoods.com']
    start_urls = ['https://www.harsch.com/properties/']
    # start_urls = ['https://www.harsch.com/properties/seattle-region/']


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def parse(self, response):
        links = response.xpath('//li[@id="menu-item-1517"]//ul[@class="sub-menu"][1]/li/a/@href').extract()
        for link in links:
            print(link)
            yield scrapy.FormRequest(url=link,callback=self.parse2,dont_filter=True)

    def parse2(self,response):
        links = response.xpath('//div[@class="fusion-portfolio-content"]/h2/a/@href').extract()
        for link in links:
            print(link)
        # link = 'https://www.harsch.com/property/lawnfield-business-park/?portfolioCats=35'
            yield scrapy.FormRequest(url=link,callback=self.parse3,dont_filter=True)

    def parse3(self,response):
        print(response.url)

        try:
            name = response.xpath('//div[@class="fusion-column-wrapper fusion-flex-column-wrapper-legacy"]/div/h1/text()').extract_first()
            print(name)
        except Exception as e:
            print(e)
            name=''

        # add = "".join(response.xpath('//div[@class="fusion-column-wrapper fusion-flex-column-wrapper-legacy"]/div//h5/text()').extract())
        # print(add)

        try:
            add11 = response.xpath('//div[@class="fusion-column-wrapper fusion-flex-column-wrapper-legacy"]/div//h5//text()').extract()
            add1 = ''.join(add11)
            print(add1)
        except Exception as e:
            print(e)
        if "•" in add1:


            add = add1.split("•")[0].split(",")

            if len(add) == 2:
                street = add[0]
                city = ''
                state = add[1].split()[0]
                zip_c = add[1].split()[1]

            elif len(add) == 1:
                street = add[0]
                city = ''
                state = ''
                zip_c = ''

            else:
                try:
                    if len(add[-2].split())>2:
                        try:
                            if len(add[-3].split())>2:
                                street = add[0] + add[1] + add[2]
                                city = ''
                                state = add[-1].split()[0]
                                zip_c = add[-1].split()[1]
                            else:
                                street = add[0] + add[1]
                                city = ''
                                try:
                                    state = add[-1].split()[0]
                                    zip_c = add[-1].split()[1]
                                except:
                                    state = ''
                                    zip_c = add[-1]
                        except Exception as e :
                            print(e)
                    else:

                        try:
                            # street = add1.split(",")[0].strip()
                            street = add1.split("•")[0].rsplit(",",2)[0].strip()

                            print(street)
                        except Exception as e:
                            print(e)
                            street=''

                        try:
                            # city = add1.split(",")[1].strip()
                            city = add1.split("•")[0].rsplit(",",2)[1].strip()
                            print(city)
                        except Exception as e:
                            print(e)
                            city=''



                        try:
                            state = add1.split("•")[0].rsplit(",",2)[2].split()[0].strip()

                            zip_c = add1.split("•")[0].rsplit(",", 2)[2].split()[1].strip()

                        except Exception as e:
                            print(e)
                            state= ''
                            zip_c = add1.split("•")[0].rsplit(",", 2)[2]

                except Exception as e:
                    print(e)

            try:
                sqft = add1.split("•")[1].strip()
                print(sqft)
            except Exception as e:
                print(e)
                sqft=''
        else:
            sqft = ''
            add = add1.split(",")

            if len(add) == 2:
                street = add[0]
                city = ''
                state = add[1].split()[0]
                zip_c = add[1].split()[1]


            else:
                if len(add[-2].split()) > 2:
                    if add[-2] != "NORTH LAS VEGAS" or "SALT LAKE CITY":
                        street = ''.join(add[:-1])
                        d = add[-1].split()
                        if len(d) >2:
                            city = add[-1].split()[0] + add[-1].split()[1]

                            state = ''
                            zip_c = add[-1].split()[2]
                        else:
                            city = add[-1].split()[0]
                            if len(city) == 2:
                                city = ''
                                state = add[-1].split()[0]
                                zip_c = add[-1].split()[2]
                    else:
                        street = ''.join(add[:-2])
                        # d = add[-1].split()

                        city = add[-2]

                        state = add[-1].split()[0]
                        zip_c = add[-1].split()[1]

                else:
                    try:
                        # street = add1.split(",")[0].strip()
                        street = add1.rsplit(",", 2)[0].strip()

                        print(street)
                    except Exception as e:
                        print(e)
                        street=''

                    try:
                        # city = add1.split(",")[1].strip()
                        city = add1.rsplit(",", 2)[1].strip()
                        print(city)
                    except Exception as e:
                        print(e)
                        city=''

                    try:
                        state = add1.rsplit(",", 2)[2].split()[0].strip()
                        # state = add1.split(",")[2].strip()
                        # state = state.split("•")[0].strip()
                        # state = state.split(" ")[0].strip()
                        # print(state)
                    except Exception as e:
                        print(e)
                        state=''

                    try:
                        zip_c = add1.rsplit(",", 2)[2].split()[1].strip()
                        # zip_c = add1.split(",")[2].strip()
                        # zip_c = zip_c.split("•")[0].strip()
                        # zip_c = zip_c.split(" ")[1].strip()
                        print(zip_c)
                    except Exception as e:
                        print(e)
                        zip_c=''

        if name == 'Patrick Commerce Center':
            city = 'LAS VEGAS'
            state = ''
            zip_c = '89120'
        elif name == 'Lawnfield Business Park':
            city = 'CLACKAMAS'
            state = ''
            zip_c = '97015'
            sqft= '76,000 SF'
        # city = add1[0]
        try:
            desc = "".join(response.xpath('//div[@class="fusion-text fusion-text-1"]/p/text()').extract())
            print(desc)
            if desc == '':
                desc = "".join(response.xpath('//div[@class="fusion-text fusion-text-1"]/div/p/text()').extract())
                if desc == "":
                    desc = "".join(response.xpath('//div[@class="fusion-text fusion-text-1"]/div/text()').extract())
                    if desc == '':
                        desc = "".join(response.xpath('//div[@class="fusion-text fusion-text-1"]/p/span/text()').extract())
                        if desc == "":
                            desc = "".join(response.xpath('//div[@class="text"]/div/text()').extract())
        except Exception as e:
            print(e)
            desc=''

        try:
            siteplan = response.xpath('//*[contains(text(),"View Site Plan")]/../@href').extract_first()
            print(siteplan)
        except Exception as e:
            print(e)
            siteplan=''

        try:
            leasing_name1 = response.xpath('//div[@class="fusion-text fusion-text-2"]/h4/text()').extract_first()
            print(leasing_name1)
        except Exception as e:
            print(e)
            leasing_name1=''

        try:
            leasing_phone = response.xpath('//div[@class="fusion-text fusion-text-2"]/p/a[1]/text()').extract_first()
            print(leasing_phone)
        except Exception as e:
            print(e)
            leasing_phone=''

        try:
            leasing_email = response.xpath('//div[@class="fusion-text fusion-text-2"]/p/a[2]/text()').extract_first()
            print(leasing_email)
        except Exception as e:
            print(e)
            leasing_email=''

        try:
            leasing_name2 = response.xpath('//div[@class="fusion-text fusion-text-3"]/h4/text()').extract_first()
            print(leasing_name2)
        except Exception as e:
            leasing_name2=''

        try:
            leasing_phone2 = response.xpath('//div[@class="fusion-text fusion-text-3"]/p/a[1]/text()').extract_first()
            print(leasing_phone2)
        except Exception as e:
            leasing_phone2=''

        try:
            leasing_email2 = response.xpath('//div[@class="fusion-text fusion-text-3"]/p/a[2]/text()').extract_first()
            print(leasing_email2)
        except Exception as e:
            leasing_email2=''

        item = ProprtySitesItem()
        item['Property_Name'] = name
        item['Address'] = street
        # item['TMP_Address'] =
        item['City'] = city
        item['State'] = state
        item['Zip'] = zip_c
        item['GLA'] = sqft
        item['Description'] = desc
        item['Leasing_Contact_Name'] = leasing_name1
        item['Leasing_Contact_Name2'] = leasing_name2
        item['Leasing_Contact_Phone'] = leasing_phone
        item['Leasing_Contact_Phone2'] = leasing_phone2
        item['Leasing_Contact_Email'] = leasing_email
        item['Leasing_Contact_Email2'] = leasing_email2
        item['Site_Plan_URL'] = siteplan
        item['Property_URL'] = response.url
        yield item


# execute("scrapy crawl store_733 -a list_id=733".split())
