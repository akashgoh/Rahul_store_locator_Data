import json
import re
import requests
import scrapy
from scrapy.http import HtmlResponse
import datetime
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func


class Store500Spider(scrapy.Spider):
    name = "store_500"
    allowed_domains = []
    start_urls = ['https://whitestonereit.com/communities/']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def parse(self, response):
        links = [
            "https://buildout.com/plugins/af9baf38e66e0079f47458bf764acc34653621d2/inventory?utf8=%E2%9C%93&lat_min=&lat_max=&lng_min=&lng_max=&page=0&placesAutoComplete=&q%5Btype_use_offset_eq_any%5D%5B%5D=&q%5Bmax_space_available_gteq%5D=&q%5Bmin_space_available_lteq%5D=&q%5Bstate_eq_any%5D%5B%5D=&q%5Bbroker_eq_any%5D%5B%5D=&q%5Bcity_eq_any%5D%5B%5D=&q%5Bsale_or_lease_eq%5D=&q%5Bproperty_use_id_eq_any%5D%5B%5D=&q%5Bcompany_office_id_eq_any%5D%5B%5D=&q%5Bg%5D%5B0%5D%5Bm%5D=or&q%5Bs%5D%5B%5D=name_or_address+asc",
            "https://buildout.com/plugins/af9baf38e66e0079f47458bf764acc34653621d2/inventory?utf8=%E2%9C%93&lat_min=&lat_max=&lng_min=&lng_max=&page=1&placesAutoComplete=&q%5Btype_use_offset_eq_any%5D%5B%5D=&q%5Bmax_space_available_gteq%5D=&q%5Bmin_space_available_lteq%5D=&q%5Bstate_eq_any%5D%5B%5D=&q%5Bbroker_eq_any%5D%5B%5D=&q%5Bcity_eq_any%5D%5B%5D=&q%5Bsale_or_lease_eq%5D=&q%5Bproperty_use_id_eq_any%5D%5B%5D=&q%5Bcompany_office_id_eq_any%5D%5B%5D=&q%5Bg%5D%5B0%5D%5Bm%5D=or&q%5Bs%5D%5B%5D=name_or_address+asc"
        ]
        for link in links:
            header = {
                "accept": "application/json, text/javascript, */*; q=0.01",
                "x-requested-with": "XMLHttpRequest"
            }
            yield scrapy.Request(url=link, callback=self.get_data, headers=header)

    def get_data(self, response):
        data_json = json.loads(response.text)
        for data in data_json['inventory']:
            Property_Name = data['display_name']
            Address = data['address']
            City = data['city']
            State = data['state']
            for i in data['index_attributes']:
                if 'Building Size' in i[0]:
                    gla = i[1]
                    if ',' in gla:
                        gla = i[1].replace(',','')
                    if 'SF' in gla:
                        gla = gla.replace('SF','')
                    GLA = gla.strip()
                    break
                else:
                    GLA = ''
            Description = data['description']
            Leasing_Contact = data['broker_contacts'][0]['name']
            Leasing_Contact_Phone = data['broker_contacts'][0]['phone']
            Leasing_Contact_Email = data['broker_contacts'][0]['email']
            Property_URL = data['show_link']
            token = response.url.split('/')[4]
            p_id = Property_URL.split('=')[-1]
            iframe_link = f"https://buildout.com/plugins/{token}/whitestonereit.com/inventory/{p_id}?pluginId=0&iframe=true&embedded=true&cacheSearch=true&propertyId={p_id}"
            res1 = requests.get(iframe_link)
            response1 = HtmlResponse(url=res1.url, body=res1.content)
            Site_Plan_URL_tmp = re.findall(r'<!--\[if lte IE 9\]><img class="(.*?)<!\[endif\]-->', response1.text, re.DOTALL)
            if len(Site_Plan_URL_tmp) == 1:
                Site_Plan_URL_tmp = re.findall(r'src="(.*?)"', Site_Plan_URL_tmp[0], re.DOTALL)
                if len(Site_Plan_URL_tmp) == 1:
                    Site_Plan_URL_link = Site_Plan_URL_tmp[0]
                    res2 = requests.get(Site_Plan_URL_link)
                    response2 = HtmlResponse(url=res2.url, body=res2.content)
                    Site_Plan_URL = response2.url
                else:
                    Site_Plan_URL = ''
            elif len(Site_Plan_URL_tmp) > 1:
                site_urls = []
                for site_tmp in Site_Plan_URL_tmp:
                    Site_Plan_URL1 = re.findall(r'src="(.*?)"', site_tmp, re.DOTALL)
                    res2 = requests.get(Site_Plan_URL1[0])
                    response2 = HtmlResponse(url=res2.url, body=res2.content)
                    site_urls.append(response2.url)
                Site_Plan_URL = ' | '.join(site_urls)
            else:
                Site_Plan_URL = ''
            try:
                item = ProprtySitesItem()
                item['Property_Name'] = Property_Name
                item['Address'] = Address
                item['City'] = City
                item['State'] = State
                item['GLA'] = GLA
                item['Description'] = Description
                item['Leasing_Contact'] = Leasing_Contact
                item['Leasing_Contact_Phone'] = Leasing_Contact_Phone
                item['Leasing_Contact_Email'] = Leasing_Contact_Email

                item['Site_Plan_URL'] = Site_Plan_URL
                item['Property_URL'] = Property_URL
                yield item
            except Exception as e:
                print(f"not insert {response.url}" + str(e))
# Property_Name,Address,City,State,GLA,Description,Leasing_Contact,Leasing_Contact_Phone,Leasing_Contact_Email,Site_Plan_URL,Property_URL

from scrapy.cmdline import execute
# execute("scrapy crawl store_500 -a list_id=500".split())