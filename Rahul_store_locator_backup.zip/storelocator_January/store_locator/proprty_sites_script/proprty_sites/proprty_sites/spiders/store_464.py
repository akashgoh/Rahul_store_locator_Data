# -*- coding: utf-8 -*-
import scrapy
import json
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func
import datetime


class store_464_Spider(scrapy.Spider):
    name = 'store_464'
    # allowed_domains = ['www.example.com']
    start_urls = ['https://www.thevireogroup.com/category/properties/']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def parse(self, response):

        links=response.xpath('//ul[@class="category-posts"]/li//div[@class="entry-meta"]/span/a/@href').getall()
        for link in links:
            yield scrapy.Request(url=link, callback=self.finaldata)

    def finaldata(self, response):

        try:
            store_name=response.xpath('//h3[@class="widget-title"]/text()').get().strip().split(',')[0].strip()
        except Exception as e:
            print(e,response.url)
            store_name=''

        address=store_name
        try:
            city=response.xpath('//h3[@class="widget-title"]/text()').get().strip().split(',')[-2].strip()
        except Exception as e:
            print(e,response.url)
            city=''

        try:
            state = response.xpath('//h3[@class="widget-title"]/text()').get().strip().split(',')[-1].strip()
        except Exception as e:
            print(e,response.url)
            state=''

        try:
            GLA=response.xpath('//div[@itemprop="articleBody"]/p/text()').get().strip().split()[0].strip()
        except Exception as e:
            print(e,response.url)
            GLA=''
        try:
            Brochure_url= response.xpath('//div[@itemprop="articleBody"]/p/a/@href').get()
        except Exception as e:
            print(e,response.url)
            Brochure_url=''

        try:
            item = ProprtySitesItem()
            item['Property_Name'] = store_name
            item['Address'] = address
            item['City'] = city
            item['State'] = state
            item['GLA'] = GLA
            item['Brochure_URL'] = Brochure_url
            item['Property_URL'] = response.url


            # print (item)
            yield item
        except Exception as e:
            print("item", e)


# there are we making same changes manually in city,state
# from scrapy.cmdline import execute
# execute('''scrapy crawl store_464 -a list_id=464'''.split())
