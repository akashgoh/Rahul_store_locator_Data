# -*- coding: utf-8 -*-
# -*- coding: utf-8 -*-
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
import html2text
h = html2text.HTML2Text()
import datetime
import scrapy, json, requests, re
import html2text
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func



class dlc_managementSpider(scrapy.Spider):
    name = 'store_473'
    allowed_domains = []
    # start_urls = ['https://www.crcrealty.com/commercial-properties/']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):

        link='http://dlc.propertycapsule.com/property/output/find/search4'
        header={'Upgrade-Insecure-Requests': '1',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36',
                'Sec-Fetch-Dest': 'document',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9'}
        yield scrapy.Request(url=link,callback=self.parse,headers=header,dont_filter=True)


    def parse(self, response):

        # open_in_browser(response)
        links=response.xpath('//table[@class="table-listing display responsive nowrap"]//a//@href').getall()
        header = {'Upgrade-Insecure-Requests': '1',
                  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36',
                  'Sec-Fetch-Dest': 'document',
                  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9'}

        for link in links:
            yield scrapy.FormRequest(url=link, callback=self.get_store,headers=header)



    def get_store(self,response):
        # open_in_browser(response)
        link=response.xpath('//div[@id="plan-container"]/iframe/@src').get(default='').strip()
        item=ProprtySitesItem()

        item['Property_Name'] = response.xpath('//h1//text()').get(default='')
        item['Address'] = response.xpath('//h2[contains(text(),"Property Highlights")]/following-sibling::p/b/text()[2]').get(default='')
        item['City'] = response.xpath('//h2[contains(text(),"Property Highlights")]/following-sibling::p/b/text()[3]').get(default='').split(',')[0]
        item['State'] =response.xpath('//h2[contains(text(),"Property Highlights")]/following-sibling::p/b/text()[3]').get(default='').split(',')[-1].strip().split(' ')[0]
        item['Zip'] =response.xpath('//h2[contains(text(),"Property Highlights")]/following-sibling::p/b/text()[3]').get(default='').split(',')[-1].strip().split(' ')[-1]


        item['GLA'] = response.xpath('//b[contains(text(),"GLA:")]/following-sibling::text()').get(default='')
        item['Description'] = ''.join(response.xpath('//div[@class="component default stack-order-1"]//li//text()').getall())
        link=response.xpath('//a[contains(text(),"View Leasing Information")]//@href')
        item['Leasing_contact_name'] = response.xpath('//div[@class="component card bg-blue"]//h2//text()').get(default='')
        item['Leasing_contact_phone'] =response.xpath('//strong[contains(text(),"Phone:")]/following-sibling::text()').get(default='')
        d=response.xpath('//iframe[@id="jsviewer"]//@src').get(default='')
        try:id=re.findall('sitemap_ID:(.*?)/',d)[0]
        except:id=''
        item['Site_Plan_URL'] = f'http://dlc.propertycapsule.com/property/capsule_data/1/property/sitemap_image/{id}.png'
        item['URL'] = response.url # self.f1.country_dict.get(item['country'].lower())
        yield item


#
from scrapy.cmdline import execute
# execute('''scrapy crawl store_473 -a list_id=473'''.split())
