import scrapy, os, logging, hashlib
import datetime
import scrapy, json, requests, re
import html2text
from scrapy.cmdline import execute

from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func



class Store431Spider(scrapy.Spider):
    name = 'store_431'
    allowed_domains = []
    start_urls = ['http://properties.edens.com/property/output/find/search4/prevsearch:1']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    # def start_requests(self):
    #     try:
    #         source_url = link = 'http://properties.edens.com/property/output/find/search4/prevsearch:1/'
    #         file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(self.run_date) + '.html'
    #         yield scrapy.FormRequest(url=str(link), callback=self.firstlevel,
    #                                  meta={'source_url': source_url,
    #                                        'file_path': file_path, 'proxy_type': self.proxy_type})
    #     except Exception as e:
    #         logging.log(logging.ERROR, e)

    def parse(self, response):
        try:

            links = response.xpath('//*[@class="property"]/div[@class="property-info"]/a/@href').extract()
            # links = ['http://properties.edens.com/p/shopping-center-commercial-real-estate/Alexandria-VA-22314/530firststreet']
            for link in links:
                print(link)
                yield scrapy.FormRequest(url=link.strip(), callback=self.get_store_list)

        except Exception as e:
            print("firstlevel", e, response.url)

    # Get data from the response
    def get_store_list(self, response):
        item = ProprtySitesItem()

        try:
            try:
                item['Property_Name'] = response.xpath('//h1/text()').extract_first(default='').strip()
            except Exception as e:
                print("store_name", e, response.url)

            try:
                address_data = response.xpath('//*[@class="component-pc-header"]/p/text()').extract_first(default='')
                if address_data:
                    address_data = address_data.split(',')
                    item['address'] = address_data[0].strip()
                    item['city'] = address_data[1].strip()
                    item['state'] = address_data[-1].strip().split(' ')[0].strip()
                    zip_code = address_data[-1].strip().split(' ')
                    if len(zip_code) > 1:
                        item['zip_code'] = zip_code[-1]
                    else:
                        item['zip_code'] = ''


            except Exception as e:
                print(e)

            try:
                item['Description'] = ' '.join(response.xpath('//*[@class="component component-text"]/div/div/p/text()|//*[@class="component component-text"]/div/div/ul/li/text()').extract())
            except Exception as e:
                print(e)

            try:
                GLA_text = response.xpath('//*[@class="component component-text"]/div/div/ul/li[contains(text(),"SF")]/text()').extract_first(default='')
                if GLA_text:
                    GLA = re.findall(r'(\d+)', GLA_text.replace(',', ''))
                    if GLA:
                        if "million" in GLA_text:
                            item['GLA'] = GLA[0]*"M"
                        else:
                            item['GLA'] = GLA[0]
                    else:
                        item['GLA'] = ''
                else:
                    item['GLA'] = ''
            except Exception as e:
                print(e)

            try:
                Parking_text = response.xpath('//*[@class="component component-text"]/div/div/ul/li[contains(text(),"Retail Parking Spots")]/text()').extract_first(default='')
                if Parking_text:
                    Parking = re.findall(r'(\d+)', Parking_text.replace(',', ''))[0]
                    if Parking:
                       item['Parking'] = Parking[0]
                    else:
                        item['Parking'] = ''
                else:
                    item['Parking'] = ''
            except Exception as e:
                print(e)

            try:
                Residential_Units_text = response.xpath('//*[@class="component component-text"]/div/div/ul/li[contains(text(),"Residential Units")]/text()').extract_first(default='')
                if Residential_Units_text:
                    Residential_Units = re.findall(r'(\d+)', Residential_Units_text.replace(',',''))[0]
                    if Residential_Units:

                        item['Residential_Units'] = Residential_Units


                    else:
                        item['Residential_Units'] = ''
                else:
                    item['Residential_Units'] = ''
            except Exception as e:
                print(e)

            try:
                item['Leasing_Contact'] = response.xpath('normalize-space(//address/text())').extract_first(default='')
            except Exception as e:
                print(e)

            try:
                item['Leasing_Phone'] = response.xpath('//address/a[contains(@href,"tel:")]/text()').extract_first(default='')
            except Exception as e:
                print(e)

            try:
                item['Leasing_Email'] = response.xpath('//address/a[contains(@href,"mailto:")]/text()').extract_first(default='')
            except Exception as e:
                print(e)

            try:
                plan_link = response.xpath('//*[@data-component-name="SitePlan"]//iframe/@src').extract_first(default='')
                if plan_link:
                    # plan_r = requests.get(plan_link)
                    # image_data = re.findall(r'data =(.*?);\n', plan_r.text)[0]
                    # image_data_json = json.loads(image_data)
                    # item['Site_Plan_URL'] = image_data_json["planWidgetObjects"]["mapPlanImg"]
                    item['Site_Plan_URL'] = plan_link
            except Exception as e:
                print(e)

            item['Property_URL'] = response.url

            yield item
        except Exception as e:
            logging.log(logging.ERROR, e)

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_431 -a list_id=431'''.split())

