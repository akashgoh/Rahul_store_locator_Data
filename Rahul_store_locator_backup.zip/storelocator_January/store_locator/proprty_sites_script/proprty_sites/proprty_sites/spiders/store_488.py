# -*- coding: utf-8 -*-
import datetime
import scrapy, json, requests, re
import html2text
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func


import scrapy
from scrapy.cmdline import execute


class SpgroupSpider(scrapy.Spider):
    name = 'store_488'
    allowed_domains = ['spgroup.com']
    start_urls = ['http://spgroup.com/prop_state.aspx']
    # custom_settings = {
    #     "FEED_EXPORT_FIELDS": ["Property Name", "Address", "City", "State", "Zip", "GLA", "Leasing Contact Name",
    #                            "Leasing Contact Phone", "Leasing Contact Email", "Site Plan URL", "Property URL"]
    # }

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def parse(self, response):
        for state in response.xpath('//*[@name="DDState"]//@value').getall():
            url = "http://spgroup.com/prop_state.aspx?STATE=" + state
            yield scrapy.Request(
                url=url,
                callback=self.list_prop
            )

    def list_prop(self, response):
        for url in response.xpath('//*[contains(@href, "PROPID")]/@href').getall():
            yield scrapy.Request(
                url=response.urljoin(url),
                callback=self.process_prop
            )

    def process_prop(self, response):
        p_id = response.xpath('//*[@id="PropID"]//text()').get('').strip()
        name = response.xpath('//*[@id="PropName"]//text()').get('').strip()
        add = response.xpath('//*[contains(@id, "Addr")]//text()').getall()
        czs = response.xpath('//*[@id="CitySTZIP"]//text()').get('').split(", ")

        item = ProprtySitesItem()
        item["Property_Name"] = f"{p_id} {name}"
        item["Address"] = ", ".join(add).strip()
        item["City"] = czs[0].strip()

        try:
            item["State"] = czs[1].split()[0].strip()
        except:
            item["State"] = ""

        try:
            item["Zip"] = czs[1].split()[1].strip()
        except:
            item["Zip"] = ""

        item["GLA"] = response.xpath('//*[@id="TotalSF"]/text()').get('').strip()
        item["Leasing_Contact_Name"] = response.xpath('//*[@id="DMName"]/text()').get('').strip()
        item["Leasing_Contact_Phone"] = response.xpath('//*[@id="DMPhone"]/text()').get('').strip()
        item["Leasing_Contact_Email"] = response.xpath('//*[@id="DMMail"]/text()').get('').strip()
        item["Site_Plan_URL"] = response.urljoin(response.xpath('//*[@id="SitePlan"]/@src').get('').strip())
        item["Property_URL"] = response.url
        yield item


# name = "schottenstein_property_group"
today = datetime.datetime.now().strftime("%m-%d-%Y")
# execute("scrapy crawl store_488 -a list_id=488".split())