# -*- coding: utf-8 -*-
import re
import datetime
import scrapy,os,logging,hashlib
import requests,json
from lxml.html import open_in_browser
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func
import datetime
import html2text


class Store861Spider(scrapy.Spider):
    name = 'store_859'
    allowed_domains = []
    start_urls = []
    # not_export_data = True


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        self.f1.set_details(self.list_id, run_date)
        try:

            source_url = "https://feilorg.com/retail"

            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(run_date) + '.html'
            yield scrapy.FormRequest(url=str(source_url), callback=self.firstlevel,
                                     # headers=headers,
                                     meta={'source_url': source_url,
                                           # 'search_term': search_term,
                                           'file_path': file_path, 'proxy_type': self.proxy_type})
        except Exception as e:
            print(e)

    def firstlevel(self, response):
        file_path = response.meta['file_path']
        try:

            block1 = response.xpath('//*[@class="container"]//a/@href').extract()
            for i in block1:
                yield scrapy.FormRequest(url="https://feilorg.com/"+i, callback=self.sndlevel, dont_filter=True,
                                         meta={'file_path':file_path})
        except Exception as e:
            print(e)


    def sndlevel(self, response):
        try:
            if not response.url.startswith('file://'):
                self.f1.page_save(response.meta['file_path'], response.body)

            try:
                Property_Name = response.xpath('//*[@class="details-title"]//text()').extract_first()
            except Exception as e:
                print(e)
            try:
                Address = response.xpath('//*[@class="details-address"]//text()[1]').extract_first()
            except Exception as e:
                print(e)

            try:
                City = response.xpath('//*[@class="details-address"]//text()[2]').extract_first().strip()
            except Exception as e:
                print(e)

            try:
                Brochure_URL = "https://feilorg.com/" + response.xpath('//*[contains(text(),"Property Brochure")]/../a/@href|//*[contains(text(),"Property Flyer & Site Plan")]/../a/@href').extract_first().replace("../../../","")
            except Exception as e:
                Brochure_URL = ""
                print(e)

            try:
                Website = response.xpath('//*[contains(text(),"Property Website")]/../a/@href').extract_first()
            except Exception as e:
                Website = ""
                print(e)
            try:
                res = requests.get(Website)
                response = HtmlResponse(url=response.url, body=res.content)
            except Exception as e:
                print(e)
            # print(response.text)

            try:
                data = response.xpath('//*[@class="sqs-block-content"]//p[4]//text()[1]').extract_first()
                state = data.split(",")[2].split(" ")[1]
                zipcode = data.split(",")[2].split(" ")[2]
            except Exception as e:
                state = ""
                zipcode = ""
                print(e)

            try:
                Hours = '|'.join(response.xpath('//*[contains(text(),"Hours of OperatioN:")]/../p[2]//text()').extract()).strip()
            except Exception as e:
                Hours = ""
                print(e)

            try:
                Phone_Number = response.xpath('//*[@class="sqs-block-content"]//p[4]//text()[2]').extract_first()
            except Exception as e:
                Phone_Number = ""
                print(e)



            item = ProprtySitesItem()
            item['Property_Name'] = Property_Name
            item['Address'] = Address
            item['City'] = City
            item['Brochure_URL'] = Brochure_URL
            item['Website'] = Website
            item['State'] = state
            item['zip_code'] = zipcode
            item['Hours'] = Hours
            item['Phone_Number'] = Phone_Number
            item['url'] = response.url
            yield item
        except Exception as e:
            print(e)




# execute('''scrapy crawl store_859 -a list_id=859'''.split())