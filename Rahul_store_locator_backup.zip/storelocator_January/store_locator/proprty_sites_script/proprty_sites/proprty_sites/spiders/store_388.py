# -*- coding: utf-8 -*-
import datetime
import scrapy, json, requests, re
import html2text
import pandas as pd
from scrapy.http import HtmlResponse
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func


class Store388Spider(scrapy.Spider):
    name = 'store_388'
    allowed_domains = []
    start_urls = ['https://www.draadvisors.com/portfolio_map.aspx']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def parse(self,response):
        try:
            headers = re.findall('"(.*?)":',re.findall("cols.properties=(\{.*?\});",response.text)[0])
            body = json.loads(re.findall("data.properties=(\[\[.*?\]\]);",response.text)[0])

            df = pd.DataFrame(body,columns=headers)
            ID_list = df['TeamID']
            print(ID_list)
            for id in ID_list:
                try:
                    head = {'Host': 'www.draadvisors.com',
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:72.0) Gecko/20100101 Firefox/72.0',
                            'Accept': '*/*',
                            'Accept-Language': 'en-GB,en;q=0.5',
                            'Accept-Encoding': 'gzip, deflate, br',
                            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                            'X-Requested-With': 'XMLHttpRequest',
                            'Origin': 'https://www.draadvisors.com',
                            'Referer': 'https://www.draadvisors.com/portfolio_map.aspx'}
                    data = f"teamId={str(id).strip()}&action=ajax&params%5Boffice%5D=true&params%5Bindustrial%5D=true&params%5Bretail%5D=true&params%5Bmultifamily%5D=true"
                    res = requests.post('https://www.draadvisors.com/portfolio_map.aspx',headers=head, data=data,verify=False)
                    response_f = HtmlResponse(url=res.url,body=res.content)

                    temp_add = response_f.xpath('//*[@class="address"]//text()').extract()
                    add = temp_add[0]
                    # print(add)
                    city = temp_add[-1].strip().split(',')[0]
                    state = temp_add[-1].strip().split(',')[-1].strip().split( )[0]
                    zip = temp_add[-1].strip().split(',')[-1].strip().split( )[-1]

                    size_temp = response_f.xpath('//*[@class="size"]/text()').extract_first(default='').strip()
                    size = ''.join(re.findall('(\d+)',size_temp)) if size_temp!='' else ''
                    try:
                        temp = [j.split('-') for j in [i.split(':')[-1].strip() for i in response_f.xpath('//*[@class="broker"]/text()[1]').extract()]]
                        leasing = '|'.join([i[0].strip() for i in temp])
                        leasing_metrp = '|'.join([i[1].strip() for i in temp])
                        phone = '|'.join([i.strip().replace('-', '.').replace(' ', '.') for i in response_f.xpath('//*[@class="broker"]//text()[2]').extract()]).strip()
                    except Exception as e:
                        leasing =leasing_metrp =phone=''
                        print(e)
                    l_mail = '|'.join([i.strip() for i in response_f.xpath('//a[contains(@href,"mailto")]/text()').extract()])


                    item = ProprtySitesItem()
                    item['Property_Name'] = response_f.xpath('//*[@class="popup-title"]/text()').extract_first(default='').strip()
                    item['Address'] = add
                    item['City'] = city
                    item['State'] = state
                    item['zip_code'] = zip
                    item['Total_SF'] = size
                    item['Leasing'] = leasing
                    item['Leasing_Metro_Area'] = leasing_metrp
                    item['Leasing_Phone'] = phone
                    item['Leasing_Email'] = l_mail
                    item['URL'] = response.url
                    yield item
                except Exception as e:
                    print(e)


        except Exception as e:
            print(e)


# from scrapy.cmdline import execute
# execute('''scrapy crawl store_388 -a list_id=388'''.split())
