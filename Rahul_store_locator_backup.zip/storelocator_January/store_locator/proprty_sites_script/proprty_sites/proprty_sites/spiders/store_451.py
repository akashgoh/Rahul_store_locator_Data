
import datetime
import scrapy, json, requests, re
import html2text
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func


class regencycentersSpider(scrapy.Spider):
    name = 'store_451'
    allowed_domains = []
    start_urls = ['https://www.regencycenters.com/properties']



    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)
        
    def parse(self, response):

        link = 'https://www.regencycenters.com/api/GetCenters?_=1580465415320'
        header={"Accept":"application/json, text/javascript, */*; q=0.01",
                "Accept-Encoding":"gzip, deflate, br",
                "Accept-Language":"en-US,en;q=0.9",
                "Connection":"keep-alive",
                "Host":"www.regencycenters.com",
                "Referer":"https://www.regencycenters.com/properties",
                "Sec-Fetch-Mode":"cors",
                "Sec-Fetch-Site":"same-origin",
                "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36",
                "X-Requested-With":"XMLHttpRequest"}
        yield scrapy.FormRequest(url=link, callback=self.get_store_list,headers=header)


    def get_store_list(self, response):

        links=re.findall('"DetailPageLink":"(.*?)"',str(response.text))
        for link in links:
            link='https://www.regencycenters.com'+link
            yield scrapy.FormRequest(url=link,callback=self.get_store)


    def get_store(self,response):
        item = ProprtySitesItem()

        item['Property_Name'] = response.xpath('//h1[@class="propertyDetailName"]//text()').get(default='')
        item['Address'] = response.xpath('//span[@class="address"]//text()').get(default='').strip()
        address=response.xpath('//span[@class="address"]//text()[2]').get(default='').strip()
        if ',' in address:

            item['City'] = address.split(',')[0].strip()
            item['State'] = address.split(',')[-1].strip().split(' ')[0]
            item['Zip_Code'] = address.split(',')[-1].strip().split(' ')[-1]
        else:
            item['City'] = ''
            item['State'] = ''
            item['Zip_Code'] = ''

        item['Market'] = response.xpath('//strong[contains(text(),"Market:")]/../text()[2]').get(default='')
        item['GLA'] = response.xpath('//strong[contains(text(),"SF:")]/../text()').get(default='')
        item['Key_Retailers'] = response.xpath('//strong[contains(text(),"Key Retailers:")]/../text()').get(default='')
        item['VPD'] = response.xpath('//strong[contains(text(),"Vehicles Per Day:")]/../text()[3]').get(default='')
        item['Siteplan'] = response.xpath('//input[@id="propertyBrochureUrl"]//@value').get(default='')
        item['Leasing_Rep'] = response.xpath('//h4[@id="leasingAgentInfo"]//a//text()').get(default='')
        item['Leasing_Rep_Phone'] =response.xpath('//span[contains(text(),"Phone Number")]/following-sibling::text()').get(default='')
        item['Leasing_Rep_Email'] = response.xpath('//a[contains(text(),"Email")]//@title').get(default='')
        item['URL'] = response.url # self.f1.country_dict.get(item['country'].lower())
        yield item



# from scrapy.cmdline import execute
# execute('''scrapy crawl store_451 -a list_id=451'''.split())
