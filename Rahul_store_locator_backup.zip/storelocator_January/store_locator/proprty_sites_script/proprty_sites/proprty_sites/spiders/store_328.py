# # -*- coding: utf-8 -*-
# import datetime
# import scrapy, json, requests, re
# import html2text
# from proprty_sites.items import ProprtySitesItem
# from proprty_sites.spiders.common_functions import Func
#
# class store_328_Spider(scrapy.Spider):
#     name = 'store_328'
#     allowed_domains = ['www.example.com']
#     start_urls = ['https://www.washreit.com/properties/']
#     not_export_data = True
#
#     def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
#         super().__init__(name, **kwargs)
#         self.list_id, self.proxy_type = list_id, proxy_type
#         self.f1 = Func()
#         self.run_date = str(datetime.datetime.today()).split()[0]
#         self.table_name = self.f1.set_details(self.list_id, self.run_date)
#
#     def parse(self, response):
#
#         try:
#             links = response.xpath('//@data-propurl').extract()
#             for link in links:
#
#                 yield scrapy.FormRequest(url=link,callback=self.firstlevel,dont_filter=True)
#         except Exception as e:
#             print("parse",e,response.url)
#
#
#
#     def firstlevel(self,response):
#         try:
#             try:
#                 Property_Name = response.xpath('//h1[@class="wr-property__title"]/text()').extract_first().strip()
#             except Exception as e:
#                 print("Property_Name",e,response.url)
#
#             try:
#                 fullAddress = response.xpath('//div[@class="wr-property__subtitle"]/text()').extract_first().\
#                     replace("1300 N. 17th Street Arlington,","1300 N. 17th Street,Arlington,").\
#                     replace('600 New Hampshire Avenue, NW Washington,','600 New Hampshire Avenue, NW,Washington,').strip().split(",")
#                 if len(fullAddress)== 4:
#                     Address = fullAddress[0] + "," + fullAddress[1]
#                     City = fullAddress[2]
#                     statezip = fullAddress[-1].split()
#                     State = statezip[0]
#                     zip_code = statezip[1]
#                 else:
#                     Address = fullAddress[0]
#                     City = fullAddress[1]
#                     statezip = fullAddress[-1].split()
#                     State = statezip[0]
#                     zip_code = statezip[1]
#             except Exception as e:
#                 print("Address",e,response.url)
#
#             # try:
#             #     City = fullAddress[1]
#             # except Exception as e:
#             #     print("City",e,response.url)
#             #
#             # try:
#             #     statezip = fullAddress[-1].split()
#             #     State = statezip[0]
#             # except Exception as e:
#             #     print("State", e, response.url)
#             #
#             # try:
#             #     zip_code = statezip[1]
#             # except Exception as e:
#             #     print("zip_code",e,response.url)
#
#             try:
#                 Submarket = response.xpath('//*[contains(text(),"Submarket")]/following-sibling::text()').extract_first()
#                 if Submarket == None:
#                     Submarket = ''
#                 else:
#                     Submarket = Submarket.strip()
#             except Exception as e:
#                 print("Submarket",e,response.url)
#
#             try:
#                 Building_Size = response.xpath(
#                     '//*[contains(text(),"Building Size")]/following-sibling::text()').extract_first()
#                 if Building_Size == None:
#                     Building_Size = ''
#                 else:
#                     Building_Size = Building_Size.strip()
#             except Exception as e:
#                 print("Building_Size",e,response.url)
#
#             try:
#                 Year_Constructed = response.xpath(
#                     '//*[contains(text(),"Year Constructed")]/following-sibling::text()').extract_first()
#                 if Year_Constructed == None:
#                     Year_Constructed = ''
#                 else:
#                     Year_Constructed = Year_Constructed.strip()
#             except Exception as e:
#                 print("Year_Constructed",e,response.url)
#
#             try:
#                 Year_Acquired = response.xpath(
#                     '//*[contains(text(),"Year Acquired")]/following-sibling::text()').extract_first()
#                 if Year_Acquired == None:
#                     Year_Acquired = ''
#                 else:
#                     Year_Acquired = Year_Acquired.strip()
#             except Exception as e:
#                 print("Year_Acquired",e,response.url)
#
#             try:
#                 Access = response.xpath(
#                     '//h5[contains(text(),"Access")]/following-sibling::text()').extract_first()
#                 if Access == None:
#                     Access = ''
#                 else:
#                     Access = Access.strip()
#             except Exception as e:
#                 print("Access",e,response.url)
#
#             try:
#                 Leasing = response.xpath(
#                     '//div[@class="wr-property__contacts_flexitem"][1]/div[1]/text()').extract_first()
#                 if Leasing == None:
#                     Leasing = ''
#                 else:
#                     Leasing = Leasing.strip()
#             except Exception as e:
#                 print("Leasing",e,response.url)
#
#             try:
#                 Leasing_Phone = response.xpath(
#                     '//div[@class="wr-property__contacts_flexitem"][1]/div[2]/text()').extract_first()
#                 if Leasing_Phone == None:
#                     Leasing_Phone = ''
#                 else:
#                     Leasing_Phone = Leasing_Phone.strip()
#             except Exception as e:
#                 print("Leasing_Phone",e,response.url)
#
#             try:
#                 Leasing_Email = response.xpath(
#                     '//div[@class="wr-property__contacts_flexitem"][1]/div[3]/text()').extract_first()
#                 if Leasing_Email == None:
#                     Leasing_Email = ''
#                 else:
#                     Leasing_Email = Leasing_Email.strip()
#             except Exception as e:
#                 print("Leasing_Email", e, response.url)
#
#             try:
#                 Management = response.xpath(
#                     '//div[@class="wr-property__contacts_flexitem"][2]/div[1]/text()').extract_first()
#                 if Management == None:
#                     Management = ''
#                 else:
#                     Management = Management.strip()
#             except Exception as e:
#                 print("Management", e, response.url)
#
#             try:
#                 Management_Phone = response.xpath(
#                     '//div[@class="wr-property__contacts_flexitem"][2]/div[2]/text()').extract_first()
#                 if Management_Phone == None:
#                     Management_Phone = ''
#                 else:
#                     Management_Phone = Management_Phone.strip()
#             except Exception as e:
#                 print("Management_Phone", e, response.url)
#
#             try:
#                 Management_Email = response.xpath(
#                     '//div[@class="wr-property__contacts_flexitem"][2]/div[3]/text()').extract_first()
#                 if Management_Email == None:
#                     Management_Email = ''
#                 else:
#                     Management_Email = Management_Email.strip()
#             except Exception as e:
#                 print("Management_Email", e, response.url)
#
#
#
#             item = ProprtySitesItem()
#             item['Property_Name'] = Property_Name
#             item['Address'] = Address
#             item['City'] = City
#             item['State'] = State
#             item['zip_code'] = zip_code
#             item['Submarket'] = Submarket
#             item['Building_Size'] = Building_Size
#             item['Year_Constructed'] = Year_Constructed.encode('ascii','ignore').decode('utf8')
#             item['Year_Acquired'] = Year_Acquired.encode('ascii','ignore').decode('utf8')
#             item['Access'] = Access
#             item['Leasing'] = Leasing
#             item['Leasing_Phone'] = Leasing_Phone
#             item['Leasing_Email'] = Leasing_Email
#             item['Management'] = Management
#             item['Management_Phone'] = Management_Phone
#             item['Management_Email'] = Management_Email
#             item['URL'] = response.url
#             yield item
#
#         except Exception as e:
#             print("firstlevel",e,response.url)
#
# #
# from scrapy.cmdline import execute
# # execute("scrapy crawl store_328 -a list_id=328".split())
