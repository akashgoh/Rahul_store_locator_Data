
# -*- coding: utf-8 -*-
import datetime
import scrapy, json, requests, re
import html2text
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func


class store_705_Spider(scrapy.Spider):
    name = 'store_705'
    allowed_domains = ['lernerretail.com']
    start_urls = ['https://lernerretail.com/portfolio']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        url = 'https://lernerretail.com/portfolio'

        yield scrapy.FormRequest(url=url , callback=self.gla)

    def gla(self, response):
        links = response.xpath('//div[@class="flex-parent  flex-align--center align-center space-around--third flex-parent--wrap pad-bottom--50 grid-js"]/div/a/@href').getall()
        glas = response.xpath('//div[@class="property-box--detail"]/text()[3]').extract()
        for links,glas in zip(links,glas):
            gla = glas.replace('\n','').strip()
            print(gla)
            yield scrapy.FormRequest(url=links, callback=self.parse_detail, meta={'gla': gla})

    # def parse1(self, response):
    #     gla = response.meta['gla']
    #     links = response.xpath('//div[@class="flex-parent  flex-align--center align-center space-around--third flex-parent--wrap pad-bottom--50 grid-js"]/div/a/@href').getall()
    #     for link in links:


            # yield scrapy.FormRequest(url=link,dont_filter=True, callback=self.parse_detail,meta={'gla': gla})

    def parse_detail(self,response):
        gla = response.meta['gla']
        item = ProprtySitesItem()


        property_name =  response.xpath('//div[@class="property-name"]/h1//text()').getall()


        address = response.xpath('//div[@class="sub-nav"]/div/text()[1]').get()
        add1 = response.xpath('//div[@class="sub-nav"]/div/text()[2]').get()
        description = response.xpath('//div[@class="overview--text"]/p/text()').get()


        managertname = response.xpath('//div[1][@class="col-50 pad-bottom--10"]/p/text()[1]').get()
        managerPhonenumber = response.xpath('//div[1][@class="col-50 pad-bottom--10"]/p/text()[4]').get()
        managerEmail = response.xpath('//div[1][@class="col-50 pad-bottom--10"]/p/a/@href').get()

        leasingname= response.xpath('//div[2][@class="col-50 pad-bottom--10"]/p/text()[1]').get()
        # if leasingname == None:
        #     leasingcontactname = response.xpath('//div[1][@class="col-50 pad-bottom--10"]/p/text()[1]').get()

        leasingPhonenumber = response.xpath('//div[2][@class="col-50 pad-bottom--10"]/p/text()[4]').get()
        # if leasingPhonenumber == None:
        #     leasingontactPhonenumber = response.xpath('//div[1][@class="col-50 pad-bottom--10"]/p/text()[4]').get()

        leasingEmail = response.xpath('//div[2][@class="col-50 pad-bottom--10"]/p/a/@href').get()
        # if leasingEmail == None:
        #     leasingcontactEmail = response.xpath('//div[1][@class="col-50 pad-bottom--10"]/p/a/@href').get()

        site_plan = response.xpath('//div[@class="pdf-box"]/a[2]/@href').get()
        website = response.xpath('//div[@class="col-40 col-100-sm align-middle pad-bottom--20 align-right"]/p/a/@href').get()

        lks = "".join(response.url)

        # address = add.split(",")[0]
        # try:
        #     city = add.split(",")[1]
        # except Exception as e:
        #     city = ''
        #
        # try:
        #     state = add.split(",")[2]
        # except Exception as e:
        #     state = ''
        #
        # try:
        #     zip = add.split(",")[-1]
        # except Exception as e:
        #     zip = ''

        item['property_name'] = property_name
        item['address'] = address
        item['description'] = description
        item['gla'] = gla
        item['managertname'] = managertname
        item['managerEmail'] = managerEmail
        item['managerPhonenumber'] = managerPhonenumber
        item['leasingcontactname'] = leasingname
        item['leasingontactPhonenumber'] = leasingPhonenumber
        item['leasingcontactEmail'] = leasingEmail
        item['city'] = add1.split(",")[0]
        item['state'] = add1.split(",")[1].split(" ")[1]

        item['zip'] = add1.split(",")[1].split(" ")[2]
        item['site_plan'] = site_plan

        item['website'] = website
        item['urls'] = lks

        yield item
        # property_name,address,description,gla,managertname,managerEmail,managerPhonenumber,leasingcontactname,leasingontactPhonenumber,leasingcontactEmail,city,state,zip,site_plan,website,urls

from scrapy.cmdline import execute
# execute("scrapy crawl store_705 -a list_id=705".split())


# -------------------------- check leasing and manager detail----------------------------