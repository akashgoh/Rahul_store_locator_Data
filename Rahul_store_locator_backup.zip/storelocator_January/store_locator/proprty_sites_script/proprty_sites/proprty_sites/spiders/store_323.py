# -*- coding: utf-8 -*-
import scrapy,re, json
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func
import datetime

from scrapy.cmdline import execute

class ShoponeSpider(scrapy.Spider):
    name = 'store_323'
    allowed_domains = []
    start_urls = []

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)


    def start_requests(self):
        headers = {'Host': 'shopone.propertycapsule.com',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:72.0) Gecko/20100101 Firefox/72.0',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                    'Accept-Language': 'en-GB,en;q=0.5',
                    'Accept-Encoding': 'gzip, deflate, br'}
        yield scrapy.FormRequest(url='https://shopone.propertycapsule.com/property/output/find/search/text:/', headers=headers,callback=self.parse)

    def parse(self, response):
        property_ids = re.findall('"propertyId":"(\d+)",',response.text)
        for id in property_ids:
            url = f"https://shopone.propertycapsule.com/properties/{str(id)}/"
            yield scrapy.FormRequest(url=url,callback=self.extract,dont_filter=True)

    def extract(self,response):
        try:
            data1 = re.findall('window.property \=(.*);',response.text)[0]
            df = json.loads(data1)
            data2 = re.findall('window.agents \=(.*);',response.text)[0]
            gh = json.loads(data2)

            item = ProprtySitesItem()
            item['Property_Name'] = df['name'] if df['name']!=None else ''
            item['Address'] = df['address'] if df['address']!=None else ''
            item['City'] = df['city'] if df['city']!=None else ''
            item['State'] = df['state'] if df['state']!=None else ''
            item['zip_code'] = df['zip'] if df['zip']!=None else ''
            # item['Country'] = df['county'] if df['county'] != None else''
            item['Type'] = df['type'] if df['type']!=None else ''
            item['GLA'] = df['gla'] if df['gla']!=None else ''
            item['Year_Constructed'] = df['year_built'] if df['year_built']!=None else ''
            item['Year_Renovated'] = df['year_renovated'] if df['year_renovated']!=None else ''
            item['Metro_Area'] = df['metroArea'] if df['metroArea']!=None else ''
            item['Leasing'] = gh[0]['name'] if gh[0]['name']!=None else ''
            item['Leasing_Phone'] = gh[0]['phone'] if gh[0]['phone']!=None else ''
            item['Leasing_Cell'] = gh[0]['mobile'] if gh[0]['mobile']!=None else ''
            item['Leasing_Email'] = gh[0]['email'] if gh[0]['email']!=None else ''
            item['Plan_url'] = re.findall('src\=\"(.*[sitemap_image_legend].*?\.png)\"',response.text)[0]
            item['URL'] = response.url
            yield item
        except Exception as e:
            print(e)

#
# execute("scrapy crawl store_323 -a list_id=323".split())