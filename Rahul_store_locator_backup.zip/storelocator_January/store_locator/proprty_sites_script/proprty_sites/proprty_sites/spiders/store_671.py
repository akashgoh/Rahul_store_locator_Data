import re
import scrapy,os,logging,hashlib
import requests,json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from store_locators.items import StoreLocatorsItem
from store_locators.spiders.common_functions import Func
import datetime


class Store424Spider(scrapy.Spider):
    name = 'store_671'
    allowed_domains = []
    not_export_data = True

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        try:
            self.list_id, self.proxy_type = list_id, proxy_type
            self.f1 = Func()
            self.run_date = str(datetime.datetime.today()).split()[0]
            self.con = self.f1.con
            self.cursor = self.f1.cursor
            self.cursor.execute('SET GLOBAL local_infile = "ON";')
            self.cursor.execute('''create table if not exists store_671 (store_hash_id varchar(32) NOT NULL,
                                                                                        `Property_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                                        `Property_Sub_Name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                                        `Address`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                                        `City` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                                        `State` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                                        `zip_code` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                                        `Description` longtext CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                                        `Project_Type`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                                        `Market_Status`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                                        `Leasing_Contact` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                                        `Leasing_Phone` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                                        `Leasing_Email` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                                        `Property_URL` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                                        `Brochure_URL` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                                        `Leasing_plan` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                                        `GLA` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
                                                                                         PRIMARY KEY (store_hash_id))''')
        except Exception as e:
            print(e)

    def start_requests(self):
        try:
            page = 1
            source_url = link = f'https://www.tuckerdevelopment.com/projects'
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
                self.run_date) + '.html'
            yield scrapy.FormRequest(url=str(link), callback=self.firstlevel,
                                     meta={'source_url': source_url, 'file_path': file_path,
                                           'proxy_type': self.proxy_type, 'page': page})
        except Exception as e:
            logging.log(logging.ERROR, e)

    def firstlevel(self, response):
        if not response.url.startswith('file://'):
            self.f1.page_save(response.meta['file_path'], response.body)
        try:
            source_url = response.meta['source_url']
            file_path = response.meta['file_path']
            proxy_type = response.meta['proxy_type']
            links = response.xpath('//*[@class="style-kfr7g29zlink"]/@href|//*[@class="style-kfr0ta5a2link"]/@href').extract()
            for link in (links):
                print(link)
                url = link
                # url = 'https://www.tuckerdevelopment.com/' + link.replace("./","")
                # page = link.replace('https://www.tuckerdevelopment.com/',
                #                     '').replace('/', '').strip()
                print(url)
                # file_path = self.f1.html_data_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
                #     self.run_date) + '_' + str(page) + '.html'
                yield scrapy.FormRequest(url=url, callback=self.get_store_list,
                                         meta={'source_url': source_url, 'file_path': file_path,
                                               'proxy_type': proxy_type})
        except Exception as e:
            print("firstlevel", e, response.url)

    def get_store_list(self, response):
        if not response.url.startswith('file://'):
            self.f1.page_save(response.meta['file_path'], response.body)


        Property_Name = ''.join(response.xpath('//*[@class="_1Z_nJ"]/h1/span/span/text()').extract())

        Property_Sub_Name = ''.join(response.xpath('//*[@class="_1Z_nJ"]/h1/span/text()').extract())
        # print(Property_Sub_Name)
        Add = ''.join(response.xpath('//*[@class="_1Z_nJ"]/p[3]/span/text()|//*[@class="_1Z_nJ"]/p[5]/span/text()|//*[@class="_1Z_nJ"]/p[4]/span/text()').extract())
        # print(len(Address))
        Address = Add.split(',')[0]
        print(Add)
        try:
            City = ''.join(Add.split(',')[-2]).strip()
        except Exception as e:
            print(e)
            City=''
        try:
            State =''.join(Add.split(',')[-1]).split(' ')[1]
        except Exception as e:
            print(e)
            State=''

        try:
            zip_code = re.findall('(\d{5})', Add)[0].strip()
        except Exception as e:
            print(e)
            zip_code = ''
        Description =''.join(response.xpath('//*[@class="_1Z_nJ"][2]/p[1]/span/text()').extract()).replace("Redevelopment","").replace("Development","").strip()

        try:

            if "square" in Description:
                GLA = Description.split(" square")[0].split(" ")[-1].replace("(~","")
                print(GLA)
            elif "SF" in Description:
                GLA = Description.split(" SF")[0].split(" ")[-1].replace("(~","")
                print(GLA)
            else:
                GLA = ""
        except Exception as e:
            print(e)

        # print(Description)
        Leasing_Contact = ''.join(response.xpath('//*[contains(text(),"RETAIL LEASING")]/../../../../div[6]/p[2]//text()').extract()).encode('ascii','ignore').decode('utf8')
        print(Leasing_Contact)
        Leasing_Phone =''.join(response.xpath('//*[contains(text(),"RETAIL LEASING")]/../../../../div[6]/p[4]//text()').extract())
        # print(Leasing_Phone)
        Leasing_Email = ''.join(response.xpath('//*[contains(text(),"RETAIL LEASING")]/../../../../div[6]/p[3]//text()').extract())
        # print(Leasing_Email)

        Property_URL= response.url

        Brochure_URL = '|'.join(response.xpath('//*[contains(text(),"Brochure")]/../@href').extract())

        Project_Type = ''.join(response.xpath('//*[contains(text(),"PROJECT TYPE")]/../../../../div[2]//span//text()').extract())
        # Project_Type = Project_Type.split('.')[-1].strip()
        print(Project_Type)
        Leasing_plan = ''.join(response.xpath('//*[contains(text(),"Leasing Plan")]/../@href').extract())

        Market_Status = ''.join(response.xpath('//*[contains(text(),"MARKET STATUS")]/../../../../div[4]//span//text()').extract())
        print(Market_Status)
        # if Property_Name == "District 1860":
        #     Market_Status = "Pre-Construction"
        # if Property_Name == "North & Harlem":
        #     Market_Status = "Pre-Construction"
        # if Property_Name == "The EP":
        #     Market_Status = "Pre-Construction"
        # if Property_Name == "900 West":
        #     Market_Status = "Currently leasing retail"
        # if Property_Name == "Hudson Lights":
        #     Market_Status = "Currently leasing retail and residential"
        # if Property_Name == "Wheatland Marketplace":
        #     Market_Status = "Currently leasing retail"
        # if Property_Name == "Town Square Wheaton":
        #     Market_Status = "Currently leasing retail and office"
        # if Property_Name == "Country Club Plaza":
        #     Market_Status = "Currently leasing retail"
        # if Property_Name == "Central Parkway":
        #     Market_Status = "Currently leasing retail"
        # if Property_Name == "South Loop Marketplace":
        #     Market_Status = "Currently leasing retail"
        # if Property_Name == "24 Jones":
        #     Market_Status = "Currently leasing residential"
        # if Property_Name == "Springfield Avenue Marketplace":
        #     Market_Status = "Completed in 2016|Sold in 2018"
        # if Property_Name == "Courtyard Marriott Downtown":
        #     Market_Status = "Completed in 2013|Sold in 2019"
        # if Property_Name == "Marketplace at Six Corners":
        #     Market_Status = "Sold in 1998"
        # if Property_Name == "Metropolitan Square":
        #     Market_Status = "Completed in 2005|Sold in 2007"
        # if Property_Name == "Park Avenue Centre":
        #     Market_Status = "Completed in 2005|Sold in 2007"
        # if Property_Name == "Pointe Plaza":
        #     Market_Status = "Completed in 1999|Sold in 2014"
        # if Property_Name == "Lincolnwood Centre":
        #     Market_Status = "Completed in 2001|Sold in 2001"
        # if Property_Name == "Ravinia Plaza":
        #     Market_Status = "Sold in 2006"
        # if Property_Name == "Yorkville Marketplace":
        #     Market_Status = "Sold in 2015"
        if Property_Name == "Park Avenue Centre":
            State = "IL"
        if Property_Name == "900 West":
            State = "IL"
        if Property_Name == "South Loop Marketplace":
            Project_Type = "Development"
        if Leasing_Phone == "6810 McCormick Boulevard, Lincolnwood, IL 60712":
            Leasing_Phone = ""
        if Property_Name == "24 Jones":
            Leasing_Phone = "(973)556-4192"
        if Property_Name == "Pointe Plaza":
            GLA = "328,706"
        if Property_Name == "Ravinia Plaza":
            Address = "153rd Street and LaGrange Road"
        if Property_Name == "Lincolnwood Centre":
            GLA = "62,000 "


        # if Leasing_Contact  == "Conventional bank debt financing.Sold in 2001":
        #     Leasing_Contact = ""
        # if Leasing_Contact == "Sold in 2014":
        #     Leasing_Contact = ""
        # if Leasing_Contact == "Sold in 2007":
        #     Leasing_Contact = ""
        # if Leasing_Contact == "Sold in 2018":







        store_hash_id = bytes(f"{Property_Name} {State} {City} {zip_code} {Leasing_Phone} {Leasing_Email} {Property_URL}",
            encoding='utf-8')
        store_hash_id = int(hashlib.md5(store_hash_id).hexdigest(), 16) % (10 ** 16)


        try:
            insert = "insert into store_671 (`store_hash_id`,`Property_Name`,`Property_Sub_Name`,`Address`,`City`,`State`,`zip_code`,`Description`,`Leasing_Contact`,`Leasing_Phone`,`Leasing_Email`,`Property_URL`,`Brochure_URL`,`Project_Type` ,`Market_Status`, `Leasing_plan`,`GLA`) VALUES (%s, %s, %s ,%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
            arg = (store_hash_id,Property_Name,Property_Sub_Name,Address,City,State,zip_code,Description,Leasing_Contact,Leasing_Phone,Leasing_Email,
                                         Property_URL,Brochure_URL,Project_Type ,Market_Status,Leasing_plan,GLA)
            self.cursor.execute(insert, arg)
            self.con.commit()
            print('Data Inserted...')
        except Exception as e:
            print(e)

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_671 -a list_id=671 -a proxy_type='''.split())
# Note : TotalSF and GLA manually
