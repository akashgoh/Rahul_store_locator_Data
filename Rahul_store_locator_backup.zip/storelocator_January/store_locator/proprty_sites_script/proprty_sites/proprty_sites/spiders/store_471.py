# -*- coding: utf-8 -*-
import datetime
import scrapy, json, requests, re
import html2text
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func

class store_471Spider(scrapy.Spider):
    name = 'store_471'
    allowed_domains = []
    start_urls = ['https://www.cblproperties.com/leasing/properties']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)


    def parse(self, response):
        # open_in_browser(response)
        urls = set(response.xpath('//a[@class="map-sidebar-link"]//@href').extract())
        for url in urls:
            url='https://www.cblproperties.com'+url
            yield scrapy.Request(url=url,callback=self.parse_data,dont_filter=True)


    def parse_data(self,response):
        item = ProprtySitesItem()

        item['Property_Name'] = response.xpath('//h1[@class="cblHero--title"]//text()').get(default='')
        item['Address'] = response.xpath('//div[@class="cblTitleContent__content"]//p//text()').get(default='').replace('\n','').replace('\t','').strip()
        item['City'] = response.xpath('//div[@class="cblTitleContent__content"]//p[2]//text()').get(default='').split(',')[0]
        item['State'] = response.xpath('//div[@class="cblTitleContent__content"]//p[2]//text()').get(default='').split(',')[-1].strip().split(' ')[0]
        item['Zip_Code'] = response.xpath('//div[@class="cblTitleContent__content"]//p[2]//text()').get(default='').split(',')[-1].strip().split(' ')[-1]
        item['Description'] = ''.join(response.xpath('//div[@class="clearfix"]/following-sibling::div/p/text()').getall()).strip()
        item['GLA'] = response.xpath('//label[contains(text(),"Total Building Area (GLA)")]/../..//label//text()').get(default='').strip()
        item['Leasing_Contact_Name'] =response.xpath('//div[contains(text(),"Leasing Contact")]/following-sibling::div//text()').get(default='').strip()
        item['Leasing_Contact_Phone'] =response.xpath('//div[contains(text(),"Leasing Contact")]/following-sibling::div//p/a/text()').get(default='').replace('Office:','').replace('|','').strip()
        item['Leasing_Contact_Email'] =response.xpath('//div[contains(text(),"Leasing Contact")]/following-sibling::div//p[3]//a//text()').get(default='')
        item['Property_Manager_Name'] =response.xpath('//div[contains(text(),"General Manager")]/following-sibling::div//text()').get(default='').strip()
        item['Property_Manager_Phone'] =response.xpath('//div[contains(text(),"General Manager")]/following-sibling::div//p/a/text()').get(default='').replace('Office:','').replace('|','').strip()
        item['Property_Manager_Email'] =response.xpath('//div[contains(text(),"General Manager")]/following-sibling::div//p[3]//a//text()').get(default='')
        item['Site_Plan_Url'] ='https://www.cblproperties.com'+response.xpath('//a[@class="cblTitleContent__title with-icon-right"]//@href').get(default='')
        item['URL'] =response.url
        yield item


# Property_Name,Address,City,State,Zip_Code,Description,GLA,Leasing_Contact_Name,Leasing_Contact_Phone,Leasing_Contact_Email,Property_Manager_Name,Property_Manager_Phone,Property_Manager_Email,Site_Plan_Url,URL

# from scrapy.cmdline import execute
# execute("scrapy crawl store_471 -a list_id=471".split())