import re
import requests
import scrapy
from scrapy.http import HtmlResponse
import datetime
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func


class Store501Spider(scrapy.Spider):
    name = "store_501"
    allowed_domains = []
    start_urls = ['https://www.worldclassproperty.com/properties/']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def parse(self, response):
        file = response.xpath('//script/@src').extract()
        js_link = f"https://www.worldclassproperty.com{file[1]}"
        res = requests.get(url=js_link)
        response = HtmlResponse(url=res.url, body=res.content)
        text1 = re.findall(r'{carouselImg:(.*?)mapdetails:', response.text, re.DOTALL)
        if len(text1) > 0:
            for data in text1:
                name = re.findall(r'title:"(.*?)",', data, re.DOTALL)
                if len(name) == 1:
                    if ' ' in name[0]:
                        p_name = name[0].replace(' ','').lower()
                    else:
                        p_name = name[0].lower()
                else:
                    print(name)
                    p_name = ''
                link = f"https://www.worldclassproperty.com/developments/{p_name}"
                yield scrapy.Request(url=link, callback=self.get_data, meta={'data': data,'p_name': name[0]})

    def get_data(self, response):
        try:
            Property_Name_text = re.findall(r'title:"(.*?)",', response.meta['data'], re.DOTALL)
            if len(Property_Name_text) == 1:
                Property_Name = Property_Name_text[0].strip()
            else:
                Property_Name = ''
        except Exception as e:
            Property_Name = ''
            print("Property_Name " + str(e))
        if response.meta['p_name'] == Property_Name:
            try:
                address_text = re.findall(r'address:"(.*?)",', response.meta['data'], re.DOTALL)
                if len(address_text) == 1:
                    Address = address_text[0].strip().split(',')[0]
                else:
                    Address = ''
            except Exception as e:
                print(e)
                Address = ''
            try:
                city_text = re.findall(r'city:"(.*?)",', response.meta['data'], re.DOTALL)
                if len(city_text) == 1:
                    City = city_text[0].strip()
                else:
                    City = ''
            except Exception as e:
                print(e)
                City = ''
            try:
                state_text = re.findall(r'state:"(.*?)",', response.meta['data'], re.DOTALL)
                if len(state_text) == 1:
                    State = state_text[0].strip()
                else:
                    State = ''
            except Exception as e:
                print(e)
                State = ''
            try:
                gla = re.findall(r'availableSF:"(.*?)",', response.meta['data'], re.DOTALL)
                gla_tmp = ''
                if len(gla) == 1:
                    gla_tmp = gla[0]
                    if ',' in gla_tmp:
                        gla_tmp = gla_tmp.replace(',','')
                    if 'SF' in gla_tmp:
                        gla_tmp = gla_tmp.replace('SF','')
                    if 'Sf' in gla_tmp:
                        gla_tmp = gla_tmp.replace('Sf','')
                    if gla_tmp != '':
                        GLA = gla_tmp.strip()
                    else:
                        GLA = ''
                else:
                    GLA = ''
            except Exception as e:
                GLA = ''
                print("gla " + str(e))
            try:
                des1 = re.findall(r'introduction1:\"(.*?)\",introduction2:', response.meta['data'], re.DOTALL)
                des2 = re.findall(r'introduction2:\"(.*?)\",assetType:', response.meta['data'], re.DOTALL)
                if len(des1) == 1 or len(des2) == 1:
                    Description = f"{des1[0]} {des2[0]}"
                else:
                    Description = ''
            except Exception as e:
                print(e)
                Description = ''
            try:
                item = ProprtySitesItem()
                item['Property_Name'] = Property_Name
                item['Address'] = Address
                item['City'] = City
                item['State'] = State
                item['GLA'] = GLA
                item['Description'] = Description
                item['Leasing_Contact_Phone'] = '512.808.1111'
                item['Leasing_Contact_Email'] = 'info@worldclassproperty.com'
                item['Property_URL'] = response.url
                yield item
            except Exception as e:
                print(f"not insert {response.url}" + str(e))
        else:
            print("other")


from scrapy.cmdline import execute
# execute("scrapy crawl store_501 -a list_id=501".split())