# -*- coding: utf-8 -*-
import re
import datetime
import scrapy,os,logging,hashlib
import requests,json
from lxml.html import open_in_browser
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func
import datetime
import html2text


class Store861Spider(scrapy.Spider):
    name = 'store_861'
    allowed_domains = []
    start_urls = []
    # handle_httpstatus_list = [404]
    # not_export_data = True


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)


    def start_requests(self):
        run_date = str(datetime.datetime.today()).split()[0]
        self.f1.set_details(self.list_id, run_date)
        try:

            source_url = "https://www.rosenthalproperties.com/properties/"


            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(run_date) + '.html'
            yield scrapy.FormRequest(url=str(source_url), callback=self.socondlevel,
                                     # headers=headers,
                                     meta={'source_url': source_url,
                                           # 'search_term': search_term,
                                           'file_path': file_path, 'proxy_type': self.proxy_type})
        except Exception as e:
            print(e)


    def socondlevel(self, response):
        try:
            data = re.findall('var REACTIVE = (.*?)php"};',response.text)[0] + 'php"}'
            body1 = json.loads(data)
            body = body1['allTermNames']
            for i in range(0,len(body)):
                # if body[i]['guid'] != 404:

                    try:
                        url = body[i]['guid']
                    except Exception as e:
                        print(e)

                    try:
                        Property_Name = body[i]['post_title']
                    except Exception as e:
                        print(e)



                    try:
                        res = requests.get(url)
                        # if '200' in str(res):
                        response = HtmlResponse(url=response.url, body=res.content)
                    except Exception as e:
                        print(e)

                    try:
                        Add = response.xpath('//*[@class="et_pb_module et_pb_text et_pb_text_0  et_pb_text_align_left et_pb_bg_layout_light"]//div//text()').extract_first()
                        Address = Add.split(",")[0]
                        City = Add.split(",")[1]
                        State = Add.split(",")[-1]
                    except Exception as e:
                        Address = ""
                        City = ""
                        State = ""
                        print(e)

                    try:
                        Description = '|'.join(response.xpath('//*[contains(text(),"AVAILABLE:")]/../../../div//text()').extract()).strip()
                    except Exception as e:
                        Description = ""
                        print(e)

                    try:
                        Leasing_Contact_Name = '|'.join(response.xpath('//*[contains(text(),"LEASING AGENT")]/../../..//div[@class="et_pb_blurb_description"]//p/text()[1]').extract()).strip()
                    except Exception as e:
                        Leasing_Contact_Name = ""
                        print(e)

                    try:
                        Leasing_Contact_Phone = '|'.join(response.xpath('//*[contains(text(),"LEASING AGENT")]/../../..//div[@class="et_pb_blurb_description"]//p/text()[2]').extract()).strip()
                    except Exception as e:
                        Leasing_Contact_Phone = ""
                        print(e)

                    try:
                        Leasing_Contact_Email = '|'.join(response.xpath('//*[contains(text(),"LEASING AGENT")]/../../..//div[@class="et_pb_blurb_description"]//p/a/@href').extract()).strip().replace("mailto:","")
                    except Exception as e:
                        Leasing_Contact_Email = ""
                        print(e)

                    try:
                        Site_Plan_URL = response.xpath('//*[contains(text(),"SITE PLAN")]/@href').extract_first().strip()
                    except Exception as e:
                        Site_Plan_URL = ""
                        print(e)

                    try:
                        Brochure_URL = response.xpath('//*[contains(text(),"BROCHURE")]/@href').extract_first()
                    except Exception as e:
                        Brochure_URL = ""
                        print(e)


                    item = ProprtySitesItem()
                    item['url'] = url
                    item['Property_Name'] = Property_Name
                    item['Address'] = Address
                    item['City'] = City
                    item['State'] = State
                    item['Description'] = Description
                    item['Leasing_Contact_Name'] = Leasing_Contact_Name
                    item['Leasing_Contact_Phone'] = Leasing_Contact_Phone
                    item['Leasing_Contact_Email'] = Leasing_Contact_Email
                    item['Site_Plan_URL'] = Site_Plan_URL
                    item['Brochure_URL'] = Brochure_URL
                    item['Property_URL'] = url
                    item['Country'] = "United States"
                    item['country_code'] = "US"
                    yield item




            # print(data)
        except Exception as e:
            print(e)

execute('''scrapy crawl store_861 -a list_id=861'''.split())