import json
import os
import re
import scrapy
import requests
from scrapy.http import HtmlResponse
import datetime
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func


class Store498Spider(scrapy.Spider):
    name = "store_498"
    allowed_domains = []
    start_urls = ['https://westfin.com/properties/']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def parse(self, response):
        url = "https://bmez25zt7f-2.algolianet.com/1/indexes/*/queries?x-algolia-agent=Algolia%20for%20JavaScript%20(3.33.0)%3B%20Browser%20(lite)%3B%20instantsearch.js%20(3.6.0)%3B%20JS%20Helper%20(2.28.0)&x-algolia-application-id=BMEZ25ZT7F&x-algolia-api-key=f903d6174145b46784f1e66bda37c7fc"
        data1 = '{"requests":[{"indexName":"wp_prod_posts_property","params":"query=&hitsPerPage=500&maxValuesPerFacet=10&page=0&highlightPreTag=__ais-highlight__&highlightPostTag=__%2Fais-highlight__&distinct=true&facets=%5B%22available_space%22%2C%22min_available_space%22%2C%22property_type%22%5D&tagFilters=&numericFilters=%5B%22min_available_space%3E%3D0%22%2C%22min_available_space%3C%3D22000%22%5D"},{"indexName":"wp_prod_posts_property","params":"query=&hitsPerPage=1&maxValuesPerFacet=10&page=0&highlightPreTag=__ais-highlight__&highlightPostTag=__%2Fais-highlight__&distinct=true&attributesToRetrieve=%5B%5D&attributesToHighlight=%5B%5D&attributesToSnippet=%5B%5D&tagFilters=&analytics=false&clickAnalytics=false&facets=min_available_space"}]}'
        header = {
            'accept': 'application/json',
            'Accept-Encoding': 'gzip, deflate, br',
            'Accept-Language': 'en-US,en;q=0.9',
            'content-type': 'application/x-www-form-urlencoded',
            'Host': 'bmez25zt7f-dsn.algolia.net',
            'Origin': 'https://westfin.com',
            'Referer': 'https://westfin.com/properties/',
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'cross-site',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.100 Safari/537.36'
        }
        res = requests.post(url=url, data=data1, headers=header)
        response = HtmlResponse(url=res.url, body=res.content)
        data_json = json.loads(response.text)
        counts = len(data_json['results'][0]['hits'])
        for count in range(counts):
            Property_Name = data_json['results'][0]['hits'][count]['post_title']
            location = data_json['results'][0]['hits'][count]['location']
            Address = location.split(',')[0]
            City = location.split(',')[1]
            State = location.split(',')[2].split(' ')[1]
            Zip_code = data_json['results'][0]['hits'][count]['zip_code']
            GLA = data_json['results'][0]['hits'][count]['shopping_center_size']
            Property_URL = data_json['results'][0]['hits'][count]['permalink']
            yield scrapy.Request(url=Property_URL, callback=self.get_data, meta={'Property_Name': Property_Name, 'Address': Address, 'City': City, 'State': State,'Zip_code':Zip_code, 'GLA': GLA, 'Property_URL': Property_URL})

    def get_data(self, response):
        try:
            Property_Name = response.meta['Property_Name'].strip()
        except Exception as e:
            Property_Name = ''
            print("Property_Name " + str(e))
        try:
            Address = response.meta['Address'].strip()
        except Exception as e:
            Address = ''
            print("Address " + str(e))
        try:
            City = response.meta['City'].strip()
        except Exception as e:
            City = ''
            print("City " + str(e))
        try:
            State = response.meta['State'].strip()
        except Exception as e:
            State = ''
            print("State " + str(e))
        try:
            Zip_code = response.meta['Zip_code'].strip()
        except Exception as e:
            Zip_code = ''
            print("Zip_code " + str(e))
        try:
            GLA = response.meta['GLA']
        except Exception as e:
            GLA = ''
            print("GLA " + str(e))
        try:
            Property_URL = response.meta['Property_URL'].strip()
        except Exception as e:
            Property_URL = ''
            print("Property_URL " + str(e))
        name_tmp = response.xpath('//*[@class="contact-title"]/text()').extract()
        try:
            Leasing_Contact_Name = response.xpath(f'//*[contains(text(),"{name_tmp[0]}")]/preceding-sibling::a/text()').extract_first().strip()
        except Exception as e:
            Leasing_Contact_Name = ''
            print("Leasing_Contact_Name " + str(e))
        try:
            Leasing_Contact_Phone = response.xpath(f'//*[contains(text(),"{name_tmp[0]}")]/following-sibling::a[@class="contact-phone"]/text()').extract_first().strip()
        except Exception as e:
            Leasing_Contact_Phone = ''
            print("Leasing_Contact_Phone " + str(e))
        try:
            Property_Manager_Name = response.xpath(f'//*[contains(text(),"{name_tmp[1]}")]/preceding-sibling::a/text()').extract_first().strip()
        except Exception as e:
            Property_Manager_Name = ''
            print("Property_Manager_Name " + str(e))
        try:
            Property_manager_phone = response.xpath(f'//*[contains(text(),"{name_tmp[1]}")]/following-sibling::a[@class="contact-phone"]/text()').extract_first().strip()
        except Exception as e:
            Property_manager_phone = ''
            print("Property_manager_phone " + str(e))
        try:
            Site_Plan_URL = re.findall(r';map&quot;:&quot;(.*?)&quot;,',response.text)
            if len(Site_Plan_URL) == 1:
                Site_Plan_URL = 'https:' + Site_Plan_URL[0].replace('\\','')
                res = requests.get(url=Site_Plan_URL)
                response1 = HtmlResponse(url=res.url,body=res.content)
                Site_Plan_URL = response1.url
        except Exception as e:
            Site_Plan_URL = ''
            print("Site_Plan_URL " + str(e))

        try:
            Brochure_URL = response.xpath('//a[contains(text(),"Download Brochure")]/@href').extract_first().strip()
        except Exception as e:
            Brochure_URL = ''
            print("Brochure_URL " + str(e))

        try:
            item = ProprtySitesItem()
            item['Property_Name'] = Property_Name
            item['Address'] = Address
            item['City'] = City
            item['State'] = State
            item['ZIP'] = Zip_code
            item['Property_URL'] = Property_URL
            item['Property_manager_phone'] = Property_manager_phone
            item['Property_Manager_Name'] = Property_Manager_Name
            item['Leasing_Contact_Name'] = Leasing_Contact_Name
            item['Leasing_Contact_Phone'] = Leasing_Contact_Phone
            item['GLA'] = GLA
            item['Brochure_URL'] = Brochure_URL
            item['Site_Plan_URL'] = Site_Plan_URL
            yield item
        except Exception as e:
            print("not insert " + str(e))


from scrapy.cmdline import execute
# execute("scrapy crawl store_498 -a list_id=498".split())
