# -*- coding: utf-8 -*-
import datetime
import re

import scrapy

from proprty_sites.spiders.common_functions import Func
from proprty_sites.items import ProprtySitesItem


class Store442Spider(scrapy.Spider):
    name = 'store_442'
    allowed_domains = []
    start_urls = ['https://linearretail.com/all-properties/']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)


    def parse(self, response):
        links = response.xpath('//h5/a/@href').getall()
        for link in links:
            yield scrapy.Request(url=link, callback=self.parse2)
            # yield scrapy.Request(url='https://linearretail.com/portfolio/retail-space-356-lafayette-rd-hampton-nh-03842/', callback=self.parse2)


    def parse2(self, response):
        try:property_name = response.xpath('//h1/text()').get(default='').strip()
        except Exception as e:print(e)

        text = response.xpath('//h1/following-sibling::span/text()').get().split(',')
        if len(text) == 2:
            address = text[0].strip()
            city = ''
        elif len(text) == 3:
            address = text[0].strip()
            city = text[1].strip()

        try:
            zip_code = text[-1].split(' ')[-1].strip()
            zip_code = re.findall(r'(\d{5})', zip_code)[0]
        except:
            zip_code = ''

        if address == '249 Newbury Street':
            zip_code = '02116'

        state = text[-1].split(' ')[1].strip()
        if state == 'Manchester':
            state = 'MA'

        try:description = response.xpath('//h5/following-sibling::p/text()').get(default='').strip()
        except Exception as e:print(e)

        text2 = response.xpath('//h5[contains(text(),"Contact")]/following-sibling::text()').getall()

        try:leasing_contact = text2[0].strip()
        except Exception as e:print(e)

        try:
            Leasing_phone = []
            leasing_phone1 = text2[2].strip()
            leasing_phone = re.findall(r'(\(\d+\) \d+-\d+)|(\d+-\d+-\d+)|(\(\d+\)-\d+-\d+)|(\d+–\d+–\d+)|(\d+.\d+.\d+)', leasing_phone1)
            for leas in leasing_phone:
                leasing = ''.join(leas)
                Leasing_phone.append(leasing)
        except Exception as e:
            print(e)

        try:leasing_email = response.xpath('//a[contains(text(),"@")]/text()').get(default='').strip()
        except Exception as e:print(e)

        property_url = response.url

        try:site_plan_url = 'https://linearretail.com'+response.xpath('//a[@title="Site Map"]/@href').get(default='').strip()
        except Exception as e:print(e)


        item = ProprtySitesItem()
        item['Property_Name'] = property_name
        item['Address'] = address
        item['City'] = city
        item['State'] = state
        item['ZipCode'] = zip_code
        item['Description'] = description
        item['Leasing_Contact_Name'] = leasing_contact
        item['Leasing_Contact_Phone'] = "|".join(Leasing_phone)
        item['Leasing_Contact_Email'] = leasing_email
        item['Site_Plan_URL'] = site_plan_url
        item['Property_URL'] = property_url
        yield item

if __name__ == '__main__':
    from scrapy.cmdline import execute
    execute('scrapy crawl store_442 -a list_id=442'.split())
