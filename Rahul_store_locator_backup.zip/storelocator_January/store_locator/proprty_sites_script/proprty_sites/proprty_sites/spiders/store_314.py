import re

import requests
import scrapy
import datetime
import hashlib
import re
import scrapy
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func
from scrapy.http import HtmlResponse
from scrapy.utils.response import open_in_browser

class HinesProperties(scrapy.Spider):
    name='store_314'

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)


    def start_requests(self):
        link='https://www.shopirvinecompany.com/centers/'
        yield scrapy.Request(url=link,callback=self.data,dont_filter=True)
    def data(self,response):
        links=response.xpath('//div[@id="accordion"]//li//@href').getall()
        names=response.xpath('//div[@id="accordion"]//li//text()').getall()
        for link,name in zip (links,names):
            link='https://www.shopirvinecompany.com'+link
            yield scrapy.Request(url=link,callback=self.get_data,dont_filter=True,meta={'name':name})
    def get_data(self,response):
        # open_in_browser(response)
        item = ProprtySitesItem()
        address=response.xpath('//h4[contains(text(),"Address")]/following-sibling::ul/li/text()').get()
        item['Property_Name']=response.meta['name']
        item['Address'] = response.xpath('//div[@class="address"]//text()[1]').get()
        address=response.xpath('//div[@class="address"]//text()[2]').get()
        item['City'] = address.split(',')[0]
        item['State'] = address.split(',')[1].strip().split(' ')[0]
        item['ZipCode'] = address.split(',')[1].strip().split(' ')[-1]



        leas=response.xpath('//a[contains(text(),"View leasing info")]//@href').get(default='')
        if leas !='':
            leas=f'https://www.shopirvinecompany.com{leas}'
            ress=requests.get(url=leas)
            print(ress)
            ress=HtmlResponse(url=leas,body=ress.content)
            print(ress)

            try:
                item['Anchor_1']=ress.xpath('//*[contains(text(),"Anchors")]/../following-sibling::td//text()[1]').get(default='')
                print(item['Anchor_1'])
            except:
                item['Anchor_1']=''
            # sqft = ress.xpath('//th[contains(text(),"SQ FT")]/../../following-sibling::tbody//td[2]//text()').get(default='')
            # sqft = ress.xpath('//div[@class="body col-md-8 col-xs-12"]//tbody/tr/td[2]/text()').get(default='')
            sqft = ress.xpath('//div[@class="widget widget-center-facts"]//table/tr/td[2]/text()').extract_first()
            print(sqft)

            item['SqFt'] = sqft
            try:item['Anchor_2']=ress.xpath('//*[contains(text(),"Anchors")]/../following-sibling::td//text()[2]').get(default='')
            except:item['Anchor_2']=''
            try:item['Anchor_3']=ress.xpath('//*[contains(text(),"Anchors")]/../following-sibling::td//text()[3]').get(default='')
            except:item['Anchor_3']=''
            a=ress.xpath('//a[contains(text(),"Site Plan (PDF)")]//@href').get(default='')
            aa=f'https://www.shopirvinecompany.com{a}'
            item['Plan_Url'] = aa
            # open_in_browser(ress)
            item['GLA']=ress.xpath('//h2[contains(text(),"Available Space")]/following-sibling::table//td[2]//text()').get(default='')

        else:
            item['Anchor_1']=''
            item['Anchor_2']=''
            item['Anchor_3']=''
            item['Plan_Url']=''
            item['GLA']=''
        item['URL']=response.url
        yield item

from scrapy.cmdline import execute
# execute("scrapy crawl store_314 -a list_id=314".split())