# -*- coding: utf-8 -*-
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
import html2text
h = html2text.HTML2Text()
import datetime
import scrapy, json, requests, re
import html2text
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func

class JbgsmithSpider(scrapy.Spider):
    name = 'store_470'
    allowed_domains = ['cafarocompany.com']
    start_urls = ['https://www.cafarocompany.com/cafaro-properties/']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)


    def parse(self, response):

        links=response.xpath('//div[@class="property_listing"]/div/a[1]/@href').getall()
        for link in links:
            yield scrapy.FormRequest(url=link, callback=self.get_store)
        next_page=response.xpath('//li[@class="roundright"]/a/@href').get(default='')
        if next_page!='':
            yield scrapy.FormRequest(url=next_page, callback=self.parse)


    def get_store(self,response):

        item=ProprtySitesItem()

        item['Property_Name'] = response.xpath('//h1[@class="entry-title entry-prop"]//text()').get(default='')
        item['Address'] = response.xpath('//span[@class="adres_area"]/text()').get(default='')
        item['City'] = response.xpath('//span[@class="adres_area"]//a/text()').get(default='')
        item['Description'] = ''.join(response.xpath('//span[@class="s1"]//text()|//div[@id="Property"]//p[2]//text()|//p[@class="p1"]//text()').getall())
        item['Leasing_contact_name'] = response.xpath('//div[@class="mydetails"]/following-sibling::h3//text()').get(default='')
        item['Leasing_contact_phone'] =response.xpath('//div[@class="mydetails"]/following-sibling::div[@class="agent_detail"]//a//text()').get(default='')
        item['Leasing_contact_email'] = response.xpath('//div[@class="mydetails"]/following-sibling::div[@class="agent_detail agent_email_class"]//a//text()').get(default='')
        item['Site_Plan_url'] =response.xpath('//div[@id="SitePlan"]//img//@src').get(default='')
        item['URL'] = response.url # self.f1.country_dict.get(item['country'].lower())
        yield item



from scrapy.cmdline import execute
# execute('''scrapy crawl store_470 -a list_id=470'''.split())
