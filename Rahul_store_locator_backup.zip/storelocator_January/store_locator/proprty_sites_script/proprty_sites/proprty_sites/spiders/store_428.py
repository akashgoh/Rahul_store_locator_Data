# -*- coding: utf-8 -*-
import scrapy
import json
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func
import datetime

class store_428_Spider(scrapy.Spider):
    name = 'store_428'
    # allowed_domains = ['www.example.com']
    start_urls = ['http://www.choicereit.ca/']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)



    def parse(self, response):
        link = 'https://webwidgets.q4api.com/v1/fusion?sql=SELECT%20*%20FROM%201BNdwW0PCqQOnQ6Ru65-qwzDr7PQcOScUybosI_ZG_K8%20ORDER%20BY%20%27Details%27%20DESC&key=AIzaSyC01AjTwWEaITKSSMfJbbr67t0hfhGn06Q'
        yield scrapy.FormRequest(url=link, callback=self.data)


    def data(self,response):
        item = ProprtySitesItem()
        data = response.text
        machine_data = json.loads(data)
        rawle=len(machine_data['rows'])
        raw=machine_data['rows']
        for i in range(0,int(rawle)):
            Address=raw[i][1]
            property_name=Address
            City=raw[i][2]
            Providence=raw[i][3]
            GLA=raw[i][6]
            url=raw[i][10]
            # if len(url)==0:
            if url=="":
                item['Property_Name']=property_name
                item['Address']=Address
                item['City']=City
                item['State']=Providence
                item['GLA'] = GLA
                item['Brochure_URL'] = ''
                item['Property_URL'] = ''
                item['plan_url'] = ''
                yield item
                # print(item)
            else:
                if 'http' not in url:
                    url='http://www.choicereit.ca'+url
                    yield scrapy.Request(url=url, callback=self.finaldata,
                                         meta={'Address': Address, 'City': City, 'Providence': Providence, 'GLA': GLA})
                else:
                    yield scrapy.Request(url=url,callback=self.finaldata,meta={'Address':Address,'City':City,'Providence':Providence,'GLA':GLA})

    def finaldata(self,response):
        try:
            item = ProprtySitesItem()

            Address=response.meta['Address']
            City=response.meta['City']
            Providence=response.meta['Providence']
            GLA=response.meta['GLA']
            url=response.url

            # try:
            #     tele_acces_line=response.xpath('//p[@class="disclaimerphone"]/a/text()').get().strip()
            # except:
            #     tele_acces_line=''

            try:
                lat=response.xpath('//div[@class="mini-gmap"]/@data-lat').get()
                long=response.xpath('//div[@class="mini-gmap"]/@data-long').get()
                direction='https://www.google.com/maps?saddr=My+Location&daddr='+str(lat)+','+str(long)
            except Exception as e:
                direction=''
                print(e,url)
            try:
                pdf='http:'+response.xpath('//p[@class="download"]/a/@href').get()
            except:
                pdf=''

            item['Property_Name'] = Address
            item['Address'] = Address
            item['City'] = City
            item['State'] = Providence
            item['GLA'] = GLA
            item['Brochure_URL'] = direction
            item['Property_URL'] = url
            item['plan_url'] = pdf

            yield item
        except Exception as e:
            print(e)


# from scrapy.cmdline import execute
# execute('''scrapy crawl store_428 -a list_id=428'''.split())