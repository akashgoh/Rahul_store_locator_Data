# -*- coding: utf-8 -*-
# -*- coding: utf-8 -*-
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
import html2text
h = html2text.HTML2Text()
import datetime
import scrapy, json, requests, re
import html2text
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func

class SiteCentersSpider(scrapy.Spider):
    name = 'store_491'
    allowed_domains = ['example.com']
    start_urls = ['https://www.sitecenters.com/explore-our-properties']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def parse(self, response):
        try:
            links = response.xpath('//*[@class="data-table__tbody"]/tr/td[1]/a/@href').getall()
            for link in links:
                url = 'https://www.sitecenters.com' + link
                yield scrapy.FormRequest(url=url, callback=self.parse_data, dont_filter=True)
        except Exception as e:
            print(e)

    def parse_data(self, response):

        # id = response.meta['id']
        # try:
        #     f = open('E:/Anil/Html Pages/StoreLocator/SiteCenters/' + str(id) + '.html', 'wb')
        #     f.write(response.text.encode('utf-8'))
        #     print('Page Saved...', str(id))
        #     f.close()
        # except Exception as e:
        #     print(e)

        try:
            item = ProprtySitesItem()
            item['Property_Name'] = response.xpath('//*[@class="page-header__main__title type--a2 type--white"]/text()').get().strip()
            addr = response.xpath('//*[@class="link__text type--b1"]/text()').getall()
            try:
                item['Address'] = addr[0].strip()
                print(item['Address'])
            except:
                item['Address'] = ''
            try:
                item['City'] = addr[1].split(',')[0].strip()
            except:
                item['City'] = ''
            try:
                item['State'] = addr[1].split(',')[1].strip().split()[0].strip()
            except:
                item['State'] = ''
            try:
                item['Zip'] = addr[1].split(',')[1].strip().split()[1].strip()
            except:
                item['Zip'] = ''
            try:
                item['Description'] = ' '.join(response.xpath('//*[@class="page-header__property-detail-copy"]/div//text()').getall()).strip()
            except:
                item['Description'] = ''
            try:
                item['GLA'] = re.findall(r'is a (.*?) sf',item['Description'])[0].replace(',','')
            except:
                item['GLA'] = ''
            try:
                item['Leasing_Contact_Name'] = response.xpath('//*[contains(text(),"Retail Leasing")]/../p/text()').get().strip()
            except:
                item['Leasing_Contact_Name'] = ''
            try:
                item['Leasing_Contact_Phone'] = response.xpath('//*[contains(text(),"Retail Leasing")]/../../li[2]/p/text()').get().strip()
            except:
                item['Leasing_Contact_Phone'] = ''
            try:
                item['Property_Manager_Name'] = response.xpath('//*[contains(text(),"Property Manager")]/../p/text()').get().strip()
            except:
                item['Property_Manager_Name'] = ''
            try:
                item['Property_Manager_Phone'] = response.xpath('//*[contains(text(),"Property Manager")]/../../li[2]/p/text()').get().strip()
            except:
                item['Property_Manager_Phone'] = ''
            try:
                item['Site_Plan_URL'] = 'https:' + str(response.xpath('//*[@class="page-header__property-detail-map"]//ul/li[5]/div/a/@href').get())
                # print(item['Site_Plan_URL'])
            except:
                item['Site_Plan_URL'] = ''
            item['Property_URL'] = response.url
            yield item
        except Exception as e:
            print(e)


# from scrapy.cmdline import execute
# execute("scrapy crawl store_491 -a list_id=491".split())