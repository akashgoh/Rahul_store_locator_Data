# -*- coding: utf-8 -*-
import json
import re
import datetime
import html2text
import scrapy
# from nltk import RegexpTokenizer
# from nltk.corpus import stopwords
from scrapy.http import HtmlResponse

from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func

h = html2text.HTML2Text()

class store460Spider(scrapy.Spider):
    name = 'store_460'
    allowed_domains = []
    start_urls = ['https://www.goldenbergdevelopment.com/properties/']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)
        # print(self.table_name)

    def parse(self,response):
        urls = response.xpath('//*[@class="entry"]/a/@href').extract()
        # name = response.xpath('//*[@class="entry-title"]/text()').extract()
        # email = response.xpath('//*[@class="entry-contact"]/a/text()').extract()
        for url in urls:
            yield scrapy.Request(url=url, callback=self.parseData2, dont_filter=True)

    def parseData2(self,response):
        item = ProprtySitesItem()

        text = html2text.HTML2Text()
        text.ignore_images = True
        text.ignore_links = True
        text.ignore_emphasis = True
        text.body_width = 0
        text.ignore_tables = True

        item['PropertyName'] = response.xpath('//*[@class="entry-title"]/text()').extract_first(default="")
        info = response.xpath('//*[@class="entry-content"]//a/text()').get()

        try:
            item['Address'] = info.split(',')[0].strip()
            item['City'] = info.split(',')[1].strip()
            item['State'] = info.split(',')[2].strip()
        except Exception as e:
            item['Address'] =''
            item['City'] =''
            item['State'] = ''

        item['Description'] = ''.join(response.xpath('//*[@class="entry-content"]/p[1]/text()').extract()).strip()
        item['LeasingContactName'] = ''
        item['LeasingContactEmail'] = ''
        item['Siteplanurl'] = ''.join(response.xpath("//*[contains(text(),'Site Plan')]/@href").extract())
        item['PropertyURL'] = response.url
        yield item

from scrapy.cmdline import execute
# execute("scrapy crawl store_460 -a list_id=460".split())