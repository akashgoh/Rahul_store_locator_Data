import datetime
import hashlib
import scrapy
from parsel import Selector
from proprty_sites.spiders.common_functions import Func
from proprty_sites.items import ProprtySitesItem


class retail_value_inc(scrapy.Spider):
    name = 'store_453'

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)
        urls = ['https://retailvalueinc.com/disposition-properties']
        for i in urls:
            yield scrapy.Request(url=i,callback=self.Extract)
    # def parse(self, response):
    #     urls = response.xpath('//table[@id="search-results-table"]//td/a/@href').extract()
    #     for i in urls:
    #         yield scrapy.Request(url='https://www.roireit.net'+i,callback=self.Extract)

    def Extract(self,response):
        item = ProprtySitesItem()
        name = response.xpath('//h4/text()').extract()
        # addr = response.xpath('//div[@typography="BodyAlpha"]/p[1]/span/a/text()').extract()
        gla = response.xpath('//div[@data-typography="BodyBeta"]/text()').extract()

        deatils = response.xpath('//*[contains(text(),"Dispositions")]/../../..').extract()
        siteplan = response.xpath('//*[contains(text(),"Downloads")]/following-sibling::a[3]/text()').extract()

        for i in range(26):
            item['Property_Name'] = name[i]
            try:
                data = Selector(str(deatils[i])).xpath('//div/p/span/text()').extract()
                email = Selector(str(deatils[i])).xpath('//div/p/span/a/text()').extract()
                print(email)
                addr  = email[0]

                if len(addr.split(',')) == 3:
                    item['Address'] = addr.split(',')[0].strip()
                    item['City'] = addr.split(',')[1].strip()
                    item['State'] = addr.split(',')[2].strip().split(' ')[0].strip()
                    item['Zip'] = addr.split(',')[2].strip().split(' ')[1].strip()
                elif len(addr.split(',')) == 4:
                    item['Address'] = addr.split(',')[0].strip()
                    item['City'] = addr.split(',')[1].strip()
                    item['State'] = addr.split(',')[4].strip()
                    item['Zip'] = addr.split(',')[3].strip()

                item['GLA'] = gla[i]

                item['Leasing_Contact_Name'] = data[2].strip().strip('|').split('|')[0].strip()
                item['Leasing_Contact_Phone'] = data[2].split('|')[1].strip()
                item['Leasing_Contact_Email'] = email[1]

                item['Property_Manager_Name'] = data[4].strip().strip('|').split('|')[0].strip()
                item['Property_manager_phone'] = data[4].split('|')[1].strip()
                item['Property_manager_email'] = email[2]

                item['Site_Plan_URL'] = response.xpath('//div/p/span/a[contains(text(),"Site Plan")]/@href').extract_first()
                item['Property_URL'] = response.url

            except Exception as e:
                print('error in e',e)

            hasstr = (str(item['Property_URL']) + str(item['Property_Name'])).encode('utf8')
            Hash_id = int(hashlib.md5(hasstr).hexdigest(), 16)
            item['hash'] = Hash_id
            print(item)
            yield item

if __name__ == '__main__':
    from scrapy.cmdline import execute
    # execute("scrapy crawl store_453".split())
    execute("scrapy crawl store_453 -a list_id=453".split())