import logging
import os
import re

import datetime
import scrapy, json, requests, re
import html2text
from scrapy.cmdline import execute

from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func

class Store721Spider(scrapy.Spider):
    name = 'store_726'
    allowed_domains = []


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        try:
            source_url = link = 'http://www.gumberg.com/properties/'
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(self.run_date) + '.html'
            yield scrapy.FormRequest(url=str(link), callback=self.prop_link,meta={'source_url': source_url,'file_path': file_path})

        except Exception as e:
            logging.log(logging.ERROR, e)

    def prop_link(self,response):
        links = response.xpath('//li[@class="property_title"]/a/@href').getall()
        for link in links:
            # print(link)
            header = {

            }
            yield scrapy.FormRequest(url=str(link), callback=self.parse)

    def parse(self,response):
        # print(response.text)
        property_name = response.xpath('//div[@class="property-sidebar"]/div/h2/text()').get()
        address = response.xpath('//div[@class="property-sidebar"]/div[2]/p[1]/span[2]/text()[1]').get()
        csz = response.xpath('//div[@class="property-sidebar"]/div[2]/p[1]/span[2]/text()[2]').get()
        city = csz.split(',')[0]
        state = csz.split(',')[1].split(' ')[1]
        zip_code = csz.split(',')[1].split(' ')[-1]
        GLA = response.xpath('//div[@class="property-sidebar"]/div[2]/p[2]/span[2]/text()').get().replace('over','').replace(',','').strip()
        try:
            AT = response.xpath('//p//span[@class="value"]/ul/li/text()').extract()

            Anchor_Tenants = '|'.join(AT)
        except:
            Anchor_Tenants = ''

        try:
            Brochure = re.findall(r'<li><a href="(.*?)">Brochure</a></li>',response.text)
            if Brochure != '':
                if 'http://www.gumberg.com' in Brochure:
                    BrochureURL = Brochure
                else:
                    BrochureURL = 'http://www.gumberg.com/' + str(Brochure)
            else:
                BrochureURL = ''
        except:
            BrochureURL = ''

        try:

            SitePlan = re.findall(r'<li><a href="(.*?)">Site Plan</a></li>',response.text)
            if SitePlan != '':
                if 'http://www.gumberg.com' in SitePlan:
                    SitePlanURL = SitePlan
                else:
                    SitePlanURL = 'http:' + str(SitePlan)
            else:
                SitePlanURL = ''
        except:
            SitePlanURL = ''

        item = ProprtySitesItem()
        b = str(BrochureURL).replace('"','').replace("'","").replace('http://www.gumberg.com/[','').replace(']','').replace("'target=_blank',","")
        s = str(SitePlanURL).replace('"','').replace("'","").replace('http:[','').replace(']','').replace("'target=_blank',","")

        if 'http://www.gumberg.com' not in b:
            b = ('http://www.gumberg.com' + b).replace('target=_blank','').strip()
        else:
            b = b

        if 'http://www.gumberg.com' not in s:
            s = ('http://www.gumberg.com' + s).replace('target=_blank','').strip()
        else:
            s = s

        item['Property_name'] = property_name
        item['Address'] = address
        item['City'] = city
        item['State'] = state
        item['ZIP'] = zip_code.replace('\xa0','')
        item['GLA'] = GLA.replace(',','').replace('SF','')
        item['BrochureURL'] = b
        item['SitePlanURL'] = s
        item['Anchor_Tenants'] = Anchor_Tenants
        item['PropertyURL'] = response.url

        yield item

# execute('''scrapy crawl store_726 -a list_id=726'''.split())



