# -*- coding: utf-8 -*-
import datetime
import scrapy, json, requests, re
import html2text
from scrapy.http import HtmlResponse
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func

class continental_realty_corporationSpider(scrapy.Spider):
    name = 'store_472'
    allowed_domains = []
    # start_urls = ['https://www.crcrealty.com/commercial-properties/']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)


    def start_requests(self):

        link='http://www.crcrealty.com/commercial-properties/'
        header={'Upgrade-Insecure-Requests': '1',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36',
                'Sec-Fetch-Dest': 'document',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9'}
        yield scrapy.Request(url=link,callback=self.parse,headers=header,dont_filter=True)


    def parse(self,response):

        # open_in_browser(response)
        links=response.xpath('//a[contains(text(),"More Info")]//@href').getall()
        header = {'Upgrade-Insecure-Requests': '1',
                  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36',
                  'Sec-Fetch-Dest': 'document',
                  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9'}

        for link in links:
            yield scrapy.FormRequest(url=link, callback=self.get_store,headers=header)

    def get_store(self,response):
        item=ProprtySitesItem()
        item['Property_Name'] = response.xpath('//h4[@class="heading-title"]//text()').get(default='')

        add=response.xpath('//h2[@class="address"]/text()').get().rsplit(',',2)
        item['Address'] = add[0]
        item['City'] = add[1]
        item['State'] =add[2].strip().split(' ')[0]
        item['Zip'] =add[2].strip().split(' ')[-1]

        item['GLA'] = response.xpath('//div[@class="icon tape"]/following-sibling::h4/text()').get(default='')
        item['Description'] = ''.join(response.xpath('//h3//li//text()').getall())
        item['Leasing_contact_name'] = response.xpath('//h4[contains(text(),"Leasing Contact")]/following-sibling::div[2]/h2/text()|//h4[contains(text(),"LEASING CONTACT")]/following-sibling::div[2]/h2/text()').get(default='')
        item['Leasing_contact_phone'] =response.xpath('//h4[contains(text(),"Leasing Contact")]/following-sibling::div[2]/p/a/text()|//h4[contains(text(),"LEASING CONTACT")]/following-sibling::div[2]/p/a/text()').get(default='')
        item['Property_manager_name'] =response.xpath('//h4[contains(text(),"Property Management Contact")]/following-sibling::div[2]/h2/text()|//h4[contains(text(),"PROPERTY MANAGEMENT")]/following-sibling::div[2]/h2/text()').get(default='')

        if item['Leasing_contact_name']:
            if item['Property_manager_name']:
                try:
                    item['Leasing_contact_email'] = re.findall(r'<a href="mailto:(.*?)">',response.text)[0]
                except Exception as e:
                    print(e)
                    item['Leasing_contact_email'] = ''
                try:
                    item['Property_manager_email'] = re.findall(r'"mailto:(.*?)"', response.text)[1]
                except Exception as e:
                    print(e)
                    item['Property_manager_email'] = ''
            else:
                try:
                    item['Leasing_contact_email'] = re.findall(r'"mailto:(.*?)"', response.text)[0]
                except:
                    item['Leasing_contact_email'] = ''
                item['Property_manager_email'] = ''

        else:
            if item['Property_manager_name']:
                item['Leasing_contact_email'] = ''
                try:
                    item['Property_manager_email']= re.findall(r'"mailto:(.*?)"', response.text)[0]
                except:
                    item['Property_manager_email'] = ''
            else:
                item['Leasing_contact_email'] = ''
                item['Property_manager_email'] = ''

        item['Property_manager_phone'] =response.xpath('//h4[contains(text(),"Property Management Contact")]/following-sibling::div[2]/p/a/text()|//h4[contains(text(),"PROPERTY MANAGEMENT")]/following-sibling::div[2]/p/a/text()').get(default='')

        item['URL'] = response.url # self.f1.country_dict.get(item['country'].lower())

        l_e = response.xpath('//*[@class="round yardi-link sidebar"]/@href').get()

        if l_e:
            res = requests.get(l_e)
            site = HtmlResponse(url=res.url, body=res.content)

            Brochure_url = site.xpath('//*[contains(text(),"Brochure")]/@href').get()
            if Brochure_url:
                item['Brochure_url'] = 'https://continentalrealty.commercialcafe.com' +str(Brochure_url)
            else:
                item['Brochure_url'] = ''

            siteplan = site.xpath('//*[contains(text(),"Marketing LP")]/@href').get()
            if siteplan :
                item['siteplan_url'] = 'https://continentalrealty.commercialcafe.com' +str(siteplan)
            else:
                item['siteplan_url'] = ''

        else:
            item['Brochure_url'] = ''
            item['siteplan_url'] = ''
        yield item



from scrapy.cmdline import execute
# execute('''scrapy crawl store_472 -a list_id=472'''.split())
