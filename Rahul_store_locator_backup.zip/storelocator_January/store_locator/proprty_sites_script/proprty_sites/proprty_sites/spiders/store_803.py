# -*- coding: utf-8 -*-
import scrapy,re, json
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func
import datetime

from scrapy.cmdline import execute

class ShoponeSpider(scrapy.Spider):
    name = 'store_803'
    allowed_domains = []
    start_urls = ['https://www.amcap.com/properties/']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)


    def parse(self, response):

        link=response.xpath('//div[@class="tabscontent"]//div[@class="properties_grid_detail"]//a/@href').extract()

        for i in link:
            url = i
            yield scrapy.FormRequest(url=url,callback=self.extract,dont_filter=True)

    def extract(self,response):

            a=response.text

            pname=response.xpath('//meta[@property="og:title"]/@content').extract_first()
            if '| AmCap Incorporated' in pname:
                pname=pname.replace('| AmCap Incorporated','')
            print(pname)

            add=response.xpath('//div[@class="property_overview_top"]/p/text()').extract_first().replace('\n','').strip()

            ct1=add.split('-')

            ct2=ct1[-1].split(',')
            city=ct2[0].strip()
            st=ct2[-1]
            st1=st.split('(')
            state=st1[-1].replace(')','').strip()


            # des=response.xpath('//div[@class="property_overview_bottom"]//p/text()').extract_first()
            des=response.xpath('//div[@class="modal-body"]//text()').extract_first()
            print(des)

            try:
                gla=re.findall('<li> GLA:(.*?)</li>',a)[0].replace(',','').strip()
            except Exception as e:
                print('glaerorr',e)


            try:
                metroarea=re.findall('<li> Metro Area:(.*?)</li>',a)[0]
            except Exception as e:
             print('metroarea eror',e)


            try:
               parking=re.findall('<li> Parking Spaces:(.*?)</li>',a)[0].strip()
            except Exception as e:
               print('parking space',e)

            mgname= response.xpath('//div[@class="col-lg-5 col-md-12 col-sm-12 col-xs-12 property_overview_top_lft"]//h5/text()').extract_first()

            data=response.xpath('//div[@class="col-lg-5 col-md-12 col-sm-12 col-xs-12 property_overview_top_lft"]//address//text()').extract()

            mgemail=data[-2]

            mgphone=data[3]


            try:
                manager_officeadd=''.join(data[:3]).strip()
            except:
                print('manager adress')

            if 'Office:' in manager_officeadd:
                manager_officeadd=manager_officeadd.replace('Office:','')



            leasing= response.xpath('//div[@class="col-lg-7 col-md-12 col-sm-12 col-xs-12 property_overview_top_lft property_overview_top_right"]//h5/text()').extract_first()

            lsdata=response.xpath('//div[@class="col-lg-7 col-md-12 col-sm-12 col-xs-12 property_overview_top_lft property_overview_top_right"]//address//text()').extract()

            # docs=response.xpath('//div[@class="news_details pdf_css"]//a/@href').extract()
            # if len(docs)<=1:
            #     docsm=''.join(docs)
            #     if 'demographic' in docsm:
            #         demograph=docsm
            #     elif 'Site' in docs:
            #         siteplan=docsm
            #     elif 'Web' in docs:
            #         brch=docsm
            #     else:
            #         pass
            # else:
            #
            #     try:
            #         if 'demographic' or 'Demographic' in docs:
            #             demograph=docs[0]
            #         elif 'Web' in docs:
            #             brch=docs[0]
            #
            #         elif 'Site' in docs:
            #             siteplan=docs[0]
            #     except:
            #         demograph=''
            #
            #     print(docs)
            #     try:
            #         brch= docs[1]
            #     except:
            #         if 'Web' in docs:
            #             brch=docs[0]
            #         elif 'Site' in docs:
            #             siteplan=docs[0]
            #
            #     try:
            #          siteplan= docs[2]
            #     except:
            #         if 'Site' in docs:
            #             siteplan=docs[0]
            #         else:
            #             siteplan=''

            lsphone=lsdata[3]
            lsemail=lsdata[-2]
            leasadd= ', '.join(lsdata[:3]).strip()

            if 'Office:' in leasadd:
                leasadd = leasadd.replace('Office:', '')

            try:
                siteplan =response.xpath('//div[@id="siteplan"]/a/img/@src').extract_first()
                if 'https://cdn.shortpixel.ai/client/q_lossless,ret_img/' in siteplan:
                    siteplan=siteplan.replace('https://cdn.shortpixel.ai/client/q_lossless,ret_img/','')
                print(siteplan)
            except:
                siteplan=''

            item = ProprtySitesItem()
            item['Property_name'] = pname
            item['Address'] = add
            item['city'] = city
            item['state'] = state
            item['description']=des
            item['country'] = 'US'
            item['GLA'] = gla
            item['metro_area'] = metroarea
            item['parking_space']=parking
            item['manager_name']=mgname
            item['manager_phone']=mgphone
            item['manager_email']=mgemail
            item['manager_office_address']=manager_officeadd
            item['Leasing'] = leasing
            item['Leasing_Phone'] = lsphone
            item['Leasing_Email'] = lsemail
            item['Leasing_office_address']=leasadd
            item['Plan_url'] =  siteplan
            # item['Brochure_url'] =brch
            # item['Demographics_url']=demograph
            item['URL'] = response.url
            yield item


# execute("scrapy crawl store_803 -a list_id=803".split())