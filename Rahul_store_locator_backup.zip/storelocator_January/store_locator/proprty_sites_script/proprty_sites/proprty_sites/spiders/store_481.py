# # -*- coding: utf-8 -*-
# import scrapy
# import json
# from proprty_sites.items import ProprtySitesItem
# from proprty_sites.spiders.common_functions import Func
# import datetime
# import re
#
#
# class store_481_Spider(scrapy.Spider):
#     name = 'store_481'
#     # allowed_domains = ['www.example.com']
#     start_urls = ['https://www.newmarkmerrill.com/leasing/']
#
#     def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
#         super().__init__(name, **kwargs)
#         self.list_id, self.proxy_type = list_id, proxy_type
#         self.f1 = Func()
#         self.run_date = str(datetime.datetime.today()).split()[0]
#         self.table_name = self.f1.set_details(self.list_id, self.run_date)
#
#
#     def parse(self, response):
#         links=response.xpath('//div[@class="w2dc-categories-root w2dc-category-item"]/a/@href').getall()
#
#         for link in links:
#             yield scrapy.Request(url=link, callback=self.property_link)
#
#     def property_link(self,response):
#
#         data = re.findall('eval\((.*?)\)\,', response.text)[0]
#         machine_data=json.loads(data)
#         stores=len(machine_data)
#         links=[]
#         for i in range(0,int(stores)):
#             p_link=machine_data[i][8]
#             links.append(p_link)
#
#         links.extend(['https://www.newmarkmerrill.com/leasing/beach-talbert-village18061-beach-blvd-huntington-beach-ca-92648/','https://www.newmarkmerrill.com/leasing/triangle-town-center1015-ocean-beach-highway-longview-wa-98632/','https://www.newmarkmerrill.com/leasing/rialto-marketplace-ii-rialto-ca-92376/'])
#
#         for link in links:
#             yield scrapy.Request(url=link, callback=self.finaldata)
#
#     def finaldata(self, response):
#
#         store_name=response.xpath('//h2[@itemprop="name"]/text()').get().strip()
#
#         try:
#             address= response.xpath('//h2[@itemprop="name"]/text()').getall()[1].strip().split(',')[0].strip()
#         except Exception as e:
#             print(e, response.url)
#             address = ''
#
#         try:
#             city= response.xpath('//h2[@itemprop="name"]/text()').getall()[1].strip().split(',')[1].strip()
#         except Exception as e:
#             print(e,response.url)
#             city=''
#
#         try:
#             state=  response.xpath('//h2[@itemprop="name"]/text()').getall()[1].strip().split(',')[-1].strip().split()[0].strip()
#         except Exception as e:
#             print(e,response.url)
#             state=''
#
#         try:
#             zip_code = response.xpath('//h2[@itemprop="name"]/text()').getall()[1].strip().split(',')[-1].strip().split()[-1].strip()
#         except Exception as e:
#             print(e,response.url)
#             zip_code=''
#
#         try:
#             gla = \
#             response.xpath('//span[contains(text(),"SQFT:")]/preceding-sibling::span/../following-sibling::span/text()').get().strip()
#         except Exception as e:
#             print(e, response.url)
#             gla = ''
#
#         try:
#             Description=' '.join( response.xpath('//div[@class="w2dc-field w2dc-field-output-blockw2dc-field-output-block-string w2dc-field-output-block-15"]//text()').getall()).strip()
#         except Exception as e:
#             print(e,response.url)
#             Description=''
#
#         try:
#             Leasing_Contact_Name=response.xpath('//span[contains(text(),"Name:")]/preceding-sibling::span/../following-sibling::span/text()').get().strip()
#         except Exception as e:
#             print(e, response.url)
#             Leasing_Contact_Name=''
#
#         try:
#             Leasing_Contact_Phone=response.xpath('//span[contains(text(),"Phone:")]/preceding-sibling::span/../following-sibling::span/text()').get().strip()
#         except Exception as e:
#             print(e, response.url)
#             Leasing_Contact_Phone = ''
#
#         try:
#             Leasing_Contact_Email= response.xpath('//span[contains(text(),"Email:")]/preceding-sibling::span/../following-sibling::span/a/text()').get().strip()
#         except Exception as e:
#             print(e,response.url)
#             Leasing_Contact_Email=''
#
#         try:
#             Brochure_URL= response.xpath('//a[@itemprop="url"]/@href').get().strip()
#         except Exception as e:
#             print(e,response.url)
#             Brochure_URL=''
#
#         try:
#             item = ProprtySitesItem()
#             item['Property_Name'] = store_name
#             item['Address']=address
#             item['City'] = city
#             item['State'] = state
#             item['Zip']=zip_code
#             item['Gla']=gla
#             item['Description'] = Description
#
#             item['Leasing_Contact_Name']=Leasing_Contact_Name
#             item['Leasing_Contact_Phone'] =Leasing_Contact_Phone
#             item['Leasing_Contact_Email'] =Leasing_Contact_Email
#
#             item['Brochure_URL'] =Brochure_URL
#
#             item['Property_URL'] = response.url
#
#             # print (item)
#             yield item
#         except Exception as e:
#             print("item", e)
#
#
#
#
# # from scrapy.cmdline import execute
# # execute('''scrapy crawl store_481 -a list_id=481'''.split())
