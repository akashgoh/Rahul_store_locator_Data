# -*- coding: utf-8 -*-
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
import html2text
h = html2text.HTML2Text()
import datetime
import scrapy, json, requests, re
import html2text
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func

class JbgsmithSpider(scrapy.Spider):
    name = 'store_436'
    allowed_domains = []
    start_urls = ['https://api-jbgsmith.reol.com/api/page/portfolio/retail']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def parse(self, response):
        try:
            df = json.loads(response.text)
            loop = df['data']['search']['properties']
            for lp in loop:
                name = lp['property']['name']
                full_address = lp['property']['full_address']
                # city = lp['property']['state']
                city = lp['property']['city']
                print(city)
                # a = lp['featured_property']['property']['city']
                # print(a)
                id = lp['property']['id']
                url = f"https://www.jbgsmith.com/property/retail/{name.strip().replace(' ','-')}/{str(id)}"
                #3313718

                head = {'Host': 'api-jbgsmith.reol.com',
                        # 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:72.0) Gecko/20100101 Firefox/72.0',
                        'Accept': '*/*',
                        'Accept-Language': 'en-GB,en;q=0.5',
                        'Accept-Encoding': 'gzip, deflate, br',
                        'Origin': 'https://www.jbgsmith.com',
                        'Referer': url}
                res = requests.get(f'https://api-jbgsmith.reol.com/api/page/property/retail?id={str(id)}',headers=head)
                response_f = HtmlResponse(url=res.url,body=res.content)

                gh = json.loads(response_f.text)
                desc = gh['data']['content']
                try:
                    temp = h.handle(gh['data']['overview_content'])
                    if 'GROSS LEASABLE AREA' or 'GLA' in temp:
                        a = re.findall('GROSS LEASABLE AREA(.*)sf',temp,re.DOTALL)
                        if a!=[]:
                            try:gla_temp = a[0].replace(',','').replace('*','').strip() if a[0].replace(',','').replace('*','').strip()!=None else ''
                            except:gla_temp = ''
                        else:gla_temp=''
                    else:
                        gla_temp=''
                except:gla_temp=''
                try:l_name = gh['data']['leasing_agents'][0]['name'] if  gh['data']['leasing_agents'][0]['name']!=None else ''
                except:l_name = ''
                try:l_phone = gh['data']['leasing_agents'][0]['phone'] if  gh['data']['leasing_agents'][0]['phone']!=None else ''
                except:l_phone = ''
                try:l_mail = gh['data']['leasing_agents'][0]['email'] if  gh['data']['leasing_agents'][0]['email']!=None else ''
                except:l_mail = ''

                item = ProprtySitesItem()
                item['Property_Name'] = name
                item['Address'] = full_address
                item['City'] = city
                item['Description'] = desc
                item['GLA'] = gla_temp
                item['Leasing_Contact'] = l_name
                item['Leasing_Phone'] = l_phone
                item['Leasing_Email'] = l_mail
                item['Property_URL'] = url
                yield item
        except Exception as e:
            print(e)

# execute("scrapy crawl store_436 -a list_id=436".split())