# -*- coding: utf-8 -*-
import datetime
import scrapy, json, requests, re
import html2text
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func



class cadillac_fairview_canadaSpider(scrapy.Spider):
    name = 'store_469'
    allowed_domains = []
    start_urls = ['https://api.cfretail.ca/retail_api/properties/allByProvince']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)


    def parse(self, response):
        # open_in_browser(response)
        links=re.findall('"_id":"(.*?)"',response.text)
        for link in links:
            link='https://api.cfretail.ca/retail_api/properties/'+link
        # header={"Accept":"application/json, text/javascript, */*; q=0.01",
        #         "Accept-Encoding":"gzip, deflate, br",
        #         "Accept-Language":"en-US,en;q=0.9",
        #         "Connection":"keep-alive",
        #         "Host":"www.regencycenters.com",
        #         "Sec-Fetch-Mode":"cors",
        #         "Sec-Fetch-Site":"same-origin",
        #         "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36",
        #         "X-Requested-With":"XMLHttpRequest"}
            yield scrapy.FormRequest(url=link, callback=self.get_store)



    def get_store(self,response):
        data=json.loads(response.text)
        # open_in_browser(response)
        item=ProprtySitesItem()

        item['Property_Name'] = data['property']['title']
        item['City'] = data['property']['location_city']
        item['State'] = data['property']['location_prov']
        item['Address'] = data['property']['location_street']
        item['Zip'] = data['property']['location_postal']


        item['GLA'] = data['stats'][1]['value']
        item['Description'] = data['property']['intro_copy'].replace('\n','').replace('<p>','').replace('</p>','')
        item['Leasing_contact_name'] = data['contacts'][0]['name']
        item['Leasing_contact_phone'] =data['contacts'][0]['phone']
        item['Leasing_contact_email'] = data['contacts'][0]['email']
        item['Site_Plan_url'] = data['downloads'][0]['link']
        item['URL'] = response.url # self.f1.country_dict.get(item['country'].lower())
        yield item



from scrapy.cmdline import execute
# execute('''scrapy crawl store_469 -a list_id=469'''.split())
