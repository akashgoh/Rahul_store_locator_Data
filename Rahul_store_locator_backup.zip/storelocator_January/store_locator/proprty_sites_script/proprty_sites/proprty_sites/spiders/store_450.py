import hashlib
import re

import scrapy
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func
import datetime

class rd_management(scrapy.Spider):
    name = 'store_450'

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        source_url = link = 'https://www.reddevelopment.com/properties/'
        file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(self.run_date) + '.html'
        yield scrapy.Request(url=link,callback=self.parse,meta={'source_url': source_url,'file_path': file_path})



    def parse(self, response):
        urls = response.xpath('//*[@class="w-post-elm post_image usg_post_image_1 stretched grid_post-image"]/a/@href').extract()
        print(urls)
        for i in urls:
            print('--')
            yield scrapy.Request(url=i,callback=self.Extract)

    def Extract(self,response):
        item = ProprtySitesItem()

        Property_Name = response.xpath('//div[@class="wpb_text_column corporate-landingmat_row1-header-main"]/div/p/text()').extract_first().strip()


        try:
            add1 = str(response.text).split("onclick='return {&quot;address&quot;:&quot;")[1]
            add1 = str(add1).split('United States&quot;,&quot;markers&')[0]
            address = str(add1).split(',')[0]
            city = str(address).split()[-1]
            state = (str(add1).split(',')[-1]).split()[0]
            zip = (str(add1).split(',')[-1]).split()[-1]
        except:
            address = ''
            city = ''
            state = ''
            zip = ''

        try:
            Description = ' '.join(response.xpath('//div[@class="wpb_text_column corporate-landingmat_row2-paragraph"]/div[@class="wpb_wrapper"]/p//text()').extract())
        except Exception as e:
            Description = ''
            print('error in description',e,response.url)
        #
        # if item['Description'] == None:
        #     item['Description'] =''
        # if len(item['Description']) < 10:
        #     item['Description'] =''
        #
        # try:item['Leasing_Contact_Name'] = response.xpath('//*[@class="dark-blue-txt bold-txt text-uppercase fs16"]/text()').extract_first()
        try:
            # item['Leasing_Contact_Name'] = re.findall(r'LEASING CONTACT</h3><div class="w-iconbox-text"><p> (.*?)<br />', response.text) or re.findall(r'LEASING MANAGER</h3><div class="w-iconbox-text"><p>(.*?)<br />', response.text)
            Leasing_Contact_Name = response.xpath('//*[contains(text(),"RETAIL LEASING CONTACT")]/following-sibling::div/p//text()[1]').get()
            if Leasing_Contact_Name == None:
                Leasing_Contact_Name = response.xpath('//*[contains(text(),"LEASING CONTACT")]/following-sibling::div/p//text()[1]').get()

                if Leasing_Contact_Name == None:
                    Leasing_Contact_Name = response.xpath('//*[contains(text(),"SALES & LEASING MANAGER")]/following-sibling::div/p//text()[1]').get()
                    if Leasing_Contact_Name == None:
                        Leasing_Contact_Name = response.xpath('//*[contains(text(),"LEASING CONTACT")]/following-sibling::div/p//text()[1]').get()
                    else:
                        Leasing_Contact_Name = ''
                else:
                    Leasing_Contact_Name = Leasing_Contact_Name
            else:
                Leasing_Contact_Name = Leasing_Contact_Name
        except Exception as e:
            Leasing_Contact_Name = ''
            print('error in name',e,response.url)
        #
        # try:item['Leasing_Contact_Phone'] = ' '.join(response.xpath('//*[@class="col-sm-8"]/text()').extract()).strip()
        try:
            # item['Leasing_Contact_Phone'] = response.xpath('//div[@class="w-iconbox-text"]/p/text()[2]').extract()[1]
            Leasing_Contact_Phone = response.xpath('//*[contains(text(),"RETAIL LEASING CONTACT")]/following-sibling::div/p/a/text()').get()
            if Leasing_Contact_Phone == None:
                Leasing_Contact_Phone = response.xpath('//*[contains(text(),"LEASING CONTACT")]/following-sibling::div/p/a/text()').get()
                if Leasing_Contact_Phone == None:
                    Leasing_Contact_Phone = response.xpath('//*[contains(text(),"SALES & LEASING MANAGER")]/following-sibling::div/p/a/text()').get()
                    if Leasing_Contact_Phone == None:
                        Leasing_Contact_Phone = response.xpath('//*[contains(text(),"LEASING CONTACT")]/following-sibling::div/p/a/text()').get()
                    else:
                        Leasing_Contact_Phone = ''
                else:
                    Leasing_Contact_Phone = Leasing_Contact_Phone
            else:
                Leasing_Contact_Phone = Leasing_Contact_Phone
        except Exception as e:
            Leasing_Contact_Phone = ''
            print('error in phone',e,response.url)
        #

        Leasing_Contact_Email = response.xpath('//*[@class="__cf_email__"]/@data-cfemail').get()
        try:
            r = int(Leasing_Contact_Email[:2], 16)
            email = ''.join([chr(int(Leasing_Contact_Email[i:i + 2], 16) ^ r) for i in range(2, len(Leasing_Contact_Email), 2)])
        except (ValueError):
            email = ''
            pass
        #
        Site_Plan_URL = response.xpath('//*[@class="vc_column-link smooth-scroll"]/@href').extract_first()
        Property_URL = response.url
        #
        # hasstr = (str(item['Property_URL']) + str(item['Property_Name'])).encode('utf8')
        # Hash_id = int(hashlib.md5(hasstr).hexdigest(), 16)
        # item['hash'] = Hash_id
        item['Property_Name'] = Property_Name
        item['Address'] = address
        item['City'] = city
        item['State'] = state
        item['Zip'] = zip
        item['Leasing_Contact_Name'] = Leasing_Contact_Name
        item['Leasing_Contact_Phone'] = Leasing_Contact_Phone
        item['Leasing_Contact_Email'] = email
        item['Site_Plan_URL'] = Site_Plan_URL
        item['Property_URL'] = Property_URL
        item['Description'] = Description
        yield item

from scrapy.cmdline import execute
# execute("scrapy crawl store_450 -a list_id=450".split())
#isme thode loche hote h