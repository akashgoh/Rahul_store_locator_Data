# -*- coding: utf-8 -*-
import re
import scrapy
from scrapy.utils.response import open_in_browser
import logging

import scrapy, json, requests, re
import html2text
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func

import datetime
import html2text


class Bedrin459CrawlerSpider(scrapy.Spider):
    name = 'store_459'
    allowed_domains = ['bedrin.com']
    start_urls = ['https://bedrin.com/properties/']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def parse(self, response):
        ul = response.xpath("//*[contains(text(),'Property Details')]/../..//@href").extract()
        for u in ul:
            if not 'http' in u:
                u = 'https://bedrin.com/' + u
                yield scrapy.Request(url=u, callback=self.parsedata, dont_filter=True)
            yield scrapy.Request(url=u, callback=self.parsedata, dont_filter=True)

    def parsedata(self,response):
        try:
            pname = response.xpath('//*[@class="title"]/text()').extract_first().replace('\xa0','').strip()
        except Exception as e:
            pname = ''
            print(e)

        try:
            add = ' '.join(response.xpath('//div[@class="wpb_text_column wpb_content_element "]//h4//text()').extract()).replace('\xa0',' ').replace('\n','')
            stat = add.split(',')[-1].strip()
            ci = add.split(',')[-2].strip()
            cit = ci.split(' ')[-1].strip()
        except Exception as e:
            add = ''
            stat = ''
            cit = ''
            print(e)

        try:
            dec = ''.join(response.xpath('//*[@class="vc_tta-panel-body"]//p/text()').extract())
        except Exception as e:
            dec = ''
            print(e)

        try:
            brochurl = ''.join(re.findall(r' alt="" srcset="(.*?),',response.text)).strip()
        except Exception as e:
            brochurl = ''
            print(e)

        try:
            # leasing_name = ''.join(re.findall(r'style="text-align: center;"><span class="bodyText">(.*?)<br />',response.text)).strip()
            l1 = response.xpath('//*[contains(text(),"Leasing Contact")]//following-sibling::i/../../../..//div[@class="vc_wp_text wpb_content_element"]//h4[1]//text()[1]').extract_first().strip()
            l2 = ''.join(response.xpath('//*[contains(text(),"Leasing Contact")]//following-sibling::i/../../../..//div[@class="vc_wp_text wpb_content_element"]//h4[1]//text()[2]').extract()).strip()
            leasing_name = str(l1) +' '+str(l2)
        except Exception as e:
            leasing_name = ''
            print(e)

        try:
            # leasing_contact = ''.join(re.findall(r'<a href="tel:(.*?)">',response.text))
            leasing_contact =''.join(response.xpath('//*[contains(text(),"Leasing Contact")]//following-sibling::i/../../../..//div[@class="vc_wp_text wpb_content_element"]//h4[1]//text()[3]').extract()).replace('(','').replace(') ','-').strip()
        except Exception as e:
            leasing_contact = ''
            print(e)


        try:
            # leasing_email = '|'.join(re.findall(r'<a href="mailto:(.*?)">',response.text))
            leasing_email = ''.join(response.xpath('//*[contains(text(),"Leasing Contact")]//following-sibling::i/../../../..//div[@class="vc_wp_text wpb_content_element"]//h4[1]//a//text()[1]').extract())
        except Exception as e:
            leasing_email = ''
            print(e)

        if 'St. George Square – The Triad' in pname:
            zpcode = '27103'
        elif "Oak Hill Plaza – Virginia's Capital" in pname:
            zpcode = '23223'
        elif 'Northwest Centre – The Triad' in pname:
            zpcode = '27455'
        elif 'Killian Hill Center – Atlanta Metro' in pname:
            zpcode = '30039'
        elif 'Olde Towne Plaza – Suburb of St. Louis' in pname:
            zpcode = '63011'
        elif 'Hunt Village – The Triad' in pname:
            zpcode = '27407'
        elif 'Hawthorne Center – Northern New Jersey' in pname:
            zpcode = '07506'
        elif 'Oak Hollow Village – The Triad' in pname:
            zpcode = '27265'
        elif 'Memorial Bend – Atlanta Metro' in pname:
            zpcode = '30083'
        elif 'Golden Gate – The Triad' in pname:
            zpcode = '27405'
        elif 'Garden Square – The Triad' in pname:
            zpcode = '27408'
        elif 'Club Haven – The Triad' in pname:
            zpcode = '27104'
        elif 'Brookhill V – Denver Metro' in pname:
            zpcode = '80021'
        elif '235 EastRidgewoodAvenue – Northern New Jersey' in pname:
            zpcode = '07450'
        elif 'Gate City – The Triad' in pname:
            zpcode = '27403'
        elif 'Caldwell Court – The Triad' in pname:
            zpcode = '27408'
        elif 'Battleground Plaza – The Triad' in pname:
            zpcode = '27410'
        else:
            zpcode = ''


        item = ProprtySitesItem()
        item['PropertyName'] = pname
        item['Address'] = add
        item['City'] = cit
        item['State'] = stat
        item['Zipcode'] = zpcode
        item['GLA'] = ''
        item['BrochureURL'] = brochurl
        item['Description'] = dec
        # item['Contact'] = ''
        item['LeasingContactName1'] = leasing_name
        item['LeasingContactPhone1'] = leasing_contact
        item['LeasingContactEmail1'] = leasing_email
        item['PropertyURL'] = response.url
        yield item

# from scrapy.cmdline import execute
# execute("scrapy crawl store_459 -a list_id=459".split())
