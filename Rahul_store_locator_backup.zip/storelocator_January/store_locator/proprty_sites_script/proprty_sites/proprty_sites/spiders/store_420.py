# -*- coding: utf-8 -*-
import datetime
import scrapy, json, requests, re
import html2text
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func
from scrapy.cmdline import execute

class Store420Spider(scrapy.Spider):
    name = 'store_420'
    allowed_domains = []
    not_export_data = True

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):

        run_date = str(datetime.datetime.today()).split()[0]
        self.f1.set_details(self.list_id, run_date)
        try:
            page = 1
            source_url = link = f'https://www.bayerproperties.com/portfolio/'
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
                self.run_date) + '.html'
            yield scrapy.FormRequest(url=str(link), callback=self.firstlevel,
                                     meta={'source_url': source_url,
                                           'file_path': file_path, 'proxy_type': self.proxy_type, 'page': page})
        except Exception as e:
            print(e)

    def firstlevel(self, response):
        # if not response.url.startswith('file://'):
        #     self.f1.page_save(response.meta['file_path'], response.body)
        try:
            source_url = response.meta['source_url']
            file_path = response.meta['file_path']
            proxy_type = response.meta['proxy_type']
            links = response.xpath('//div[@class="portfolio-grid-item text-center"]/a/@href').extract()
            city_state = response.xpath(
                '//div[@class="portfolio-grid-item text-center"]//div[@class="sub-heading text-uppercase"]/text()').extract()
            for link, city_state in zip(links, city_state):
                link = link
                city_state = city_state
                page = link.replace('https://www.bayerproperties.com/portfolio/', '').replace('/', '').strip()
                file_path = self.f1.html_data_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
                    self.run_date) + '_' + str(page) + '.html'
                yield scrapy.FormRequest(url=link, callback=self.get_store_list,
                                         meta={'source_url': source_url, 'file_path': file_path,
                                               'proxy_type': proxy_type, 'city_state': city_state})
        except Exception as e:
            print("firstlevel", e, response.url)

    # Get data from the response
    def get_store_list(self, response):
        if not response.url.startswith('file://'):
            self.f1.page_save(response.meta['file_path'], response.body)
        try:
            try:
                try:
                    Property_Name = re.findall('<title>(.*?)- Projects - Bayer Properties</title>', response.text)[0].strip()
                except Exception as e:
                    print("Property_Name", e, response.url)

                try:
                    city = response.meta['city_state'].split(',')[0].strip()
                    state = response.meta['city_state'].split(',')[1].strip()
                except Exception as e:
                    print("city_state", e, response.url)

                try:
                    addres_data = response.xpath('//*[contains(text(),"Location")]/../div[2]/text()').extract_first()
                    if ":" in addres_data:
                        address = addres_data.split(':')[1].strip()
                    else:
                        address = addres_data
                        if address == response.meta['city_state']:
                            address = ''
                except Exception as e:
                    print("Address", e, response.url)

                try:
                    Description = response.xpath('//div[@class="container-small-md"]//p/text()').extract_first(
                        default='').strip()
                except Exception as e:
                    print("Description", e, response.url)

                try:
                    Plan_URL1 = response.xpath('//div[@id="pitchbook-desktop"]/a/@href').extract_first(
                        default='').strip()
                    if Plan_URL1!="":
                        Plan_URL=response.url + Plan_URL1
                    print(Plan_URL)
                except Exception as e:
                    Plan_URL=""
                    print("Plan_URL", e, response.url)

                try:
                    GLA = response.xpath('//*[contains(text(),"Size")]/../div[2]/text()').extract_first(
                        default='').strip()
                except Exception as e:
                    print("GLA", e, response.url)

                try:
                    Leasing_data = response.xpath('//*[contains(text(),"Leasing")]/../div[2]//text()').extract()
                    Leasing_Contact = Leasing_data[0].strip()
                    Leasing_Email = Leasing_data[1].strip()
                    Leasing_Phone = Leasing_data[2].strip()
                except Exception as e:
                    Leasing_Contact = ''
                    Leasing_Email = ''
                    Leasing_Phone = ''


                item = ProprtySitesItem()
                item['Property_Name'] = Property_Name
                item['Address'] = address
                item['City'] = city
                item['State'] = state
                item['Description'] = Description
                item['GLA'] = GLA
                item['Leasing_Contact'] = Leasing_Contact
                item['Leasing_Phone'] = Leasing_Phone
                item['Leasing_Email'] = Leasing_Email
                item['Property_URL'] =response.url
                item['Plan_URL'] = Plan_URL
                yield item
            except Exception as e:
                print(e)

        except Exception as e:
            print(e)

    def response_html_path(self, request):
        return request.meta['fpath']

# execute("scrapy crawl store_420 -a list_id=420".split())



