import logging
import os
import re

import datetime
import scrapy, json, requests, re
import html2text
from scrapy.cmdline import execute

from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func

class Store721Spider(scrapy.Spider):
    name = 'store_731'
    allowed_domains = []


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        try:
            source_url = link = 'https://www.mack-cali.com/portfolio/search/office/all/all'
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(self.run_date) + '.html'
            yield scrapy.FormRequest(url=str(link), callback=self.prop_link,meta={'source_url': source_url,'file_path': file_path})

        except Exception as e:
            logging.log(logging.ERROR, e)

    def prop_link(self,response):
        links = re.findall(r';propertyUrl&quot;:&quot;(.*?)&quot;,',response.text)
        for link in links:
            url = str(link).replace('\\','')
            # print(url)
            yield scrapy.FormRequest(url=url, callback=self.prop_detail)

    def prop_detail(self,response):
        # print('final url........',response.url)
        try:
            property_name = response.xpath('//div[@class="container"]/h1/text()').get()
        except:
            print('prob in property_name..')
        try:
            address = response.xpath('//div[@class="container"]/h1/text()').get()
        except:
            print('prob in address..')
        try:
            cs = response.xpath('//span[@class="subtitle"]/text()').get()
            city = cs.split(',')[0]
            state = cs.split(',')[-1]
        except:
            print('prob in CS....')
        try:
            GLA = response.xpath('//*[contains(text(),"Size")]/../td[2]/text()').get()
            if '-' in GLA:
                GLA = str(GLA.split('-')[-1]).replace(',', '').replace('SF','').strip()
            else:
                GLA = str(GLA).replace(',', '').replace('SF','').strip()
        except:
            print('prob in GLA.....')
        try:
            desc = ' '.join(response.xpath('//div[@class="content"]/div/text()').getall())
        except:
            print('prob in Desc....')
        try:
            office_market = response.xpath('//*[contains(text(),"Office Market")]/../td[2]/a/text()').get()
        except:
            print('prob in office market....')
        try:
            stories = response.xpath('//*[contains(text(),"Stories")]/../td[2]/text()').get()
        except:
            print('prob in stories')

        item = ProprtySitesItem()
        item['Property_name'] = property_name
        item['Address'] = address
        item['City'] = city
        item['State'] = state
        item['GLA'] = GLA
        item['Description'] = desc.replace('\xa0','')
        item['LeasingContact'] = 'Chris Hanenberg'
        item['LeasingContactPhone'] = '7325901034'
        item['LeasingContactEmail'] = 'chanenberg@mack-cali.com'
        item['office_market'] = office_market
        item['stories'] = stories
        item['PropertyURL'] = response.url
        yield item

# execute('''scrapy crawl store_731 -a list_id=731'''.split())



