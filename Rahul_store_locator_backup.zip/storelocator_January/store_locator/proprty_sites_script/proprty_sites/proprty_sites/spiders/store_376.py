import logging
import os
import re

import datetime
import scrapy, json, requests, re
import html2text
from scrapy.cmdline import execute

from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func

class Store721Spider(scrapy.Spider):
    name = 'store_376'
    allowed_domains = []


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        try:
            source_url = link = 'https://www.regencycenters.com/properties'

            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(self.run_date) + '.html'
            yield scrapy.FormRequest(url=str(link), callback=self.prop_link,meta={'source_url': source_url,'file_path': file_path})

        except Exception as e:
            logging.log(logging.ERROR, e)

    def prop_link(self,response):
        import requests

        url = "https://www.regencycenters.com/api/GetCenters?_=1602911743478"

        payload = {}
        headers = {
            'alt-svc': 'clear',
            'cache-control': 'no-cache',
            'content-encoding': 'br',
            'content-type': 'application/json; charset=utf-8',
            'date': 'Sat, 17 Oct 2020 05:15:36 GMT',
            'expires': '-1',
            'pragma': 'no-cache',
            'server': 'bws/1.0',
            'status': '200',
            'via': '1.1 google',
            'x-be-pop': 'DSM-2-203',
            'x-robots-tag': 'none'
        }

        response = requests.request("GET", url, headers=headers, data=payload)
        res1 = response.text
        # print(res1)
        # data = response.text
        data1 = json.loads(res1)
        data_len = len(data1["centersList"])
        for i in range(0,data_len):
            Property_Name = data1["centersList"][i]["BusinessUnitName"]
            Add = data1["centersList"][i]["BusinessUnitAddress1"]
            csz = data1["centersList"][i]["BusinessUnitAddress2"]
            city = str(csz).split(',')[0]
            state = str(csz).split(',')[-1].split(' ')[1]
            zip = str(csz).split(',')[-1].split(' ')[-1]
            GLA = data1["centersList"][i]["BusinessUnitGLA"]
            Lat = data1["centersList"][i]["Latitude"]
            Long = data1["centersList"][i]["Longitude"]
            detail_link = data1["centersList"][i]["DetailPageLink"]
            link = 'https://www.regencycenters.com' + str(detail_link)
            yield scrapy.FormRequest(url=str(link), callback=self.prop_data,meta={'Property_Name':Property_Name,'Add':Add,'city':city,'state':state,'zip':zip,'GLA':GLA,'Lat':Lat,'Long':Long})

    def prop_data(self,response):
        try:
            try:
                Key_Retailers = response.xpath('//strong[contains(text(),"Key Retailers:")]/../text()').get(default='')
            except:
                Key_Retailers = ''
                print('key retailer not found..')

            try:
                Market = response.xpath('//strong[contains(text(),"Market:")]/../text()[2]').get(default='').replace("\r\n","")
            except:
                Market = ''
                print('market not found...')

            try:
                Leasing_contact = response.xpath('//h4[@id="leasingAgentInfo"]/a/text()').get()
                if Leasing_contact != None:
                    Leasing_contact = Leasing_contact
                else:
                    Leasing_contact = ''
            except Exception as e:
                print('error in Leasing contact..',e,response.url)

            try:
                Leasing_phone = str(response.xpath('//a[@class="phone"]/@href').get()).replace('tel:','').strip()
                if Leasing_phone != None:
                    Leasing_phone = Leasing_phone
                else:
                    Leasing_phone = ''
            except Exception as e:
                print('error in Leasing contact..', e, response.url)

            try:
                Leasing_email = response.xpath('//a[@class="envelope HubSpotEventLeasingContact"]/@title').get()
                if Leasing_email != None:
                    Leasing_email = Leasing_email
                else:
                    Leasing_email = ''
            except Exception as e:
                print('error in Leasing contact..', e, response.url)

            try:
                Brochure_url = response.xpath('//a[@id="propertyBrochureLink"]/@href').get()
                if Brochure_url != None:
                    Brochure_url = Brochure_url
                else:
                    Brochure_url = ''
            except Exception as e:
                print('error in Leasing contact..', e, response.url)
            # plan = response.xpath('//div[@class="large-8 columns"]/div/div[@class="panzoom hasSVG"]/script').get()
            # site_plan = str(plan).split("loadURL: '")[-1].split("',")[0]

            try:
                site_plan = re.findall(r"loadURL: '(.*?)', // External",response.text)[0]
                if site_plan != []:
                    site_plan = site_plan
                else:
                    site_plan = ''
            except Exception as e:
                print('error in Leasing contact..',e,response.url)

            try:
                VPD = response.xpath('//strong[contains(text(),"Vehicles Per Day:")]/../text()[3]').get(default='').replace("\r\n","")
            except:
                VPD = ''

            item = ProprtySitesItem()
            item['Property_Name'] = response.meta['Property_Name']
            item['Address'] = response.meta['Add']
            item['City'] = response.meta['city']
            item['State'] = response.meta['state']
            item['Zip'] = response.meta['zip']
            item['GLA'] = response.meta['GLA']
            item['Latitude'] = response.meta['Lat']
            item['Longitude'] = response.meta['Long']
            item['Leasing_contact'] = Leasing_contact
            item['Leasing_contact_phone'] = Leasing_phone
            item['Leasing_contact_email'] = Leasing_email
            item['Brochure_url'] = Brochure_url
            item['Site_plan_url'] = site_plan
            item['Key_Retailers'] = Key_Retailers
            item['Market'] = Market
            item['VPD'] = str(VPD).replace(',','')
            item['Source_url'] = response.url

            yield item
        except Exception as e:
            print(e,response.url)





# execute('''scrapy crawl store_376 -a list_id=376'''.split())



