# -*- coding: utf-8 -*-
import datetime
import json
import re

import requests
import scrapy
from scrapy.http import HtmlResponse

from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func


class Store303Spider(scrapy.Spider):
    name = 'store_303'
    allowed_domains = []
    start_urls = ['http://astonprop.propertycapsule.com/property/output/find/search']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def parse(self, response):
        links = response.xpath('//a[@class="property-detail"]/@href').getall()
        for link in links:
            yield scrapy.Request(url=link, callback=self.parse_data)
            # yield scrapy.Request(url='http://astonprop.propertycapsule.com/properties/berewicktowncenter', callback=self.parse_data)


    def parse_data(self, response):
        try:text = re.findall('window\.property\s+\=\s+(.*);', response.text)[0]
        except Exception as e:print(e)

        json_data = json.loads(text)

        try:Property_Name = json_data['name']
        except Exception as e:print(e)

        try:Address = json_data['address']
        except Exception as e:print(e)

        try:City = json_data['city']
        except Exception as e:print(e)

        try:State = json_data['state']
        except Exception as e:print(e)

        try:zip_code = json_data['zip']
        except:zip_code = ''

        try:County = json_data['county']
        except:County = ''

        try:Type = json_data['type']
        except:Type = ''

        try:Contact = response.xpath('//span[@class="p-name"]/text()').get(default='').strip()
        except Exception as e:print(e)

        try:Total_SF = GLA = re.findall(r'Total SF: <strong>(.*?)</strong>', response.text)[0]
        except:Total_SF = GLA = ''

        try:Leasing_Phone = response.xpath('//strong[@class="p-tel p-tel-office"]/text()').get(default='').strip()
        except Exception as e:print(e)

        try:Leasing_Mobile = response.xpath('//strong[@class="p-tel p-tel-mobile"]/text()').get(default='').strip()
        except Exception as e:print(e)

        try:Leasing_Fax = response.xpath('//strong[@class="p-tel p-tel-fax"]/text()').get(default='').strip()
        except Exception as e:print(e)

        try:json_data2 = json.loads(re.findall(r'window.agents = \[(.*?)\]', response.text)[0])
        except Exception as e:print(e)

        try:Leasing_Email = json_data2['email']
        except:Leasing_Email = 'jmsmith@astonprop.com'

        try:
            site_plan = response.xpath('//iframe[@id="jsviewer"]/@src').get(default='').strip()
            res = requests.get(url=site_plan)
            response1 = HtmlResponse(url=res.url, body=res.content)
            site_plan_url = re.findall(r'mapPlanImg\\":\\"(.*?)\\"', response1.text)[0].replace('\\', '').strip()
        except:
            site_plan_url = ''

        item = ProprtySitesItem()
        item['Property_Name'] = Property_Name
        item['Address'] = Address
        item['City'] = City
        item['State'] = State
        item['zip_code'] = zip_code
        item['County'] = County
        item['Type'] = Type
        item['Contact'] = Contact
        item['Total_SF'] = Total_SF
        item['GLA'] = GLA
        item['Leasing_Phone'] = Leasing_Phone
        item['Leasing_Mobile'] = Leasing_Mobile
        item['Leasing_Fax'] = Leasing_Fax
        item['Leasing_Email'] = Leasing_Email
        item['Site_Plan_URL'] = site_plan_url
        item['URL'] = response.url
        yield item


# from scrapy.cmdline import execute
# execute('scrapy crawl store_303 -a list_id=303'.split())
