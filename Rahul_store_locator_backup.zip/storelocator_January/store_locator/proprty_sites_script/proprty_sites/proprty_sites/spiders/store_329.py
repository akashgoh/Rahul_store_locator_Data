import datetime
# -*- coding: utf-8 -*-
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
import html2text
h = html2text.HTML2Text()
import datetime
import scrapy, json, requests, re
import html2text
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func


class WeingartenrealtySpider(scrapy.Spider):
    name = 'store_329'
    allowed_domains = []
    start_urls = ['http://weingartenrealty.propertycapsule.com/cre/commercial-real-estate-listings-portfolio']

    FEED_EXPORT_FIELDS = ["Property_Name", "Intersection", "City", "State", "Zip_code", "Type", "Total_SF",
                          "Metro_Area", "Leasing_Agent", "Leasing_Agent_Phone", "Leasing_Agent_Email", "DRE_Licence",
                          "Latitude", "Longitude", "Site_plan_URL", "URL"]


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def parse(self, response):

        # for i in re.findall(r"<a class='property-detail'href='(.*?)'>", response.text):
        #     prop_url = i.replace('\\/', '/')
        #     yield scrapy.Request(url=prop_url,callback=self.process_step)

        url = response.xpath('//div[@class="card-wrapper"]/ul/li/a/@href').extract()
        for link in url:
            yield scrapy.Request(url=link, callback=self.process_step)

    def process_step(self, response):
        # prop_data = json.loads(re.findall(r"window.property = (.*?);\n", response.text)[0])
        # agent_data = json.loads(re.findall(r"window.agents = (.*?);\n", response.text)[0])

        # 'Property_Name,Intersection,locale,address,City,State,Zip_code,Type,Total_SF,Metro_Area,Leasing_Agent,Leasing_Agent_Phone,Leasing_Agent_Email,DRE_Licence,Latitude,Longitude,Site_plan_URL,URL'


        #--------------------  New Code -----------------------------------------------------------#
        #============================================================================================#
        #---------------------------------------------------------------------------------------------#

        item = ProprtySitesItem()
        try:
            name = response.xpath('//div[@class="et_pb_text_inner"]/h1/text()').extract_first()
            print(name)
        except Exception as e:
            print(e)
            name=''

        try:
            lat_lng = response.xpath('//td[@class="text-left"]/a/text()').extract_first()
            print(lat_lng)
        except Exception as e:
            print(e)
            lat_lng = ''

        try:
            lat = lat_lng.split(",")[0]
            long = lat_lng.split(",")[1]
            print(lat,long)
        except Exception as e:
            print(e)
            lat,long ='',''

        try:
            street = response.xpath('//div[@class="et_pb_text_inner"]/h1/following-sibling::p/text()[1]').extract_first()
            print(street)
        except Exception as e:
            print(e)
            street=''

        try:
            add2 = response.xpath('//div[@class="et_pb_text_inner"]/h1/following-sibling::p/text()[2]').extract_first().split(',')
            print(add2)
        except Exception as e:
            print(e)
            add2=''

        try:
            city = add2[0]
            print(city)
        except Exception as e:
            print(e)
            city=''

        try:
            state = add2[1].strip().split(" ")[0]
            print(state)
        except Exception as e:
            print(e)
            state=''

        try:
            zip = add2[1].strip().split(" ")[1]
            print(zip)
        except Exception as e:
            print(e)
            zip=''

        try:
            gla = response.xpath("//*[contains(text(),'GLA')]/following-sibling::td/text()").extract_first()
            print(gla)
        except Exception as e:
            print(e)
            gla=''

        try:
            metro_area = response.xpath("//*[contains(text(),'METRO AREA')]/following-sibling::td/text()").extract_first()
            print(metro_area)
        except Exception as e:
            print(e)
            metro_area=''

        try:
            leasing_name = response.xpath("//*[contains(text(),'Leasing Agent')]/../following-sibling::li/text()").extract_first()
            print(leasing_name)
        except Exception as e:
            print(e)
            leasing_name=''

        try:
            # leasing_phone = response.xpath("//*[contains(@href,'tel')]/../li[3]/a/text()").extract_first().strip()
            # leasing_phone = response.xpath("//*[contains(@href,'tel')]/../li[3]/a/@href").extract_first()
            # leasing_phone  = leasing_phone.split(":")[1].strip()
            leasing_phone = re.findall(r'<a href="tel:(.*?)">',response.text)[0]
            print(leasing_phone)
        except Exception as e:
            print(e)
            leasing_phone = ''

        try:
            leasing_email = response.xpath("//*[contains(text(),'Contacts')]/../ul/a[2]/li/text()").extract_first().strip()
            print(leasing_email)
        except Exception as e:
            print(e)
            leasing_email = ''

        try:
            id = "".join(re.findall(r'var sitemap = "(.*?)"',response.text))
            print(id)
        except Exception as e:
            print(e)
            id=''
        try:
            # site_plan = response.xpath('//div[@class="plan-widget__map-image"]//@src').extract()
            site_plan = f'https://weingartenrealty.propertycapsule.com/property/capsule_data/271/property/sitemap_image/{id}.png'
            print(site_plan)
        except Exception as e:
            print(e)
            site_plan=''


        # item['Property_Name'] = prop_data['name']
        # item['Intersection'] = prop_data['locale'] + ", " + prop_data['address'] if prop_data['locale'] else prop_data[
        #     'address']
        # item['City'] = prop_data['city']
        # item['State'] = prop_data['state']
        # item['Zip_code'] = prop_data['zip']
        # item['Type'] = prop_data['type']
        # item['Total_SF'] = prop_data['gla']
        # item['Metro_Area'] = prop_data['metroArea']
        # item['Leasing_Agent'] = ""
        # item['Leasing_Agent_Phone'] = ""
        # item['Leasing_Agent_Email'] = ""
        # item['DRE_Licence'] = ""
        # for agent in agent_data:
        #     if agent['role'] == "Leasing Agent":
        #         item['Leasing_Agent'] = agent['name']
        #         item['Leasing_Agent_Phone'] = agent['phone']
        #         item['Leasing_Agent_Email'] = agent['email']
        #         if "DRE License #" in response.text:
        #             item['DRE_Licence'] = agent['address'].replace('DRE License # ', '')
        #
        # item['Latitude'] = prop_data['lat']
        # item['Longitude'] = prop_data['lng']
        # # URL = response.url
        # item['Site_plan_URL'] = response.xpath("//html").re('src="(.*?)" width="90%" alt="Static Map Legend"')[0]
        # item['URL'] = response.url
        # yield item



        #========================= NEW code ===========================================================================#
        item['Property_Name'] = name
        item['Intersection'] = street
        item['City'] = city
        item['State'] = state
        item['Zip_code'] = zip
        item['Type'] = ''
        item['Total_SF'] = gla
        item['Metro_Area'] = metro_area
        item['Leasing_Agent'] = leasing_name
        item['Leasing_Agent_Phone'] = leasing_phone
        item['Leasing_Agent_Email'] = leasing_email
        item['Latitude'] = ''
        item['Longitude'] = ''
        item['Site_plan_URL'] = site_plan
        item['URL'] = response.url
        yield item


# 'City,DRE_Licence,ID,Intersection,Latitude,Leasing_Agent,Leasing_Agent_Email,Leasing_Agent_Phone,Longitude,Metro_Area,Property_Name,,State,Total_SF,Type,URL,Zip_code,Site_plan_URL'


# name = "Weingarten_Realty"
# today = datetime.datetime.now().strftime("%m-%d-%Y")
# execute(f'scrapy crawl weingartenrealty -o {name}_{today}.csv'.split())



# execute("scrapy crawl store_329 -a list_id=329".split())


