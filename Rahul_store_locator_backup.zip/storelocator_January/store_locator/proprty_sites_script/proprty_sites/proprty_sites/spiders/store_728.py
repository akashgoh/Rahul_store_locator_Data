import logging
import os
import re

import datetime
import scrapy, json, requests, re
import html2text
from scrapy.cmdline import execute

from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func

class Store721Spider(scrapy.Spider):
    name = 'store_728'
    allowed_domains = []


    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        try:
            source_url = link = 'https://janourarealty.com/properties/'
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(self.run_date) + '.html'
            yield scrapy.FormRequest(url=str(link), callback=self.prop_link,meta={'source_url': source_url,'file_path': file_path})

        except Exception as e:
            logging.log(logging.ERROR, e)

    def prop_link(self,response):
        links = response.xpath('//div[@class="col-md-3 col-sm-4 prop-single-wrap"]/a/@href').getall()
        for link in links:
            # print(link)
            yield scrapy.FormRequest(url=str(link), callback=self.parse)

    def parse(self,response):
        # print(response.url)
        property_name = response.xpath('//div[@class="black-full-overlay"]/h2/text()').get()
        address = response.xpath('//div[@class="address-property"]/text()').get()
        cs = response.xpath('//div[@class="sub-title"]/text()').get()
        city = cs.split(',')[0]
        state = cs.split(',')[-1]
        # zip_code = ''
        # lat = re.findall(r'data-latitude="(.*?)"',response.text)[0]
        # long = re.findall(r'data-longitude="(.*?)"',response.text)[0]
        GLA = re.findall(r'SQUARE FOOTAGE: (.*?)</td>',response.text)[0]
        try:
            BrochureURL = response.xpath('//a[@class="tenants-icon broch"]/@href').get()
        except:
            BrochureURL = ''

        try:
            SitePlanURL = response.xpath('//a[@class="fancybox"]/@href').get()
        except:
            SitePlanURL = ''

        try:
            desc = response.xpath('//div[@class="col-md-12 col-sm-12 main-inner-cnt"]//span/text()').get()
        except:
            desc = ''

        item = ProprtySitesItem()


        item['Property_name'] = property_name
        item['Address'] = address
        item['City'] = city
        item['State'] = state
        # item['ZIP'] = zip_code
        item['GLA'] = GLA.replace(',', '')
        item['Description'] = desc
        item['LeasingContact'] = 'ALEX KARAS'
        item['LeasingContactPhone'] = '9543043900'
        item['LeasingContactEmail'] = 'akaras@janourarealty.com'
        item['BrochureURL'] = BrochureURL
        item['SitePlanURL'] = SitePlanURL
        # item['Latitude'] = lat
        # item['Longitude'] = long
        # item['country'] = item['country_code'] = 'US'
        item['PropertyURL'] = response.url

        yield item

# execute('''scrapy crawl store_728 -a list_id=728'''.split())



