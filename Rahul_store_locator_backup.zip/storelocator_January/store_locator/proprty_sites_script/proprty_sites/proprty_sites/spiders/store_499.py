import json
import re
import scrapy
import datetime
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func


class Store499Spider(scrapy.Spider):
    name = "store_499"
    allowed_domains = []
    start_urls = ['http://whlr.propertycapsule.com/property/output/find/search/cid:1/']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def parse(self, response):
        data = re.findall(r'window.uniqueSpaces = (.*?);\s+window.cid = 1;', response.text, re.DOTALL)
        if len(data) == 1:
            data_json = json.loads(data[0])
            for property in data_json:
                p_name = property['name']
                p_name = re.sub(r'[I]','i', p_name)
                p_name = re.sub(r'[\s\-\.]','', p_name)
                link = f"http://whlr.propertycapsule.com/properties/{p_name}"
                header = {
                    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
                    "Accept-Encoding": "gzip, deflate",
                    "Accept-Language": "en-US,en;q=0.9",
                    "Host": "whlr.propertycapsule.com",
                    "Referer": link,
                    "Upgrade-Insecure-Requests": "1",
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36"
                }
                yield scrapy.Request(url=link, callback=self.get_data, headers=header)

    def get_data(self, response):
        if 'property/output/find/search/text:' in response.url:
            link1 = response.url.replace("property/output/find/search/text:","properties/")
            if 'TuckernuckCommons' in link1:
                link1 = link1.replace('TuckernuckCommons','tjmaxx')
            header1 = {
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
                "Accept-Encoding": "gzip, deflate",
                "Accept-Language": "en-US,en;q=0.9",
                "Host": "whlr.propertycapsule.com",
                "Referer": link1,
                "Upgrade-Insecure-Requests": "1",
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36"
            }
            yield scrapy.Request(url=link1, callback=self.get_data, headers=header1)
        else:
            text1 = re.findall(r'window.property = (.*?);\s+window.agents =', response.text, re.DOTALL)
            if len(text1) == 1:
                data_json = json.loads(text1[0])
                try:
                    Property_Name = data_json['name']
                except Exception as e:
                    Property_Name = ''
                    print("Property_Name " + str(e))

                Address = data_json['address']
                City = data_json['city']
                State = data_json['state']
                Zip_code = data_json['zip']
                GLA = data_json['gla']
            try:
                des_list = []
                Description = response.xpath('///*[@id="propcap-overview"]//li/text()').extract()
                for des in Description:
                    des = re.sub(r'[\t\r\n]','',des)
                    if des != '':
                        des_list.append(des)
                Description = ','.join(des_list)
            except Exception as e:
                print(e)
                Description = ''
            agent = re.findall(r'window.agents = (.*?);\s+window.', response.text, re.DOTALL)
            if len(agent) == 1:
                agent_json = json.loads(agent[0])
                Leasing_Contact = agent_json[0]['name']
                Leasing_Contact_Phone = agent_json[0]['phone']
                Leasing_Contact_Email = agent_json[0]['email']

            try:
                Site_Plan_URL = re.findall(r'</h4><img src="(.*?)" width=', response.text, re.DOTALL)
                if len(Site_Plan_URL) == 1:
                    Site_Plan_URL = Site_Plan_URL[0]
                else:
                    Site_Plan_URL = ''
            except Exception as e:
                print(e)
                Site_Plan_URL = ''
            try:
                Property_URL = response.url
            except Exception as e:
                print(e)
                Property_URL = ''
            try:
                item = ProprtySitesItem()
                item['Property_Name'] = Property_Name
                item['Address'] = Address
                item['City'] = City
                item['State'] = State
                item['ZIP'] = Zip_code
                item['GLA'] = GLA
                item['Description'] = Description
                item['Leasing_Contact'] = Leasing_Contact
                item['Leasing_Contact_Phone'] = Leasing_Contact_Phone
                item['Leasing_Contact_Email'] = Leasing_Contact_Email
                item['Site_Plan_URL'] = Site_Plan_URL
                item['Property_URL'] = Property_URL
                yield item
            except Exception as e:
                print(f"not insert {response.url}" + str(e))


from scrapy.cmdline import execute
# execute("scrapy crawl store_499 -a list_id=499".split())