import re
import pgeocode
import scrapy, os, logging, hashlib
import requests, json
from scrapy.http import HtmlResponse
from scrapy.cmdline import execute
from selenium import webdriver
from selenium.webdriver.firefox.options import Options
# from store_locators.items import StoreLocatorsItem
# from store_locators.spiders.common_functions import Func
import datetime
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func



class USAARealEstateSpider(scrapy.Spider):
    name = 'usaa_real_estate'
    allowed_domains = []

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)


    def start_requests(self):
        try:
            page = 1
            source_url = link = f'https://www.usrealco.com/wp-json/properties/all-posts?page={page}'
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(self.run_date) + '.html'
            yield scrapy.FormRequest(url=str(link), callback=self.firstlevel,
                                     meta={'source_url': source_url,
                                           'file_path': file_path, 'proxy_type': self.proxy_type, 'page': page})
        except Exception as e:
            logging.log(logging.ERROR, e)

    def firstlevel(self, response):
        try:
            source_url = response.meta['source_url']
            file_path = response.meta['file_path']
            proxy_type = response.meta['proxy_type']
            store_data = json.loads(response.text)
            if len(store_data) > 0:
                for i in range(len(store_data)):
                    store_code = store_data[i]['id']
                    link = re.findall(r'href=\'(.*?)\'', store_data[i]['content'])[0]
                    yield scrapy.FormRequest(url=link, callback=self.get_store_list,
                                             meta={'source_url': source_url, 'file_path': file_path,'proxy_type': proxy_type, 'store_code': store_code})

                page = response.meta['page'] + 1
                yield scrapy.Request(url=f'https://www.usrealco.com/wp-json/properties/all-posts?page={page}', callback=self.firstlevel,
                                         meta={'source_url': source_url,
                                               'file_path': file_path, 'proxy_type': self.proxy_type, 'page': page})
            else:
                print('No data..')


        except Exception as e:
            print("firstlevel", e, response.url)

    # Get data from the response
    def get_store_list(self, response):
        try:
            try:
                try:
                    Property_Name = response.xpath('//*[@class="property_details-info"]/h1/text()').extract_first(default='')
                except Exception as e:
                    print("store_name", e, response.url)

                try:
                    addres_data = response.xpath('//*[contains(text(),"Location details")]/../following-sibling::p/text()|//*[contains(text(),"LOCATION DETAILS")]/../following-sibling::p/text()|//*[contains(text(),"Location Details")]/../following-sibling::p/text()').extract()
                    address = addres_data[0]
                    state = addres_data[-1].split(' ')[-2]
                    zip_code = addres_data[-1].split(' ')[-1]
                    city = addres_data[-1].replace(state, '').replace(zip_code, '').strip()
                except Exception as e:
                    print("address", e, response.url)

                try:
                    Asset = response.xpath('normalize-space(//*[@class="property_details-asset"]/text())').extract_first(default='')
                except Exception as e:
                    print(e)

                try:
                    Strategy = response.xpath('normalize-space(//*[@class="property_details-strategy"]/text())').extract_first(default='')
                except Exception as e:
                    print(e)

                try:
                    Type = response.xpath('normalize-space(//*[@class="property_details-type"]/text())').extract_first(default='')
                except Exception as e:
                    print(e)

                try:
                    SQFT = response.xpath('normalize-space(//*[@class="property_details-square_feet"]/text())').extract_first(default='')
                except Exception as e:
                    print(e)

                URL = response.url
                try:
                    store_hash_id = bytes(f"{Type} {Property_Name} {address} {state} {city} {zip_code} {Asset} {Strategy} {SQFT} {URL}", encoding='utf-8')
                    store_hash_id = int(hashlib.md5(store_hash_id).hexdigest(), 16) % (10 ** 16)
                except Exception as e:
                    print(e)


                item = ProprtySitesItem()
                item['Property_Name'] = Property_Name
                item['Address'] = address
                item['City'] = city
                item['State'] = state
                item['zip_code'] = zip_code
                item['Asset'] = Asset
                item['Strategy'] = Strategy
                item['Type'] = Type
                item['SQFT'] = SQFT
                item['URL'] = URL
                yield item

            except Exception as e:
                print(e)

        except Exception as e:
            logging.log(logging.ERROR, e)

    def response_html_path(self, request):
        return request.meta['fpath']


# execute('''scrapy crawl usaa_real_estate -a list_id=326 -a proxy_type=luminaty'''.split())