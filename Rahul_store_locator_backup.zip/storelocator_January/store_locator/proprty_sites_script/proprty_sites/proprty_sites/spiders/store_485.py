# -*- coding: utf-8 -*-
import datetime
import json
from pprint import pprint

import requests
import scrapy
from scrapy.cmdline import execute
from scrapy.http import HtmlResponse

from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func


class RegencypropSpider(scrapy.Spider):
    name = 'store_485'
    allowed_domains = ['regency-prop.com']
    start_urls = ['https://regency-prop.com/properties.json']
    custom_settings = {
        "FEED_EXPORT_FIELDS": ["Property Name", "Address", "City", "State", "Zip", "GLA", "Leasing Contact Name",
                               "Leasing Contact Phone", "Leasing Contact Email", "Property Manager Name",
                               "Property manager phone", "Property manager email", "Site Plan URL", "Property URL"]
    }

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def parse(self, response):
        for data in json.loads(response.body):
            address = data["address"].split(", ")
            response_prop = requests.get(data["url"])
            response_prop = HtmlResponse(body=response_prop.content, url="")

            item = ProprtySitesItem()
            item["Property_Name"] = data["name"]
            item["Address"] = address[0]
            item["City"] = address[1]
            item["State"] = address[2].split()[0].strip()
            item["Zip"] = address[2].split()[1].strip()
            item["GLA"] = data["sqft"].replace(",", "")
            item["Leasing_Contact_Name"] = data["agent"]
            item["Leasing_Contact_Phone"] = response_prop.xpath('//*[@id="agent-name"]//following-sibling::nobr/text()').get('')
            # item["Leasing Contact Phone"] = response_prop.xpath('//*[@id="agent-name"]//following-sibling::nobr/text()').get('')
            item["Leasing_Contact_Email"] = response_prop.xpath('//*[@id="agent-email"]//text()').get('')
            item["Property_Manager_Name"] = data["manager"]
            item["Property_manager_phone"] = response_prop.xpath('//*[@id="mgr"]//nobr/text()').get('')
            item["Property_manager_email"] = response_prop.xpath('//*[@id="mgr"]//a/text()').get('')
            item["Site_Plan_URL"] = response_prop.xpath('//*[contains(@alt, "Site Plan")]/@src').get('')
            item["Property_URL"] = data["url"]
            print(item)
            yield item


name = "regency_properties"
today = datetime.datetime.now().strftime("%m-%d-%Y")
# execute("scrapy crawl store_485 -a list_id=485".split())
