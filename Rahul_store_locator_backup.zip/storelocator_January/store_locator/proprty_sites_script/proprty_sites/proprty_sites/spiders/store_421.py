# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
# -*- coding: utf-8 -*-
import datetime
import scrapy, json, requests, re
import html2text
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func
from scrapy.cmdline import execute

class Store421Spider(scrapy.Spider):
    name = 'store_421'
    allowed_domains = []
    not_export_data = True

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)


    def start_requests(self):
        try:
            page = 1
            source_url = link = f'http://www.benderson.com/prop/propResults.aspx'
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
                self.run_date) + '.html'
            yield scrapy.FormRequest(url=str(link), callback=self.firstlevel,
                                     meta={'source_url': source_url,
                                           'file_path': file_path, 'proxy_type': self.proxy_type, 'page': page})
        except Exception as e:
            print(e)

    def firstlevel(self, response):
        page = 1
        source_url = response.meta['source_url']
        file_path = response.meta['file_path']
        proxy_type = response.meta['proxy_type']
        if not response.url.startswith('file://'):
            self.f1.page_save(response.meta['file_path'], response.body)

        totalcount = response.xpath('//div[@class="rgWrap rgInfoPart"]//strong[3]/text()').extract_first().strip()
        ViewState = response.xpath('//*[@id="__VIEWSTATE"]/@value').extract_first().strip()
        ViewState = ViewState.replace("/", "%2F")
        ViewState = ViewState.replace("=", "%3D")
        ViewState = ViewState.replace("+", "%2B")
        # with open('421_postmethod.txt', 'r') as content_file:
        #     content = content_file.read()
        # mydata =(content)

        # my_data=mydata
        # print(my_data)
        my_data = "radScriptMgrResults=RadGrid1Panel%7CRadGrid1%24ctl00%24ctl03%24ctl01%24ChangePageSizeLinkButton&radScriptMgrResults_TSM=%3B%3BAjaxControlToolkit%2C%20Version%3D4.1.7.1213%2C%20Culture%3Dneutral%2C%20PublicKeyToken%3D28f01b0e84b6d53e%3Aen-US%3A5e024d16-0df4-4402-9405-a3808b4211f4%3Aea597d4b%3Ab25378d2%3BTelerik.Web.UI%2C%20Version%3D2016.1.225.40%2C%20Culture%3Dneutral%2C%20PublicKeyToken%3D121fae78165ba3d4%3Aen-US%3Aab312d5a-8d8b-4310-a879-b25aeb34b5c7%3A16e4e7cd%3Aed16cbdc%3Af7645509%3A88144a7a%3A58366029%3Ab7778d6c%3Ae085fe68%3A24ee1bba%3Ae330518b%3A2003d0b8%3Ac128760b%3A1e771326%3Ac8618e41%3Ae4f8f289%3A1a73651d%3A333f8d94&__EVENTTARGET=RadGrid1%24ctl00%24ctl03%24ctl01%24ChangePageSizeLinkButton&__EVENTARGUMENT=&__VIEWSTATE=" + str(
            ViewState) + "&__VIEWSTATEGENERATOR=4B7B1BE2&__EVENTVALIDATION=%2FwEdACjZGpmlM9LpUeXoXkNe%2BF0O6n%2BnsaCoz1SxQoJBX4%2FpVZMpHoD8aSDzUCaOdMQBNoe8Hw7seLtUmM4BVC%2Bi%2BT7OhQCKJX%2FGuNI4kCeNMWwO34ch3AvZ9Lsaf3mecns1e%2BxQyIOzVRi3oifYXrRDlU79TR2jpEb1AQtV8jdwwYYzsjb%2BH9ZInjl5IjKAX4L2%2B%2B%2FKTFYqJEMPugF9cjcG1d67G65rEQlBFjvX4nE%2BT8Kh%2FSfFk8z1yTBkjXEFIlqk1aSkSviY3KWBHVKhgRqgQeTlLZaEmG5J5JJT8sjO8lY21yKZ%2BegcpKgPk8Q5oJDyGY%2Fs93YSrpw0JXiLIgwR1cGStM25pYiWG37JnXO2XXd7yZQPTnfkUjs5vs0gJmJaxOPGKiMQYNroH38FCZ6bMdTnAb6d4Vx%2BliKP4QicCNNQugzw4y1OKceKm%2BcJtlEmyzVn3jPdxM0vQFSlgePT%2BzQXs18rbC%2FC11BONTW3I3pQJ7%2FYHVInLi83X4N%2BpwzCH4GSPXmO%2BoFkdOHJGXQIY49Yngsgq85VLSdE9DMTGZFdEOo6J8Sauac3wmQqCdlyfJZChuOwo4NnHYokPyhkbRsqA1n8r71IX8EG%2FDj%2BEir59VIc0ghMkP%2FeuoBs2HpDf%2B%2FpK6T%2Fd2XoPwFdIrGNQTnrYv1AB5mzPHDZRFqba8Nvf28xXNxsC7nwDY%2Bo%2FWedv%2Frr%2FyGl3eNw9LNuB9USYucM5Nl4cv19h%2B2yMegVpk62tRlZaTZStQMJwYJlYujU9OzmngI69CCsngdeITeMVTsEOQEHKrSVnon489VgPKRNQoA9FJHxVewlnNt1bFlP449MDYkvEv%2BDhL%2BiVlP5kmrHR1qZt2Y6kqwXCwH2EuYVozSNrjtguN7Mb5DZ0G3gtrI%3D&RadGrid1%24ctl00%24ctl02%24ctl02%24FilterTextBox_Prop_PropertyName=&RadGrid1%24ctl00%24ctl02%24ctl02%24FilterTextBox_Prop_City=&RadGrid1%24ctl00%24ctl02%24ctl02%24FilterTextBox_Prop_State=&RadGrid1%24ctl00%24ctl02%24ctl02%24FilterTextBox_Prop_Zip=&RadGrid1%24ctl00%24ctl02%24ctl02%24FilterTextBox_Prop_PropertyNumber=&RadGrid1%24ctl00%24ctl02%24ctl02%24FilterTextBox_Prop_Type=&RadGrid1%24ctl00%24ctl03%24ctl01%24GoToPageTextBox=1&RadGrid1_ctl00_ctl03_ctl01_GoToPageTextBox_ClientState=%7B%22enabled%22%3Atrue%2C%22emptyMessage%22%3A%22%22%2C%22validationText%22%3A%221%22%2C%22valueAsString%22%3A%221%22%2C%22minValue%22%3A1%2C%22maxValue%22%3A21%2C%22lastSetTextBoxValue%22%3A%221%22%7D&RadGrid1%24ctl00%24ctl03%24ctl01%24ChangePageSizeTextBox=" + str(
            totalcount) + "RadGrid1_ctl00_ctl03_ctl01_ChangePageSizeTextBox_ClientState=%7B%22enabled%22%3Atrue%2C%22emptyMessage%22%3A%22%22%2C%22validationText%22%3A%22" + str(
            totalcount) + "%22%2C%22valueAsString%22%3A%22" + str(
            totalcount) + "%22%2C%22minValue%22%3A1%2C%22maxValue%22%3A406%2C%22lastSetTextBoxValue%22%3A%22" + str(
            totalcount) + "%22%7D&RadGrid1_rfltMenu_ClientState=&RadGrid1_ClientState=&__ASYNCPOST=true&RadAJAXControlID=radAjax"
        my_data = "radScriptMgrResults=RadGrid1Panel%7CRadGrid1%24ctl00%24ctl03%24ctl01%24ChangePageSizeLinkButton&radScriptMgrResults_TSM=%3B%3BAjaxControlToolkit%2C%20Version%3D4.1.7.1213%2C%20Culture%3Dneutral%2C%20PublicKeyToken%3D28f01b0e84b6d53e%3Aen-US%3A5e024d16-0df4-4402-9405-a3808b4211f4%3Aea597d4b%3Ab25378d2%3BTelerik.Web.UI%2C%20Version%3D2016.1.225.40%2C%20Culture%3Dneutral%2C%20PublicKeyToken%3D121fae78165ba3d4%3Aen-US%3Aab312d5a-8d8b-4310-a879-b25aeb34b5c7%3A16e4e7cd%3Aed16cbdc%3Af7645509%3A88144a7a%3A58366029%3Ab7778d6c%3Ae085fe68%3A24ee1bba%3Ae330518b%3A2003d0b8%3Ac128760b%3A1e771326%3Ac8618e41%3Ae4f8f289%3A1a73651d%3A333f8d94%3B&RadGrid1%24ctl00%24ctl02%24ctl02%24FilterTextBox_Prop_PropertyName=&RadGrid1%24ctl00%24ctl02%24ctl02%24FilterTextBox_Prop_City=&RadGrid1%24ctl00%24ctl02%24ctl02%24FilterTextBox_Prop_State=&RadGrid1%24ctl00%24ctl02%24ctl02%24FilterTextBox_Prop_Zip=&RadGrid1%24ctl00%24ctl02%24ctl02%24FilterTextBox_Prop_PropertyNumber=&RadGrid1%24ctl00%24ctl02%24ctl02%24FilterTextBox_Prop_Type=&RadGrid1%24ctl00%24ctl03%24ctl01%24GoToPageTextBox=1&RadGrid1_ctl00_ctl03_ctl01_GoToPageTextBox_ClientState=%7B%22enabled%22%3Atrue%2C%22emptyMessage%22%3A%22%22%2C%22validationText%22%3A%221%22%2C%22valueAsString%22%3A%221%22%2C%22minValue%22%3A1%2C%22maxValue%22%3A21%2C%22lastSetTextBoxValue%22%3A%221%22%7D&RadGrid1%24ctl00%24ctl03%24ctl01%24ChangePageSizeTextBox=405&RadGrid1_ctl00_ctl03_ctl01_ChangePageSizeTextBox_ClientState=%7B%22enabled%22%3Atrue%2C%22emptyMessage%22%3A%22%22%2C%22validationText%22%3A%22405%22%2C%22valueAsString%22%3A%22405%22%2C%22minValue%22%3A1%2C%22maxValue%22%3A405%2C%22lastSetTextBoxValue%22%3A%22405%22%7D&RadGrid1_rfltMenu_ClientState=&RadGrid1_ClientState=&__EVENTTARGET=RadGrid1%24ctl00%24ctl03%24ctl01%24ChangePageSizeLinkButton&__EVENTARGUMENT=&__VIEWSTATE=" + str(
            ViewState) + "&__VIEWSTATEGENERATOR=4B7B1BE2&__EVENTVALIDATION=%2FwEdAChkt%2F2mv414LdTNBfHzZBB46n%2BnsaCoz1SxQoJBX4%2FpVZMpHoD8aSDzUCaOdMQBNoe8Hw7seLtUmM4BVC%2Bi%2BT7OhQCKJX%2FGuNI4kCeNMWwO34ch3AvZ9Lsaf3mecns1e%2BxQyIOzVRi3oifYXrRDlU79TR2jpEb1AQtV8jdwwYYzsjb%2BH9ZInjl5IjKAX4L2%2B%2B%2FKTFYqJEMPugF9cjcG1d67G65rEQlBFjvX4nE%2BT8Kh%2FSfFk8z1yTBkjXEFIlqk1aSkSviY3KWBHVKhgRqgQeTlLZaEmG5J5JJT8sjO8lY21yKZ%2BegcpKgPk8Q5oJDyGY%2Fs93YSrpw0JXiLIgwR1cGStM25pYiWG37JnXO2XXd7yZQPTnfkUjs5vs0gJmJaxOPGKiMQYNroH38FCZ6bMdTnAb6d4Vx%2BliKP4QicCNNQugzw4y1OKceKm%2BcJtlEmyzVn3jPdxM0vQFSlgePT%2BzQXs18rbC%2FC11BONTW3I3pQJ7%2FYHVInLi83X4N%2BpwzCH4GSPXmO%2BoFkdOHJGXQIY49Yngsgq85VLSdE9DMTGZFdEOo6J8Sauac3wmQqCdlyfJZChuOwo4NnHYokPyhkbRsqA1n8r71IX8EG%2FDj%2BEir59VIc0ghMkP%2FeuoBs2HpDf%2B%2FpK6T%2Fd2XoPwFdIrGNQTnrYv1AB5mzPHDZRFqba8Nvf28xXNxsC7nwDY%2Bo%2FWedv%2Frr%2FyGl3eNw9LNuB9USYucM5Nl4cv19h%2B2yMegVpk62tRlZaTZStQMJwYJlYujU9OzmngI69CCsngdeITeMVTsEOQEHKrSVnon489VgPKRNQoA9FJHxVewlnNt1bFlP449MDYkvEv%2BDhL%2BiVlP5kmrHefQSPToGMc0MIYk9QbGc1suoLGUAa11hQNfLKnGwzMM%3D&RadGrid1%24ctl00%24ctl02%24ctl02%24FilterTextBox_Prop_PropertyName=&RadGrid1%24ctl00%24ctl02%24ctl02%24FilterTextBox_Prop_City=&RadGrid1%24ctl00%24ctl02%24ctl02%24FilterTextBox_Prop_State=&RadGrid1%24ctl00%24ctl02%24ctl02%24FilterTextBox_Prop_Zip=&RadGrid1%24ctl00%24ctl02%24ctl02%24FilterTextBox_Prop_PropertyNumber=&RadGrid1%24ctl00%24ctl02%24ctl02%24FilterTextBox_Prop_Type=&RadGrid1%24ctl00%24ctl03%24ctl01%24GoToPageTextBox=1&RadGrid1_ctl00_ctl03_ctl01_GoToPageTextBox_ClientState=%7B%22enabled%22%3Atrue%2C%22emptyMessage%22%3A%22%22%2C%22validationText%22%3A%221%22%2C%22valueAsString%22%3A%221%22%2C%22minValue%22%3A1%2C%22maxValue%22%3A21%2C%22lastSetTextBoxValue%22%3A%221%22%7D&RadGrid1%24ctl00%24ctl03%24ctl01%24ChangePageSizeTextBox=" + str(
            totalcount) + "&RadGrid1_ctl00_ctl03_ctl01_ChangePageSizeTextBox_ClientState=%7B%22enabled%22%3Atrue%2C%22emptyMessage%22%3A%22%22%2C%22validationText%22%3A%22" + str(
            totalcount) + "%22%2C%22valueAsString%22%3A%22" + str(
            totalcount) + "%22%2C%22minValue%22%3A1%2C%22maxValue%22%3A406%2C%22lastSetTextBoxValue%22%3A%22" + str(
            totalcount) + "%22%7D&RadGrid1_rfltMenu_ClientState=&RadGrid1_ClientState=&__ASYNCPOST=true&RadAJAXControlID=radAjax"

        header = {
            "accept": "*/*",
            "accept-encoding": "gzip, deflate",
            "accept-language": "en-GB,en-US;q=0.9,en;q=0.8",
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            "Origin": "http://www.benderson.com",
            "X-Requested-With": "XMLHttpRequest",
            "Referer": "http://www.benderson.com/prop/propResults.aspx",
            "user-agent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36"}

        try:
            file_path = self.f1.html_data_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
                self.run_date) + '_' + str(page) + '.html'
            yield scrapy.FormRequest(url="http://www.benderson.com/prop/propResults.aspx", method='POST', body=my_data,
                                     callback=self.secondlevel, headers=header,
                                     meta={'source_url': source_url, 'file_path': file_path,
                                           'proxy_type': proxy_type})
        except Exception as e:
            print("firstlevel", e, response.url)

    def secondlevel(self, response):
        if not response.url.startswith('file://'):
            self.f1.page_save(response.meta['file_path'], response.body)
        try:
            source_url = response.meta['source_url']
            file_path = response.meta['file_path']
            proxy_type = response.meta['proxy_type']
            links = response.xpath('//table[@class="rgMasterTable"]//tbody/tr/td/a/@href').extract()
            for link in (links):
                link = link.replace('../property.aspx', '/property.aspx')
                link = "http://benderson.com" + link.strip()
                file_path = self.f1.html_data_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
                    self.run_date) + '.html'
                yield scrapy.FormRequest(url=link, callback=self.get_store_list,
                                         meta={'source_url': source_url, 'file_path': file_path,
                                               'proxy_type': proxy_type})
        except Exception as e:
            print("firstlevel", e, response.url)

    # Get data from the response
    def get_store_list(self, response):
        if not response.url.startswith('file://'):
            self.f1.page_save(response.meta['file_path'], response.body)
        try:
            try:

                try:
                    Property_Name = response.xpath('//*[@class="propTitle"]/text()').extract_first().strip()
                except Exception as e:
                    print("Property_Name", e, response.url)

                try:
                    address = response.xpath('//*[@id="lblAddress"]//text()').extract_first(default='').strip()
                except Exception as e:
                    print("Address", e, response.url)

                try:
                    city_state = response.xpath('//*[@id="lblCityStateZip"]//text()').extract_first(default='').strip()
                    city = city_state.split(',')[0].strip()
                    state = city_state.split(',')[1].strip()
                except Exception as e:
                    print("city_state", e, response.url)

                try:
                    Leasing_Contact = response.xpath('//*[@id="lblOfficeName"]/text()').extract_first(
                        default='').strip()
                except Exception as e:
                    print("Leasing_Contact", e, response.url)

                try:
                    Leasing_data = ''.join(response.xpath('//*[@id="lblOfficeAddress"]').extract())
                    Leasing_Phone = re.findall('P:(.*?)<br>', Leasing_data)[0].strip()
                except Exception as e:
                    print("Leasing_Phone", e, response.url)

                if "value=\"Brochure\" onclick=\"javascript:WebForm_DoPostBackWithOptions" in str(response.text):
                    try:
                        Brochure_id = response.url.split('id=')[1].strip()
                        if "OFF&type=" in str(Brochure_id):
                            Brochure_id = Brochure_id.split('OFF&type=')[0].strip()
                        else:
                            Brochure_id = Brochure_id.split('&type=')[0].strip()

                        if Brochure_id != "":
                            Brochure = "http://benderson.com/prop/propertyContent/brochure/" + Brochure_id + "__brochure.pdf"
                    except Exception as e:
                        # Brochure=''
                        print("Brochure", e, response.url)
                else:
                    Brochure = ''

                item = ProprtySitesItem()
                item['Property_Name'] = Property_Name
                item['Address'] = address
                item['City'] = city
                item['State'] = state
                item['Leasing_Contact'] = Leasing_Contact
                item['Leasing_Phone'] = Leasing_Phone
                item['Property_URL'] = response.url
                item['Brochure'] = Brochure
                yield item
            except Exception as e:
                print(e)

        except Exception as e:
            print(e)

    def response_html_path(self, request):
        return request.meta['fpath']

# execute('''scrapy crawl store_421 -a list_id=421 -a proxy_type='''.split())



# not:manually chnage postmethod ,copy from sie and paste in txt

