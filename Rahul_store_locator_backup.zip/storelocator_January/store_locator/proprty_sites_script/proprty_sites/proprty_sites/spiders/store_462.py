# -*- coding: utf-8 -*-
import datetime
import json
import re

import requests
import scrapy
from scrapy.http import HtmlResponse

from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func


class Store462Spider(scrapy.Spider):
    name = 'store_462'
    allowed_domains = []
    start_urls = ['https://www.pyramidmg.com/']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def parse(self, response):
        links = response.xpath('//div[@class="col-xs-12 col-sm-6 col-md-4"]/a/@href').getall()
        for link in links:
            yield scrapy.Request(url=link, callback=self.parse_data)
            # yield scrapy.Request(url='https://www.pyramidmg.com/property/crossgates-commons/', callback=self.parse_data, dont_filter=True)


    def parse_data(self, response):
        try:property_name = response.xpath('//div[@class="col-xs-12 col-sm-5 layout-column layout-align-center-center"]/img/@alt').get(default='').strip()
        except Exception as e:print(e)

        try:description = response.xpath('//div[@class="col-xs-12 col-sm-7 property-content layout-column layout-align-center-start"]/p/text()').get(default='').strip()
        except Exception as e:print(e)

        try:GLA = response.xpath('//h5[contains(text(),"Total GLA")]/following-sibling::h2/text()').get(default='').strip()
        except Exception as e:print(e)

        try:address_link = response.xpath('//a[@class="btn property-view"]/@href').get(default='').strip()
        except Exception as e:print(e)

        if address_link:
            res = requests.get(url=address_link)
            response1 = HtmlResponse(url=res.url, body=res.content)

            text = response1.xpath('//div[@class="widget ktheme-location-3"]/p[@class="location text-center"]/a/text()|//div[@class="widget ktheme-location-5"]/p[@class="location text-center"]/a/text()|//div[@class="widget ktheme-location-2"]/p[@class="location text-center"]/a/text()').getall()

            try:address = text[0].strip()
            except:address = ''

            try:city = text[1].split(',')[0].strip()
            except:city = ''

            try:state = re.findall(r'([A-Z]{2})', text[1])[0].strip()
            except:state = ''

            try:zipcode = re.findall(r'(\d{5})', text[1])[0].strip()
            except:zipcode = ''

            link_ = response1.xpath('//span[contains(text(),"Info")]/../@href').get(default='').strip()
            if link_:
                site_plan_url = 'https://www.shopaviationmall.com/wp-content/uploads/sites/8/2019/01/Aviation_Mall_ADA_Map.png'
            else:
                site_plan_url = ''

            if property_name == 'Crossgates':
                address = '1 Crossgates Mall Rd'
                city = 'Albany'
                state = 'NY'
                zipcode = '12203'

            item = ProprtySitesItem()
            item['Property_Name'] = property_name
            item['Address'] = address
            item['City'] = city
            item['State'] = state
            item['ZipCode'] = zipcode
            item['GLA'] = GLA
            item['Description'] = description
            item['Leasing_Contact_Name'] = 'Robert M. Coleman'
            item['Leasing_Contact_Phone'] = '315-422-7000'
            item['Leasing_Contact_Email'] = 'robertcoleman@pyramidmg.com'
            item['Site_Plan_URL'] = site_plan_url
            item['Property_URL'] = response.url
            yield item


# from scrapy.cmdline import execute
# execute('scrapy crawl store_462 -a list_id=462'.split())
