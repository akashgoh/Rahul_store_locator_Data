# -*- coding: utf-8 -*-
import datetime
import json
import re

import requests
import scrapy
from random_user_agent.params import SoftwareName, OperatingSystem
from random_user_agent.user_agent import UserAgent
from scrapy.http import HtmlResponse

from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func


class Store444Spider(scrapy.Spider):
    name = 'store_444'
    allowed_domains = []
    handle_httpstatus_list = [301, 302, 404, 403]

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        for i in range(1, 20):
            headers = {
                "Accept":"application/json, text/javascript, */*; q=0.01",
                "Accept-Encoding":"gzip, deflate, br",
                "Accept-Language":"en-US,en;q=0.9",
                "Connection":"keep-alive",
                "Content-Type":"application/json;charset=UTF-8",
                "Host":"looplink.majesticrealty.com",
                "Origin":"https://looplink.majesticrealty.com",
                "Referer":"https://looplink.majesticrealty.com/SearchResults?SearchType=",
                "Cookie": "fpestid=uhv_YiT7eat3r57Q5XFYSDDp2AMHEByzYxaXxlCSx3p0MIXSpnqqWGz7RA7nQRq4Ih8y0g; _ga=GA1.2.56713884.1603948655; _gid=GA1.2.1608845405.1603948655; LNUniqueVisitor=328bef45-9895-4921-835a-ebe7d164e48d; _vwo_uuid_v2=DE9FEE31710FAE109B3E8C3CA649A894E|0135ece9b6bd1f6881080abb58d6b288; _ga=GA1.3.56713884.1603948655; _gid=GA1.3.1608845405.1603948655; _gat_UA-31346-1=1",
                "Sec-Fetch-Dest":"empty",
                "X-Request-ID": "be8c949ba7d841698c52a32719a401b3",
                "Sec-Fetch-Mode":"cors",
                "Sec-Fetch-Site":"same-origin",
                "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36",
                "X-Requested-With":"XMLHttpRequest"
            }

            payload = {"d":{"l":0, "p":i, "s":20, "cc":["US"], "cil":[], "col":[], "ipc":False, "lsu":0, "ml":[], "pcl":[], "al":"", "scl":[], "sl":[], "di":0, "k":None, "bsu":None, "bsr":None, "lsr":None, "fl":{"ifl":False, "sl":{"lrc":"USD", "lrr":None, "sar":None, "lrt":0, "sau":2, "lrpsu":0, "slt":0}}, "fs":{"pr":None, "prc":"USD", "prrt":0, "crr":{}}, "apl":[{"AssociateID":None, "RelationshipTypes":2, "EmailAddress":"", "FirstName":None, "LastName":None}], "rm":0, "mkl":[], "prml":[], "psml":[], "sfl":[], "sflp":[], "sml":[], "pg":None, "cb":None, "r":{"d":0}, "pf":1, "cf":0, "scf":0, "ill":[], "pn":"", "der":{"rl":"2001-01-01T00:00:00", "ru":"1999-12-31T00:00:00"}, "e":"LL4"},"r":{"rai":0, "sid":4967, "f":2, "c":"F-X9wE14Q"},"o":[{"Key":"SiteID", "Value":4967},{"Key":"SearchNumber", "Value":3},{"Key":"createLocTitle", "Value":"Y"},{"Key":"haveMap", "Value":True},{"Key":"searchEventSource", "Value":3}]}

            link = 'https://looplink.majesticrealty.com/LoopLink/Services/Listing/ListingSearchLL.svc/PerformPdsSearchPage'
            print(link)
            yield scrapy.FormRequest(url=link, callback=self.parse, headers=headers, body=json.dumps(payload),meta={'proxy_type': self.proxy_type}, method='POST',dont_filter=True)


    def parse(self, response):
        s=response.text
        print(s)
        json_data = json.loads(response.text)

        length = len(json_data['r']['l'])
        for i in range(0, int(length)):
            id = json_data['r']['l'][i]['i']
            try:name = json_data['r']['l'][i]['ma']['al'].replace(' ','-')
            except Exception as e:print(e)
            headers = {
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
                "Accept-Encoding": "gzip, deflate, br",
                "Accept-Language": "en-US,en;q=0.9",
                "Cache-Control": "max-age=0",
                "Connection": "keep-alive",
                "Host": "looplink.majesticrealty.com",
                "If-None-Match": 'W/"1d460-QpVwz0XslW6vjLS/SAzJWLA7i8w"',
                "Referer": "https://looplink.majesticrealty.com/SearchResults",
                "Sec-Fetch-Dest": "document",
                "Sec-Fetch-Mode": "navigate",
                "Sec-Fetch-Site": "same-origin",
                "Sec-Fetch-User": "?1",
                "Upgrade-Insecure-Requests": "1",
                "User-Agent":get_useragent()
            }
            link = "https://looplink.majesticrealty.com/Listing/"+str(name)+"/"+str(id)+"/"
            link = link.replace('-&-','-').replace('-@-','-').replace('---','-').replace('-#1','').strip()

            res = requests.get(url=link, headers=headers)
            response1 = HtmlResponse(url=res.url, body=res.content)
            if res.status_code != 200:
                print('ERROR : '+res.url)
            else:
                try:property_name = '|'.join(response1.xpath('//h1[@class="profile-hero-title"]/span/text()').getall())
                except:property_name = ''

                try:address = property_name.split('|')[-1]
                except:address = ''

                try:city = re.findall(r'gtm-listing-city="(.*?)"', response1.text)[0]
                except:city = ''

                try:text = response1.xpath('//h2[@class="profile-hero-sub-title"]/text()').get(default='')
                except:text = ''

                try:state = text.split(',')[-1].strip()
                except:state = ''

                try:GLA = re.findall(r'(\d+,\d+)', text)[0].strip()
                except:GLA = ''

                try:leasing_contact_name = '|'.join(response1.xpath('//section[@class="broker-contact-form-bar"]//img/@alt').getall())
                except:leasing_contact_name = ''

                try:leasing_phone = re.findall(r'<span class="phone-number">(.*?)</span>', response1.text)[0]
                except:leasing_phone = ''

                try:description = response1.xpath('//meta[@name="description"]/@content').get(default='')
                except:description = ''

                try:site_plan_url = response1.xpath('//ul[@class="links-list"]/li[last()]/a/@href').get(default='')
                except:site_plan_url = ''

                item = ProprtySitesItem()
                item['Property_Name'] = property_name
                item['Address'] = address
                item['City'] = city
                item['State'] = state
                item['GLA'] = GLA
                item['Leasing_Contact_Name'] = leasing_contact_name
                item['Description'] = description
                item['Leasing_Contact_Phone'] = leasing_phone
                item['Site_Plan_URL'] = site_plan_url
                item['Property_URL'] = response.url
                if property_name != '':
                    yield item


def get_useragent():
    software_names = [SoftwareName.CHROME.value]
    operating_systems = [OperatingSystem.WINDOWS.value, OperatingSystem.LINUX.value]
    user_agent_rotator = UserAgent(software_names=software_names, operating_systems=operating_systems)
    return user_agent_rotator.get_random_user_agent()


# from scrapy.cmdline import execute
# execute('scrapy crawl store_444 -a list_id=444'.split())