# -*- coding: utf-8 -*-
# pip install scrapy-html-storage
import re
from scrapy.http import HtmlResponse
import datetime
import scrapy, json, requests, re
import html2text
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func
from scrapy.cmdline import execute

class Store425Spider(scrapy.Spider):
    name = 'store_425'
    allowed_domains = []
    not_export_data = True

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        try:
            page = 1
            source_url = link = f'http://cedarrealtytrust.propertycapsule.com/property/output/find/search4/'
            file_path = self.f1.html_link_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
                self.run_date) + '.html'
            yield scrapy.FormRequest(url=str(link), callback=self.firstlevel,
                                     meta={'source_url': source_url, 'file_path': file_path,
                                           'proxy_type': self.proxy_type, 'page': page})
        except Exception as e:
            print(e)

    def firstlevel(self, response):
        if not response.url.startswith('file://'):
            self.f1.page_save(response.meta['file_path'], response.body)
        try:
            source_url = response.meta['source_url']
            file_path = response.meta['file_path']
            proxy_type = response.meta['proxy_type']
            links = response.xpath('//div[@class="columns small-12 medium-12 large-7"]//a/@href').extract()
            headers = {
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
                "User-Agent": "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Mobile Safari/537.36",
                "Accept-Encoding": "gzip, deflate",
                "Accept-Language": "en-GB,en-US;q=0.9,en;q=0.8",
                "Referer": "http://cedarrealtytrust.propertycapsule.com/property/output/find/search4/",
                "Cookie": "_fbp=fb.1.1581404583121.673965502; _ga=GA1.2.1469702972.1581404584; PCAPSESSID3=ktcsqto8dncvl3n2uine5nn1c2; _gid=GA1.2.20303395.1581925490"
                }
            for link in (links):
                link = link.strip()
                page = link.replace('http://cedarrealtytrust.propertycapsule.com/property/output/center/detail/id:',
                                    '').replace('/', '').strip()
                file_path = self.f1.html_data_directory + str(self.list_id) + '_' + str(self.name) + '_' + str(
                    self.run_date) + '_' + str(page) + '.html'
                yield scrapy.FormRequest(url=link, callback=self.get_store_list, headers=headers,
                                         meta={'source_url': source_url, 'file_path': file_path,
                                               'proxy_type': proxy_type})
        except Exception as e:
            print("firstlevel", e, response.url)

    # Get data from the response
    def get_store_list(self, response):
        if not response.url.startswith('file://'):
            self.f1.page_save(response.meta['file_path'], response.body)
        try:
            try:
                try:
                    Property_Name = response.xpath('//h1[@class="property-title"]/text()').extract_first().strip()
                except Exception as e:
                    print("Property_Name", e, response.url)

                try:
                    Address1 = response.xpath('//div[@class="address"]//text()').extract()
                    Address = Address1[0].strip()
                    Address2 = Address1[1].strip()
                    city = Address2.split(',')[0].strip()
                    state_bunch = Address2.split(',')[1].strip()
                    state = state_bunch.split(' ')[0].strip()
                    Zip_Code = state_bunch.split(' ')[1].strip()
                except Exception as e:
                    print("Address", e, response.url)

                try:
                    Description = ''.join(response.xpath(
                        '//div[@class="property-intro columns small-12 medium-8 add-bot-pad"]/p/text()').extract())
                    Description = Description.strip()
                except Exception as e:
                    Description = ''
                    print("Description", e, response.url)

                try:
                    GLA = re.findall('<b>Total SF:</b>(.*?)<br/>', response.text)[0].strip()
                except Exception as e:
                    GLA = ''
                    print("GLA", e, response.url)

                try:
                    Leasing_Contact = ','.join(response.xpath('//div[@class="leasing-rep"]//b/text()').extract())
                    Leasing_Contact = Leasing_Contact.strip(',')
                    Leasing_Contact = Leasing_Contact.strip()
                except Exception as e:
                    Leasing_Contact = ''
                    print("Leasing_Contact", e, response.url)

                try:
                    Leasing_Email = ','.join(
                        response.xpath('//div[@class="leasing-rep"]/ul//li/span/../a/text()').extract())
                    Leasing_Email = Leasing_Email.strip(',')
                    Leasing_Email = Leasing_Email.strip()
                except Exception as e:
                    Leasing_Email = ''
                    print("Leasing_Email", e, response.url)

                try:
                    Leasing_Phone = response.xpath('//div[@class="leasing-rep"]/ul/li/span/../text()').extract()
                    Leasing_Phone = str(' '.join([img for img in Leasing_Phone]))
                    Leasing_Phone = re.sub('[\t]|\n|\s\s+|\r', ' ', str(Leasing_Phone)).strip()
                    Leasing_Phone = Leasing_Phone.replace(' ', ',').strip()
                except Exception as e:
                    Leasing_Phone = ''
                    print("Leasing_Phone", e, response.url)

                try:
                    Property_Manager_Name = ','.join(
                        response.xpath('//div[@class="property-manager"]/h5//text()').extract())
                    Property_Manager_Name = Property_Manager_Name.strip(',')
                    Property_Manager_Name = Property_Manager_Name.strip()
                except Exception as e:
                    Property_Manager_Name = ''
                    print("Property_Manager_Name", e, response.url)

                try:
                    Property_Manager_Phone = response.xpath(
                        '//div[@class="property-manager"]/ul/li/span/../text()').extract()
                    # Property_Manager_Phone =''.join(response.xpath('//div[@class="property-manager"]//ul//li/span[@class="fa fa-fw fa-sm fa-phone cedargreen-text"]/../text()').extract())
                    Property_Manager_Phone = str(' '.join([img for img in Property_Manager_Phone]))
                    Property_Manager_Phone = re.sub('[\t]|\n|\s\s+|\r', ' ', str(Property_Manager_Phone)).strip()
                    Property_Manager_Phone = Property_Manager_Phone.replace(' ', ',').strip()
                except Exception as e:
                    Property_Manager_Phone = ''
                    print("Property_Manager_Phone", e, response.url)

                try:
                    Property_Managers = ','.join(response.xpath(
                        '//div[@class="property-manager"]//ul//li/span[@class="fa fa-fw fa-sm fa-envelope cedargreen-text"]/../a/text()').extract())
                    Property_Managers = Property_Managers.strip(',')
                    Property_Managers = Property_Managers.strip()
                except Exception as e:
                    Property_Managers = ''
                    print("Property_Managers", e, response.url)

                try:
                    sitemapid = re.findall('/sitemap_ID:(.*?)/', response.text)[0].strip()
                    Site_Plan_URL = "http://cedarrealtytrust.propertycapsule.com/property/capsule_data/287/property/sitemap_image/" + str(
                        sitemapid) + ".png?".strip()
                except Exception as e:
                    Site_Plan_URL = ''
                    print("Site_Plan_URL", e, response.url)

                item = ProprtySitesItem()
                item['Property_Name'] = Property_Name
                item['Address'] = Address
                item['City'] = city
                item['State'] = state
                item['Zip_Code'] = Zip_Code
                item['Description'] = Description
                item['GLA'] = GLA
                item['Leasing_Contact'] = Leasing_Contact
                item['Leasing_Phone'] = Leasing_Phone
                item['Leasing_Email'] = Leasing_Email
                item['Property_Manager_Name'] = Property_Manager_Name
                item['Property_Manager_Phone'] = Property_Manager_Phone
                item['Property_Managers'] = Property_Managers
                item['Site_Plan_URL'] = Site_Plan_URL
                item['Property_URL'] = response.url
                yield item
            except Exception as e:
                print(e)

        except Exception as e:
            print(e)


# execute('''scrapy crawl store_425 -a list_id=425 -a proxy_type='''.split())


