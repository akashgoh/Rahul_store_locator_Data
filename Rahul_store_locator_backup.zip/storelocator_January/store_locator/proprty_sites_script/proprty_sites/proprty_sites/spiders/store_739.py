# -*- coding: utf-8 -*-
import datetime
import scrapy, json, requests, re
import html2text
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func

h = html2text.HTML2Text()


class kilroyrealtySpider(scrapy.Spider):
    name = 'store_739'
    allowed_domains = ['kilroyrealty.com']
    start_urls = ['https://kilroyrealty.com/properties-json']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def parse(self, response):

        data = json.loads(response.text)
        n = len(data['nodes'])
        print(n)
        for i in range(0,n):
            property_name = data['nodes'][i]['node']['title']
            address = data['nodes'][i]['node']['address_thoroughfare']
            url =  data['nodes'][i]['node']['path']
            property_type = data['nodes'][i]['node']['property_type']
            project_type = data['nodes'][i]['node']['project_type']

            url = 'https://kilroyrealty.com'+url

            yield scrapy.Request(url=url,callback=self.parseData2,dont_filter=True,
                                 meta={'property_name':property_name,'property_type':property_type,
                                       'project_type':project_type,'address':address})

    def parseData2(self, response):
        data = response.text
        property_name = response.meta['property_name']
        address = response.meta['address']
        property_type = response.meta['property_type']
        project_type = response.meta['project_type']

        text = html2text.HTML2Text()
        text.ignore_images = True
        text.ignore_links = True
        text.ignore_emphasis = True
        text.body_width = 0
        text.ignore_tables = True
        try:
            GLA = re.findall('<div class="section-name">SQUARE(.*?)</p>',response.text,re.DOTALL)[0]
            GLA = ''.join(re.findall('\d+',GLA))
        except Exception as e:
            GLA = ''

        try:
            city = re.findall('<span class="locality">(.*?)</span>',response.text)[0]
        except Exception as e:
            city =''

        try:
            state = re.findall('<span class="state">(.*?)</span>',response.text)[0]
        except Exception as e:
            state = ''

        try:
            zipcode = re.findall('<span class="postal-code">(.*?)</span>',response.text)[0]
        except Exception as e:
            zipcode = ''

        try:
            Email = re.findall('<div class="section-name">ASSET(.*?)</p>',response.text,re.DOTALL)[0]
            Email = re.findall('<p><a href="mailto:(.*?)">',Email,re.DOTALL)[0]
        except Exception as e:
            Email = ''

        try:
            property_website = re.findall('<div class="section-name">PROPERTY(.*?)</p>',response.text,re.DOTALL)[0]
            property_website = re.findall('<a href="(.*?)"',property_website,re.DOTALL)[0]
        except Exception as e:
            property_website = ''

        try:
            Leasing_Contact_Name = re.findall('.com">(.*?)</a>',response.text,re.DOTALL)[0]
        except Exception as e:
            try:
                Leasing_Contact_Name = re.findall('.com ">(.*?)</a>',response.text,re.DOTALL)[0]
            except Exception as e:
                Leasing_Contact_Name = ''

        try:
            leasing_website = re.findall('<div class="section-name">PROPERTY(.*?)</p>',response.text,re.DOTALL)[0]
            leasing_website = re.findall('<a href="(.*?)"',leasing_website,re.DOTALL)[0]
        except Exception as e:
            leasing_website = ''

        try:
            No_Of_Building = re.findall('<div class="section-name">Number(.*?)</p>',response.text,re.DOTALL)[0]
            No_Of_Building = ''.join(re.findall('\d+', No_Of_Building))

        except Exception as e:
            No_Of_Building = ''


        item = ProprtySitesItem()
        item['Property_Name'] = property_name
        item['Address'] = address
        item['City'] = city
        item['State'] = state
        item['Zip'] = zipcode
        item['Email'] = Email
        item['GLA'] = GLA
        item['Property_Type'] = property_type
        item['Project_Type'] = project_type
        item['Property_Website'] = property_website
        item['Leasing_Website'] = leasing_website
        item['No_Of_Building'] = No_Of_Building
        item['Leasing_Contact_Name'] = Leasing_Contact_Name
        item['Property_URL'] = response.url
        yield item

from scrapy.cmdline import execute
# execute("scrapy crawl store_739 -a list_id=739".split())