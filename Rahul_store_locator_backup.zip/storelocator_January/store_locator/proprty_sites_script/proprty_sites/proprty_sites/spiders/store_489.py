# -*- coding: utf-8 -*-
import datetime
import re

import scrapy

from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func


class Store489Spider(scrapy.Spider):
    name = 'store_489'
    allowed_domains = []
    start_urls = ['http://properties.shopcore.com/property/output/find/search4/']

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)


    def parse(self, response):
        links = response.xpath('//a[@class="card-flip"]/@href').getall()
        for link in links:
            yield scrapy.Request(url=link, callback=self.parse2)


    def parse2(self, response):
        try:property_name = response.xpath('//h1[@class="type--a1"]/text()').get(default='').strip()
        except Exception as e:print(e)

        try:address = response.xpath('//h1[@class="type--a1"]/following-sibling::p[1]/text()').get(default='').strip()
        except Exception as e:print(e)

        try:city = response.xpath('//h1[@class="type--a1"]/following-sibling::p[2]/text()').get(default='').split(',')[0].strip()
        except Exception as e:print(e)

        try:state = response.xpath('//h1[@class="type--a1"]/following-sibling::p[2]/text()').get(default='').split(',')[-1].split(' ')[1].strip()
        except Exception as e:print(e)

        try:zipcode = response.xpath('//h1[@class="type--a1"]/following-sibling::p[2]/text()').get(default='').split(',')[-1].split(' ')[-1].strip()
        except Exception as e:print(e)

        try:GLA = response.xpath('//p[contains(text(),"sq")]/text()').get(default='').replace(',','').replace('sq. ft.','').strip()
        except Exception as e:print(e)

        try:leasing_contact_name = response.xpath('//h4[contains(text(),"Leasing")]/following-sibling::p/text()').get(default='').strip()
        except Exception as e:print(e)

        try:leasing_phone = response.xpath('//h4[contains(text(),"Leasing")]/following-sibling::p[contains(text(),"Phone")]/text()').get(default='').replace('Phone:','').strip()
        except Exception as e:print(e)

        try:leasing_email = response.xpath('//h4[contains(text(),"Leasing")]/../a//text()').get(default='').strip()
        except Exception as e:print(e)

        try:property_manager_name = response.xpath('//h4[contains(text(),"Property Manager")]/following-sibling::p/text()').get(default='').strip()
        except Exception as e:print(e)

        try:property_manager_phone = response.xpath('//h4[contains(text(),"Property Manager")]/following-sibling::p[contains(text(),"Phone")]/text()').get(default='').strip()
        except Exception as e:print(e)

        try:property_manager_email = response.xpath('//h4[contains(text(),"Property Manager")]/../a//text()').get(default='').strip()
        except Exception as e:print(e)

        try:
            site_plan_url = response.xpath('//div[@id="property-site-plan"]/iframe/@src').get(default='').strip()
            id = re.findall('/sitemap_ID:(.*?)/',site_plan_url)[0]
            url1 = f'https://properties.shopcore.com/property/capsule_data/650/property/sitemap_image/{id}.png'
            print(url1)
        except Exception as e:print(e)

        try:brochure_url = response.xpath('//a[@title="Download leasing brochure"]/@href').get(default='').strip()
        except Exception as e:print(e)

        property_url = response.url

        item = ProprtySitesItem()
        item['Property_Name'] = property_name
        item['Address'] = address
        item['City'] = city
        item['State'] = state
        item['ZipCode'] = zipcode
        item['GLA'] = GLA
        item['Leasing_Contact_Name'] = leasing_contact_name
        item['Leasing_Contact_Phone'] = leasing_phone
        item['Leasing_Contact_Email'] = leasing_email
        item['Property_Manager_Name'] = property_manager_name
        item['Property_Manager_Phone'] = property_manager_phone
        item['Property_Manager_Email'] = property_manager_email
        item['Site_Plan_URL'] = url1
        item['Property_URL'] = property_url
        item['Brochure_URL'] = brochure_url
        yield item

from scrapy.cmdline import execute
# execute('scrapy crawl store_489 -a list_id=489'.split())
