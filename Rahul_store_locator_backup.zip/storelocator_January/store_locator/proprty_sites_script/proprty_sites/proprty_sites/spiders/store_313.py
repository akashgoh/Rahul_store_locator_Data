import datetime
import scrapy, json, requests, re
import html2text
from proprty_sites.items import ProprtySitesItem
from proprty_sites.spiders.common_functions import Func

class HinesProperties(scrapy.Spider):
    name='store_313'

    def __init__(self, name=None, list_id="", proxy_type="", **kwargs):
        super().__init__(name, **kwargs)
        self.list_id, self.proxy_type = list_id, proxy_type
        self.f1 = Func()
        self.run_date = str(datetime.datetime.today()).split()[0]
        self.table_name = self.f1.set_details(self.list_id, self.run_date)

    def start_requests(self):
        link='https://www.hines.com/properties?isSidebarOpen=true&loc=-53.95608553098789%7C-178.9453125%7C80.23850054635392%7C196.5234375'
        header={'Upgrade-Insecure-Requests':'1',
                'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36',
                'Sec-Fetch-User': '?1',
                'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                'Sec-Fetch-Site':'same-origin',
                'Sec-Fetch-Mode':'navigate'}
        yield scrapy.Request(url=link,callback=self.data,headers=header,dont_filter=True)

    def data(self,response):
        links=response.xpath('//a[@class="property-result "]//@href').getall()
        for link in links:
            header = {'Upgrade-Insecure-Requests': '1',
                      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36',
                      'Sec-Fetch-User': '?1',
                      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                      'Sec-Fetch-Site': 'same-origin',
                      'Sec-Fetch-Mode': 'navigate'}
            link='https://www.hines.com'+link
            yield scrapy.Request(url=link,callback=self.get_data,headers=header,dont_filter=True)

    def get_data(self,response):
        item = ProprtySitesItem()
        address=response.xpath('//h4[contains(text(),"Address")]/following-sibling::ul/li/text()').get()
        item['Property_Name']=response.xpath('//h1//text()').get()
        if len(address) ==2:
            item['Address'] = ''
            item['City'] = address.split(',')[0]
            item['State'] = address.split(',')[1].replace('\n','').strip()
        else:
            item['City']=address.split(',')[-2]
            item['State']=address.split(',')[-1].replace('\n','').strip()
            item['Address'] = address.replace(''+item['City']+'','').replace(''+item['State']+'','')

        if len(item['State']) ==2:
            item['State']=item['State']
        else:
            item['State']=''

        item['Location']=response.xpath('//h4[contains(text(),"Location")]/following-sibling::ul/li[@class="small-list__item"]//text()').get(default='')
        item['SqFt']=''.join(re.findall('(\d+)',response.xpath('//li[contains(text(),"square ")]//text()').get(default='').replace(',','')))
        talent=response.xpath('//h4[contains(text(),"Major Tenants")]/following-sibling::ul/li//text()').getall()
        try:item['Major_Tenant_1']=talent[0]
        except:item['Major_Tenant_1']=''
        try:item['Major_Tenant_2']=talent[1]
        except:item['Major_Tenant_2']=''
        try:item['Major_Tenant_3']=talent[2]
        except:item['Major_Tenant_3']=''
        item['URL']=response.url
        yield item

from scrapy.cmdline import execute
# execute('scrapy crawl store_313 -a list_id=313'.split())