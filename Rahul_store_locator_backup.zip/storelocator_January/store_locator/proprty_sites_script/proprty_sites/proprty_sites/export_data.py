# -*- coding: utf-8 -*-
# This file is for generating output csv file and uploading it to dropbox

import pymysql
import pandas as pd
from proprty_sites.db_config import *
from proprty_sites.qa_tool import perform_qa
import logging
import numpy as np
import datetime as dt
from elasticsearch import Elasticsearch
from datetime import datetime,timedelta
import re


def digit_only(text):
    return re.sub('\D','',str(text))


def populate_qa_logs(master_dict, qa_output):
    try:
        con = pymysql.connect(db_host, db_user, db_password, db_name)
        cursor = con.cursor()
        master_dict['is_validated'] = qa_output
        master_dict['log_date_time'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        field_list = []
        value_list = []

        for field in master_dict:
            # if field != 'number_of_store' and master_dict[field]:
            field_list.append(str(field))
            value_list.append(str(master_dict[field]).replace("'", "’"))

        fields = ','.join(field_list)
        values = "','".join(value_list)
        insert_db = "insert into " + db_qa_log_table + "( " + fields + " ) values ( '" + values + "' )"
        cursor.execute(insert_db)
        con.commit()
    except Exception as e:
        print(e)


def export_data(f1,start_time,end_time):
# def export_data(list_name,list_id,country_code):

    try:
        duration = end_time - start_time
        con = f1.con
        # con = pymysql.connect(db_host, db_user, db_password,db_name)
        cursor = con.cursor()
        run_date = dt.datetime.now().strftime('%m-%d-%y')

        sql = ("Select * from " + db_output_table + " where list_id ='" + str(f1.list_id) +"' and process_date ='" + str(f1.run_date)+"'")
        df = pd.read_sql(sql, con)
        try:
            df['phone_number'] = df['phone_number'].apply(lambda x : digit_only(x))
        except Exception as e:
            print(e)

        output_path = f1.output_directory + str(f1.file_name)+'_'+str(run_date)+'.csv'
        number_of_record = len(df.index)
        df.drop(columns=['store_hash_id','list_id','search_term'],inplace=True)
        old_columns = list(df.columns)
        new_columns = [column.replace('_', ' ') for column in old_columns]
        columns = {}
        for col, new_col in zip(old_columns, new_columns):
            columns[col] = new_col
        df.rename(columns=columns, inplace=True)
        df.to_csv(output_path, index=False)
        print('csv generated',output_path)

        qa_output = perform_qa(f1.list_id,output_path)

        # get master_dict
        list_id = f1.list_id
        master_df = pd.read_csv(master_file)
        master_df_item = master_df[master_df['list_id'] == list_id]
        if master_df_item.empty:
            print('Please provide existing list id.')
            return False
        master_df_item.fillna(0, inplace=True)
        master_dict = master_df_item.iloc[0, :].to_dict()
        master_dict['cc_id'] = master_df['cc_id'][0]
        master_dict['data_count'] = len(df.index)
        master_dict['diff_between_agg-data_xbyte_count'] = int(
            (master_dict.get('agg_data_count', '')) - master_dict['data_count'])

        details_dict = dict()
        desired_key_from_master = (
            'list_id', 'file_name', 'website_url', 'developer_name', 'agg_data_count', 'xbyte_count', 'last_build_date')

        for key in master_dict.keys():
            if key in desired_key_from_master:
                if type(master_dict[key]) == np.float64:
                    val = int(master_dict[key])
                else:
                    val = master_dict[key]
                details_dict[key] = val

        details_dict['present_count'] = len(df.index)
        details_dict['diff_agg_data_present_count'] = int(
            (master_dict.get('agg_data_count', '')) - details_dict['present_count'])
        details_dict['diff_xbyte_present_count'] = int(
            (master_dict.get('xbyte_count', '')) - details_dict['present_count'])

        populate_qa_logs(details_dict, qa_output)


        if qa_output:
            # Populating count table
            old_columns = list(df.columns)
            new_columns = [column.replace(' ', '_') for column in old_columns]
            columns = {}
            for col, new_col in zip(old_columns, new_columns):
                columns[col] = new_col
            df.rename(columns=columns, inplace=True)
            # df.drop(columns=['list_id'], inplace=True)
            timestamp = datetime.now() - timedelta(hours=5, minutes=30)
            cnt_fields = ['list_id','website_url', 'total_count', 'start_time', 'end_time', 'duration',
                          'developer_name','timestamp']
            cnt_values = [f1.list_id,f1.website_url, number_of_record, str(start_time), str(end_time), str(duration),
                          str(f1.developer_name),timestamp]
            counts = df.count(axis=0).to_dict()
            for cnt in counts.items():
                try:
                    cnt_fields.append(cnt[0])
                    cnt_values.append(cnt[1])
                except Exception as e:
                    print(e)

            if elastic:
                es = Elasticsearch(['https://0344c0c954b148c4a412c7cc64c80f00.us-east-1.aws.found.io:9243'],
                                   http_auth=('elastic', 'vhr4byyTWPcS9TYUN4vqUiYi'))
                es.indices.create(index=elastic_count_table, ignore=400)
                e1 = dict(zip(cnt_fields, cnt_values))

                es.index(index=elastic_count_table, body=e1)

            cnt_fields = ','.join(cnt_fields)
            cnt_values = "','".join(map(str, cnt_values))

            try:
                insert_db = "insert into " + db_data_count_table + "( " + cnt_fields + " ) values ( '" + cnt_values + "' )"
                cursor.execute(insert_db)
                con.commit()
            except Exception as e:
                print('During data count table', e)

    except Exception as e:
        print(e)



