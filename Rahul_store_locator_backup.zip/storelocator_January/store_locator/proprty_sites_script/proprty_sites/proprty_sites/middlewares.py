# -*- coding: utf-8 -*-

# Define here the models for your spider middleware
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/spider-middleware.html

from scrapy import signals


class ProprtySitesSpiderMiddleware(object):
    # Not all methods need to be defined. If a method is not defined,
    # scrapy acts as if the spider middleware does not modify the
    # passed objects.

    @classmethod
    def from_crawler(cls, crawler):
        # This method is used by Scrapy to create your spiders.
        s = cls()
        crawler.signals.connect(s.spider_opened, signal=signals.spider_opened)
        return s

    def process_spider_input(self, response, spider):
        # Called for each response that goes through the spider
        # middleware and into the spider.

        # Should return None or raise an exception.
        return None

    def process_spider_output(self, response, result, spider):
        # Called with the results returned from the Spider, after
        # it has processed the response.

        # Must return an iterable of Request, dict or Item objects.
        for i in result:
            yield i

    def process_spider_exception(self, response, exception, spider):
        # Called when a spider or process_spider_input() method
        # (from other spider middleware) raises an exception.

        # Should return either None or an iterable of Request, dict
        # or Item objects.
        pass

    def process_start_requests(self, start_requests, spider):
        # Called with the start requests of the spider, and works
        # similarly to the process_spider_output() method, except
        # that it doesn’t have a response associated.

        # Must return only requests (not items).
        for r in start_requests:
            yield r

    def spider_opened(self, spider):
        spider.logger.info('Spider opened: %s' % spider.name)


class ProprtySitesDownloaderMiddleware(object):
    # Not all methods need to be defined. If a method is not defined,
    # scrapy acts as if the downloader middleware does not modify the
    # passed objects.

    @classmethod
    def from_crawler(cls, crawler):
        # This method is used by Scrapy to create your spiders.
        s = cls()
        crawler.signals.connect(s.spider_opened, signal=signals.spider_opened)
        return s

    def process_request(self, request, spider):
        # Called for each request that goes through the downloader
        # middleware.
        if request.meta.get('proxy_type'):
            if request.meta['proxy_type'] == "luminati_random":
                lum_proxy_services = {'lum-customer-xbyte-zone-zone_us-country-us': '0gi0pioy3oey',
                                      'lum-customer-xbyte-zone-zone_germany-country-de': '33mvqyt5wceu',
                                      'lum-customer-xbyte-zone-zone_uk-country-gb': 'bqa3iap0g4nr',
                                      'lum-customer-xbyte-zone-zone_france-country-fr': '1xkv97p3lmhq',
                                      'lum-customer-xbyte-zone-zone_spain-country-es': 'k4vt6e2v53v9',
                                      'lum-customer-xbyte-zone-zone_italy-country-it': 'et2g17oqw1nm',
                                      'lum-customer-xbyte-zone-zone_australia-country-au': 'rjbsuy1tzgco',
                                      'lum-customer-xbyte-zone-zone_japan-country-jp': '5v9sl7ilbppn',
                                      'lum-customer-xbyte-zone-zone_taiwan-country-tw': 'b2kqeq76cxi6',
                                      'lum-customer-xbyte-zone-zone_netherland-country-nl': 'zvptczvd2ahq',
                                      'lum-customer-xbyte-zone-zone_russia-country-ru': 'plpsy85v8pu6',
                                      'lum-customer-xbyte-zone-zone_india-country-in': 'w6zj0g4ikjy3',
                                      'lum-customer-xbyte-zone-zone_israel-country-il': 'gtuythxi5oc3'}
                username, password = random.choice(list(lum_proxy_services.items()))
                request.meta['proxy'] = "https://zproxy.lum-superproxy.io:22225"
                request.headers['Proxy-Authorization'] = basic_auth_header(username, password)
            elif request.meta['proxy_type'] == "luminati_us":
                username, password = 'lum-customer-xbyte-zone-zone_us-country-us', '0gi0pioy3oey'
                request.meta['proxy'] = "https://zproxy.lum-superproxy.io:22225"
                request.headers['Proxy-Authorization'] = basic_auth_header(username, password)
            elif request.meta['proxy_type'] == "storm":
                request.meta['proxy'] = "https://5.79.73.131:13200"
                request.headers['Proxy-Authorization'] = basic_auth_header('alpesh.khunt.xbyte@gmail.com', 'xbyte123')


        # if request.meta.get('proxy_type'):
        #     proxy = config.proxy_services.get(request.meta['proxy_type'])
        #     if proxy:
        #         request.meta['proxy'] = proxy.get('ip_address')
        #         request.headers['Proxy-Authorization'] = basic_auth_header(proxy.get('username'), proxy.get('password'))
        #     # if request.meta['proxy_type'] == "storm_proxy":
        #     #     request.meta['proxy'] = "https://5.79.73.131:13200"
        #     #     request.headers['Proxy-Authorization'] = basic_auth_header('alpesh.khunt.xbyte@gmail.com', 'xbyte123')
        #     # elif request.meta['proxy_type'] == "luminati":
        #     #     request.meta['proxy'] = "http://zproxy.lum-superproxy.io:22225"
        #     #     request.headers['Proxy-Authorization'] = basic_auth_header('lum-customer-xbyte-zone-zone_us-country-us', '0gi0pioy3oey  ')
        #
        #     else:
        #         pass

        return None

    def process_response(self, request, response, spider):
        # Called with the response returned from the downloader.

        # Must either;
        # - return a Response object
        # - return a Request object
        # - or raise IgnoreRequest
        return response

    def process_exception(self, request, exception, spider):
        # Called when a download handler or a process_request()
        # (from other downloader middleware) raises an exception.

        # Must either:
        # - return None: continue processing this exception
        # - return a Response object: stops process_exception() chain
        # - return a Request object: stops process_exception() chain
        pass

    def spider_opened(self, spider):
        spider.logger.info('Spider opened: %s' % spider.name)
