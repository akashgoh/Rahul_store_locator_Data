# This file contains information related to Database configuration.
import os
import platform

db_host = "localhost"
db_user = "root"
db_password = "xbyte"
db_name = "property_sites_storelocator"
db_zip_table = "zip_table"
db_log_table = "log_table"
db_master_table = "master_table"
db_output_table = "output_table_turning"
db_data_count_table = "data_count_table"
db_country_table = "country_table"
db_us_state_table = "us_state_table"
db_qa_log_table = "qa_log_table"
db_proxy_table= "proxy_table"
elastic = False
elastic_count_table = "agg_store_locator_count"

master_file_sheet_id = "1WuCniaa8TQRffZHwfS2zURyT02aJAX3-laXI4AMGkc0"
master_file_tab_id = "2011677482"
master_file = f'https://docs.google.com/spreadsheets/d/{master_file_sheet_id}/export?gid={master_file_tab_id}&format=csv'

length_file_tab_id = "1389275692"
length_file = f'https://docs.google.com/spreadsheets/d/{master_file_sheet_id}/export?gid={length_file_tab_id}&format=csv'


proxy_services = {}


# directory creation and path
sep_dir_name = 'proprty_sites_script'

spider_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),'spiders','')
current_directory = str((os.path.dirname(os.path.abspath(__file__)))).split(sep_dir_name)[0]

html_link_directory = os.path.join(current_directory,'html','html_link_1','')
html_data_directory = os.path.join(current_directory,'html','html_data_1','')
output_directory = os.path.join(current_directory,'output','')
static_directory = os.path.join(current_directory,'static','')
compare_directory = os.path.join(current_directory,'compare','')

for directory in [html_link_directory, html_data_directory, output_directory, static_directory, compare_directory] :
    if not os.path.exists(directory):
        os.makedirs(directory)

class config():
    db_host = "localhost"
    db_user = "root"
    db_password = "xbyte"
    db_name = "property_sites_storelocator"
    # db_zip_table = "zip_table"
    # db_log_table = "log_table"
    db_master_table = "master_table"
    db_country_table = "country_table"
    db_us_state_table = "us_state_table"
    db_proxy_table= "proxy_table"
    elastic = False
    elastic_count_table = "agg_store_locator_count"

    dir_path = os.path.dirname(os.path.realpath(__file__))
    dir_path = os.path.join(dir_path,'spiders','')

    master_file_sheet_id = "1WuCniaa8TQRffZHwfS2zURyT02aJAX3-laXI4AMGkc0"
    master_file_tab_id = "2011677482"
    master_file = f'https://docs.google.com/spreadsheets/d/{master_file_sheet_id}/export?gid={master_file_tab_id}&format=csv'

    length_file_tab_id = "1389275692"
    length_file = f'https://docs.google.com/spreadsheets/d/{master_file_sheet_id}/export?gid={length_file_tab_id}&format=csv'

    proxy_services = {}
    # directory creation and path
    sep_dir_name = 'proprty_sites_script'

    spider_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'spiders', '')
    current_directory = str((os.path.dirname(os.path.abspath(__file__)))).split(sep_dir_name)[0]

    html_link_directory = os.path.join(current_directory, 'html', 'html_link_1', '')
    html_data_directory = os.path.join(current_directory, 'html', 'html_data_1', '')
    output_directory = os.path.join(current_directory, 'output', '')
    static_directory = os.path.join(current_directory, 'static', '')
    compare_directory = os.path.join(current_directory, 'compare', '')

    for directory in [html_link_directory, html_data_directory, output_directory, static_directory, compare_directory]:
        if not os.path.exists(directory):
            os.makedirs(directory)